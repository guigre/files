<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Campanhas
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->

              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">
				  <div class="box-body">
                    <div class="form-group">
                      <label for="idCampanha" class="col-sm-2 control-label">ID<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="idCampanha" placeholder="" disabled="disabled">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="descricao" class="col-sm-2 control-label">DESCRI&Ccedil;&Atilde;O<font color="red">*</font></label>
                      <div class="col-xs-6">
                        <input type="text" class="form-control" id="descricao" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="dataInicio" class="col-sm-2 control-label">DATA INCIAL<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="dataInicio" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="dataFim" class="col-sm-2 control-label">DATA FINAL<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="dataFim" placeholder="">
                      </div>
                    </div>
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
				    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaCamanhas">

                </div><!-- /.box-body -->
              </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


<script>

	function novo(){

		buscaProximoID();
		$('#descricao').val('');
		$('#acao').val('cadastrar');
		$('#descricao').focus();

	}

	function salvar(){

		var idCampanha = $('#idPergunta').val();
		var descricao  = $('#descricao').val();
    var dataInicio = $('#dataInicio').val();
    var dataFim    = $('#dataFim').val();
		var acao       = $('#acao').val();

		if(descricao == ''){
			exibeErro('<p>Campo <b>(DESCRI&Ccedil;&Atilde;O)</b> Obrigatório!</p>');
			$('#descricao').focus();
		}else if(dataInicio == ''){
      exibeErro('<p>Campo <b>(DATA INICIO</b> Obrigatório!</p>');
			$('#dataInicio').focus();
    }else if(dataFim == '' ){
      exibeErro('<p>Campo <b>(DATA FIM)</b> Obrigatório!</p>');
			$('#dataFim').focus();
    }else{
			$.ajax({
				url: 'ajax/campanha.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'idCampanha' : idCampanha,
					     'descricao'  : descricao,
               'dataInicio' : dataInicio,
               'dataFim'    : dataFim,
					     'acao'       : acao
				},
				beforeSend: function() {

				},
				complete: function() {

				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}

				}
			});

		}

	}

	function atualizaTabela(){
		$.ajax({
			url: 'ajax/campanha.php?acao=listaCampanhas',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {

			},
			complete: function() {

			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){

						$('#divTabelaCamanhas').html(result.tabela);

						$("#tabelaCampanhas").DataTable();

					}else{

						$('#divTabelaCamanhas').html('<p>Sem resultados...');

					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}

			}
		});

	}

	function editar(id){

		$.ajax({
			url: 'ajax/campanha.php?acao=buscaCampanha',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'idCampanha' : id
			},
			beforeSend: function() {

			},
			complete: function() {

			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){

						$('#idCampanha').val(result.idCampanha);
		        $('#descricao').val(result.descricao);
            $('#dataInicio').val(result.dataInicio);
            $('#dataFim').val(result.dataFim);
		        $('#acao').val('atualizar');

						$('#descricao').focus();

					}else{


					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}

			}
		});

	}

	function buscaProximoID(){

		$.ajax({
			url: 'ajax/campanha.php?acao=buscaProximoID',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {

			},
			complete: function() {

			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);

				$('#idCampanha').val(result.idCampanha);

			}
		});

	}

	buscaProximoID();

	atualizaTabela();

	$('#descricao').focus();

	$('#descricao').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});

  $('#dataInicio').inputmask('dd/mm/yyyy',{"placeholder": "","yearrange":{minyear: 1600, maxyear: 9999}});
	$('#dataFim').inputmask('dd/mm/yyyy',{"placeholder": "","yearrange":{minyear: 1600, maxyear: 9999}});	  

</script>

<?php include("inc/rodape.php"); ?>
