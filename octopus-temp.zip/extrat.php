<?php
ini_set('display_errors','Off');

$path = "C:/xampp/htdocs/adminti/dados_mesclados.csv";

$ponteiro = fopen($path,"r");

$codigo = "";

$contador = 0;

$tipoIdade = array();
$pressao = array();
$glicose = array();
$hipertrigliceridemia = array();

while (!feof ($ponteiro)){

	$linha = fgets($ponteiro,4096);	
		
	$linha = str_replace('"','',$linha);

	$explode = explode(";",$linha);
	
	if($explode[0] >= 25 AND $explode[0] <= 30){
	
		print "NAO_PROGRAMA<br>";
	
	}else if($explode[0] >= 31 AND $explode[0] <= 38){
	
		print "PROGRAMA<br>";
	
	} else if($explode[0] >= 40 AND $explode[0] <= 45){
	
		print "PROGRAMA<br>";
	
	} else if($explode[0] >= 46 AND $explode[0] <= 53){
	
		print "NAO_PROGRAMA<br>";
	
	} else if($explode[0] >= 55 AND $explode[0] <= 65){
	
		print "PROGRAMA<br>";
	
	} else if($explode[0] >= 66 AND $explode[0] <= 70){
	
		print "PROGRAMA<br>";
	
	} else{
		
		print "PROGRAMA<br>";
		
	}
	
	/*if($explode[0] <= 12){
		array_push($tipoIdade,"CRIANCA");	
	}
	if($explode[0] > 12 AND $explode[0] <= 59){
		array_push($tipoIdade,"ADULTO");		
	}	
	if($explode[0] > 59){
		array_push($tipoIdade,"IDOSO");		
	}
	
	if(str_replace(",",".",$explode[5]) >= 140){
		array_push($pressao,"HIPERTENSO");
	}else{
		array_push($pressao,"NAO_HIPERTENSO");
	}
	
	if(str_replace(",",".",$explode[9]) >= 100){
		array_push($glicose,"DIABETICO");
	}else{
		array_push($glicose,"NAO_DIABETICO");
	}	
	
	if(str_replace(",",".",$explode[7]) >= 150){
		array_push($hipertrigliceridemia,"HIPERTRIGLICERIDEMIA");
	}else{
		array_push($hipertrigliceridemia,"NAO_HIPERTRIGLICERIDEMIA");
	}*/	
	
	/*if($explode[2] == "LAJEADO" or $explode[2] == "ENCANTADO" or $explode[2] == "ARROIO DO MEIO" or $explode[2] == "ESTRELA" or $explode[2] == "CRUZEIRO DO SUL" or $explode[2] == "BOM RETIRO DO SUL"){
		
		print "VALE_TAQUARI<br>";
		
	}else{
		
		print "VALE_RIO_PARDO<br>";
		
	}*/
	
	
	
	
}

	foreach($hipertrigliceridemia as $dados){
		
		print $dados."<br>";
		
	}



?>