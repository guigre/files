<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Indicadores
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="codigoCadastro" class="col-sm-2 control-label">Código</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="codigoCadastro" placeholder="" disabled>
                      </div>
                    </div>				  
                    <div class="form-group">
                      <label for="indicadorCadastro" class="col-sm-2 control-label">Indicador<font color="red">*</font></label>
                      <div class="col-xs-8">
                        <input type="text" class="form-control" id="indicadorCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="classificacaoCadastro" class="col-sm-2 control-label">Classificação<font color="red">*</font></label>
					  <div class="col-xs-4">
                      <select class="form-control" id="classificacaoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Gerais de TI'>Gerais de TI</option>
						<option value='N3-Redes'>N3-Redes</option>
						<option value='Processo de Desenvolvimento'>Processo de Desenvolvimento</option>
						<option value='Processo de Incidentes'>Processo de Incidentes</option>
						<option value='Processo de Mudancas'>Processo de Mudancas</option>
						<option value='Processo de Projetos'>Processo de Projetos</option>
						<option value='Processo de Requisicoes'>Processo de Requisicoes</option>
						<option value='Resp. Processo de Desenvovimento'>Resp. Processo de Desenvovimento</option>
						<option value='Resp. Processo de Mudancas'>Resp. Processo de Mudancas</option>
						<option value='Resp. Processo de Projetos'>Resp. Processo de Projetos</option>
						<option value='Resp. Processo Incidentes e Req.'>Resp. Processo Incidentes e Req.</option>
						<option value='Telefonia'>Telefonia</option>
                      </select>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="grupoCadastro" class="col-sm-2 control-label">Grupo<font color="red">*</font></label>
					  <div class="col-xs-4">
                      <select class="form-control" id="grupoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Indicadores de Processos de TI'>Indicadores de Processos de TI</option>
						<option value='Indicadores dos responsaveis pelos processos de TI'>Indicadores dos responsaveis pelos processos de TI</option>
						<option value='Indicadores estrategicos de TI'>Indicadores estrategicos de TI</option>
						<option value='Indicadores gerais de TI'>Indicadores gerais de TI</option>
						<option value='Indicadores PPR'>Indicadores PPR</option>
                      </select>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="periodCadastro" class="col-sm-2 control-label">Periodicidade<font color="red">*</font></label>
					  <div class="col-xs-4">
                      <select class="form-control" id="periodCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Semanal'>Semanal</option>
						<option value='Mensal'>Mensal</option>
						<option value='Bimestral'>Bimestral</option>
						<option value='Anual'>Anual</option>
                      </select>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="responsavelCadastro" class="col-sm-2 control-label">Responsável<font color="red">*</font></label>
					  <div class="col-xs-4">
					  <div id="divResponsavel">

					  </div>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="tipoCadastro" class="col-sm-2 control-label">Tipo<font color="red">*</font></label>
					  <div class="col-xs-4">
                      <select class="form-control" id="tipoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Apenas Resultado'>Apenas Resultado</option>
						<option value='Resultado e 2 Detalhes'>Resultado e 2 Detalhes</option>
						<option value='Resultado e Detalhe'>Resultado e Detalhe</option>
						<option value='Resultado e Meta'>Resultado e Meta</option>
						<option value='Resultado, Meta e Detalhe'>Resultado, Meta e Detalhe</option>
						<option value='Resultado, Meta e 2 Detalhes'>Resultado, Meta e 2 Detalhes</option>
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="formaCalculoCadastro" class="col-sm-2 control-label">Forma Cálculo</label>
                      <div class="col-xs-8">
                        <input type="text" class="form-control" id="formaCalculoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="orgiemCadastro" class="col-sm-2 control-label">Origem</label>
                      <div class="col-xs-8">
                        <input type="text" class="form-control" id="origemCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="observacaoCadastro" class="col-sm-2 control-label">Observação</label>
                      <div class="col-xs-8">
                        <input type="text" class="form-control" id="observacaoCadastro" placeholder="">
                      </div>
                    </div>					
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaIndicadores">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#codigoCadastro').val('');
		$('#indicadorCadastro').val('');
		$('#classificacaoCadastro').val('');
		$('#grupoCadastro').val('');
		$('#periodCadastro').val('');
		$('#responsavelCadastro').val('');
		$('#tipoCadastro').val('');
		$('#formaCalculoCadastro').val('');
		$('#origemCadastro').val('');
		$('#observacaoCadastro').val('');
	
		$('#indicadorCadastro').focus();
		
	}
	
	function montaResponsavel(){
		
		$.ajax({
			url: 'ajax/indicador.php?acao=montaResponsavel',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divResponsavel').html(result.select);
						
					}else{
										
						$('#divReponsavel').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}

	function salvar(){
		
		var codigoCadastro        = $('#codigoCadastro').val();
		var indicadorCadastro     = $('#indicadorCadastro').val();
		var classificacaoCadastro = $('#classificacaoCadastro').val();
		var grupoCadastro         = $('#grupoCadastro').val();
		var periodCadastro        = $('#periodCadastro').val();
		var responsavelCadastro   = $('#responsavelCadastro').val();
		var tipoCadastro          = $('#tipoCadastro').val();
		var formaCalculoCadastro  = $('#formaCalculoCadastro').val();
		var origemCadastro        = $('#origemCadastro').val();
		var observacaoCadastro    = $('#observacaoCadastro').val();
		
		if(indicadorCadastro == ''){
			exibeErro('<p>Campo <b>(Indicador)</b> Obrigatório!</p>');
			$('#indicadorCadastro').focus();
		}else if(classificacaoCadastro == ''){
			exibeErro('<p>Campo <b>(Classificação)</b> Obrigatório!</p>');
			$('#classificacaoCadastro').focus();
		}else if(grupoCadastro == ''){
			exibeErro('<p>Campo <b>(Grupo)</b> Obrigatório!</p>');
			$('#grupoCadastro').focus();
		}else if(periodCadastro == ''){
			exibeErro('<p>Campo <b>(Periodicidade)</b> Obrigatório!</p>');
			$('#periodCadastro').focus();
		}else if(responsavelCadastro == ''){
			exibeErro('<p>Campo <b>(Responsável)</b> Obrigatório!</p>');
			$('#responsavelCadastro').focus();
		}else if(tipoCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo)</b> Obrigatório!</p>');
			$('#tipoCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/indicador.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					   'codigoCadastro'        : codigoCadastro,       
					   'indicadorCadastro'     : indicadorCadastro,    
					   'classificacaoCadastro' : classificacaoCadastro,
					   'grupoCadastro'         : grupoCadastro,        
					   'periodCadastro'        : periodCadastro,       
					   'responsavelCadastro'   : responsavelCadastro,  
					   'tipoCadastro'          : tipoCadastro,         
					   'formaCalculoCadastro'  : formaCalculoCadastro, 
					   'origemCadastro'        : origemCadastro,       
					   'observacaoCadastro'    : observacaoCadastro
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){		

		$.ajax({
			url: 'ajax/indicador.php?acao=listaIndicadores',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaIndicadores').html(result.tabela);
						
						$("#tabelaIndicadores").DataTable();
						
					}else{
										
						$('#divTabelaIndicadores').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(codigo){
		
		$.ajax({
			url: 'ajax/indicador.php?acao=buscaIndicador',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'codigo' : codigo				
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#codigoCadastro').val(result.codigo);
						$('#indicadorCadastro').val(result.indicador);	
						$('#classificacaoCadastro').val(result.classificacao);	
						$('#grupoCadastro').val(result.grupo);	
						$('#periodCadastro').val(result.periodicidade);	
						$('#responsavelCadastro').val(result.responsavel);	
						$('#tipoCadastro').val(result.tipo);	
						$('#formaCalculoCadastro').val(result.forma_calculo);	
						$('#origemCadastro').val(result.origem);	
						$('#observacaoCadastro').val(result.observacao);	
						
						$('#indicadorCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#codigoCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir o indicador?");		
		}else{
			exibeErro('Você deve selecionar um indicador primeiro.');
		}
	}
	
	function excluir(){		
		
		if($('#codigoCadastro').val() != ''){
			
			var codigo = $('#codigoCadastro').val();
			
			$.ajax({
				url: 'ajax/indicador.php?acao=desativaIndicador',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					'codigo' : codigo				
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar um indicador primeiro.');			
		}		
		
	}
	
	atualizaTabela();
	montaResponsavel();
	
	$('#usuarioCadastro').focus();
	
	$('#statusCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

