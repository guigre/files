<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Planos
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">	
				  <input type="hidden" id="cduserid" value="<?php print $_SESSION['usuario']; ?>">
                  <div class="box-body">			  
                    <div class="form-group">
                      <label for="modalidadeCadastro" class="col-sm-2 control-label">Modalidade<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="modalidadeCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="planoCadastro" class="col-sm-2 control-label">Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="planoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tipoPlanoCadastro" class="col-sm-2 control-label">Tipo Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="tipoPlanoCadastro" placeholder="">
                      </div>
                    </div>	
                    <div class="form-group">
                      <label for="inicioCadastro" class="col-sm-2 control-label">Data Inicial<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="inicioCadastro" placeholder="">
                      </div>
                    </div>						
                    <div class="form-group">
                      <label for="fimCadastro" class="col-sm-2 control-label">Data Final<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="fimCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="abrangenciaCadastro" class="col-sm-2 control-label">Abrangência<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="abrangenciaCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Regional'>Regional</option>
						<option value='Nacional'>Nacional</option>						
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="tipoPessoaCadastro" class="col-sm-2 control-label">Tipo Pessoa<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="tipoPessoaCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='F'>Física</option>
						<option value='J'>Jurídica</option>						
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="participacaoCadastro" class="col-sm-2 control-label">Taxa de Participação<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="participacaoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='S'>Sim</option>
						<option value='N'>Não</option>						
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="simulaCadastro" class="col-sm-2 control-label">Simula APP<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="simulaCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='S'>Sim</option>
						<option value='N'>Não</option>						
                      </select>
					  </div>
                    </div>				
                    <div class="form-group">
                      <label for="contratacaoCadastro" class="col-sm-2 control-label">Tipo Contratanção<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="contratacaoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Individual/familiar'>Individual/familiar</option>
                      </select>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="produtoCadastro" class="col-sm-2 control-label">Produto<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="produtoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Assistencial'>Assistencial</option>
						<option value='Universitario'>Universitário</option>
						<option value='Unimed Pleno'>Unimed Pleno</option>
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="acomodacaoCadastro" class="col-sm-2 control-label">Acomodação<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="acomodacaoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Privativo'>Privativo</option>
						<option value='Semi-Privativo'>Semi-Privativo</option>
						<option value='N/A'>N/A</option>
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="formaPagamentoCadastro" class="col-sm-2 control-label">Forma Pagamento<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="formaPagamentoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Pre-Pagamento'>Pre-Pagamento</option>
                      </select>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="registroCadastro" class="col-sm-2 control-label">Registro<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="registroCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="segmentacaoCadastro" class="col-sm-2 control-label">Segmentação<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="segmentacaoCadastro">
						<option value=''>:: Selecione ::</option>
						<option value='Ambulatorial'>Ambulatorial</option>
						<option value='Hospitalar'>Hospitalar</option>
						<option value='Ambulatorial / Hospitalar'>Ambulatorial / Hospitalar</option>
						<option value='Referencia'>Referencia</option>
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="descricaoPlanoCadastro" class="col-sm-2 control-label">Descrição Plano<font color="red">*</font></label>
                      <div class="col-xs-4">
                        <input type="text" class="form-control" id="descricaoPlanoCadastro" placeholder="">
                      </div>
                    </div>					
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Findar Plano</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaPlanos">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#modalidadeCadastro').val('');
		$('#planoCadastro').val('');
		$('#tipoPlanoCadastro').val('');
		$('#inicioCadastro').val('');
		$('#fimCadastro').val('');
		$('#abrangenciaCadastro').val('');
		$('#tipoPessoaCadastro').val('');
		$('#participacaoCadastro').val('');
		$('#simulaCadastro').val('');
		$('#contratacaoCadastro').val('');
		$('#produtoCadastro').val('');
		$('#acomodacaoCadastro').val('');
		$('#formaPagamentoCadastro').val('');
		$('#registroCadastro').val('');
		$('#segmentacaoCadastro').val('');
		$('#descricaoPlanoCadastro').val('');
		$('#acao').val('cadastra');
		
		$('#modalidadeCadastro').prop("disabled",false);
		$('#planoCadastro').prop("disabled",false);
		$('#tipoPlanoCadastro').prop("disabled",false);
		$('#inicioCadastro').prop("disabled",false);
		$('#abrangenciaCadastro').prop("disabled",false);
		$('#tipoPessoaCadastro').prop("disabled",false);
		$('#participacaoCadastro').prop("disabled",false);
		$('#simulaCadastro').prop("disabled",false);
		$('#contratacaoCadastro').prop("disabled",false);
		$('#produtoCadastro').prop("disabled",false);
		$('#acomodacaoCadastro').prop("disabled",false);
		$('#formaPagamentoCadastro').prop("disabled",false);
		$('#registroCadastro').prop("disabled",false);
		$('#segmentacaoCadastro').prop("disabled",false);
		$('#descricaoPlanoCadastro').prop("disabled",false);		
	
		$('#modalidadeCadastro').focus();
		
	}

	function salvar(){
		
		var modalidadeCadastro     = $('#modalidadeCadastro').val();
		var planoCadastro          = $('#planoCadastro').val();
		var tipoPlanoCadastro      = $('#tipoPlanoCadastro').val();
		var inicioCadastro         = $('#inicioCadastro').val();
		var fimCadastro            = $('#fimCadastro').val();
		var abrangenciaCadastro    = $('#abrangenciaCadastro').val();
		var tipoPessoaCadastro     = $('#tipoPessoaCadastro').val();
		var participacaoCadastro   = $('#participacaoCadastro').val();
		var simulaCadastro         = $('#simulaCadastro').val();
		var contratacaoCadastro    = $('#contratacaoCadastro').val();
		var produtoCadastro        = $('#produtoCadastro').val();
		var acomodacaoCadastro     = $('#acomodacaoCadastro').val();
		var formaPagamentoCadastro = $('#formaPagamentoCadastro').val();
		var registroCadastro       = $('#registroCadastro').val();
		var segmentacaoCadastro    = $('#segmentacaoCadastro').val();
		var descricaoPlanoCadastro = $('#descricaoPlanoCadastro').val();
		var acao   	    		   = $('#acao').val();
		var cduserid			   = $('#cduserid').val();
		
		if(modalidadeCadastro == ''){
			exibeErro('<p>Campo <b>(Modalidade)</b> Obrigatório!</p>');
			$('#modalidadeCadastro').focus();
		}else if(planoCadastro == ''){
			exibeErro('<p>Campo <b>(Plano)</b> Obrigatório!</p>');
			$('#planoCadastro').focus();
		}else if(tipoPlanoCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo Plano)</b> Obrigatório!</p>');
			$('#tipoPlanoCadastro').focus();
		}else if(inicioCadastro == ''){
			exibeErro('<p>Campo <b>(Data Inicial)</b> Obrigatório!</p>');
			$('#inicioCadastro').focus();
		}else if(fimCadastro == ''){
			exibeErro('<p>Campo <b>(Data Final)</b> Obrigatório!</p>');
			$('#fimCadastro').focus();
		}else if(abrangenciaCadastro == ''){
			exibeErro('<p>Campo <b>(Abrangência)</b> Obrigatório!</p>');
			$('#abrangenciaCadastro').focus();
		}else if(tipoPessoaCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo Pessoa)</b> Obrigatório!</p>');
			$('#tipoPessoaCadastro').focus();
		}else if(participacaoCadastro == ''){
			exibeErro('<p>Campo <b>(Taxa Participação)</b> Obrigatório!</p>');
			$('#participacaoCadastro').focus();
		}else if(simulaCadastro == ''){
			exibeErro('<p>Campo <b>(SimulaAPP)</b> Obrigatório!</p>');
			$('#simulaCadastro').focus();
		}else if(contratacaoCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo Contratanção)</b> Obrigatório!</p>');
			$('#contratacaoCadastro').focus();
		}else if(produtoCadastro == ''){
			exibeErro('<p>Campo <b>(Produto)</b> Obrigatório!</p>');
			$('#produtoCadastro').focus();
		}else if(acomodacaoCadastro == ''){
			exibeErro('<p>Campo <b>(Acomodação)</b> Obrigatório!</p>');
			$('#abrangenciaCadastro').focus();
		}else if(formaPagamentoCadastro == ''){
			exibeErro('<p>Campo <b>(Forma Pagamento)</b> Obrigatório!</p>');
			$('#formaPagamentoCadastro').focus();
		}else if(registroCadastro == ''){
			exibeErro('<p>Campo <b>(Registro)</b> Obrigatório!</p>');
			$('#registroCadastro').focus();
		}else if(segmentacaoCadastro == ''){
			exibeErro('<p>Campo <b>(Segmentação)</b> Obrigatório!</p>');
			$('#segmentacaoCadastro').focus();
		}else if(descricaoPlanoCadastro == ''){
			exibeErro('<p>Campo <b>(Descrição Plano)</b> Obrigatório!</p>');
			$('#descricaoPlanoCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/plano.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'modalidadeCadastro'     : modalidadeCadastro,        
					   'planoCadastro'          : planoCadastro,         
					   'tipoPlanoCadastro'      : tipoPlanoCadastro,     
					   'inicioCadastro'         : inicioCadastro,        
					   'fimCadastro'            : fimCadastro,           
					   'abrangenciaCadastro'    : abrangenciaCadastro,   
					   'tipoPessoaCadastro'     : tipoPessoaCadastro,     
					   'participacaoCadastro'   : participacaoCadastro,  
					   'simulaCadastro'         : simulaCadastro,
					   'cduserid'		        : cduserid,
					   'contratacaoCadastro'    : contratacaoCadastro,   
					   'produtoCadastro'        : produtoCadastro,       
					   'acomodacaoCadastro'     : acomodacaoCadastro,    
					   'formaPagamentoCadastro' : formaPagamentoCadastro,
					   'registroCadastro'       : registroCadastro,      
					   'segmentacaoCadastro'    : segmentacaoCadastro,   
				       'descricaoPlanoCadastro' : descricaoPlanoCadastro,
					   'acao'    				: acao
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){	
		$.ajax({
			url: 'ajax/plano.php?acao=listaPlanos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaPlanos').html(result.tabela);
						
						$("#tabelaPlanos").DataTable();
						
					}else{
										
						$('#divTabelaPlanos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(modalidade,plano,tipoPlano,dataInicio){
		
		console.log(modalidade);
		console.log(plano);
		console.log(tipoPlano);
		console.log(dataInicio);	
		
		$.ajax({
			url: 'ajax/plano.php?acao=buscaPlano',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'modalidade' : modalidade,
			    'plano'		 : plano,
				'tipoPlano'	 : tipoPlano,
				'dataInicio' : dataInicio
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#modalidadeCadastro').val(result.cdmodalidade);
		                $('#planoCadastro').val(result.cdplano);
		                $('#tipoPlanoCadastro').val(result.cdtipoplano);
		                $('#inicioCadastro').val(result.dtiniciocomerc);
		                $('#fimCadastro').val(result.dtfimcomerc);
		                $('#abrangenciaCadastro').val(result.dsareageografica);
		                $('#tipoPessoaCadastro').val(result.tipopessoa);
		                $('#participacaoCadastro').val(result.lgparticipacao);
		                $('#simulaCadastro').val(result.lgsimulaapp);
		                $('#contratacaoCadastro').val(result.dstipocontratacao);
		                $('#produtoCadastro').val(result.dsproduto);
		                $('#acomodacaoCadastro').val(result.dsacomodacao);
		                $('#formaPagamentoCadastro').val(result.dsformapagto);
		                $('#registroCadastro').val(result.cdregistro);
		                $('#segmentacaoCadastro').val(result.dssegmentacao);
		                $('#descricaoPlanoCadastro').val(result.dsplano);
		                $('#acao').val('atualizar');
						
						$('#modalidadeCadastro').prop("disabled",true);
						$('#planoCadastro').prop("disabled",true);
						$('#tipoPlanoCadastro').prop("disabled",true);
						$('#inicioCadastro').prop("disabled",true);
						
						$('#fimCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#inicioCadastro').val() != ''){
			findarPlano("Você realmente deseja findar o plano? Caso sim, informe a data final da vigência.");		
		}else{
			exibeErro('Você deve selecionar um plano primeiro.');
		}
	}
	
	function findar(){
		
		$('#modalidadeCadastro').prop("disabled",true);
		$('#planoCadastro').prop("disabled",true);
		$('#tipoPlanoCadastro').prop("disabled",true);
		$('#inicioCadastro').prop("disabled",true);
		$('#abrangenciaCadastro').prop("disabled",true);
		$('#tipoPessoaCadastro').prop("disabled",true);
		$('#participacaoCadastro').prop("disabled",true);
		$('#simulaCadastro').prop("disabled",true);
		$('#contratacaoCadastro').prop("disabled",true);
		$('#produtoCadastro').prop("disabled",true);
		$('#acomodacaoCadastro').prop("disabled",true);
		$('#formaPagamentoCadastro').prop("disabled",true);
		$('#registroCadastro').prop("disabled",true);
		$('#segmentacaoCadastro').prop("disabled",true);
		$('#descricaoPlanoCadastro').prop("disabled",true);
		$('#acao').val('findar');
		
		$('#fimCadastro').focus();	
		
	}
		
	atualizaTabela();
	
	$('#modalidadeCadastro').focus();
	
	$('#inicioCadastro').inputmask('dd/mm/yyyy',{"placeholder": "","yearrange":{minyear: 1600, maxyear: 9999}});		
	$('#fimCadastro').inputmask('dd/mm/yyyy',{"placeholder": "","yearrange":{minyear: 1600, maxyear: 9999}});		
	
	$('#descricaoPlanoCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

