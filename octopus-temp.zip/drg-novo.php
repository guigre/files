<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-file-text"></i> DRG - Diagnosis Related Groups
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->

              <!-- Horizontal Form -->
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Filtro para extra&ccedil;&atilde;o dos dados
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
                    <div class="row">
                      <label for="anoConsulta" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
                      <div class="col-xs-1" style="padding-bottom:15px !important; ">

					  		<select id="anoIni" class="form-control">
							  <option value="2016">2016</option>
							  <option value="2017">2017</option>
							  <option value="2018">2018</option>
							  <option value="2019">2019</option>
							  <option value="2020">2020</option>
							</select>

                      </div>
                      <div class="col-xs-1" style="padding-bottom:15px !important; ">

					  		<select id="anoFim" class="form-control">
							  <option value="2016">2016</option>
							  <option value="2017">2017</option>
							  <option value="2018">2018</option>
							  <option value="2019">2019</option>
							  <option value="2020">2020</option>
							</select>

                      </div>
                    </div>
                    <div class="row">
                      <label for="anoConsulta" class="col-sm-2 control-label">Per&iacute;odo<font color="red">*</font></label>
                      <div class="col-xs-1" style="padding-bottom:15px !important;">

					  		<select id="periodoIni" class="form-control">
							  <option value="11">011</option>
							  <option value="12">012</option>
							  <option value="21">021</option>
							  <option value="22">022</option>
							  <option value="31">031</option>
							  <option value="32">032</option>
							  <option value="41">041</option>
							  <option value="42">042</option>
							  <option value="51">051</option>
							  <option value="52">052</option>
							  <option value="61">061</option>
							  <option value="62">062</option>
							  <option value="71">071</option>
							  <option value="72">072</option>
							  <option value="81">081</option>
							  <option value="82">082</option>
							  <option value="91">091</option>
							  <option value="92">092</option>
							  <option value="101">101</option>
							  <option value="102">102</option>
							  <option value="111">111</option>
							  <option value="112">112</option>
							  <option value="121">121</option>
							  <option value="122">122</option>
							</select>

                      </div>
                      <div class="col-xs-1" style="padding-bottom:15px !important;" >

					  		<select id="periodoFim" class="form-control">
							  <option value="11">011</option>
							  <option value="12">012</option>
							  <option value="21">021</option>
							  <option value="22">022</option>
							  <option value="31">031</option>
							  <option value="32">032</option>
							  <option value="41">041</option>
							  <option value="42">042</option>
							  <option value="51">051</option>
							  <option value="52">052</option>
							  <option value="61">061</option>
							  <option value="62">062</option>
							  <option value="71">071</option>
							  <option value="72">072</option>
							  <option value="81">081</option>
							  <option value="82">082</option>
							  <option value="91">091</option>
							  <option value="92">092</option>
							  <option value="101">101</option>
							  <option value="102">102</option>
							  <option value="111">111</option>
							  <option value="112">112</option>
							  <option value="121">121</option>
							  <option value="122">122</option>
							</select>

                      </div>

                    </div>
                    <div class="row">
                      <label for="hospital" class="col-sm-2 control-label">Hospital<font color="red">*</font></label>
                      <div class="col-xs-2">
					  		<select id="hospital" class="form-control">
							  <option value="0">:: Selecione ::</option>
							  <option value="264">:: Hospital Bruno Born ::</option>
							  <option value="261">:: Hospital Estrela ::</option>
							  <option value="262">:: Hospital Ana Nery ::</option>
							  <option value="263">:: Hospital Santa Cruz ::</option>
							</select>
                      </div>
                    </div>
                  </div><!-- /.form group -->
				  <div class="box-body">
					<div class="row">
					<label for="acao" class="col-sm-2 control-label">A&ccedil;&atilde;o<font color="red">*</font></label>
                      <div class="col-xs-2">
					  		<select id="acao" class="form-control">
							  <option value="INCLUIR">:: INCLUIR ::</option>
							  <option value="SUBSTITUIR">:: SUBSTITUIR ::</option>
							</select>
                      </div>
					</div>
				  </div>
				  <div class="box-body">
					<div class="row">
					<label for="senha" class="col-sm-2 control-label">Senha</label>
					<div class="col-xs-2">
                        <input type="text" class="form-control" id="senha" placeholder="">
                      </div>
					</div>
				  </div>				  				  
				<div class="box-body">
					<div class="row">
						<label for="arquivo" class="col-sm-2 control-label"></label>
							<div class="col-md-3">
							<div class="box box-primary box-solid">
								<div class="box-header with-border">
								<h3 class="box-title">Arquivo para corre&ccedil;&otilde;es de senhas DRG</h3>
								</div><!-- /.box-header -->
								<div class="box-body">
									<input type="file" id="fileupload" name="files[]">
								</div><!-- /.box-body -->
								<div id="progress" class="progress">
									<div class="progress-bar progress-bar-success"></div>
								</div>
								<div id="files"></div>
								<input type="hidden" id="arquivoEntrada">
							</div><!-- /.box -->
							</div><!-- /.col -->
					</div>

				</div>

                    <div class="box-footer">
						<!--<button type="button" class="btn btn-primary" onclick="javascript:void(extrair())" id="btnExtrair">Extrair Dados</button>&nbsp;&nbsp;-->
						<button type="button" class="btn btn-warning" onclick="javascript:void(gerarCSV())" id="btnArquivo">Gerar Senhas em Branco</button>&nbsp;&nbsp;
						<button type="button" class="btn btn-success" onclick="javascript:void(importar())" id="btnImportar">Enviar para o DRG</button>&nbsp;&nbsp;
						<div id="divImport"></div>
                    </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Resultado do Envio</h3>
                </div>
                <div class="box-body" id="divDados">

                </div>
              </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->


<script>

	function commaSeparateNumber(val) {
		while (/(\d+)(\d{3})/.test(val.toString())) {
			val = val.toString().replace(/(\d+)(\d{3})/, '$1' + '.' + '$2');
		}
		return val;
	}

	function extrair(){

		var anoIni     = $('#anoIni').val();
		var anoFim     = $('#anoFim').val();
		var periodoIni = $('#periodoIni').val();
		var periodoFim = $('#periodoFim').val();
		var hospital   = $('#hospital').val();

		if(hospital !== '0'){

			$.ajax({
				url: 'ajax/drg.php?acao=solicitaDadosCustosPaciente',
				type: 'POST',
				timeout: 15000000,
				dataType: 'json',
				data: {
						'anoIni'     : anoIni,
						'anoFim'     : anoFim,
						'periodoIni' : periodoIni,
						'periodoFim' : periodoFim,
						'hospital'   : hospital

				},
				beforeSend: function() {
					$('#divDados').html("<img src='img/ajax-loader.gif'>&nbsp;Por favor aguarde, isso pode levar alguns minutos...");
				},
				complete: function() {
						$('#btnImportar').prop('disabled',false);
						$('#btnArquivo').prop('disabled',false);
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					console.log(result);
					if(result != null){
						if(result.ok == 1){

							$('#divDados').html(result.tabela);

							$("#tabelaDados").DataTable(
								{
									'iDisplayLength' : 200,
									'order': [[ 4, 'asc' ]]
								}
							);

						}else{

							$('#divDados').html('<p>Sem resultados...');

						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}

				}
			});

		}else{
			exibeErro('<p>Por favor selecione o hospital.</p>');
		}

	}

	function importar(){

		var anoIni         = $('#anoIni').val();
		var anoFim         = $('#anoFim').val();
		var periodoIni     = $('#periodoIni').val();
		var periodoFim     = $('#periodoFim').val();
		var arquivoEntrada = $('#arquivoEntrada').val();
		var hospital       = $('#hospital').val();

		if(hospital !== '0'){

			$.ajax({
				url: 'ajax/drg-new.php?acao=enviarDRG',
				type: 'POST',
				timeout: 15000000,
				dataType: 'json',
				data: {
						'anoIni'         : anoIni,
						'anoFim'         : anoFim,
						'periodoIni'     : periodoIni,
						'periodoFim'     : periodoFim,
						'arquivoEntrada' : arquivoEntrada,
						'hospital'       : hospital

				},
				beforeSend: function() {
					$('#btnArquivo').prop('disabled',true);
					$('#btnImportar').prop('disabled',true);
					$('#divImport').html("<img src='img/ajax-import.gif'>&nbsp;Enviando dados para o DRG, isso pode levar alguns minutos...");
				},
				complete: function() {
						$('#btnArquivo').prop('disabled',false);
						$('#btnImportar').prop('disabled',false);
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					console.log(result);
					if(result != null){
						if(result.ok == 1){

							$('#divDados').html("<p>Dados enviados com sucesso, clique para baixar o arquivo de sa&iacute;da: " + "<a href='arquivos/php/files/"+ result.arquivo +"'>"+ result.arquivo +"</a></p>");
              $('#divImport').html("");

						}else{

							$('#divDados').html('<p>Sem resultados...');
              $('#divImport').html("");

						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}

				}
			});

		}else{
			exibeErro('<p>Por favor selecione o hospital.</p>');
		}

	}

	function gerarCSV(){

		//$('#import').show();

		//alert($('#arquivoImport').val());

		var anoIni         = $('#anoIni').val();
		var anoFim         = $('#anoFim').val();
		var periodoIni     = $('#periodoIni').val();
		var periodoFim     = $('#periodoFim').val();
		var arquivoEntrada = $('#arquivoEntrada').val();
		var hospital       = $('#hospital').val();

		if(hospital !== '0'){

			$.ajax({
				url: 'ajax/drg-new.php?acao=gerarArquivoCSV',
				type: 'POST',
				timeout: 15000000,
				dataType: 'json',
				data: {
						'anoIni'         : anoIni,
						'anoFim'         : anoFim,
						'periodoIni'     : periodoIni,
						'periodoFim'     : periodoFim,
						'arquivoEntrada' : arquivoEntrada,
						'hospital'       : hospital

				},
				beforeSend: function() {
					$('#btnExtrair').prop('disabled',true);
					$('#btnImportar').prop('disabled',true);
					$('#btnArquivo').prop('disabled',true);
					$('#divImport').html("<img src='img/ajax-import.gif'>&nbsp;Gerando arquivo CSV, isso pode levar alguns minutos...");
				},
				complete: function() {
						$('#btnExtrair').prop('disabled',false);
						$('#btnImportar').prop('disabled',false);
						$('#btnArquivo').prop('disabled',false);

				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					console.log(result);
					if(result.ok == 1){
						$('#divImport').html("<p>&nbsp;</p><font size=3>Arquivo gerado com sucesso, clique para baix&aacute;-lo: " + "<a href='arquivos/php/files/"+ result.arquivo +"'>"+ result.arquivo +"</a></font>");
					}

				}
			});

		}else{
			exibeErro('<p>Por favor selecione o hospital.</p>');
		}

	}

	$('#btnImportar').prop('disabled',false);
	$('#btnArquivo').prop('disabled',false);
	$('#arquivoImport').hide();
	$('#import').hide();

	$('#anoIni').val('2018');
	$('#anoFim').val('2018');

	$('#arquivo').change(function() {

		if($('#arquivo').is(':checked')){
			$('#arquivoImport').show();
		}else{
			$('#arquivoImport').hide();
		}

	/*	$('input[type="file"]').change(function(e, data){
			//console.log(e.target.files[0]);
				//var fileName = e.target.files[0];



				console.log(document.getElementById("arquivoImport").files[0]);


			//	alert('The file "' + fileName +  '" has been selected.');
		});*/



	});

	'use strict';

    $('#fileupload').fileupload({
        url: 'arquivos/php/',
        dataType: 'json',
        done: function (e, data) {
            $.each(data.result.files, function (index, file) {
                $('<p/>').text("Arquivo importado com sucesso!").appendTo('#files');
				$('#arquivoEntrada').val(file.name);
            });
			//$('#btnExtrair').prop('disabled',false);
			$('#btnArquivo').prop('disabled',false);
			$('#btnImportar').prop('disabled',false);
        },
        progressall: function (e, data) {
            $('#btnExtrair').prop('disabled',true);
			var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress .progress-bar').css(
                'width',
                progress + '%'
            );

        }
    });

</script>

<?php include("inc/rodape.php"); ?>
