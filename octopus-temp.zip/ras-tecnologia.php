<?php include("inc/topo.php"); ?>

	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
				<i class="fa fa-inbox"></i> RAs Tecnologia
			</h1>
		</section>

        <!-- Main content -->
        <section class="content">

			<!-- Your Page Content Here -->
		  
			<!-- Horizontal Form -->
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Registros de Atendimentos com a TI</h3>&nbsp;&nbsp;
                </div><!-- /.box-header -->
			</div><!-- /.box -->
			
			<div class="row">
				<div class="col-md-12">
					<div class="box">
						<div class="box-header">
							<h3 class="box-title">Totvs</h3>
						</div><!-- /.box-header -->
						<div id="loadingTotvs" style='float:left'></div>
						<div class="box-body" id="divTabelaTotvs"></div>
					</div><!-- /.box -->
				</div>
			
				<!--<div class="col-md-6">
					<div class="box">
						<div class="box-header">
							<h3 class="box-title">Qualitor</h3>
						</div>
						<div id="loadingQualitor" style='float:left'></div>
						<div class="box-body" id="divTabelaQualitor"></div>
					</div>
				</div>-->
			</div>
        </section><!-- /.content -->
	</div><!-- /.content-wrapper -->
<script>

	function buscaRAs(){
	
		$('#divTabelaTotvs').html('');
		
		$.ajax({
			url: 'ajax/ras-tecnologia.php?acao=buscaRAs',
			type: 'POST',
			timeout: 30000,
			dataType: 'json',
			data: {
				   'atendente' : 'tecnologia'
			},
			beforeSend: function() {
				$('#loadingTotvs').html('<p><img src=img/ajax-loader.gif></p>');
			},
			complete: function() {
				$('#loadingTotvs').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				
				if(result.ok == 1){
				
					var tabela = "<table id='tabelaRAs' class='table table-bordered table-striped'>"
								+ "<thead>"
								+  "<tr>"
								+		"<th>RA Totvs</th>"
								+		"<th>Chamado Qualitor</th>"
								+		"<th>Responsável</th>"
								+		"<th>Status</th>"
								+	"</tr>"
								+	"</thead>"
								+	"<tbody>";
								
					$.each(result.ras,function(k,ra){
					
						//console.log(ra);

						tabela += "<tr>";
						tabela += "<td>" + ra['RA'] + "</td>";
						tabela += "<td>" + ra['Chamado'] + "</td>";
						tabela += "<td>" + ra['Usuario'] + "</td>";
						
						if(ra['status'] == 'Pendente'){
							tabela += "<td><span class='label label-warning'>" + ra['status'] + "</span></td>";
						}else{
							tabela += "<td>&nbsp;</td>";
						}
						tabela += "</tr>";
					});
						
					tabela += "</tbody></table>";
					
					$('#divTabelaTotvs').html(tabela);
					$("#tabelaRAs").DataTable({
						"language": {
							"paginate": {
								"previous": "Anterior",
								"next": "Próximo"
							},
							"lengthMenu": "Mostre _MENU_ registros por página",
							"zeroRecords": "Nada encontrado - desculpe",
							"info": "Mostrando página _PAGE_ de _PAGES_",
							"infoEmpty": "Sem registros"
						},
						"pagingType": "simple_numbers",
						"searching" : false,
						"order": [[ 3, "desc" ],[ 0, "asc" ]]
					});
				}
				else{
					exibeErro('<p>Não foi possível encontrar registros de RA</p>');
				}
			}
		});
	}
	
	/*function buscaChamadosRA(){
	
		$('#divTabelaQualitor').html('');
		
		$.ajax({
			url: 'ajax/ras-tecnologia.php?acao=buscaChamadosRA',
			type: 'POST',
			timeout: 30000,
			dataType: 'json',
			beforeSend: function() {
				$('#loadingQualitor').html('<p><img src=img/ajax-loader.gif></p>');
			},
			complete: function() {
				$('#loadingQualitor').html('');
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				
				if(result.ok == 1){
				
					var tabela = "<table id='tabelaQualitor' class='table table-bordered table-striped'>"
								+ "<thead>"
								+  "<tr>"
								+		"<th>RA</th>"
								+		"<th>Chamado</th>"
								+		"<th>Responsável</th>"
								+	"</tr>"
								+	"</thead>"
								+	"<tbody>";
							
					$.each(result.chamados,function(k,chamado){

						var qualitor = chamado.split(";");
						tabela += "<tr>";
						tabela += "<td>" + qualitor[1].substring(24) + "</td>";
						tabela += "<td>" + qualitor[0] + "</td>";
						tabela += "<td>" + qualitor[2] + "</td>";
						tabela += "</tr>";
					});

					tabela += "</tbody></table>";
					
					$('#divTabelaQualitor').html(tabela);
					$("#tabelaQualitor").DataTable({
						"language": {
							"paginate": {
								"previous": "Anterior",
								"next": "Próximo",								
							},
							"lengthMenu": "Mostre _MENU_ registros por página",
							"zeroRecords": "Nada encontrado - desculpe",
							"info": "Mostrando página _PAGE_ de _PAGES_",
							"infoEmpty": "Sem registros"
						},
						"pagingType": "simple_numbers",
						"searching" : false
					});
				}
				else{
					exibeErro('<p>Não foi possível encontrar registros de RA</p>');
				}
			}
		});
	}*/
	
	buscaRAs();
	//buscaChamadosRA();
	
</script>	  

<?php include("inc/rodape.php"); ?>