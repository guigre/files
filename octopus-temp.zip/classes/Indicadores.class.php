<?php
class Indicadores extends Utils{

    var $id;
    var $ds_indicador;
	var $ds_classificacao;
    var $ds_grupo;
    var $ds_periodicidade;
	var $ds_forma_calculo;
	var $ds_origem;
	var $ds_observacao;
	var $id_responsavel;
	var $ds_tipo;
    var $tabela = "indicador_ti";
	var $row;
      
    function cadastraIndicador($indicador,$classificacao,$grupo,$periodicidade,$forma_calculo,$origem,$observacao,$responsavel,$tipo){
	    $this->abreConexaoOracle();
		$codigo = $this->buscaUltimoCodigo() + 1;
		$query="INSERT INTO $this->tabela
		 				    (id,
						     ds_indicador,
							 ds_classificacao,
							 ds_grupo,
							 ds_periodicidade,
							 ds_forma_calculo,
							 ds_origem,
							 ds_observacao,
							 id_responsavel,
							 ds_tipo) 
				     VALUES					   
					   	    ($codigo,
						    '$indicador',
							'$classificacao',
							'$grupo',
							'$periodicidade',
							'$forma_calculo',
							'$origem',
							'$observacao',
							 $responsavel,
							'$tipo')";							
		$insert = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		if($resultado){
			oci_commit($this->conexaoOracle);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
    function atualizaIndicador($id,$indicador,$classificacao,$grupo,$periodicidade,$forma_calculo,$origem,$observacao,$responsavel,$tipo){
	    $this->abreConexaoOracle();		 
	    $query="UPDATE $this->tabela 
		 		   SET ds_indicador     = '$indicador',
				       ds_classificacao = '$classificacao',
				       ds_grupo         = '$grupo',
				       ds_periodicidade = '$periodicidade',
				       ds_forma_calculo = '$forma_calculo',
				       ds_origem        = '$origem',
				       ds_observacao    = '$observacao',
				       id_responsavel   = $responsavel, 
				       ds_tipo          = '$tipo'
			     WHERE id               = $id";
		$update = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}

    function desativaIndicador($id){
	    $this->abreConexaoOracle();		 
	    $query="DELETE
                  FROM $this->tabela
				WHERE  id = $id";
		$delete = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
	function listaIndicadores(){
        $this->abreConexaoOracle();
		$query = "SELECT * 
		            FROM $this->tabela
			    ORDER BY id";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaIndicador($id){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE id=$id";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);				   
	    if($row[0] > 0){
			$this->id               = $row[0];
			$this->ds_indicador     = $row[1];
			$this->ds_classificacao = $row[2];
			$this->ds_grupo         = $row[3];
			$this->ds_periodicidade = $row[4];
			$this->ds_forma_calculo = $row[5];
			$this->ds_origem        = $row[6];
			$this->ds_observacao    = $row[7];
			$this->id_responsavel   = $row[8];
			$this->ds_tipo       	= $row[9];			
			return true;
	    }else{
			return false;
	    }
    } 
	
	function buscaUltimoCodigo(){
        $this->abreConexaoOracle();
		$query = "SELECT MAX(id) 
		            FROM $this->tabela";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);
		return $row[0];
	}	
}

?>
