<?php
class Privilegios extends Utils{

    /*var $id;
    var $ds_usuario;
	var $ds_login;
    var $ds_email;
    var $ds_senha;
	var $ds_privilegio;
	var $ds_status;
    var $privilegios = array();*/
	var $tabela = "USUARIO_TO_PRIVILEGIO";
	/*var $row;*/
		
	/*var $inseriuDep = false;	*/
		
    function existePrivilegio($login, $menu){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE login ='$login'
				     AND menu = '$menu'";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);
		$menu = oci_fetch_row($consulta);		
	    if($menu){
			return true;
	    }else{
			return false;
	    }
    }
      
    function cadastraPrivilegio($login,$menu){
	    $this->abreConexaoOracle();
		$query="INSERT INTO $this->tabela
		 				    (login,
							 menu) 
				     VALUES	('$login',
							 '$menu')";							
		$insert = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		if($resultado){
			oci_commit($this->conexaoOracle);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
	function listaPrivilegios(){
        $this->abreConexaoOracle();
		$query = "SELECT * 
		            FROM $this->tabela
			    ORDER BY login";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
	function excluiPrivilegio($login,$menu){
	    $this->abreConexaoOracle();
		$query="DELETE $this->tabela
		 	     WHERE login ='$login'
				   AND menu = '$menu'";							
		$insert = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		if($resultado){
			oci_commit($this->conexaoOracle);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
    /*function desativaUsuario($id){
	    $this->abreConexaoOracle();		 
	    $query="UPDATE $this->tabela 
		           SET ds_status = 'I'
				WHERE  id        = $id";
		$update = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}	
	
	function buscaUsuario($id){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE id=$id";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);				   
	    if($row[0] > 0){
			$this->id            = $row[0];
			$this->ds_usuario    = $row[1];
			$this->ds_login      = $row[2];
			$this->ds_senha      = $row[3];
			$this->ds_privilegio = $row[4];
			$this->ds_email      = $row[5];
			$this->ds_status     = $row[6];
			$this->buscaDepartamentoByUsuario($row[0]);
			return true;
	    }else{
			return false;
	    }
    } 
	
	function buscaUltimoCodigo(){
        $this->abreConexaoOracle();
		$query = "SELECT MAX(id) 
		            FROM $this->tabela";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);
		return $row[0];
	}
	
    function buscaDepartamentoByUsuario($codigo){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM indicador_ti_usuario_depto
				   WHERE id_usuario=$codigo";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		while($row = oci_fetch_row($consulta)){
			array_push($this->departamentos,$row[1]);
		}
    }*/	
	
}

?>
