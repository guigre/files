<?php
class Usuarios extends Utils{

    var $id;
    var $ds_usuario;
	var $ds_login;
    var $ds_email;
    var $ds_senha;
	var $ds_privilegio;
	var $ds_status;
    var $departamentos = array();
	var $tabela = "indicador_ti_usuario";
	var $row;
		
	var $inseriuDep = false;	
		
    function loginSistema($login,$senha){
	    $this->abreConexaoOracle();		
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE ds_login = '$login'";	
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);
		$row = oci_fetch_row($consulta);
		if(!$row){
		    return false;
	    }else{
		    if($row[3] == $this->criptografaSenha($senha)){
			    $this->id            = $row[0];
			    $this->ds_usuario    = $row[1];
			    $this->ds_login      = $row[2];
			    $this->ds_senha      = $row[3];
			    $this->ds_privilegio = $row[4];				
			    $this->ds_email      = $row[5];
				$this->ds_status     = $row[6];				
			    return true;
		   }else{
				return false;
		   }
	    }
    }
      
    function existeUsuario($login){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE ds_login='$login'";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);
		$usuario = oci_fetch_row($consulta);		
	    if($usuario){
			return true;
	    }else{
			return false;
	    }
    }
      
    function cadastraUsuario($usuario,$login,$senha,$privilegio,$email,$status,$departamentos){
	    $this->abreConexaoOracle();
		$codigo = $this->buscaUltimoCodigo() + 1;
		$query="INSERT INTO $this->tabela
		 				    (id,
						     ds_usuario,
							 ds_login,
							 ds_senha,
							 ds_privilegio,
							 ds_email,
							 ds_status) 
				     VALUES					   
					   	    ($codigo,
						    '$usuario',
							'$login',
							'".$this->criptografaSenha($senha)."',
							'$privilegio',
							'$email',
							'$status')";							
		$insert = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		if($resultado){
			foreach($departamentos as $dados){
				$queryDepartamentos = "INSERT INTO indicador_ti_usuario_depto (id_usuario, 
				                                                               id_departamento)
								            VALUES                            ($codigo,
																			   $dados)";
				$insertDep = oci_parse($this->conexaoOracle, $queryDepartamentos);
				$resultadoDep = oci_execute($insertDep, OCI_NO_AUTO_COMMIT);																			   
				if($resultadoDep){																	
					$inseriuDep = true; 
				}			
			}
			if($inseriuDep){
				oci_commit($this->conexaoOracle);	
				return true;				
			}else{
				oci_rollback($this->conexaoOracle);
				return false;				
			}			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
    function atualizaUsuario($id,$usuario,$privilegio,$email,$status,$departamentos){
	    $this->abreConexaoOracle();		 
	    $query="UPDATE $this->tabela 
		 		   SET ds_usuario    = '$usuario',
                       ds_privilegio = '$privilegio',
                       ds_email      = '$email',
                       ds_status     = '$status'					   
				 WHERE id            = $id";
		$update = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			$queryDelete = "DELETE FROM indicador_ti_usuario_depto WHERE id_usuario = $id";
			$delete = oci_parse($this->conexaoOracle, $queryDelete);
			$resultadoDel = oci_execute($delete, OCI_NO_AUTO_COMMIT);			
			if($resultadoDel){
				oci_commit($this->conexaoOracle);
				foreach($departamentos as $dados){
					$queryDepartamentos = "INSERT INTO indicador_ti_usuario_depto (id_usuario, 
																				   id_departamento)
												VALUES                            ($id,
																				   $dados)";
					$insertDep = oci_parse($this->conexaoOracle, $queryDepartamentos);
					$resultadoDep = oci_execute($insertDep, OCI_NO_AUTO_COMMIT);																			   
					if($resultadoDep){																	
						$inseriuDep = true; 
					}			
				}
				if($inseriuDep){
					oci_commit($this->conexaoOracle);	
					return true;				
				}else{
					oci_rollback($this->conexaoOracle);
					return false;				
				}
			}else{
				oci_rollback($this->conexaoOracle);
				return false;				
			}
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}

    function desativaUsuario($id){
	    $this->abreConexaoOracle();		 
	    $query="UPDATE $this->tabela 
		           SET ds_status = 'I'
				WHERE  id        = $id";
		$update = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}	
	
	function listaUsuarios(){
        $this->abreConexaoOracle();
		$query = "SELECT * 
		            FROM $this->tabela
				   WHERE ds_status = 'A'
			    ORDER BY id";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaUsuario($id){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE id=$id";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);				   
	    if($row[0] > 0){
			$this->id            = $row[0];
			$this->ds_usuario    = $row[1];
			$this->ds_login      = $row[2];
			$this->ds_senha      = $row[3];
			$this->ds_privilegio = $row[4];
			$this->ds_email      = $row[5];
			$this->ds_status     = $row[6];
			$this->buscaDepartamentoByUsuario($row[0]);
			return true;
	    }else{
			return false;
	    }
    } 
	
	function buscaUltimoCodigo(){
        $this->abreConexaoOracle();
		$query = "SELECT MAX(id) 
		            FROM $this->tabela";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);
		return $row[0];
	}
	
    function buscaDepartamentoByUsuario($codigo){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM indicador_ti_usuario_depto
				   WHERE id_usuario=$codigo";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		while($row = oci_fetch_row($consulta)){
			array_push($this->departamentos,$row[1]);
		}
    }	
	
}

?>
