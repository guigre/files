<?php
class Departamentos extends Utils{

    var $codigo;
    var $descricao;
	var $tabela = "indicador_ti_departamento";
	var $row;
      
    function existeDepartamento($descricao){
		$this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE ds_departamento='$descricao'";		
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);
		$departamento = oci_fetch_row($consulta);		
	    if($departamento){
			return true;
	    }else{
			return false;
	    }
    }
      
    function cadastraDepartamento($descricao){
	    $this->abreConexaoOracle();
		$codigo = $this->buscaUltimoCodigo() + 1;
		$query="INSERT INTO $this->tabela
		 				    (cd_departamento,
						     ds_departamento) 
				     VALUES					   
					   	    ($codigo,
						    '$descricao')";							
		$insert = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
    function atualizaDepartamento($codigo,$descricao){
	    $this->abreConexaoOracle();		 
	    $query="UPDATE $this->tabela 
		 		   SET ds_departamento = '$descricao'
				 WHERE cd_departamento = $codigo";
		$update = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}

    function desativaDepartamento($codigo){
	    $this->abreConexaoOracle();		 
	    $query="DELETE 
		          FROM $this->tabela 
				WHERE  cd_departamento = $codigo";
		$delete = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
	function listaDepartamentos(){
        $this->abreConexaoOracle();
		$query = "SELECT * 
		            FROM $this->tabela
			    ORDER BY cd_departamento";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;		 
    }
	
	function listaDepartamentosByDescricao(){
        $this->abreConexaoOracle();
		$query = "SELECT * 
		            FROM $this->tabela
			    ORDER BY ds_departamento";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;		 
    }	
	
    function buscaDepartamento($codigo){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE cd_departamento=$codigo";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);				   
	    if($row[0] > 0){
			$this->codigo    = $row[0];
			$this->descricao = $row[1];
			return true;
	    }else{
			return false;
	    }
    }
	
	function buscaUltimoCodigo(){
        $this->abreConexaoOracle();
		$query = "SELECT MAX(cd_departamento) 
		            FROM $this->tabela";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);
		return $row[0];
	}
		
}

?>
