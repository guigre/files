<?php
class Campanha extends Utils{

	var $idCampanha;
	var $descricao;
	var $dataInicio;
	var $dataFim;
  var $tabela = "unmcampanha";
	var $row;

  function cadastraCampanha($idCampanha,$descricao,$dataInicio,$dataFim){

	    $this->abreConexaoOracleOrquestra();

		  $query = "INSERT INTO $this->tabela (idcampanha,
				                					         descricao,
																				   dtinicio,
																				   dtfim)
					                       VALUES  ('$idCampanha',
								   	                      '$descricao',
																				  '$dataInicio',
																				  '$dataFim')";

		  $insert = oci_parse($this->conexaoOracleOrquestra, $query);

		  $resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);

		  if($resultado){
			  oci_commit($this->conexaoOracleOrquestra);
			  return true;
		  }else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}

    function atualizaCampanha($idCampanha,
	                            $descricao,
														  $dataInicio,
														  $dataFim){
	    $this->abreConexaoOracleOrquestra();
	    $query = "UPDATE $this->tabela
		 		           SET descricao  = '$descricao',
									 	   dtinicio   = '$dataInicio',
											 dtFim      = '$dataFim'
				         WHERE idcampanha = '$idCampanha'";

		  $update = oci_parse($this->conexaoOracleOrquestra, $query);
		  $resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);

		  if($resultado){
			  oci_commit($this->conexaoOracleOrquestra);
			  return true;
		  }else{
			  oci_rollback($this->conexaoOracleOrquestra);
			  return false;
		  }
	}

	function listaCampanhas(){
    $this->abreConexaoOracleOrquestra();
		$query = "SELECT idcampanha,
						         descricao,
										 dtinicio,
										 dtfim
		            FROM $this->tabela";
    $retorno = array();
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);
    while ($row = oci_fetch_row($consulta)){
      array_push($retorno,$row);
    }
      return $retorno;
  }

  function buscaCampanha($idCampanha){
	    $this->abreConexaoOracleOrquestra();
	    $query = "SELECT idcampanha,
			                 descricao,
			                 dtinicio,
											 dtfim
		  		        FROM $this->tabela
				         WHERE idcampanha = $idCampanha";
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);
		$row = oci_fetch_assoc($consulta);
		if(count($row) > 0){
		  $this->$idCampanha = $row['IDCAMPANHA'];
      $this->descricao   = $row['DESCRICAO'];
			$this->dataInicio  = $row['DTINICIO'];
			$this->dataFim     = $row['DTFIM'];
			return true;
	  }else{
			return false;
	  }
  }

	function buscaProximoID(){
	    $this->abreConexaoOracleOrquestra();
	    $query = "SELECT max(idcampanha) + 1 as IDCAMPANHA
		  		        FROM $this->tabela";
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);
		$row = oci_fetch_assoc($consulta);
		if(count($row) > 0){
			return $row['IDCAMPANHA'];
	  }else{
			return 0;
	  }
	}

}

?>
