<?php
class RelatoriosSA extends Utils{

    var $relatorio;
	
    function consultasPadrao($prestador,$dataInicial,$dataFinal){
	    $this->abreConexaoOracleSA();
		$query="select g.nr_guia, g.cd_cartao_bnf, g.nm_completo_bnf, to_char(p.dt_nasc,'DD/MM/YYYY') Nascimento, g.cd_prestador_exec, g.nm_profissional_exec, i.cd_item_exec, i.ds_item_exec, to_date(g.dt_hr_emissao, 'DD/MM/YYYY') Entrada, to_char(i.dt_hr_exec_final, 'DD/MM/YYYY HH24:MI:SS') Finalizacao
				from cm_tiss_guia_itens i
				join cm_tiss_guia g on i.cd_tiss_guia = g.cd_tiss_guia
				left join sce_beneficiarios b on g.cd_cartao_unimed_bnf = b.cd_unimed and g.cd_cartao_plano_bnf = b.cd_carteira and g.cd_cartao_benef_bnf = b.cd_fami
				and g.cd_cartao_depen_bnf = b.cd_depen
				left join sce_pessoas p on b.cd_pessoa = p.cd_pessoa
				where i.tp_item = 'IR'
				and i.cd_item_exec = 10101039
				and g.cd_prestador_exec = $prestador
				and to_date(g.dt_hr_emissao,'dd/mm/yy') between to_date('$dataInicial','dd/mm/yy') AND to_date('$dataFinal','dd/mm/yy')
				order by i.dt_hr_exec_final";
		$retorno = array();	
		$consulta = oci_parse($this->conexaoOracleSA, $query);
		oci_execute($consulta);		
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }		

}

?>
