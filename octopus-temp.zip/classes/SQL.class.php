<?php
class SQL{

	var $cd_indicador;
	var $cd_resultado;
	var $nr_semana;
	var $nr_mes;
	var $nr_ano;
	var $nr_proximo_mes;
	var $nr_ano_proximo_mes;
	var $ds_detalhe_indicador;
	var $nr_meta;
	var $nr_resultado;
	var $ds_detalhe_indicador2;
	var $conexaoOracle = null;
	var $erros = array();
	var $count = 0;
	var $achou = false;

	// INSERE DADOS NO ORACLE	
	function insereDadosOracle(){
	
		if($this->ds_detalhe_indicador == ""){
			$ds_detalhe1 = " is null";
		}else{
			$ds_detalhe1 = " = '".$this->ds_detalhe_indicador."'";
		}
		
		if($this->ds_detalhe_indicador2 == ""){
			$ds_detalhe2 = ' is null';
		}else{
			$ds_detalhe2 = " = '".$this->ds_detalhe_indicador2."'";
		}
		
		if($this->nr_mes == ""){
			$ds_mes = ' is null';
		}else{
			$ds_mes = ' = '.$this->nr_mes;
		}
		
		if ($this->cd_indicador != 3){
			$consultaExistencia = oci_parse($this->conexaoOracle, "SELECT id_resultado
																	 FROM indicador_ti_resultado
																	WHERE id                    = ".$this->cd_indicador."
																	  AND nr_semana             = ".$this->nr_semana."
																	  AND nr_mes                ".$ds_mes."
																	  AND nr_ano                = ".$this->nr_ano."
																	  AND ds_detalhe_indicador  ".$ds_detalhe1."
																	  AND ds_detalhe_indicador2 ".$ds_detalhe2."");
		}else{
			$consultaExistencia = oci_parse($this->conexaoOracle, "SELECT id_resultado
																	 FROM indicador_ti_resultado
																	WHERE id                    = ".$this->cd_indicador."
																	  AND nr_semana             = ".$this->nr_semana."
																	  AND nr_mes                ".$ds_mes."
																	  AND nr_ano                = ".$this->nr_ano."");
		}

        oci_execute($consultaExistencia);
		
		$idexistente = oci_fetch_row($consultaExistencia);
		
		if($idexistente[0] == null){
		
			$consultaID = oci_parse($this->conexaoOracle, "SELECT max(id_resultado) + 1 
															FROM indicador_ti_resultado
														   WHERE id = ".$this->cd_indicador."");
			oci_execute($consultaID);

			$id1 = oci_fetch_row($consultaID);
			
			if($id1[0] == null){
				$id1[0] = 1;
			}
			
			$cd_resultado = $id1[0];	

			$insert = oci_parse($this->conexaoOracle, "INSERT INTO indicador_ti_resultado (id,
																						   id_resultado,
																						   nr_semana,
																						   nr_mes,
																						   nr_ano,
																						   ds_detalhe_indicador,
																						   nr_meta,
																						   nr_resultado,
																						   ds_detalhe_indicador2) 
																				 VALUES (  ".$this->cd_indicador.",
																						   $cd_resultado,
																						   '".$this->nr_semana."',
																						   '".$this->nr_mes."',
																						   '".$this->nr_ano."',
																						   '".$this->ds_detalhe_indicador."',
																						   '".$this->nr_meta."',
																						   '".$this->nr_resultado."',
																						   '".$this->ds_detalhe_indicador2."')");			
			
			$result = oci_execute($insert, OCI_NO_AUTO_COMMIT);
			
			if(!$result){
			
				$erro = oci_error($insert);
				
				$id_erro = $erro['code'];
				
				if($id_erro == 1){
					
					$erro = "".$this->cd_indicador.";".$cd_resultado.";".$this->nr_semana.";".$this->nr_mes.";".$this->nr_ano.";".$this->ds_detalhe_indicador.";".$this->nr_meta.";".$this->nr_resultado.";".$this->ds_detalhe_indicador2."";
					
					$erros[$count] = $erro;
					
					$count++;
				
				}else{
				
					$erro = "".$this->cd_indicador.";".$cd_resultado.";".$this->nr_semana.";".$this->nr_mes.";".$this->nr_ano.";".$this->ds_detalhe_indicador.";".$this->nr_meta.";".$this->nr_resultado.";".$this->ds_detalhe_indicador2."";
					
					$erros[$count] = $erro;
					
					$count++;			

				}					   
				
				oci_rollback($this->conexaoOracle);
			
			}else{
				
				oci_commit($this->conexaoOracle);
			
			}
		}
		else{
		
			$cd_resultado = $idexistente[0];				
			
			if ($this->cd_indicador != 3){
				$update = oci_parse($this->conexaoOracle, "UPDATE indicador_ti_resultado
															  SET nr_meta      = '".$this->nr_meta."',
																  nr_resultado = '".$this->nr_resultado."'
															WHERE id           = ".$this->cd_indicador."
															  AND id_resultado = $cd_resultado");			
			}else{
				$update = oci_parse($this->conexaoOracle, "UPDATE indicador_ti_resultado
															  SET nr_meta              = '".$this->nr_meta."',
															      ds_detalhe_indicador = '".$this->ds_detalhe_indicador."',
																  nr_resultado         = '".$this->nr_resultado."'
															WHERE id           = ".$this->cd_indicador."
															  AND id_resultado = $cd_resultado");
			}
			
			$resultUpdate = oci_execute($update, OCI_NO_AUTO_COMMIT);
			
			if(!$resultUpdate){
			
				$erro = oci_error($update);
				
				$id_erro = $erro['code'];
				
				if($id_erro == 1){
					
					$erro = "".$this->cd_indicador.";".$cd_resultado.";".$this->nr_semana.";".$this->nr_mes.";".$this->nr_ano.";".$this->ds_detalhe_indicador.";".$this->nr_meta.";".$this->nr_resultado.";".$this->ds_detalhe_indicador2."";
					
					$erros[$count] = $erro;
					
					$count++;
				
				}else{
				
					$erro = "".$this->cd_indicador.";".$cd_resultado.";".$this->nr_semana.";".$this->nr_mes.";".$this->nr_ano.";".$this->ds_detalhe_indicador.";".$this->nr_meta.";".$this->nr_resultado.";".$this->ds_detalhe_indicador2."";
					
					$erros[$count] = $erro;
					
					$count++;			

				}					   
				
				oci_rollback($this->conexaoOracle);
			
			}else{
				
				oci_commit($this->conexaoOracle);
			
			}
		}
	}
	
	function geraArquivoErros(){
	
		if($erros != null){	
	
			$countVetor = 0;
		
			$fp = fopen("c:/temp/erros-indicadores.csv", "a");
			 
			while($countVetor < sizeof($erros)){

				$escreve = fwrite($fp, $erros[$countVetor]);

				$countVetor++;	

			}			
			
			fclose($fp);

			return true;
			
		}else{
			return false;
		}
	}

	function buscaIndicador($cd_indicador, $nr_mes, $nr_ano, $conexaoOracle){

		$this->conexaoOracle = $conexaoOracle;
		
		$conexaoSqlServer = mssql_connect('srvdb9','qualitorv8','qualitorv8@29');

		if($nr_mes == 12) {
			$this->nr_ano_proximo_mes = "".sprintf("%02d", ($nr_ano + 1));
			$this->nr_proximo_mes = "".sprintf("%02d", 1);
		}else{
			$this->nr_ano_proximo_mes = "".sprintf("%02d", $nr_ano);
			$this->nr_proximo_mes = "".sprintf("%02d", ($nr_mes + 1));
		}
		
		switch($cd_indicador){
		
			// PERCENTUAL DE REDU��O DE INCIDENTES NOS PROCESSOS PRINCIPAIS
			case 2:					 
					 if($conexaoSqlServer){
					
							$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
					
							$sql = "SELECT ROUND((SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
										  (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))     AS Qtde
											 FROM hd_chamado ch2
									   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
											WHERE ch2.cdempresa      = 1
										   	  AND ch2.cdtipochamado  = 1
											  AND ch2.cdsituacao    <> 8
											  AND YEAR(ch2.dtchamado) =  $nr_ano - 1
											  AND dbo.consulta_cod_categoria(ch2.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742))), 2) - 100.00
                                      FROM hd_chamado ch
                                INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                                     WHERE ch.cdempresa      = 1
                                       AND ch.cdtipochamado  = 1
                                       AND ch.cdsituacao    <> 8
                                       AND YEAR(ch.dtchamado)  = $nr_ano
                                       AND dbo.consulta_cod_categoria(ch.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742)";
					
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								$this->cd_indicador          = $cd_indicador;
								$this->cd_resultado          = 0;
								$this->nr_semana             = "0";
								$this->nr_mes                = $nr_mes;
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = "";
								$this->nr_meta               = "-1";
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";			
							
								$this->insereDadosOracle();
							
							}
					 }			
			break;			

			// PERCENTUAL DE REDU��O DE INCIDENTES NOS PROCESSOS PRINCIPAIS (MONITORAMENTO)
			case 3:					 
					 if($conexaoSqlServer){
					
							$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
					
							$sql = "SELECT ROUND((SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
										  (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))     
											 FROM hd_chamado ch2
									   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
											WHERE ch2.cdempresa      = 1
										   	  AND ch2.cdtipochamado  = 1
											  AND ch2.cdsituacao    <> 8
											  AND MONTH(ch2.dtchamado) = $nr_mes
											  AND YEAR(ch2.dtchamado) =  $nr_ano - 1
											  AND dbo.consulta_cod_categoria(ch2.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742))), 2) - 100.00 AS Qtde,
										   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Detalhe
                                      FROM hd_chamado ch
                                INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                                     WHERE ch.cdempresa       = 1
                                       AND ch.cdtipochamado   = 1
                                       AND ch.cdsituacao     <> 8
									   AND ch.dspalavrachave not like '%EOU%'
                                       AND MONTH(ch.dtchamado) = $nr_mes
                                       AND YEAR(ch.dtchamado)  = $nr_ano
                                       AND dbo.consulta_cod_categoria(ch.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742)";
					
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								$this->cd_indicador          = $cd_indicador;
								$this->cd_resultado          = 0;
								$this->nr_semana             = "0";
								$this->nr_mes                = $nr_mes;
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = utf8_encode($row['Detalhe']);
								$this->nr_meta               = "-1";
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";
								
								$this->insereDadosOracle();
							}
							
							$sql = "SELECT ROUND((SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								  (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
									FROM hd_chamado ch2
									INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									WHERE ch2.cdempresa      = 1
									  AND ch2.cdtipochamado  = 1
									  AND ch2.cdsituacao    <> 8
									  AND MONTH(ch2.dtchamado) <= $nr_mes
									  AND YEAR(ch2.dtchamado) = $nr_ano - 1
									  AND dbo.consulta_cod_categoria(ch2.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742))), 2) - 100.00 AS Qtde,
									  SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Detalhe
							FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							WHERE ch.cdempresa      = 1
							  AND ch.cdtipochamado  = 1
							  AND ch.cdsituacao    <> 8
							  AND MONTH(ch.dtchamado) <= $nr_mes
							  AND YEAR(ch.dtchamado) = $nr_ano
							  AND ch.dspalavrachave not like '%EOU%'
							  AND dbo.consulta_cod_categoria(ch.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742)";
							  
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								$this->cd_indicador          = $cd_indicador;
								$this->nr_semana             = "0";
								$this->nr_mes                = "";
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = utf8_encode($row['Detalhe']);
								$this->nr_meta               = "-1";
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";
							
								$this->insereDadosOracle();
							}  
							
					 }			
			break;			
			
			// 12 - PERCENTUAL DE DESENVOLVIMENTOS ENTREGUES NO PRAZO		
			case 12:		
					
					if($conexaoSqlServer){
					
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
					
						$sql = "SELECT ROUND(COUNT(ch.cdchamado) * 100.00 /
					           (SELECT COUNT(ch2.cdchamado)
						          FROM hd_chamado ch2 
					        INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
						         WHERE eq2.cdempresa     = 1
						           AND ch2.cdsituacao   <> 8
						           AND ch2.cdtipochamado = 8
						           AND MONTH(ch2.dttermino) = $nr_mes
						           AND YEAR(ch2.dttermino)  = $nr_ano), 2) AS Prazo
						          FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
						         WHERE eq.cdempresa = 1
						           AND (CAST(ch.dttermino AS DATE) <= CAST(ch.dtprevisaotermino AS DATE)
							        OR ch.dtprevisaotermino is null)
						           AND ch.cdsituacao      <> 8
						           AND ch.cdtipochamado    = 8
						           AND MONTH(ch.dttermino) = $nr_mes
						           AND  YEAR(ch.dttermino) = $nr_ano
						   GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), ch.cdtipochamado
						   ORDER BY YEAR(ch.dttermino), MONTH(ch.dttermino)";
					
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){

								$this->cd_indicador          = $cd_indicador;
								$this->cd_resultado          = 0;
								$this->nr_semana             = "0";
								$this->nr_mes                = $nr_mes;
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = "";
								$this->nr_meta               = "85";
								$this->nr_resultado          = $row['Prazo'];
								$this->ds_detalhe_indicador2 = "";			
							
								$this->insereDadosOracle();		

							}
					
					}
			break;
					
			// 13 - QUANTIDADE DE INCIDENTES DEVIDO DESENVOLVIMENTO		
			case 13:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.cdchamado) AS Qtde
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND ch.dspalavrachave = 'DEV'
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND YEAR(ch.dtchamado)  = $nr_ano
						      GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)
							  ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}
						
					}			
			break;	
			
			// 14 - DESENVOLVIMENTOS REABERTOS
			case 14:			
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_ocorrencia_reabertura(ch.cdchamado)) * 100.00 /
									(SELECT COUNT(ch2.cdchamado)
									   FROM hd_chamado ch2 
							     INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
							          WHERE eq2.cdempresa   = 1
									    AND ch2.cdsituacao <> 8
									    AND ch2.cdtipochamado = ch.cdtipochamado
									    AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
									    AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Reabertos
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 8
							       AND MONTH(ch.dtchamado) = $nr_mes
							       AND YEAR(ch.dtchamado)  = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado), ch.cdtipochamado";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Reabertos'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}		
						
					}
			break;
			
			// 15 - QUANTIDADE DE DESENVOLVIMENTOS EM ABERTO POR "IDADE"
			case 15:			
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						/*$sql = "SET NOCOUNT ON

								DECLARE @mmReferencia        CHAR(2)
								DECLARE @aaReferencia        CHAR(4)
								DECLARE @cdIdade             INT
								DECLARE @dsIdade             VARCHAR(15)
								DECLARE @qtDesenvolvimentos  INT
								DECLARE @nrDiasInicial       INT
								DECLARE @nrDiasFinal         INT

								DECLARE @Saida TABLE 
								(
									mmReferencia        CHAR(2),
									dsIdade             VARCHAR(15),
									qtDesenvolvimentos  INT
								)

								SET @mmReferencia = $nr_mes
								SET @aaReferencia = $nr_ano
								
								SET @cdIdade = 1

								WHILE @cdIdade <= 4 BEGIN
								
									SET @dsIdade = (CASE 
														WHEN @cdIdade = 1 THEN '<= 30 dias'
														WHEN @cdIdade = 2 THEN '31 a 60 dias'
														WHEN @cdIdade = 3 THEN '61 a 90 dias'
														WHEN @cdIdade = 4 THEN '>= 90 dias'
														ELSE ''
													END)
								
									SET @nrDiasInicial = 30 * (@cdIdade - 1)
									SET @nrDiasFinal   = 30 * @cdIdade
								
									IF @cdIdade = 1 SET @nrDiasInicial = -1
									IF @cdIdade = 4 SET @nrDiasFinal   = 2147483647
								
									SELECT @qtDesenvolvimentos = COUNT(ch.cdchamado)
									FROM hd_chamado ch 
									INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
									WHERE eq.cdempresa = 1
									AND ch.cdsituacao <> 8
									AND ch.cdtipochamado = 8
									AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
									AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
									and datediff(day,ch.dtchamado,DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE)))  > @nrDiasInicial
									and datediff(day,ch.dtchamado,DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))) <= @nrDiasFinal
									ORDER BY 1
								
									INSERT INTO @Saida (mmReferencia, dsIdade, qtDesenvolvimentos)
									SELECT @mmReferencia, @dsIdade, @qtDesenvolvimentos
								
									SET @cdIdade = @cdIdade + 1
								END
								
								SELECT dsIdade            AS Idade,
									   qtDesenvolvimentos AS Qtde
								  FROM @Saida";*/
								  
						$sql = "SET NOCOUNT ON

								DECLARE @mmReferencia        CHAR(2)
								DECLARE @aaReferencia        CHAR(4)

								SET @mmReferencia = $nr_mes
								SET @aaReferencia = $nr_ano
								
								SELECT 'Em Aprovacao'       as Classificacao,
									   COUNT(ch.cdchamado)  as Qtde
								FROM hd_chamado ch 
								INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								WHERE eq.cdempresa = 1
								AND ch.cdsituacao <> 8
								AND ch.cdtipochamado = 8
								AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
								AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
								AND ch.dtprevisaotermino IS NULL

								UNION ALL

								SELECT 'Total'               as Classificacao,
										COUNT(ch.cdchamado)  as Qtde
								FROM hd_chamado ch 
								INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								WHERE eq.cdempresa = 1
								AND ch.cdsituacao <> 8
								AND ch.cdtipochamado = 8
								AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
								AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
								AND ch.dtprevisaotermino IS NOT NULL

								UNION ALL

								SELECT 'Atraso'              as Classificacao,
									   COUNT(ch.cdchamado)   as Qtde
								FROM hd_chamado ch 
								INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								WHERE eq.cdempresa = 1
								AND ch.cdsituacao <> 8
								AND ch.cdtipochamado = 8
								AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
								AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
								AND ((ch.dttermino IS NOT NULL AND ch.dtprevisaotermino < ch.dttermino)
								OR (ch.dttermino IS NULL AND convert(date,ch.dtprevisaotermino) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))

								UNION ALL
								
								SELECT (CASE MONTH(ch.dtprevisaotermino)
										  WHEN  '1' THEN 'Jan' 
										  WHEN  '2' THEN 'Fev' 
										  WHEN  '3' THEN 'Mar' 
										  WHEN  '4' THEN 'Abr' 
										  WHEN  '5' THEN 'Mai' 
										  WHEN  '6' THEN 'Jun' 
										  WHEN  '7' THEN 'Jul' 
										  WHEN  '8' THEN 'Ago' 
										  WHEN  '9' THEN 'Set' 
										  WHEN  '10' THEN 'Out' 
										  WHEN  '11' THEN 'Nov' 
										  WHEN  '12' THEN 'Dez' 
										 ELSE 'Not month'
										END + '/' + CONVERT(VARCHAR,YEAR(ch.dtprevisaotermino))) as Classificacao,
								count(ch.cdchamado)                                              as Qtde
								FROM hd_chamado ch 
								INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								WHERE eq.cdempresa = 1
								AND ch.cdsituacao <> 8
								AND ch.cdtipochamado = 8
								AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
								AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
								AND NOT ((ch.dttermino IS NOT NULL AND ch.dtprevisaotermino < ch.dttermino)
								OR (ch.dttermino IS NULL AND convert(date,ch.dtprevisaotermino) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
								GROUP BY  MONTH(ch.dtprevisaotermino), YEAR(ch.dtprevisaotermino)";		  
						
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							if (utf8_encode($row['Classificacao']) == "Total"){
								$nr_meta = "35";
							}
							else
							{
								$nr_meta = "";
							}
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Classificacao']);
							$this->nr_meta               = $nr_meta;
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}		
						
					}
			break;		
			
			// 16 - QUANTIDADE DE INCIDENTES ABERTOS DEVIDO A DESENVOLVIMENTOS POR RESPONSAVEL
			case 16:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario  AS Responsavel,
							     COUNT(ch.cdchamado) AS Qtde
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND ch.dspalavrachave = 'DEV'
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado), us.nmusuario
							  ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
							
							$achou = true;

						}

						if($achou == false){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = 0;
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
						
					}
			break;

			// 17 - DESENVOLVIMENTOS ENCERRADOS NO M�S
			case 17:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.dttermino) AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 8
								   AND  YEAR(ch.dttermino)  = $nr_ano
								   AND  MONTH(ch.dttermino) = $nr_mes
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;
			
			// 18 - TEMPO M�DIO DE AN�LISE POR RESPONS�VEL (DURA��O)
			case 18:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 1
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                   AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
									   count(CdChamado)                   AS Qtde
								  FROM @Retorno
							     WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;			
			
			// 19 - TEMPO M�DIO DE APROVA��O DO OR�AMENTO POR RESPONS�VEL (DURA��O)
			case 19:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 205
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;			
			
			// 20 - TEMPO M�DIO DE EXECU��O (EXTERNA) POR RESPONS�VEL (DURA��O)
			case 20:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 206
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;	

			// 21 - TEMPO M�DIO DE EXECU��O (INTERNA) POR RESPONS�VEL (DURA��O)
			case 21:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 213
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;	

			// 22 - TEMPO M�DIO DE LIBERA��O POR RESPONS�VEL (DURA��O)
			case 22:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 209
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;			
			
			// 23 - TEMPO M�DIO DE OR�AMENTO POR RESPONS�VEL (DURA��O)
			case 23:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 204
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;		

			// 24 - TEMPO M�DIO DE TESTES EXERNOS (AREA/SOLICITANTE) POR RESPONS�VEL (DURA��O)
			case 24:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 208
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;	

			// 25 - TEMPO M�DIO DE TESTES INTERNOS (TI) POR RESPONS�VEL (DURA��O)
			case 25:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado        INT
								DECLARE @nmResponsavel    VARCHAR(50)
								DECLARE @nrTempoEtapa     NUMERIC(11,2)
								
								DECLARE @Retorno TABLE 
								(
									cdChamado      INT,
									nmResponsavel  VARCHAR(50),
									nrTempoEtapa   NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT ch.cdchamado, us.nmusuario, dbo.consulta_tempo_acompanhamento(ch.cdchamado, ac.cdacompanhamento, 'hora')
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado)
									INNER JOIN ad_usuario us ON (us.cdusuario = ac.cdusuario)
									WHERE eq.cdempresa   = 1
									AND ch.cdsituacao   <> 8
									AND ch.cdtipochamado = 8
									AND MONTH(ac.dtacompanhamento) = $nr_mes
									AND YEAR(ac.dtacompanhamento)  = $nr_ano
									AND dbo.consulta_etapa_acompanhamento(ac.cdchamado, ac.cdacompanhamento) = 207
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								WHILE @@fetch_status = 0 BEGIN
								
									IF EXISTS (SELECT ret.cdChamado FROM @Retorno ret WHERE ret.cdChamado     = @cdChamado
																						AND ret.nmResponsavel = @nmResponsavel) BEGIN
								
										UPDATE @Retorno
										SET nrTempoEtapa  = nrTempoEtapa + @nrTempoEtapa
										WHERE cdChamado   = @cdChamado
										AND nmResponsavel = @nmResponsavel
									END
									ELSE BEGIN
								
										INSERT INTO @Retorno (cdChamado, nmResponsavel, nrTempoEtapa)
										VALUES(@cdChamado, @nmResponsavel, @nrTempoEtapa)
									END
								
									FETCH NEXT FROM cursor_chamado INTO @cdChamado, @nmResponsavel, @nrTempoEtapa
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                      AS Responsavel,
									   ROUND(AVG(nrTempoEtapa * 1.00), 2) AS Media,
								       count(CdChamado)                   AS Qtde
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;			
			
			// 26 - PERCENTUAL DE INCIDENTES COM ALTERA��ES NA CLASSIFICA��O
			case 26:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_ocorrencia_reclassificacao(ch.cdchamado)) * 100.00 /
								      (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa     = 1
									      AND ch2.cdsituacao   <> 8
									      AND ch2.cdtipochamado = 1
								 	      AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
									      AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Incidentes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
							       AND MONTH(ch.dtchamado) = $nr_mes
							       AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)
							  ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 27 - PERCENTUAL DE INCIDENTES POR SEVERIDADE
			case 27:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT se.nmseveridade AS Severidade,
								 ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
									(SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
									   FROM hd_chamado ch2 
							     INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									  WHERE eq2.cdempresa     = 1
										AND ch2.cdsituacao   <> 8
										AND ch2.cdtipochamado = 1
										AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
										AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Incidentes
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_severidade se ON(se.cdseveridade = ch.cdseveridade)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado), se.nmseveridade
							  ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado), se.nmseveridade";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Severidade']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 28 - PERCENTUAL DE INCIDENTES REABERTOS
			case 28:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_ocorrencia_reabertura(ch.cdchamado)) * 100.00 /
								      (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
										 FROM hd_chamado ch2 
									  INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
										   WHERE eq2.cdempresa     = 1
											 AND ch2.cdsituacao   <> 8
											 AND ch2.cdtipochamado = 1
											 AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
											 AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Incidentes
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)
						      ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			

			// 29 - PERCENTUAL DE INCIDENTES RESOLVIDOS ANTES DO USU�RIO REPORTAR
			case 29:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
									  (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								         FROM hd_chamado ch2 
                                   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
                                        WHERE eq2.cdempresa     = 1
                                          AND ch2.cdsituacao   <> 8
                                          AND ch2.cdtipochamado = 1
										  AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
										  AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Incidentes
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND ch.dspalavrachave = 'PRO'
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)
							  ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			
			
			// 30 - PERCENTUAL DE INCIDENTES SOLUCIONADOS NO PRAZO
			case 30:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								      (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
										 FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
										WHERE eq2.cdempresa     = 1
										  AND ch2.cdsituacao   <> 8
										  AND ch2.cdtipochamado = 1
										  AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
										  AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2) AS Incidentes
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
							  ORDER BY YEAR(ch.dttermino), MONTH(ch.dttermino)";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "85";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 33 - PERCENTUAL DE INCIDENTES SOLUCIONADOS POR N�VEL DE ATENDIMENTO
			case 33:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT dbo.consulta_nivel_atendimento(ch.cdchamado) AS Equipe, 
							           ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
							          (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								         FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
								        WHERE eq2.cdempresa     = 1
								          AND ch2.cdsituacao   <> 8
								          AND ch2.cdtipochamado = 1
								          AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
								          AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2) AS Incidentes
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado = 1
								   AND ch.dttermino is not null
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), dbo.consulta_nivel_atendimento(ch.cdchamado)
							  ORDER BY 1";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Equipe']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// QUANTIDADE DE INCIDENTES EM ABERTO POR "IDADE" 
			case 34:					 
					 if($conexaoSqlServer){
					
							$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
					
							$sql = "SET NOCOUNT ON

									DECLARE @mmReferencia        CHAR(2)
									DECLARE @aaReferencia        CHAR(4)
									DECLARE @cdIdade             INT
									DECLARE @dsIdade             VARCHAR(15)
									DECLARE @qtDesenvolvimentos  INT
									DECLARE @nrDiasInicial       INT
									DECLARE @nrDiasFinal         INT

									DECLARE @Saida TABLE 
									(
										mmReferencia        CHAR(2),
										dsIdade             VARCHAR(15),
										qtDesenvolvimentos  INT
									)
									
									SET @mmReferencia = $nr_mes
									SET @aaReferencia = $nr_ano
									SET @cdIdade = 1

									WHILE @cdIdade <= 4 BEGIN

										SET @dsIdade = (CASE 
															WHEN @cdIdade = 1 THEN '<= 30 dias'
															WHEN @cdIdade = 2 THEN '31 a 60 dias'
															WHEN @cdIdade = 3 THEN '61 a 90 dias'
															WHEN @cdIdade = 4 THEN '>= 90 dias'
															ELSE ''
														END)
									
										SET @nrDiasInicial = 30 * (@cdIdade - 1)
										SET @nrDiasFinal   = 30 * @cdIdade
									
										IF @cdIdade = 1 SET @nrDiasInicial = -1
										IF @cdIdade = 4 SET @nrDiasFinal   = 2147483647
									
										SELECT @qtDesenvolvimentos = COUNT(ch.cdchamado)
										FROM hd_chamado ch 
										INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
										WHERE eq.cdempresa = 1
										AND ch.cdsituacao <> 8
										AND ch.cdtipochamado = 1
										AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
										AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
										and datediff(day,ch.dtchamado,DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE)))  > @nrDiasInicial
										and datediff(day,ch.dtchamado,DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))) <= @nrDiasFinal
										ORDER BY 1
									
										INSERT INTO @Saida (mmReferencia, dsIdade, qtDesenvolvimentos)
										SELECT @mmReferencia, @dsIdade, @qtDesenvolvimentos
									
										SET @cdIdade = @cdIdade + 1
									END

								SELECT dsIdade            AS Idade,
									   qtDesenvolvimentos AS Qtde
								  FROM @Saida";
					
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								if($row['Idade'] == ">= 90 dias"){
									$nr_meta = "18";
								}else
								{
									if($row['Idade'] == "<= 30 dias"){
										$nr_meta = "64";
									}else{
										$nr_meta = "";
									}
								}
							
								$this->cd_indicador          = $cd_indicador;
								$this->cd_resultado          = 0;
								$this->nr_semana             = "0";
								$this->nr_mes                = $nr_mes;
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = $row['Idade'];
								$this->nr_meta               = $nr_meta;
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";			
							
								$this->insereDadosOracle();
							
							}
							
					 }			
			break;			

			// 35 - QUANTIDADE DE INCIDENTES POR SERVI�O - TOP 10
			case 35:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT TOP 10 dbo.consulta_nome_categoria(ch.cdchamado)                AS Categoria,
									          SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))     AS Abertura
								  FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE ch.cdempresa     = 1
								   AND ch.cdtipochamado = 1
								   AND ch.cdsituacao   <> 8
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY dbo.consulta_nome_categoria(ch.cdchamado)
							  ORDER BY 2 desc";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Categoria']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Abertura'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 36 - QUANTIDADE DE INCIDENTES POR SEVERIDADE
			case 36:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT se.nmseveridade                                             AS Severidade,
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))        AS Qtde
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_severidade se ON(se.cdseveridade = ch.cdseveridade)
							  	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY se.nmseveridade";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Severidade']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 37 - QUANTIDADE DE INCIDENTES RESOLVIDOS NO PRAZO OU FORA
			case 37:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Prazo'                                              AS Descricao,
								       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
							       AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(1 AS BIT)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND YEAR(ch.dttermino)  = $nr_ano
							
							UNION ALL
							
							    SELECT 'Fora Prazo'                                         AS Descricao,
								       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
							       AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(0 AS BIT)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND YEAR(ch.dttermino)  = $nr_ano";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Descricao']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 40 - QUANTIDADE DE INCIDENTES RESOLVIDOS POR N�VEL DE ATENDIMENTO
			case 40:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT dbo.consulta_nivel_atendimento(ch.cdchamado)                        AS Equipe,
									   'Prazo'                                                             AS Descricao,
								      isnull((SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								                FROM hd_chamado ch2 
								          INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
								               WHERE eq2.cdempresa = 1
								                 AND dbo.consulta_nivel_atendimento(ch2.cdchamado) = dbo.consulta_nivel_atendimento(ch.cdchamado)
								                 AND ch2.cdsituacao   <> 8
								                 AND ch2.cdtipochamado = 1
								                 AND (ch2.dttermino <= ch2.dtprevisaotermino
								                 OR ch2.dtprevisaotermino is null)
								                 AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
								                 AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)),0)     AS Qtde
								
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado = 1
								   and ch.dttermino is not null
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
						      GROUP BY YEAR(ch.dttermino), MONTH(ch.dttermino), dbo.consulta_nivel_atendimento(ch.cdchamado)
								
								UNION ALL 
								
								SELECT dbo.consulta_nivel_atendimento(ch.cdchamado)                         AS Equipe,  
									   'Fora Prazo'                                                         AS Descricao,
								       isnull((SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								                 FROM hd_chamado ch2 
								           INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
								                WHERE eq2.cdempresa = 1
								                 AND dbo.consulta_nivel_atendimento(ch2.cdchamado) = dbo.consulta_nivel_atendimento(ch.cdchamado)
								                 AND ch2.cdsituacao   <> 8
								                 AND ch2.cdtipochamado = 1
								                 AND ch2.dttermino > ch2.dtprevisaotermino
								                 AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
								                 AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)),0)     AS Qtde
								
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado = 1
								   and ch.dttermino is not null
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
						      GROUP BY  YEAR(ch.dttermino), MONTH(ch.dttermino), dbo.consulta_nivel_atendimento(ch.cdchamado)
						      ORDER BY 1, 2 desc";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Equipe']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = utf8_encode($row['Descricao']);			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;		

			// 41 - QUANTIDADE DE INCIDENTES SUSPENSOS POR EQUIPE
			case 41:
			
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT dbo.consulta_nivel_atendimento(ch.cdchamado)         AS Equipe,
							 	       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Suspensos
									   
							      FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_suspenso su ON(su.cdchamado = ch.cdchamado
												 AND CAST(('$this->nr_ano_proximo_mes' + '-' + '$this->nr_proximo_mes' + '-01') AS DATETIME) >= convert(datetime, su.dtsuspensao)
												 AND ((CAST(('$this->nr_ano_proximo_mes' + '-' + '$this->nr_proximo_mes' + '-01') AS DATETIME) <= convert(datetime, su.dtreativacao))
													   OR (su.nrsequencia = (SELECT max(su2.nrsequencia)
																			   FROM hd_suspenso su2
																			  WHERE su2.cdchamado = su.cdchamado) 
													   AND su.dtreativacao IS NULL)))
								 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
						      GROUP BY dbo.consulta_nivel_atendimento(ch.cdchamado)
						      ORDER BY 1";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Equipe']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Suspensos'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	
			
			

			// 42 - QUANTIDADE DE INCIDENTES SUSPENSOS POR RESPONS�VEL
			case 42:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                            AS Responsavel,  
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))    AS Suspensos
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
							INNER JOIN hd_suspenso su ON(su.cdchamado = ch.cdchamado
												 AND CAST(('$this->nr_ano_proximo_mes' + '-' + '$this->nr_proximo_mes' + '-01') AS DATETIME) >= convert(datetime, su.dtsuspensao)
												 AND ((CAST(('$this->nr_ano_proximo_mes' + '-' + '$this->nr_proximo_mes' + '-01') AS DATETIME) <= convert(datetime, su.dtreativacao))
													   OR (su.nrsequencia = (SELECT max(su2.nrsequencia)
																			   FROM hd_suspenso su2
																			  WHERE su2.cdchamado = su.cdchamado) 
													   AND su.dtreativacao IS NULL)))
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado = 1
							  GROUP BY us.nmusuario
							  ORDER BY 1";
							  
						$result = mssql_query($sql);
						
						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Suspensos'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	
			
			// 43 - QUANTIDADE TOTAL DE INCIDENTES ABERTOS
			case 43:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))  AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							  	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND YEAR(ch.dtchamado)  = $nr_ano
								   AND MONTH(ch.dtchamado) = $nr_mes
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)
							  ORDER BY YEAR(ch.dtchamado), MONTH(ch.dtchamado)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 44 - TEMPO M�DIO DE ATENDIMENTO POR RESPONS�VEL COM SUSPENS�O (DURA��O)
			case 44:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                                    AS Responsavel,  
									   ROUND(SUM(dbo.consulta_Tempo_Chamado(ch.cdchamado,'HORA')) /
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)), 2)        AS Media,
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))            AS Qtde
								
								  FROM hd_chamado ch
							INNER JOIN hd_equipe eq  ON(ch.cdequipe = eq.cdequipe)
							 LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
							  	 WHERE YEAR(ch.dttermino)  = $nr_ano
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8 
								   AND ch.cdtipochamado = 1 
							  GROUP BY us.nmusuario
							  ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 45 - TEMPO M�DIO DE ATENDIMENTO POR RESPONS�VEL SEM SUSPENS�O (DURA��O)
			case 45:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                                    AS Responsavel,  
									   ROUND(SUM(isnull(ch.nrtempototal,0) / 60) /
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)), 2)        AS Media,
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))            AS Qtde
								  FROM hd_chamado ch
							INNER JOIN hd_equipe eq  ON(ch.cdequipe = eq.cdequipe)
							 LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
							     WHERE YEAR(ch.dttermino)  = $nr_ano
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
							  GROUP BY us.nmusuario
							  ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 64 - PERCENTUAL REQUISI��ES POR TIPO
			case 64:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ti.nmtipochamado                                                 AS Tipo, 
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado IN (2,3,4,5)
									      AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
									      AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dtchamado) = $nr_mes
							       AND  YEAR(ch.dtchamado) = $nr_ano
							  GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado), ti.nmtipochamado
							  ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;		

			// 65 - PERCENTUAL REQUISI��ES REABERTAS
			case 65:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ti.nmtipochamado                                                 AS Tipo, 
                                       ROUND(SUM(dbo.consulta_ocorrencia_reabertura(ch.cdchamado)) * 100.00 /
                                      (SELECT COUNT(ch2.cdchamado)
                                         FROM hd_chamado ch2 
                                   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
                                        WHERE eq2.cdempresa = 1
                                          AND ch2.cdsituacao <> 8
                                          AND ch2.cdtipochamado = ch.cdtipochamado
                                          AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
                                          AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Requisicoes
                                  FROM hd_chamado ch 
                            INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                            INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
                                 WHERE eq.cdempresa   = 1
                                   AND ch.cdsituacao <> 8
                                   AND ch.cdtipochamado IN (2,3,4,5)
                                   AND MONTH(ch.dtchamado) = $nr_mes
                                   AND  YEAR(ch.dtchamado) = $nr_ano
                              GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado), ch.cdtipochamado, ti.nmtipochamado
                         
                         UNION
                         
                         SELECT 'Requisi��o'                                                                 AS Tipo,
                                ROUND(SUM(dbo.consulta_ocorrencia_reabertura(ch.cdchamado)) * 100.00 /
                                (SELECT COUNT(ch2.cdchamado)
                                   FROM hd_chamado ch2 
                             INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
                                  WHERE eq2.cdempresa   = 1
                                    AND ch2.cdsituacao <> 8
                                    AND ch2.cdtipochamado IN (2,3,4,5)
                                    AND MONTH(ch2.dtchamado) = MONTH(ch.dtchamado)
                                    AND YEAR(ch2.dtchamado)  = YEAR(ch.dtchamado)), 2) AS Requisicoes
                           FROM hd_chamado ch 
                     INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                          WHERE eq.cdempresa = 1
                            AND ch.cdsituacao <> 8
                            AND ch.cdtipochamado IN (2,3,4,5)
                            AND MONTH(ch.dtchamado) = $nr_mes
                            AND  YEAR(ch.dtchamado) = $nr_ano
                       GROUP BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 68 - REQUISI��ES SOLUCIONADAS POR TIPO
			case 68:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ti.nmtipochamado                                                 AS Tipo, 
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado IN (2,3,4,5)
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2)            AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), ti.nmtipochamado
							  ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;		

			// 69 - REQUISI��ES SOLUCIONADAS NO PRAZO
			case 69:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Requisicao'                                                     AS Tipo,
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado IN (2,3,4,5)
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2)           AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
							
							UNION
							
							    SELECT ti.nmtipochamado                                                 AS Tipo,
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado = ch.cdtipochamado
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2)           AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), ch.cdtipochamado, ti.nmtipochamado";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			
			
			// 70 - REQUISI��ES SOLUCIONADAS POR N�VEL DE ATENDIMENTO
			case 70:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Requisicao'                                                     AS Tipo,
                                       dbo.consulta_nivel_atendimento(ch.cdchamado)                     AS Equipe,
                                       ROUND(COUNT(ch.cdchamado) * 100.00 /
                                      (SELECT COUNT(ch2.cdchamado)
                                         FROM hd_chamado ch2 
                                   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
                                        WHERE eq2.cdempresa   = 1
                                          AND ch2.cdsituacao <> 8
                                          AND ch2.cdtipochamado IN (2,3,4,5)
                                          AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
                                          AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2)           AS Requisicoes
                                  FROM hd_chamado ch 
                            INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                            INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
                                 WHERE eq.cdempresa   = 1
                                   AND ch.cdsituacao <> 8
                                   AND ch.cdtipochamado IN (2,3,4,5)
                                   AND MONTH(ch.dttermino) = $nr_mes
                                   AND  YEAR(ch.dttermino) = $nr_ano
                              GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), dbo.consulta_nivel_atendimento(ch.cdchamado)

							UNION

								SELECT ti.nmtipochamado                                                 AS Tipo,
							   		   dbo.consulta_nivel_atendimento(ch.cdchamado)                     AS Equipe,
									   ROUND(COUNT(ch.cdchamado) * 100.00 /
								   	  (SELECT COUNT(ch2.cdchamado)
										 FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
										WHERE eq2.cdempresa   = 1
									   	  AND ch2.cdsituacao <> 8
										  AND ch2.cdtipochamado = ch.cdtipochamado
										  AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
										  AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)), 2)           AS Requisicoes
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							 	 WHERE eq.cdempresa   = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
						      GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), dbo.consulta_nivel_atendimento(ch.cdchamado), ch.cdtipochamado, ti.nmtipochamado";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = utf8_encode($row['Equipe']);		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			
			
			// 71 - QUANTIDADE DE REQUISI��ES EM ABERTO POR TIPO E "IDADE"
			case 71:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @mmReferencia        CHAR(2)
								DECLARE @aaReferencia        CHAR(4)
								DECLARE @cdIdade             INT
								DECLARE @dsIdade             VARCHAR(15)
								DECLARE @qtDesenvolvimentos  INT
								DECLARE @nrDiasInicial       INT
								DECLARE @nrDiasFinal         INT

								DECLARE @Saida TABLE 
								(
									mmReferencia        CHAR(2),
									dsIdade             VARCHAR(15),
									qtDesenvolvimentos  INT
								)

								SET @mmReferencia = $nr_mes
								SET @aaReferencia = $nr_ano
								
								SET @cdIdade = 1

								WHILE @cdIdade <= 4 BEGIN

									SET @dsIdade = (CASE 
														WHEN @cdIdade = 1 THEN '<= 30 dias'
														WHEN @cdIdade = 2 THEN '31 a 60 dias'
														WHEN @cdIdade = 3 THEN '61 a 90 dias'
														WHEN @cdIdade = 4 THEN '>= 90 dias'
														ELSE ''
													END)

									SET @nrDiasInicial = 30 * (@cdIdade - 1)
									SET @nrDiasFinal   = 30 * @cdIdade

									IF @cdIdade = 1 SET @nrDiasInicial = -1
									IF @cdIdade = 4 SET @nrDiasFinal   = 2147483647

									SELECT @qtDesenvolvimentos = COUNT(ch.cdchamado)
									FROM hd_chamado ch 
									INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
									WHERE eq.cdempresa = 1
									AND ch.cdsituacao <> 8
									AND ch.cdtipochamado IN (2,3,4,5)
									AND convert(date, ch.dtchamado) < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
									AND (ch.dttermino IS NULL or (convert(date,ch.dttermino) >= DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))))
									and datediff(day,ch.dtchamado,DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE)))  > @nrDiasInicial
									and datediff(day,ch.dtchamado,DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))) <= @nrDiasFinal
									ORDER BY 1

									INSERT INTO @Saida (mmReferencia, dsIdade, qtDesenvolvimentos)
									SELECT @mmReferencia, @dsIdade, @qtDesenvolvimentos

									SET @cdIdade = @cdIdade + 1
								END

								SELECT dsIdade            AS Idade,
									   qtDesenvolvimentos AS Qtde
								  FROM @Saida";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							if($row['Idade'] == ">= 90 dias"){
								$nr_meta = "14";
							}else
							{
								if($row['Idade'] == "<= 30 dias"){
									$nr_meta = "59";
								}else{
									$nr_meta = "";
								}
							}

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = $row['Idade'];
							$this->nr_meta               = $nr_meta;
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			
			
			// 72 - QUANTIDADE DE REQUISI��ES ABERTAS POR TIPO
			case 72:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ti.nmtipochamado                                      AS Tipo,
									   COUNT(ch.cdchamado)  AS Qtde
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							 	 WHERE eq.cdempresa   = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND YEAR(ch.dtchamado)  = $nr_ano
								   AND MONTH(ch.dtchamado) = $nr_mes
							  GROUP BY ti.nmtipochamado";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 74 - QUANTIDADE DE REQUISI��ES SOLUCIONADAS POR TIPO E N�VEL DE ATENDIMENTO
			case 74:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT dbo.consulta_nivel_atendimento(ch.cdchamado)          AS Nivel,
								       ti.nmtipochamado                                      AS Tipo,
								       COUNT(ch.cdchamado)  AS Qtde
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND YEAR(ch.dttermino)  = $nr_ano
							       AND MONTH(ch.dttermino) = $nr_mes
							  GROUP BY dbo.consulta_nivel_atendimento(ch.cdchamado), ti.nmtipochamado
							  ORDER BY 1, 2";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Nivel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = utf8_encode($row['Tipo']);		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 75 - QUANTIDADE DE REQUISI��ES SOLUCIONADAS NO PRAZO OU FORA
			case 75:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Prazo'                                                          AS Prazo,
                                       'Requisicao'                                                     AS Tipo,
                                       COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado) ) = CAST(1 AS BIT)
								   
							UNION ALL

								SELECT 'Fora Prazo'                                                     AS Prazo,
									   'Requisicao'                                                     AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							  	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado) ) = CAST(0 AS BIT)

							UNION ALL

								SELECT 'Prazo'                                                          AS Prazo,
									   ti.nmtipochamado                                                 AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado) ) = CAST(1 AS BIT)
						      GROUP BY ch.cdtipochamado, ti.nmtipochamado
							  
							UNION ALL

								SELECT 'Fora Prazo'                                                     AS Prazo,
									   ti.nmtipochamado                                                 AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado) ) = CAST(0 AS BIT)
						      GROUP BY ch.cdtipochamado, ti.nmtipochamado
						      ORDER BY 2, 1 desc ";
							  							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = $row['Prazo'];		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			
			
			// 76 - QUANTIDADE DE REQUISI��ES SOLUCIONADAS POR N�VEL DE ATENDIMENTO
			case 76:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT dbo.consulta_nivel_atendimento(ch.cdchamado)          AS Nivel,
									   COUNT(ch.cdchamado)  AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND YEAR(ch.dttermino)  = $nr_ano
								   AND MONTH(ch.dttermino) = $nr_mes
							  GROUP BY dbo.consulta_nivel_atendimento(ch.cdchamado)";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Nivel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 77 - QUANTIDADE DE REQUISI��ES POR SERVI�O - TOP 10
			case 77:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT TOP 10 dbo.consulta_nome_categoria(ch.cdchamado)                AS Categoria,
											  COUNT(ch.cdchamado)     AS Abertura
								  FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
					 			 WHERE ch.cdempresa = 1
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dtchamado) = $nr_mes
								   AND  YEAR(ch.dtchamado) = $nr_ano
						  	  GROUP BY YEAR(ch.dtchamado), MONTH(ch.dtchamado), dbo.consulta_nome_categoria(ch.cdchamado)
						  	  ORDER BY 2 desc";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Categoria']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Abertura'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;		

			// 79 - QUANTIDADE DE REQUISI��ES SOLUCIONADAS POR TIPO
			case 79:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ti.nmtipochamado                                      AS Tipo,
									   COUNT(ch.cdchamado)  								 AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND YEAR(ch.dttermino)  = $nr_ano 
								   AND MONTH(ch.dttermino) = $nr_mes
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), ti.nmtipochamado";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 80 - QUANTIDADE TOTAL DE REQUISI��ES ABERTAS
			case 80:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.cdchamado)  AS Qtde
                                  FROM hd_chamado ch 
                            INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                                 WHERE eq.cdempresa   = 1
                                   AND ch.cdsituacao <> 8
                                   AND ch.cdtipochamado IN (2,3,4,5)
                                   AND YEAR(ch.dtchamado)  = $nr_ano
                                   AND MONTH(ch.dtchamado) = $nr_mes";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 81 - TEMPO M�DIO DE ATENDIMENTO POR RESPONS�VEL COM SUSPENS�O (DURA��O)
			case 81:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                                    AS Responsavel,  
                                       ROUND(SUM(dbo.consulta_Tempo_Chamado(ch.cdchamado,'HORA')) /
                                       COUNT(ch.cdchamado), 2)        AS Media,
                                       COUNT(ch.cdchamado)            AS Qtde
                                  FROM hd_chamado ch
                            INNER JOIN hd_equipe eq  ON(ch.cdequipe = eq.cdequipe)
                             LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
                                 WHERE YEAR(ch.dttermino)  = $nr_ano
                                   AND MONTH(ch.dttermino) = $nr_mes
                                   AND eq.cdempresa   = 1
                                   AND ch.cdsituacao <> 8
                                   AND ch.cdtipochamado IN (2,3,4,5)
                              GROUP BY us.nmusuario
                              ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 82 - TEMPO M�DIO DE ATENDIMENTO POR RESPONS�VEL SEM SUSPENS�O (DURA��O)
			case 82:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                                    AS Responsavel,  
									   COUNT(ch.cdchamado)            AS Qtde,
									   ROUND(SUM(isnull(ch.nrtempototal,0) /*/ 60*/) /
									   COUNT(ch.cdchamado), 2)        AS Media
								  FROM hd_chamado ch
							INNER JOIN hd_equipe eq  ON(ch.cdequipe = eq.cdequipe)
							 LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
								 WHERE YEAR(ch.dttermino)  = $nr_ano
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND eq.cdempresa   = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
							  GROUP BY us.nmusuario --, ch.cdchamado
						      ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = $row['Qtde'];		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 105 - TEMPO M�DIO DE AN�LISE POR RESPONS�VEL (ESFOR�O)
			case 105:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																   AND MONTH(ac.dtacompanhamento) = $nr_mes
																   AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 1, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 106 - TEMPO M�DIO DE APROVA��O DO OR�AMENTO POR RESPONS�VEL (ESFOR�O)
			case 106:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 205, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END
								
								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE' 
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 107 - TEMPO M�DIO DE EXECU��O (EXTERNA) POR RESPONS�VEL (ESFOR�O)
			case 107:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 206, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END

								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 108 - TEMPO M�DIO DE EXECU��O (INTERNA) POR RESPONS�VEL (ESFOR�O)
			case 108:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 213, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END

								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 109 - TEMPO M�DIO DE LIBERA��O POR RESPONS�VEL (ESFOR�O)
			case 109:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 209, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END

								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 110 - TEMPO M�DIO DE OR�AMENTO POR RESPONS�VEL (ESFOR�O)
			case 110:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 204, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END

								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;		

			// 111 - TEMPO M�DIO DE TESTES EXTERNOS (AREA/SOLICITANTE) POR RESPONS�VEL (ESFOR�O)
			case 111:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 208, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END

								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	

			// 112 - TEMPO M�DIO DE TESTES INTERNOS (TI) POR RESPONS�VEL (ESFOR�O)
			case 112:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @cdChamado INT
								DECLARE @Retorno TABLE 
								(
									CdChamado     INT,
									nmResponsavel VARCHAR(50),
									nrTempoEtapa  NUMERIC(11,2)
								)

								DECLARE cursor_chamado CURSOR FOR
									SELECT DISTINCT ch.cdchamado
									FROM dbo.hd_chamado ch
									INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
									INNER JOIN hd_acompanhamento ac ON (ac.cdchamado = ch.cdchamado
																	AND MONTH(ac.dtacompanhamento) = $nr_mes
																	AND YEAR(ac.dtacompanhamento)  = $nr_ano)
									WHERE eq.cdempresa       = 1
										AND ch.cdsituacao   <> 8
										AND ch.cdtipochamado = 8
								OPEN cursor_chamado

								FETCH NEXT FROM cursor_chamado INTO @cdChamado
								WHILE @@fetch_status = 0 BEGIN
								
									INSERT INTO @Retorno (CdChamado, nmResponsavel, nrTempoEtapa)
									SELECT @cdChamado, nmResponsavel, nrTempoEtapa FROM dbo.consulta_esforco_etapa_chamado(@cdChamado, 207, $nr_ano, $nr_mes, 'HORA')
									FETCH NEXT FROM cursor_chamado INTO @cdChamado
								END

								CLOSE cursor_chamado
								DEALLOCATE cursor_chamado
								
								SELECT nmResponsavel                                 AS Responsavel, 
									   isnull(ROUND(AVG(nrTempoEtapa * 1.00), 2), 0) AS Media
								  FROM @Retorno
								 WHERE nmResponsavel <> 'SOLICITANTE'
							  GROUP BY nmResponsavel";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Responsavel']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			

			// 113 - TEMPO M�DIO DE ATENDIMENTO POR RESPONS�VEL (ESFOR�O)
			case 113:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                                         AS Nome, 
									   round(sum(isnull(ac.nrduracao,0)) / count(DISTINCT ch.cdchamado), 2) AS Media
								  FROM hd_chamado ch
							INNER JOIN hd_acompanhamento ac ON (ch.cdchamado = ac.cdchamado)
							   	   AND YEAR(ac.dtacompanhamento)  = $nr_ano
								   AND MONTH(ac.dtacompanhamento) = $nr_mes
							INNER JOIN ad_usuario us ON (ac.cdusuario = us.cdusuario)
							INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
							  GROUP BY us.nmusuario
							  ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Nome']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			
			
			// 114 - TEMPO M�DIO DO ATENDIMENTO POR RESPONS�VEL
			case 114:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT us.nmusuario                                                         AS Nome, 
									   round(sum(isnull(ac.nrduracao,0)) / count(DISTINCT ch.cdchamado), 2) AS Media
								  FROM hd_chamado ch
						    INNER JOIN hd_acompanhamento ac ON (ch.cdchamado = ac.cdchamado
														   AND YEAR(ac.dtacompanhamento)  = $nr_ano
													       AND MONTH(ac.dtacompanhamento) = $nr_mes )
							INNER JOIN ad_usuario us ON (ac.cdusuario = us.cdusuario)
							INNER JOIN hd_equipe eq ON (eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa   = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
							  GROUP BY us.nmusuario
							  ORDER BY 1";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Nome']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Media'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 115 - QUANTIDADE TOTAL DE DESENVOLVIMENTOS ABERTOS
			case 115:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.cdchamado) AS Qtde
							      FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 8
							   	   AND  YEAR(ch.dtchamado) = $nr_ano
								   AND MONTH(ch.dtchamado) = $nr_mes
						      GROUP BY MONTH(ch.dtchamado), 
							            YEAR(ch.dtchamado)";
				
						$result = mssql_query($sql);
						
						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}

					}
			break;	

			// PERCENTUAL DE REDU��O DE INCIDENTES
			case 117:					 
					 if($conexaoSqlServer){
					
							$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
					
							$sql = "SELECT ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
										  (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))     
											 FROM hd_chamado ch2
									   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
											WHERE ch2.cdempresa      = 1
										   	  AND ch2.cdtipochamado  = 1
											  AND ch2.cdsituacao    <> 8
											  AND MONTH(ch2.dtchamado) = $nr_mes
											  AND YEAR(ch2.dtchamado) =  $nr_ano - 1), 2) - 100.00 AS Qtde
                                      FROM hd_chamado ch
                                INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                                     WHERE ch.cdempresa       = 1
                                       AND ch.cdtipochamado   = 1
                                       AND ch.cdsituacao     <> 8
									   AND ch.dspalavrachave not like '%EOU%'
                                       AND MONTH(ch.dtchamado) = $nr_mes
                                       AND YEAR(ch.dtchamado)  = $nr_ano";
					
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								$this->cd_indicador          = $cd_indicador;
								$this->cd_resultado          = 0;
								$this->nr_semana             = "0";
								$this->nr_mes                = $nr_mes;
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = "";
								$this->nr_meta               = "-2";
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";			
							
								$this->insereDadosOracle();
							
							}
							
							$sql = "SELECT ROUND((SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								  (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))     
									FROM hd_chamado ch2
									INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									WHERE ch2.cdempresa      = 1
									  AND ch2.cdtipochamado  = 1
									  AND ch2.cdsituacao    <> 8
									  AND MONTH(ch2.dtchamado) <= $nr_mes
									  AND YEAR(ch2.dtchamado) = $nr_ano - 1)), 2) - 100.00  AS Qtde
							FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							WHERE ch.cdempresa      = 1
							  AND ch.cdtipochamado  = 1
							  AND ch.cdsituacao    <> 8
							  AND MONTH(ch.dtchamado) <= $nr_mes
							  AND YEAR(ch.dtchamado) = $nr_ano
							  AND ch.dspalavrachave not like '%EOU%'";
							  
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								$this->cd_indicador          = $cd_indicador;
								$this->nr_semana             = "0";
								$this->nr_mes                = "";
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = "";
								$this->nr_meta               = "-2";
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";
							
								$this->insereDadosOracle();
							}
					}
			break;			
			
			// 120 - QUANTIDADE TOTAL DE INCIDENTES ENCERRADOS
			case 120:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Encerrados
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND YEAR(ch.dttermino)  = $nr_ano
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
						  	  ORDER BY YEAR(ch.dttermino), MONTH(ch.dttermino)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Encerrados'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;			

			// 121 - QUANTIDADE TOTAL DE REQUISI��ES ENCERRADAS
			case 121:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.cdchamado)  AS Qtde
                                  FROM hd_chamado ch 
                            INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                                 WHERE eq.cdempresa   = 1
                                   AND ch.cdsituacao <> 8
                                   AND ch.cdtipochamado IN (2,3,4,5)
                                   AND YEAR(ch.dttermino)  = $nr_ano
                                   AND MONTH(ch.dttermino) = $nr_mes";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "Requisicao";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;

			// 123 - PERCENTUAL DE INCIDENTES INICIADOS NO PRAZO (RESPOSTA)
			case 123:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								      (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
										 FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
										WHERE eq2.cdempresa     = 1
										  AND ch2.cdsituacao   <> 8
										  AND ch2.cdtipochamado = 1
										  AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
										  AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
										  AND dbo.consulta_tipo_compromisso(ch2.cdchamado) = 'RESPOSTA'), 2) AS Incidentes
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
							  ORDER BY YEAR(ch.dttermino), MONTH(ch.dttermino)";
							  
							  
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "85";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 124 - PERCENTUAL DE INCIDENTES SOLUCIONADOS NO PRAZO (SOLUCAO)
			case 124:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								      (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
										 FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
										WHERE eq2.cdempresa     = 1
										  AND ch2.cdsituacao   <> 8
										  AND ch2.cdtipochamado = 1
										  AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
										  AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
										  AND dbo.consulta_tipo_compromisso(ch2.cdchamado) = 'SOLUCAO'), 2) AS Incidentes
								  FROM hd_chamado ch 
						    INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 1
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
							  ORDER BY YEAR(ch.dttermino), MONTH(ch.dttermino)";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "85";
							$this->nr_resultado          = $row['Incidentes'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 125 - REQUISI��ES SOLUCIONADAS NO PRAZO (RESPOSTA)
			case 125:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Requisicao'                                                     AS Tipo,
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado IN (2,3,4,5)
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
										  AND dbo.consulta_tipo_compromisso(ch2.cdchamado) = 'RESPOSTA'), 2)           AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
							
							UNION
							
							    SELECT ti.nmtipochamado                                                 AS Tipo,
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado = ch.cdtipochamado
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
										  AND dbo.consulta_tipo_compromisso(ch2.cdchamado) = 'RESPOSTA'), 2)           AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), ch.cdtipochamado, ti.nmtipochamado";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	
			
			// 126 - REQUISI��ES SOLUCIONADAS NO PRAZO (SOLUCAO)
			case 126:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Requisicao'                                                     AS Tipo,
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado IN (2,3,4,5)
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
										  AND dbo.consulta_tipo_compromisso(ch2.cdchamado) = 'SOLUCAO'), 2)           AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
							
							UNION
							
							    SELECT ti.nmtipochamado                                                 AS Tipo,
								       ROUND(COUNT(ch.cdchamado) * 100.00 /
								      (SELECT COUNT(ch2.cdchamado)
									     FROM hd_chamado ch2 
								   INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
									    WHERE eq2.cdempresa   = 1
									      AND ch2.cdsituacao <> 8
									      AND ch2.cdtipochamado = ch.cdtipochamado
									      AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
									      AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
										  AND dbo.consulta_tipo_compromisso(ch2.cdchamado) = 'SOLUCAO'), 2)           AS Requisicoes
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(1 AS BIT)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino), ch.cdtipochamado, ti.nmtipochamado";
							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Requisicoes'];
							$this->ds_detalhe_indicador2 = "";		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	
			
			// 127 - QUANTIDADE DE REQUISI��ES INICIADAS NO PRAZO OU FORA (RESPOSTA)
			case 127:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Prazo'                                                          AS Prazo,
                                       'Requisicao'                                                     AS Tipo,
                                       COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(1 AS BIT)
								   
							UNION ALL

								SELECT 'Fora Prazo'                                                     AS Prazo,
									   'Requisicao'                                                     AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							  	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(0 AS BIT)

							UNION ALL

								SELECT 'Prazo'                                                          AS Prazo,
									   ti.nmtipochamado                                                 AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(1 AS BIT)
						      GROUP BY ch.cdtipochamado, ti.nmtipochamado
							  
							UNION ALL

								SELECT 'Fora Prazo'                                                     AS Prazo,
									   ti.nmtipochamado                                                 AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(0 AS BIT)
						      GROUP BY ch.cdtipochamado, ti.nmtipochamado
						      ORDER BY 2, 1 desc ";
							  	
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = $row['Prazo'];		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	
			
			// 128 - QUANTIDADE DE REQUISI��ES SOLUCIONADAS NO PRAZO OU FORA (SOLUCAO)
			case 128:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Prazo'                                                          AS Prazo,
                                       'Requisicao'                                                     AS Tipo,
                                       COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							     WHERE eq.cdempresa = 1
							       AND ch.cdsituacao <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(1 AS BIT)
								   
							UNION ALL

								SELECT 'Fora Prazo'                                                     AS Prazo,
									   'Requisicao'                                                     AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
							  	 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(0 AS BIT)

							UNION ALL

								SELECT 'Prazo'                                                          AS Prazo,
									   ti.nmtipochamado                                                 AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(1 AS BIT)
						      GROUP BY ch.cdtipochamado, ti.nmtipochamado
							  
							UNION ALL

								SELECT 'Fora Prazo'                                                     AS Prazo,
									   ti.nmtipochamado                                                 AS Tipo,
									   COUNT(ch.cdchamado)             AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN hd_tipochamado ti ON(ti.cdtipochamado = ch.cdtipochamado)
								 WHERE eq.cdempresa = 1
								   AND ch.cdsituacao <> 8
								   AND ch.cdtipochamado IN (2,3,4,5)
								   AND MONTH(ch.dttermino) = $nr_mes
								   AND  YEAR(ch.dttermino) = $nr_ano
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
								   AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(0 AS BIT)
						      GROUP BY ch.cdtipochamado, ti.nmtipochamado
						      ORDER BY 2, 1 desc ";
							  							  
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Tipo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = $row['Prazo'];		
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;	
			
			// 129 - QUANTIDADE DE INCIDENTES INICIADOS NO PRAZO OU FORA (RESPOSTA)
			case 129:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Prazo'                                              AS Descricao,
								       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
							       AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(1 AS BIT)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND YEAR(ch.dttermino)  = $nr_ano
							
							UNION ALL
							
							    SELECT 'Fora Prazo'                                         AS Descricao,
								       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'RESPOSTA'
							       AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'RESPOSTA') = CAST(0 AS BIT)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND YEAR(ch.dttermino)  = $nr_ano";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Descricao']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 130 - QUANTIDADE DE INCIDENTES RESOLVIDOS NO PRAZO OU FORA (SOLUCAO)
			case 130:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Prazo'                                              AS Descricao,
								       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
							       AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(1 AS BIT)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND YEAR(ch.dttermino)  = $nr_ano
							
							UNION ALL
							
							    SELECT 'Fora Prazo'                                         AS Descricao,
								       SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
							      FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
								   AND dbo.consulta_tipo_compromisso(ch.cdchamado) = 'SOLUCAO'
							       AND dbo.consulta_se_prazo_chamado(ch.cdchamado, 'SOLUCAO') = CAST(0 AS BIT)
							       AND MONTH(ch.dttermino) = $nr_mes
							       AND YEAR(ch.dttermino)  = $nr_ano";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Descricao']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 131 - REAGENDAMENTOS DE DESENVOLVIMENTOS
			case 131:			
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT 'Agenda TI'           AS Motivo,
								   count(ch.cdchamado)   AS Qtde
								  FROM hd_chamado ch
							INNER JOIN hd_acompanhamento ac ON(ac.cdchamado = ch.cdchamado
														   AND ac.dsacompanhamento LIKE '>> Chamado prorrogado <<%Motivo: Programa��o da agenda de atendimento%'
														   AND  YEAR(ac.dtacompanhamento) = $nr_ano
														   AND MONTH(ac.dtacompanhamento) = $nr_mes)
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 8

							UNION ALL

							SELECT 'Pedido �rea'         AS Motivo,
								   count(ch.cdchamado)   AS Qtde
								  FROM hd_chamado ch
							INNER JOIN hd_acompanhamento ac ON(ac.cdchamado = ch.cdchamado
														   AND ac.dsacompanhamento LIKE '>> Chamado prorrogado <<%Motivo: Pedido do Solicitante%'
														   AND  YEAR(ac.dtacompanhamento) = $nr_ano
														   AND MONTH(ac.dtacompanhamento) = $nr_mes)
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
								 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 8";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Motivo']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}		
						
					}
			break;
			
			// 132- QUANTIDADE DE DOCUMENTOS CRIADOS NA BASE DE CONHECIMENTO
			case 132:			
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT count(DISTINCT doc.cddocumento)   AS Qtde
								  FROM bc_documento doc
								 WHERE doc.cdempresa          = 1
								   AND YEAR(doc.dtdocumento)  = $nr_ano
								   AND MONTH(doc.dtdocumento) = $nr_mes";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							if ($nr_mes <= 8){
								$meta = '17';
							}else{
								$meta = '18';
							}
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = $meta;
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}

						$sql = "SELECT count(DISTINCT doc.cddocumento)   AS Qtde
								  FROM bc_documento doc
								 WHERE doc.cdempresa          = 1
								   AND YEAR(doc.dtdocumento)  = $nr_ano
								   AND MONTH(doc.dtdocumento) BETWEEN 2 and $nr_mes";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = "";
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = 180;
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}
					}
			break;
			
			// Quantidade de incidentes abertos nos processo principais
			case 133:					 
					 if($conexaoSqlServer){
					
							$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
					
							$sql = "SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS Qtde
                                      FROM hd_chamado ch
                                INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                                     WHERE ch.cdempresa       = 1
                                       AND ch.cdtipochamado   = 1
                                       AND ch.cdsituacao     <> 8
									   AND ch.dspalavrachave not like '%EOU%'
                                       AND MONTH(ch.dtchamado) = $nr_mes
                                       AND YEAR(ch.dtchamado)  = $nr_ano
                                       AND dbo.consulta_cod_categoria(ch.cdchamado) IN (12,32,52,62,72,82,92,102,112,172,202,412,432,572,742)";
					
							$result = mssql_query($sql);

							while($row = mssql_fetch_array($result)){
							
								$this->cd_indicador          = $cd_indicador;
								$this->cd_resultado          = 0;
								$this->nr_semana             = "0";
								$this->nr_mes                = $nr_mes;
								$this->nr_ano                = $nr_ano;
								$this->ds_detalhe_indicador  = "";
								$this->nr_meta               = "";
								$this->nr_resultado          = $row['Qtde'];
								$this->ds_detalhe_indicador2 = "";
								
								$this->insereDadosOracle();
							}
					 }			
			break;
			
			// 135 - DESENVOLVIMENTOS ENCERRADOS NO M�S NO PRAZO
			case 135:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.dttermino) AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 8
								   AND  YEAR(ch.dttermino)  = $nr_ano
								   AND  MONTH(ch.dttermino) = $nr_mes
								   AND  CAST(ch.dttermino AS DATE) <= CAST(ch.dtprevisaotermino AS DATE)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;
			
			// 136 - DESENVOLVIMENTOS ENCERRADOS NO M�S FORA DO PRAZO
			case 136:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.dttermino) AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   <> 8
								   AND ch.cdtipochamado = 8
								   AND  YEAR(ch.dttermino)  = $nr_ano
								   AND  MONTH(ch.dttermino) = $nr_mes
								   AND  CAST(ch.dttermino AS DATE) > CAST(ch.dtprevisaotermino AS DATE)
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;
			
			// 137 - DESENVOLVIMENTOS CANCELADOS NO M�S
			case 137:
					if($conexaoSqlServer){
		
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT COUNT(ch.dttermino) AS Qtde
								  FROM hd_chamado ch 
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							 	 WHERE eq.cdempresa     = 1
								   AND ch.cdsituacao   = 8
								   AND ch.cdtipochamado = 8
								   AND  YEAR(ch.dttermino)  = $nr_ano
								   AND  MONTH(ch.dttermino) = $nr_mes
							  GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}	
						
					}
			break;
			
			// 138 - DESENVOLVIMENTO POR ETAPA
			case 138:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SELECT isnull(etapa.nmsubsituacao, 'Aguardando Atendimento') AS Etapa,
									   count(ch.cdchamado)                                   AS Qtde
								  FROM hd_chamado ch
							LEFT JOIN hd_chamadoretencaosubsituacao chrss ON (chrss.cdchamado = ch.cdchamado
																		   AND chrss.nrsequencia = (SELECT MAX(chrss2.nrsequencia)
																									  FROM hd_chamadoretencaosubsituacao chrss2
																									 WHERE chrss2.cdchamado = chrss.cdchamado))
							LEFT JOIN hd_estruturasubsituacaoitem etapa on (etapa.nrsequencia = chrss.cdsubsituacao)
								 WHERE ch.cdempresa = 1
								   AND ch.cdtipochamado = 8
								   AND ch.cdsituacao NOT IN (7,8)
							  GROUP BY etapa.nmsubsituacao";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Etapa']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 146 - Prazo de solicita��es/demandas para TI
			case 146:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "DECLARE @Ano         INT
								DECLARE @Mes         INT

								SET @Ano = $nr_ano
								SET @Mes = $nr_mes

								SELECT ROUND(SUM(q1.Prazo) / COUNT(q1.Prazo), 2) AS Qtde
									FROM
									(SELECT tp.nmtipochamado AS Tipo,
										   ROUND((SELECT ISNULL((SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch3.cdchamado))
																  FROM hd_chamado ch3 
															INNER JOIN hd_equipe eq3 ON(eq3.cdequipe = ch3.cdequipe)
																 WHERE eq3.cdempresa = 1
																   AND ch3.cdsituacao <> 8
																   AND ch3.cdtipochamado = tp.cdtipochamado
																   AND YEAR(ch3.dtchamado) = @Ano
																   AND MONTH(ch3.dttermino) = @Mes
																   AND YEAR(ch3.dttermino)  = @Ano
																   AND dbo.consulta_se_prazo_chamado(ch3.cdchamado, dbo.consulta_tipo_compromisso(ch3.cdchamado)) = CAST(1 AS BIT)),0)
														* 100.00 /
														SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) 
												   FROM hd_chamado ch 
											 INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
												  WHERE eq.cdempresa = 1
													AND ch.cdsituacao <> 8
													AND ch.cdtipochamado = tp.cdtipochamado
													AND YEAR(ch.dtchamado) = @Ano
													AND MONTH(ch.dttermino) = @Mes
													AND YEAR(ch.dttermino)  = @Ano), 2)                                     AS Prazo
									FROM hd_tipochamado tp
									WHERE tp.cdtipochamado IN (1,2,3,4,5)

									UNION ALL

									SELECT tp.nmtipochamado,
										   ROUND((SELECT ISNULL((SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch3.cdchamado))
																  FROM hd_chamado ch3 
															INNER JOIN hd_equipe eq3 ON(eq3.cdequipe = ch3.cdequipe)
																 WHERE eq3.cdempresa = 1
																   AND ch3.cdsituacao <> 8
																   AND ch3.cdtipochamado = tp.cdtipochamado
																   AND YEAR(ch3.dtchamado) = @Ano
																   AND MONTH(ch3.dttermino) = @Mes
																   AND YEAR(ch3.dttermino)  = @Ano
																   AND ch3.dttermino <= ch3.dtprevisaotermino),0)
														* 100.00 /
														SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) 
												   FROM hd_chamado ch 
											 INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
												  WHERE eq.cdempresa = 1
													AND ch.cdsituacao <> 8
													AND ch.cdtipochamado = tp.cdtipochamado
													AND YEAR(ch.dtchamado) = @Ano
													AND MONTH(ch.dttermino) = @Mes
													AND YEAR(ch.dttermino)  = @Ano), 2) AS Prazo
									FROM hd_tipochamado tp
									WHERE tp.cdtipochamado = 8) q1";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "84";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
						$sql = "DECLARE @Ano         INT

								SET @Ano = $nr_ano

								SELECT ROUND(SUM(q1.Prazo) / COUNT(q1.Prazo), 2) AS Qtde
								FROM
								(SELECT tp.nmtipochamado AS Tipo,
									   ROUND((SELECT ISNULL((SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch3.cdchamado))
																	  FROM hd_chamado ch3 
																INNER JOIN hd_equipe eq3 ON(eq3.cdequipe = ch3.cdequipe)
																	 WHERE eq3.cdempresa = 1
																	   AND ch3.cdsituacao <> 8
																	   AND ch3.cdtipochamado = tp.cdtipochamado
																	   AND YEAR(ch3.dtchamado)  = @Ano
																	   AND YEAR(ch3.dttermino)  = @Ano
																	   AND dbo.consulta_se_prazo_chamado(ch3.cdchamado, dbo.consulta_tipo_compromisso(ch3.cdchamado)) = CAST(1 AS BIT)),0)
															* 100.00 /
															SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) 
													   FROM hd_chamado ch 
												 INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
													  WHERE eq.cdempresa = 1
														AND ch.cdsituacao <> 8
														AND ch.cdtipochamado = tp.cdtipochamado
														AND YEAR(ch.dtchamado)  = @Ano
														AND YEAR(ch.dttermino)  = @Ano), 2)                                     AS Prazo
								FROM hd_tipochamado tp
								WHERE tp.cdtipochamado IN (1,2,3,4,5)

								UNION ALL

								SELECT tp.nmtipochamado,
									   ROUND((SELECT ISNULL((SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch3.cdchamado))
																	  FROM hd_chamado ch3 
																INNER JOIN hd_equipe eq3 ON(eq3.cdequipe = ch3.cdequipe)
																	 WHERE eq3.cdempresa = 1
																	   AND ch3.cdsituacao <> 8
																	   AND ch3.cdtipochamado = tp.cdtipochamado
																	   AND YEAR(ch3.dtchamado)  = @Ano
																	   AND YEAR(ch3.dttermino)  = @Ano
																	   AND ch3.dttermino <= ch3.dtprevisaotermino),0)
															* 100.00 /
															SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) 
													   FROM hd_chamado ch 
												 INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
													  WHERE eq.cdempresa = 1
														AND ch.cdsituacao <> 8
														AND ch.cdtipochamado = tp.cdtipochamado
														AND YEAR(ch.dtchamado)  = @Ano
														AND YEAR(ch.dttermino)  = @Ano), 2) AS Prazo
								FROM hd_tipochamado tp
								WHERE tp.cdtipochamado = 8) q1";
				
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){
						
							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = "";
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = "";
							$this->nr_meta               = "84";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();	

						}
						
					}
			break;
			
			// 151 - DESENVOLVIMENTO ATRASADOS POR ETAPA
			case 151:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON
								
								DECLARE @mmReferencia        CHAR(2)
								DECLARE @aaReferencia        CHAR(4)

								SET @mmReferencia = $nr_mes
								SET @aaReferencia = $nr_ano

								SELECT isnull(etapa.nmsubsituacao, 'Aguardando Atendimento') AS Etapa,
									   count(ch.cdchamado)                                   AS Qtde
								  FROM hd_chamado ch
							LEFT JOIN hd_chamadoretencaosubsituacao chrss ON (chrss.cdchamado = ch.cdchamado
																		   AND chrss.nrsequencia = (SELECT MAX(chrss2.nrsequencia)
																									  FROM hd_chamadoretencaosubsituacao chrss2
																									 WHERE chrss2.cdchamado = chrss.cdchamado))
							LEFT JOIN hd_estruturasubsituacaoitem etapa on (etapa.nrsequencia = chrss.cdsubsituacao)
								 WHERE ch.cdempresa = 1
								   AND ch.cdtipochamado = 8
								   AND ch.cdsituacao NOT IN (7,8)
								   AND ch.dtprevisaotermino < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
							  GROUP BY etapa.nmsubsituacao";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Etapa']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 152 - DESENVOLVIMENTO ATRASADOS POR RESPONSAVEL
			case 152:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON
								
								DECLARE @mmReferencia        CHAR(2)
								DECLARE @aaReferencia        CHAR(4)

								SET @mmReferencia = $nr_mes
								SET @aaReferencia = $nr_ano

								SELECT isnull(us.nmusuario, 'Sem Responsavel')               AS Usuario,
									   count(ch.cdchamado)                                   AS Qtde
								  FROM hd_chamado ch
							 LEFT JOIN ad_usuario us on (us.cdusuario = ch.cdresponsavel)
								 WHERE ch.cdempresa = 1
								   AND ch.cdtipochamado = 8
								   AND ch.cdsituacao NOT IN (7,8)
								   AND ch.dtprevisaotermino < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
							  GROUP BY us.nmusuario";
								   
						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = utf8_encode($row['Usuario']);
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			// 153 - DESENVOLVIMENTO ATRASADOS POR QTDE DE DIAS
			case 153:
					if($conexaoSqlServer){
				
						$base = mssql_select_db('QualitorV8_prod',$conexaoSqlServer);
				
						$sql = "SET NOCOUNT ON

								DECLARE @mmReferencia        CHAR(2)
								DECLARE @aaReferencia        CHAR(4)

								SET @mmReferencia = $nr_mes
								SET @aaReferencia = $nr_ano

								SELECT datediff(DAY, ch.dtprevisaotermino, DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE)))               AS Dias,
									   count(ch.cdchamado)                                   																			 AS Qtde
								  FROM hd_chamado ch
							 LEFT JOIN ad_usuario us on (us.cdusuario = ch.cdresponsavel)
								 WHERE ch.cdempresa = 1
								   AND ch.cdtipochamado = 8
								   AND ch.cdsituacao NOT IN (7,8)
								   AND ch.dtprevisaotermino < DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE))
							  GROUP BY datediff(DAY, ch.dtprevisaotermino, DATEADD(MONTH, 1, CAST((@aaReferencia + '-' + @mmReferencia + '-01') AS DATE)))";

						$result = mssql_query($sql);

						while($row = mssql_fetch_array($result)){

							$this->cd_indicador          = $cd_indicador;
							$this->cd_resultado          = 0;
							$this->nr_semana             = "0";
							$this->nr_mes                = $nr_mes;
							$this->nr_ano                = $nr_ano;
							$this->ds_detalhe_indicador  = $row['Dias'];
							$this->nr_meta               = "";
							$this->nr_resultado          = $row['Qtde'];
							$this->ds_detalhe_indicador2 = "";			
						
							$this->insereDadosOracle();
						
						}
						
					}
			break;
			
			
		} // end switch/case
		
		mssql_close($conexaoSqlServer);
		
	} // end function
	
} // end class
?>