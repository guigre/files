<?php
class IndicadoresTI extends Utils{
	
	function listaDepartamentosByDescricao(){
        $this->abreConexaoMssql();
		$query = "SELECT cddepartamento, nmdepartamento FROM ad_departamento WHERE cdempresa = 1 ORDER BY nmdepartamento ASC";
        $retorno = array();         
		$result = mssql_query( $this->abreConexaoMssql, $query );			
		while($row = mssql_fetch_array( $result, MSSQL_ASSOC)){
			array_push($retorno,$row);
		}
        return $retorno;		 
    }
	
	function total($indicador,$ano){
		$this->abreConexaoOracle();
		$sql = "SELECT sum(nr_resultado) 
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
				 WHERE i.id   = $indicador 
				   AND nr_ano = $ano";
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		$row = oci_fetch_row($consulta);				   
		if($row[0] > 0){
			return $row[0];
		}else{
			return 0;
		}
	}
	
	function totalEncerrados($indicador,$ano,$prazo){
		$this->abreConexaoOracle();
		$sql = "SELECT sum(nr_resultado) 
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
				 WHERE i.id   = $indicador 
				   AND nr_ano = $ano
				   AND ir.ds_detalhe_indicador = '$prazo'";
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		$row = oci_fetch_row($consulta);				   
		if($row[0] > 0){
			return $row[0];
		}else{
			return 0;
		}
	}
	
	function totalReqEncerradas($indicador,$ano,$prazo){
		$this->abreConexaoOracle();
		$sql = "SELECT sum(nr_resultado) 
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
				 WHERE i.id   = $indicador 
				   AND nr_ano = $ano
				   AND ir.ds_detalhe_indicador = 'Requisicao'
				   AND ir.ds_detalhe_indicador2 = '$prazo'";
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		$row = oci_fetch_row($consulta);				   
		if($row[0] > 0){
			return $row[0];
		}else{
			return 0;
		}
	}

	function graficoTotal($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$grafico = array();		
		$sql = "SELECT ir.nr_mes,
                       ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$grafico[$row[0]] = (int)$row[1];			
		}
		
		ksort($grafico);
		
		return $grafico;
		
	}
	
	function graficoTotalIncidentesReabertos($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.nr_mes,
                       ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]] = (double)str_replace(",",".",$row[1]);			
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}	
	
	function graficoTotalIncidentesPrazo($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.nr_mes,
		               ir.nr_meta,
                       ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]]['meta'] = $row[1];			
			$incidentes[$row[0]]['resultado'] = str_replace(",",".",$row[2]);			
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}

	function graficoTotalIncidentesPrazoRepostaSolucao($indicadorInicial,$indicadorFinal,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT i.id,
		               ir.nr_mes,
                       ir.nr_resultado,
					   ir.nr_meta
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE (i.id   = $indicadorInicial
                    OR 	i.id   = $indicadorFinal)			 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			if($row[0] == $indicadorInicial){
				$incidentes[$row[1]]['resposta'] = $row[2];			
				$incidentes[$row[1]]['meta']     = $row[3];			
			}else{
				$incidentes[$row[1]]['solucao'] = $row[2];
				$incidentes[$row[1]]['meta']    = $row[3];
			}		
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}	
	
	function graficoTotalIncidentesNivel($indicador,$ano,$mes){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
                       sum(ir.nr_resultado)					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND ir.nr_ano = $ano 
				   AND ir.nr_mes = $mes 
			  GROUP BY ir.ds_detalhe_indicador";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]] = (double)str_replace(",",".",$row[1]);			
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}

	function graficoTotalIncidentesSeveridade($indicador,$ano,$mes){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
                       sum(ir.nr_resultado)					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND ir.nr_ano = $ano 
				   AND ir.nr_mes = $mes 
			  GROUP BY ir.ds_detalhe_indicador";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]] = (double)str_replace(",",".",$row[1]);			
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}	
	
	function graficoTotalIncidentesMaiores90($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.nr_mes,
					   ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND ir.ds_detalhe_indicador = '>= 90 dias' 
			  ORDER BY ir.nr_mes";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]]['resultado'] = $row[2];			
			$incidentes[$row[0]]['meta']      = $row[1];			
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}

	function graficoTotalIncidentesBacklog($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.nr_mes,
					   sum(ir.nr_meta),
                       sum(ir.nr_resultado)
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
			  GROUP BY ir.nr_mes		
			  ORDER BY ir.nr_mes";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]]['resultado'] = $row[2];			
			$incidentes[$row[0]]['meta']      = $row[1];			
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}	
	
	function graficoTotalIncidentesServico($indicador,$ano,$mes){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ds_detalhe_indicador, 
		               sum(nr_resultado)
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND ir.nr_mes = $mes
			  GROUP BY ds_detalhe_indicador 
			  ORDER BY sum(nr_resultado) desc";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]] = (int)$row[1];			
		}
		
		//$incidentes);
		
		return $incidentes;
		
	}

	function graficoTotalIncidentesServicoAnual($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ds_detalhe_indicador, 
		               sum(nr_resultado)
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
			  GROUP BY ds_detalhe_indicador 
			  ORDER BY sum(nr_resultado) desc";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]] = (int)$row[1];			
		}
		
		//$incidentes);
		
		return $incidentes;
		
	}	
	
	function percentualFinalPPR($indicador,$ano){
		$this->abreConexaoOracle();
		$sql = "SELECT ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND (ir.nr_mes IS NULL OR ir.nr_mes = 13) 		
			  ORDER BY ir.nr_mes";
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		$row = oci_fetch_row($consulta);
		$incidentes['resultado'] = (double)str_replace(",",".",$row[1]);
		$incidentes['meta']      = (double)str_replace(",",".",$row[0]);
		return $incidentes;	
	}	
	
	function graficoDocumentosPPR($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.nr_mes,
					   ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND ir.nr_mes IS NOT NULL		
			  ORDER BY ir.nr_mes";		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]]['resultado'] = (double)str_replace(",",".",$row[2]);			
			$incidentes[$row[0]]['meta']      = (double)str_replace(",",".",$row[1]);			
		}
		
		//ksort($incidentes);
		
		return $incidentes;
		
	}	
	
	function prazoSolicitacaoDemandas($indicador,$ano){
		$this->abreConexaoOracle();
		$sql = "SELECT ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND (ir.nr_mes IS NULL OR ir.nr_mes = 13) 		
			  ORDER BY ir.nr_mes";
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		$row = oci_fetch_row($consulta);
		$incidentes['resultado'] = (double)str_replace(",",".",$row[1]);
		$incidentes['meta']      = (double)str_replace(",",".",$row[0]);
		return $incidentes;	
	}

	function graficoPrazoSolicitacaoDemandas($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$incidentes = array();		
		$sql = "SELECT ir.nr_mes,
					   ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND ir.nr_mes IS NOT NULL		
			  ORDER BY ir.nr_mes";		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$incidentes[$row[0]]['resultado'] = (double)str_replace(",",".",$row[2]);			
			$incidentes[$row[0]]['meta']      = (double)str_replace(",",".",$row[1]);			
		}
		
		//ksort($incidentes);
		
		return $incidentes;
		
	}	
	
	function percentualProjetos($indicador,$ano){
		$this->abreConexaoOracle();
		$sql = "SELECT ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano";
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		$row = oci_fetch_row($consulta);
		$incidentes['resultado'] = (double)str_replace(",",".",$row[1]);
		$incidentes['meta']      = (double)str_replace(",",".",$row[0]);
		return $incidentes;	
	}	
	
	function graficoPercentualRequisicoesPrazo($indicador,$ano,$mes,$tipo){
	    $this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.nr_ano, 
					   ir.nr_resultado 
			      FROM indicador_ti i 
            INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
                 WHERE i.id = $indicador 
				   AND ir.nr_ano = $ano 
				   AND ir.nr_mes = $mes 
				   AND ds_detalhe_indicador = '$tipo'";		
				   
		//print $sql."<br>";			
				   
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = (double)str_replace(",",".",$row[1]);
		}
		
		//ksort($incidentes);
		
		return $requisicoes;		
		
	}	
	
	function graficoPercentualReqPrazoTipo($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
				   AND ir.ds_detalhe_indicador != 'Requisicao'
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = $row[1];
		}
		ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoQtdeReqEncerTipoNivel($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.ds_detalhe_indicador2,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id)
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]][$row[1]] = $row[2];
		}
		//ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoRequisicoesAbertasTipo($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = $row[1];
		}
		ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoRequisicoesEncerradasTipo($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = $row[1];
		}
		ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoPercRequisicoesAbertasTipo($indicador,$ano,$mes){  
	    $this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
                       sum(ir.nr_resultado)					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND ir.nr_ano = $ano 
				   AND ir.nr_mes = $mes 
			  GROUP BY ir.ds_detalhe_indicador";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = (double)str_replace(",",".",$row[1]);			
		}
		
		ksort($requisicoes);
		return $requisicoes;
	}	
	
	function graficoPercRequisicoesEncerradasTipo($indicador,$ano,$mes){  
	    $this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
                       sum(ir.nr_resultado)					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND ir.nr_ano = $ano 
				   AND ir.nr_mes = $mes 
			  GROUP BY ir.ds_detalhe_indicador";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = (double)str_replace(",",".",$row[1]);			
		}
		
		ksort($requisicoes);
		return $requisicoes;
	}
	
	function graficoRequisicoesReabertas($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = $row[1];
		}
		ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoRequisicoesAbertasServico($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = $row[1];
		}
		arsort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoRequisicoesEncerradasNivel($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]] = $row[1];
		}
		ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoPercReqEncerTipoNivel($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.ds_detalhe_indicador2,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id)
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[1]][$row[0]] = $row[2];
		}
		//ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoTotalRequisicoesMaiores90($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.nr_mes,
					   ir.nr_meta,
                       ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
				   AND ir.ds_detalhe_indicador = '>= 90 dias' 
			  ORDER BY ir.nr_mes";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]]['resultado'] = $row[2];			
			$requisicoes[$row[0]]['meta']      = $row[1];			
		}
		
		ksort($requisicoes);
		
		return $requisicoes;
		
	}
	
	function graficoTotalRequisicoesBacklog($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$requisicoes = array();		
		$sql = "SELECT ir.nr_mes,
					   sum(ir.nr_meta),
                       sum(ir.nr_resultado)
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id = $indicador 				 
				   AND ir.nr_ano = $ano
			  GROUP BY ir.nr_mes		
			  ORDER BY ir.nr_mes";
		
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$requisicoes[$row[0]]['resultado'] = $row[2];			
			$requisicoes[$row[0]]['meta']      = $row[1];			
		}
		
		ksort($requisicoes);
		
		return $requisicoes;
	}
	
	function graficoTotalDesenvolvimentosPrazo($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.nr_mes,
		               ir.nr_meta,
                       ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]]['meta'] = $row[1];			
			$desenvolvimentos[$row[0]]['resultado'] = str_replace(",",".",$row[2]);			
		}
		
		ksort($desenvolvimentos);
		
		return $desenvolvimentos;
		
	}
	
	function graficoTotalDesenvolvimentosPrazoEFora($indicadorIni,$indicadorFim,$ano){  
	    $this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.nr_mes,
		               ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicadorIni 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]]['prazo'] = str_replace(",",".",$row[1]);			
		}
		
		$sql = "SELECT ir.nr_mes,
		               ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicadorFim 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]]['fora'] = str_replace(",",".",$row[1]);			
		}
		
		ksort($desenvolvimentos);
		
		return $desenvolvimentos;
		
	}
	
	function graficoTotalDesenvReagendados($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ds_detalhe_indicador";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]] = $row[1];
		}
		ksort($desenvolvimentos);
		
		return $desenvolvimentos;
	}
	
	function graficoTotalIncidentesDevidoDesenv($indicador,$ano){  
	    $this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.nr_mes,
		               ir.nr_resultado					   
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir 
			        ON (i.id = ir.id) 
			     WHERE i.id   = $indicador 				 
				   AND nr_ano = $ano 
			  ORDER BY nr_mes";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]]['resultado'] = str_replace(",",".",$row[1]);
		}
		
		ksort($desenvolvimentos);
		
		return $desenvolvimentos;
		
	}
	
	function graficoTotalDesenvolvimentosBacklog($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado,
					   ir.nr_meta
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ir.id_resultado";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]]['resultado'] = str_replace(",",".",$row[1]);
			$desenvolvimentos[$row[0]]['meta']      = str_replace(",",".",$row[2]);
		}
		//ksort($desenvolvimentos);
		
		return $desenvolvimentos;
	}
	
	function graficoTotalDesenvolvimentosEtapa($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ir.id_resultado";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]] = str_replace(",",".",$row[1]);
		}
		//ksort($desenvolvimentos);
		
		return $desenvolvimentos;
	}
	
	function graficoTotalDesenvolvForaPrazoEtapa($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ir.id_resultado";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]] = str_replace(",",".",$row[1]);
		}
		//ksort($desenvolvimentos);
		
		return $desenvolvimentos;
	}
	
	function graficoTotalDesenvolvForaPrazoResp($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ir.id_resultado";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]] = str_replace(",",".",$row[1]);
		}
		//ksort($desenvolvimentos);
		
		return $desenvolvimentos;
	}
	
	function graficoTotalDesenvolvForaPrazoDias($indicador,$ano,$mes){
	    
		$this->abreConexaoOracle();		
		$desenvolvimentos = array();		
		$sql = "SELECT ir.ds_detalhe_indicador,
					   ir.nr_resultado
		          FROM indicador_ti i 
		    INNER JOIN indicador_ti_resultado ir ON (i.id = ir.id) 
			     WHERE i.id   = $indicador
				   AND nr_ano = $ano
				   AND nr_mes = $mes
			  ORDER BY ir.id_resultado";
			  
		$consulta = oci_parse($this->conexaoOracle, $sql); 		
		oci_execute($consulta);			
		while($row = oci_fetch_row($consulta)){
			$desenvolvimentos[$row[0]] = str_replace(",",".",$row[1]);
		}
		//ksort($desenvolvimentos);
		
		return $desenvolvimentos;
	}
	
	
}

?>
