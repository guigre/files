<?php
class Cooperados extends Utils{

	function listaCooperados($programaChamador, $nrVersao){

		$wsdl = "http://srv-ws-prod01:8080/wsagpl/wsagpl/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/solicitaDadosCooperado/v0";
		
		$options = array('trace' => 1,'exceptions' => 1);
		
		$cooperado = new SoapClient($wsdl,$options); 
		
		try{
			$param = array('st_programaChamador' => $programaChamador,
						   'st_nrVersao' 		 => $nrVersao); 

			$resultado = (array)$cooperado->solicitaDadosCooperado($param);

			$cooperados = array();
				
			if(is_array($resultado) && count($resultado) > 0){
				$novosResultado = (array)$resultado[ct_ttPrestadores];
				
				if(count($novosResultado[ct_ttPrestadoresRow]) == 1){
					$cooperados = $novosResultado;			
				}else{
					$cooperados = (array)$novosResultado[ct_ttPrestadoresRow];	
				}	
			}
			
			sort($cooperados);
			
			return $cooperados;

		}catch(SoapFault $exception){
		
			$erro = $exception->detail->FaultDetail->errorMessage;
			return $erro;
		}
	}
}

?>