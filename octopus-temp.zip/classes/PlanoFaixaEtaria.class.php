<?php
class PlanoFaixaEtaria extends Utils{

	var $cdtabpreco; 
	var $cdmodalidade;
	var $cdplano; 
	var $cdtipoplano;
	var $cdgrauparentesco;
	var $nrfaixaetaria;	
	var $nridademinima; 
	var $nridademaxima;
	var $vlfatorfaixa;
	var $cduserid;
	var $dtatualizacao;
	
    var $tabela = "v_estfaixa";
	var $row;
      
    function cadastraPlanoFaixaEtaria($cdtabpreco, 
	                                  $cdmodalidade,
	                                  $cdplano, 
	                                  $cdtipoplano,
	                                  $cdgrauparentesco,
	                                  $nrfaixaetaria,	
	                                  $nridademinima, 
	                                  $nridademaxima,
	                                  $vlfatorfaixa,
	                                  $cduserid){
							   
	    $this->abreConexaoOracleOrquestra();
		
		$query = "INSERT INTO V_ESTFAIXA (cdtabpreco,
										  cdmodalidade,
										  cdplano, 
										  cdtipoplano,										    
										  cdgrauparentesco,
										  nrfaixaetaria,
										  nridademinima,
										  nridademaxima,
										  vlfatorfaixa,
										  cduserid,
										  dtatualizacao)
								 VALUES ('$cdtabpreco',
								          $cdmodalidade,
										  $cdplano, 
										  $cdtipoplano, 
										  $cdgrauparentesco,
										  $nrfaixaetaria,										   
										  $nridademinima,
										  $nridademaxima,
										  '".str_replace(",",".",$vlfatorfaixa)."',
										  $cduserid,
										  SYSDATE)";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
		
	}
	
	function existePlano($modalidade, $plano, $tipoPlano){
		$this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade as MODALIDADE, 
		                 cdplano as PLANO, 
						 cdtipoplano as TIPO
				    FROM V_PLANO
				   WHERE cdmodalidade = $modalidade 
				     AND cdplano      = $plano
					 AND cdtipoplano  = $tipoPlano";
				
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        $row = oci_fetch_assoc($consulta);        
		if(count($row) > 0){
			return true;
		}else{
			return false;
		}
	}
	
    function atualizaPlanoFaixaEtaria($cdtabpreco, 
	                                  $cdmodalidade,
	                                  $cdplano, 
	                                  $cdtipoplano,
	                                  $cdgrauparentesco,
	                                  $nrfaixaetaria,	
	                                  $nridademinima, 
	                                  $nridademaxima,
	                                  $vlfatorfaixa,
	                                  $cduserid){
							   
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela 
		 		     SET nridademinima    = '$nridademinima', 
					     nridademaxima    = '$nridademaxima',
						 vlfatorfaixa     = '".str_replace(",",".",$vlfatorfaixa)."'
				   WHERE cdtabpreco       = '$cdtabpreco'
				     AND cdmodalidade     = $cdmodalidade 
				     AND cdplano          = $cdplano						 
					 AND cdtipoplano      = $cdtipoplano						 
					 AND cdgrauparentesco = $cdgrauparentesco 
					 AND nrfaixaetaria    = $nrfaixaetaria";						 
						 
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);		

		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaPlanoFaixaEtaria(){
        $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdtabpreco,
						 cdmodalidade, 
						 cdplano, 
						 cdtipoplano, 
						 cdgrauparentesco,
						 nrfaixaetaria, 						  
						 nridademinima, 
						 nridademaxima,
						 vlfatorfaixa
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaPlanoFaixaEtaria($tabelaPreco,$modalidade,$plano,$tipoPlano,$grauParentesco,$faixaEtaria){
	    $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdtabpreco,
						 cdmodalidade, 
						 cdplano, 
						 cdtipoplano, 
						 cdgrauparentesco,
						 nrfaixaetaria, 						  
						 nridademinima, 
						 nridademaxima,
						 vlfatorfaixa
		  		    FROM $this->tabela
				   WHERE cdtabpreco       = '$tabelaPreco'
				     AND cdmodalidade     = $modalidade 
				     AND cdplano          = $plano						 
					 AND cdtipoplano      = $tipoPlano						 
					 AND cdgrauparentesco = $grauParentesco 
					 AND nrfaixaetaria    = $faixaEtaria";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
		    $this->cdtabpreco       = $row['CDTABPRECO'];
			$this->cdmodalidade     = $row['CDMODALIDADE']; 
            $this->cdplano          = $row['CDPLANO']; 
            $this->cdtipoplano      = $row['CDTIPOPLANO'];             
            $this->cdgrauparentesco = $row['CDGRAUPARENTESCO']; 
			$this->nrfaixaetaria    = $row['NRFAIXAETARIA'];
            $this->nridademinima    = $row['NRIDADEMINIMA']; 
            $this->nridademaxima    = $row['NRIDADEMAXIMA'];		
			$this->vlfatorfaixa     = $row['VLFATORFAIXA']; 
			return true;
	    }else{
			return false;
	    }
    } 
	
    function excluiPlanoFaixaEtaria($tabelaPreco,$modalidade,$plano,$tipoPlano,$grauParentesco,$faixaEtaria){
	    $this->abreConexaoOracleOrquestra();
	    $query = "DELETE 
		  		    FROM $this->tabela
				   WHERE cdtabpreco       = '$tabelaPreco'
				     AND cdmodalidade     = $modalidade 
				     AND cdplano          = $plano						 
					 AND cdtipoplano      = $tipoPlano						 
					 AND cdgrauparentesco = $grauParentesco 
					 AND nrfaixaetaria    = $faixaEtaria";					 
		$delete = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
    }	
	
}

?>
