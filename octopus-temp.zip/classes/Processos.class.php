<?php
class Processos extends Utils{

	var $id;
	var $descricao; 
	
    var $tabela = "v_processos";
	var $row;
      
    function cadastraProcesso($id,$descricao){
							   
	    $this->abreConexaoOracleOrquestra();
		
		$query = "INSERT INTO $this->tabela (id, 
									         descricao)
					                VALUES  ('$id', 
								   	         '$descricao')";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
    function atualizaProcesso($id,
	                       $descricao){
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela 
		 		     SET descricao = '$descricao'					 
				   WHERE id        = '$id'";						 
						 
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);		

		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaProcessos(){
        $this->abreConexaoOracleOrquestra();
		$query = "SELECT id, 
						 descricao
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaProcesso($id){
	    $this->abreConexaoOracleOrquestra();
	    $query = "SELECT id,
		                 descricao
		  		    FROM $this->tabela
				   WHERE id = '$id'";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
		    $this->id        = $row['ID']; 
            $this->descricao = $row['DESCRICAO'];
			return true;
	    }else{
			return false;
	    }
    } 

	function buscaProximoID(){
	    $this->abreConexaoOracleOrquestra();
	    $query = "SELECT max(id) + 1 as ID
		  		    FROM $this->tabela";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
			return $row['ID'];
	    }else{
			return 0;
	    }
	}
	
}

?>
