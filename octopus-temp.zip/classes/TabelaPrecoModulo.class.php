<?php
class TabelaPrecoModulo extends Utils{

	var $cdmodalidade;
	var $cdplano; 
	var $cdtipoplano; 
	var $cdtabpreco; 
	var $cdmodulo; 
	var $vlmodulo; 
	var $nridademinima; 
	var $nridademaxima;
	
    var $tabela = "v_tabestmod";
	var $row;
      
    function cadastraTabelaPrecoModulo($cdmodalidade,
	                                   $cdplano, 
	                                   $cdtipoplano, 
	                                   $cdtabpreco, 
	                                   $cdmodulo, 
	                                   $vlmodulo, 
	                                   $nridademinima,
	                                   $nridademaxima){
							   
	    $this->abreConexaoOracleOrquestra();

		
		$query = "INSERT INTO V_TABESTMOD (cdmodalidade,
										   cdplano, 
										   cdtipoplano, 
										   cdtabpreco, 
										   cdmodulo, 
										   vlmodulo, 
										   nridademinima,
										   nridademaxima)
								  VALUES ($cdmodalidade,
										  $cdplano, 
										  $cdtipoplano, 
										 '$cdtabpreco',  
										 '$cdmodulo', 
										  '".str_replace(",",".",$vlmodulo)."', 
										  $nridademinima,
										  $nridademaxima)";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
		
	}
	
	function existePlano($modalidade, $plano, $tipoPlano){
		$this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade as MODALIDADE, 
		                 cdplano as PLANO, 
						 cdtipoplano as TIPO
				    FROM V_PLANO
				   WHERE cdmodalidade = $modalidade 
				     AND cdplano      = $plano
					 AND cdtipoplano  = $tipoPlano";
				
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        $row = oci_fetch_assoc($consulta);        
		if(count($row) > 0){
			return true;
		}else{
			return false;
		}
	}
	
    function atualizaTabelaPrecoModulo($cdmodalidade,
	                                   $cdplano, 
	                                   $cdtipoplano, 
	                                   $cdtabpreco, 
	                                   $cdmodulo, 
	                                   $vlmodulo, 
	                                   $nridademinima,
	                                   $nridademaxima){
							   
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela 
		 		     SET vlmodulo      = '".str_replace(",",".",$vlmodulo)."',
					     nridademinima = '$nridademinima', 
					     nridademaxima = '$nridademaxima'
				   WHERE cdmodalidade  = $cdmodalidade 
				     AND cdplano       = $cdplano						 
					 AND cdtipoplano   = $cdtipoplano						 
					 AND cdtabpreco    = '$cdtabpreco'
					 AND cdmodulo      = '$cdmodulo'";						 
						 
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);		

		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaTabelaPrecoModulo(){
        $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade, 
						 cdplano, 
						 cdtipoplano, 
						 cdtabpreco, 
						 cdmodulo, 
						 vlmodulo, 
						 nridademinima, 
						 nridademaxima
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaTabelaPrecoModulo($modalidade,$plano,$tipoPlano,$tabelaPreco,$modulo){
	    $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade, 
						 cdplano, 
						 cdtipoplano, 
						 cdtabpreco, 
						 cdmodulo, 
						 vlmodulo, 
						 nridademinima, 
						 nridademaxima
		  		    FROM $this->tabela
				   WHERE cdmodalidade  =  $modalidade 
				     AND cdplano       =  $plano
					 AND cdtipoplano   =  $tipoPlano
					 AND cdtabpreco    = '$tabelaPreco'
					 AND cdmodulo      = '$modulo'";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
		    $this->cdmodalidade  = $row['CDMODALIDADE']; 
            $this->cdplano       = $row['CDPLANO']; 
            $this->cdtipoplano   = $row['CDTIPOPLANO']; 
            $this->cdtabpreco    = $row['CDTABPRECO']; 
            $this->cdmodulo      = $row['CDMODULO']; 
            $this->vlmodulo      = $row['VLMODULO']; 
            $this->nridademinima = $row['NRIDADEMINIMA']; 
            $this->nridademaxima = $row['NRIDADEMAXIMA'];		
			return true;
	    }else{
			return false;
	    }
    } 
	
    function excluiTabelaPrecoModulo($modalidade,$plano,$tipoPlano,$tabelaPreco,$modulo){
	    $this->abreConexaoOracleOrquestra();
	    $query = "DELETE 
		  		    FROM $this->tabela
				   WHERE cdmodalidade  =  $modalidade 
				     AND cdplano       =  $plano
					 AND cdtipoplano   =  $tipoPlano
					 AND cdtabpreco    = '$tabelaPreco'
					 AND cdmodulo      = '$modulo'";					 
		$delete = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
    }	
	
}

?>
