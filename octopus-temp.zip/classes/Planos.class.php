<?php
class Planos extends Utils{

	var $cdmodalidade;
	var $cdplano; 
	var $cdtipoplano; 
	var $dtiniciocomerc; 
	var $dtfimcomerc; 
	var $dsareageografica; 
	var $tipopessoa; 
	var $lgparticipacao; 
	var $lgsimulaapp; 
	var $cduserid; 
	var $dtatualizacao; 
	var $dstipocontratacao; 
	var $dsproduto; 
	var $dsacomodacao; 
	var $dsformapagto; 
	var $cdregistro; 
	var $dssegmentacao; 
	var $dsplano;	
	
    var $tabela = "v_plano";
	var $row;
      
    function cadastraPlano($cdmodalidade,
	                       $cdplano, 
	                       $cdtipoplano,
	                       $dtiniciocomerc,
	                       $dtfimcomerc,
	                       $dsareageografica,
	                       $tipopessoa,
	                       $lgparticipacao,
	                       $lgsimulaapp,
	                       $cduserid,
	                       $dstipocontratacao,
	                       $dsproduto,
	                       $dsacomodacao,
	                       $dsformapagto, 
	                       $cdregistro,
	                       $dssegmentacao,
	                       $dsplano){
							   
	    $this->abreConexaoOracleOrquestra();
		
		$query = "INSERT INTO V_PLANO (cdmodalidade, 
									   cdplano, 
									   cdtipoplano, 
									   dtiniciocomerc, 
									   dtfimcomerc, 
									   dsareageografica, 
									   tipopessoa, 
									   lgparticipacao, 
									   lgsimulaapp, 
									   cduserid, 
									   dtatualizacao, 
									   dstipocontratacao, 
									   dsproduto, 
									   dsacomodacao, 
									   dsformapagto, 
									   cdregistro, 
									   dssegmentacao, 
									   dsplano)
							  VALUES ('$cdmodalidade', 
								   	  '$cdplano', 
									  '$cdtipoplano', 
									  '".date('d-M-Y',strtotime($this->data_mysql($dtiniciocomerc)))."', 
									  '".date('d-M-Y',strtotime($this->data_mysql($dtfimcomerc)))."',  
									  '$dsareageografica', 
									  '$tipopessoa', 
									  '$lgparticipacao', 
									  '$lgsimulaapp', 
									  '$cduserid', 
									  SYSDATE, 
									  '$dstipocontratacao', 
									  '$dsproduto', 
									  '$dsacomodacao', 
									  '$dsformapagto', 
									  '$cdregistro', 
									  '$dssegmentacao', 
									  '$dsplano')";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function buscaValidadePlano($modalidade, $plano, $tipoPlano){
		$this->abreConexaoOracleOrquestra();	
		
		$query = "SELECT cdmodalidade as MODALIDADE, 
		                 cdplano as PLANO, 
						 cdtipoplano as TIPO, 
						 to_char(dtfimcomerc,'dd/mm/yyyy') as DATA 
				    FROM V_PLANO
				   WHERE cdmodalidade = $modalidade 
				     AND cdplano      = $plano
					 AND cdtipoplano  = $tipoPlano
					 AND dtfimcomerc  = (SELECT MAX(dtfimcomerc) FROM V_PLANO WHERE cdmodalidade = $modalidade 
																				AND cdplano      = $plano
																			    AND cdtipoplano  = $tipoPlano)";
				
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_assoc($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;	
		
	}
	
    function atualizaPlano($cdmodalidade,
	                       $cdplano, 
	                       $cdtipoplano,
	                       $dtiniciocomerc,
	                       $dtfimcomerc,
	                       $dsareageografica,
	                       $tipopessoa,
	                       $lgparticipacao,
	                       $lgsimulaapp,
	                       $cduserid,
	                       $dstipocontratacao,
	                       $dsproduto,
	                       $dsacomodacao,
	                       $dsformapagto, 
	                       $cdregistro,
	                       $dssegmentacao,
	                       $dsplano){
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela 
		 		     SET dtfimcomerc                          = '".date('d-M-Y',strtotime($this->data_mysql($dtfimcomerc)))."',
					     dsareageografica                     = '$dsareageografica',
					     tipopessoa                           = '$tipopessoa', 
					     lgparticipacao                       = '$lgparticipacao', 
					     lgsimulaapp                          = '$lgsimulaapp', 
					     cduserid                             = '$cduserid', 
					     dtatualizacao                        = SYSDATE,
					     dstipocontratacao                    = '$dstipocontratacao',
					     dsproduto                            = '$dsproduto', 
					     dsacomodacao                         = '$dsacomodacao', 
					     dsformapagto                         = '$dsformapagto', 
					     cdregistro                           = '$cdregistro', 
					     dssegmentacao                        = '$dssegmentacao', 
					     dsplano                              = '$dsplano'					 
				   WHERE cdmodalidade                         = $cdmodalidade 
				     AND cdplano                              = $cdplano						 
					 AND cdtipoplano                          = $cdtipoplano						 
					 AND to_char(dtiniciocomerc,'dd/mm/yyyy') = '$dtiniciocomerc'";						 
						 
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);		

		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}

    function findarPlano($modalidade,$plano,$tipoPlano,$dataInicio,$dataFim,$cduserid){
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela
		             SET dtfimcomerc                           = '".date('d-M-Y',strtotime($this->data_mysql($dataFim)))."',
					     cduserid							   = '$cduserid',
						 dtatualizacao						   = SYSDATE
				   WHERE cdmodalidade                          = $modalidade 
				     AND cdplano                               = $plano
					 AND cdtipoplano                           = $tipoPlano
					 AND to_char(dtiniciocomerc,'dd/mm/yyyy')  = '$dataInicio'";
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);
			return true;			
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaPlanos(){
        $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade, 
						 cdplano, 
						 cdtipoplano, 
						 to_char(dtiniciocomerc,'dd/mm/yyyy'), 
						 to_char(dtfimcomerc,'dd/mm/yyyy'), 
						 dsareageografica, 
						 tipopessoa, 
						 lgparticipacao, 
						 lgsimulaapp, 
						 cduserid, 
						 dtatualizacao, 
						 dstipocontratacao, 
						 dsproduto, 
						 dsacomodacao, 
						 dsformapagto, 
						 cdregistro, 
						 dssegmentacao, 
						 dsplano
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaPlano($modalidade,$plano,$tipoPlano,$dataInicio){
	    $this->abreConexaoOracleOrquestra();
	    $query = "SELECT cdmodalidade, 
		                 cdplano, 
		                 cdtipoplano, 
		                 to_char(dtiniciocomerc,'dd/mm/yyyy') as DTINICIOCOMERC,
		                 to_char(dtfimcomerc,'dd/mm/yyyy') as DTFIMCOMERC, 
		                 dsareageografica, 
		                 tipopessoa, 
		                 lgparticipacao, 
		                 lgsimulaapp, 
		                 cduserid, 
		                 dtatualizacao, 
		                 dstipocontratacao, 
		                 dsproduto, 
		                 dsacomodacao, 
		                 dsformapagto, 
		                 cdregistro, 
		                 dssegmentacao, 
		                 dsplano
		  		    FROM $this->tabela
				   WHERE cdmodalidade                          = $modalidade 
				     AND cdplano                               = $plano
					 AND cdtipoplano                           = $tipoPlano
					 AND to_char(dtiniciocomerc,'dd/mm/yyyy')  = '$dataInicio'";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
		    $this->cdmodalidade       = $row['CDMODALIDADE']; 
            $this->cdplano            = $row['CDPLANO']; 
            $this->cdtipoplano        = $row['CDTIPOPLANO']; 
            $this->dtiniciocomerc     = $row['DTINICIOCOMERC']; 
            $this->dtfimcomerc        = $row['DTFIMCOMERC']; 
            $this->dsareageografica   = $row['DSAREAGEOGRAFICA']; 
            $this->tipopessoa         = $row['TIPOPESSOA']; 
            $this->lgparticipacao     = $row['LGPARTICIPACAO']; 
            $this->lgsimulaapp        = $row['LGSIMULAAPP']; 
            $this->cduserid           = $row['CDUSERID']; 
            $this->dtatualizacao      = $row['DTATUALIZACAO']; 
            $this->dstipocontratacao  = $row['DSTIPOCONTRATACAO'];
            $this->dsproduto          = $row['DSPRODUTO']; 
            $this->dsacomodacao       = $row['DSACOMODACAO']; 
            $this->dsformapagto       = $row['DSFORMAPAGTO']; 
            $this->cdregistro         = $row['CDREGISTRO']; 
            $this->dssegmentacao      = $row['DSSEGMENTACAO']; 
            $this->dsplano            = $row['DSPLANO'];		
			return true;
	    }else{
			return false;
	    }
    } 	
}

?>
