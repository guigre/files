<?php
class Processos extends Utils{

	var $id_processo;
	var $id_pergunta; 
	
    var $tabela = "v_pergunta_processo";
	var $row;
      
    function cadastraPerguntaProcesso($id_processo,$id_pergunta){
							   
	    $this->abreConexaoOracleOrquestra();
		
		$query = "INSERT INTO $this->tabela (idprocesso, 
									         idpergunta)
					                VALUES  ('$id_processo', 
								   	         '$id_pergunta')";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaPerguntasByProcesso($id_processo){
        $this->abreConexaoOracleOrquestra();
		$query = "SELECT id, 
						 descricao
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }	
}

?>
