<?php
class Resultados extends Utils{

    var $id;
    var $id_resultado;
	var $ds_indicador;
	var $nr_semana;
    var $nr_mes;
    var $nr_ano;
	var $ds_detalhe_indicador;
	var $nr_meta;
	var $nr_resultado;
	var $ds_detalhe_indicador2;
    var $tabela = "indicador_ti_resultado";
	var $row;
      
    function cadastraResultado($idIndicador,$semana,$mes,$ano,$detalheIndicador,$meta,$resultado,$detalheIndicador2){
	    $this->abreConexaoOracle();
		$idResultado = $this->buscaUltimoCodigo() + 1;
		$query="INSERT INTO $this->tabela
		 				    (id_resultado,
							 id,
							 nr_semana,
							 nr_mes,
							 nr_ano,
							 ds_detalhe_indicador,
							 nr_meta,
							 nr_resultado,
							 ds_detalhe_indicador2) 
				     VALUES					   
					   	    ($idResultado,
						     $id,
							 $semana,
							 $mes,
							 $ano,
							'$detalheIndicador',
							 $meta,
							 $resultado,
							'$detalheIndicador2')";							
		$insert = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		if($resultado){
			oci_commit($this->conexaoOracle);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
    function atualizaResultado($idResultado,$idIndicador,$semana,$mes,$ano,$detalheIndicador,$meta,$resultado,$detalheIndicador2){
	    $this->abreConexaoOracle();		 
	    $query="UPDATE $this->tabela SET
				       nr_semana             = $semana,
				       nr_mes                = $mes,
				       nr_ano                = $ano,
				       ds_detalhe_indicador  = '$detalheIndicador',
				       nr_meta               = $meta,
				       nr_resultado          = $resultado,
				       ds_detalhe_indicador2 = '$detalheIndicador2'
			     WHERE id_resultado          = $idResultado
				   AND id                    = $idIndicador";
				 
		$update = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}

    function desativaResultado($id,$idResultado){
	    $this->abreConexaoOracle();		 
	    $query="DELETE
                  FROM $this->tabela
				 WHERE id = $id
				   AND id_resultado = $idResultado";
		$delete = oci_parse($this->conexaoOracle, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);				
		if($resultado){
			oci_commit($this->conexaoOracle);
			return true;			
		}else{
			oci_rollback($this->conexaoOracle);
			return false;
		}
	}
	
	function listaResultados(){
        $this->abreConexaoOracle();
		$query = "SELECT * 
		            FROM $this->tabela
			    ORDER BY id";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaResultado($id,$idResultado){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE id=$id
				     AND id_resultado=$idResultado";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);				   
	    if($row[0] > 0){
			$this->id                    = $row[0];
			$this->id_resultado          = $row[1];
			$this->nr_semana             = $row[2];
			$this->nr_mes                = $row[3];
			$this->nr_ano                = $row[4];
			$this->ds_detalhe_indicador  = $row[5];
			$this->nr_meta               = $row[6];
			$this->nr_resultado          = $row[7];
			$this->ds_detalhe_indicador2 = $row[8];			
			return true;
	    }else{
			return false;
	    }
    } 
	
    function buscaResultadoFiltro($indicador,$mes,$ano){
	    $this->abreConexaoOracle();
	    $query = "SELECT *
		  		    FROM $this->tabela
				   WHERE 1=1 ";				 
		if($indicador != ''){			
			$query .= "AND id = $indicador ";
		}
		if($mes != ''){			
			$query .= "AND nr_mes = $mes ";
		}
		if($ano != ''){			
			$query .= "AND nr_ano = $ano";
		}		
		$retorno = array();	
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }	
	
	function buscaUltimoCodigo(){
        $this->abreConexaoOracle();
		$query = "SELECT MAX(id_resultado) 
		            FROM $this->tabela";
		$consulta = oci_parse($this->conexaoOracle, $query);
		oci_execute($consulta);		
		$row = oci_fetch_row($consulta);
		return $row[0];
	}	
}

?>
