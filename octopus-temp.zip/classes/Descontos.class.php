<?php
class Descontos extends Utils{

	var $cdmodalidade;
	var $cdplano; 
	var $cdtipoplano; 
	var $nrminbenef; 
	var $nrmaxbenef; 
	var $vldesconto;
	var $cduserid;
	var $dtatualizacao;
	
    var $tabela = "v_estdesconto";
	var $row;
      
    function cadastraDesconto($cdmodalidade,
	                          $cdplano, 
	                          $cdtipoplano,
	                          $nrminbenef, 
	                          $nrmaxbenef, 
	                          $vldesconto,
	                          $cduserid){
							   
	    $this->abreConexaoOracleOrquestra();
		
		$query = "INSERT INTO $this->tabela (cdmodalidade, 
									   cdplano, 
									   cdtipoplano,
									   nrminbenef,	
									   nrmaxbenef,	
									   vldesconto,
									   cduserid, 
									   dtatualizacao)
							  VALUES ('$cdmodalidade', 
								   	  '$cdplano', 
									  '$cdtipoplano', 
									   $nrminbenef,
									   $nrmaxbenef,
									  '".str_replace(",",".",$vldesconto)."', 
									  '$cduserid', 
									  SYSDATE)";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
    function atualizaDesconto($cdmodalidade,
	                          $cdplano, 
	                          $cdtipoplano,
	                          $nrminbenef, 
	                          $nrmaxbenef, 
	                          $vldesconto,
	                          $cduserid){
							   
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela 
		 		     SET vldesconto    ='".str_replace(",",".",$vldesconto)."',
					     cduserid      = '$cduserid', 
					     dtatualizacao = SYSDATE					     
				   WHERE cdmodalidade  = $cdmodalidade 
				     AND cdplano       = $cdplano						 
					 AND cdtipoplano   = $cdtipoplano						 
					 AND nrminbenef    = $nrminbenef
					 AND nrmaxbenef    = $nrmaxbenef";						 
						 
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);		

		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaDescontos(){
        $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade,
		                 cdplano, 
		                 cdtipoplano,
		                 nrminbenef,	
		                 nrmaxbenef,	
		                 vldesconto,
		                 cduserid, 
		                 dtatualizacao		
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
        while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaDesconto($modalidade,$plano,$tipoPlano,$minBenef,$maxBenef){
	    $this->abreConexaoOracleOrquestra();
		$query = "SELECT cdmodalidade,
		                 cdplano, 
		                 cdtipoplano,
		                 nrminbenef,	
		                 nrmaxbenef,	
		                 vldesconto,
		                 cduserid, 
		                 dtatualizacao
		  		    FROM $this->tabela
				   WHERE cdmodalidade   = $modalidade 
				     AND cdplano        = $plano
					 AND cdtipoplano    = $tipoPlano
					 AND nrminbenef     = $minBenef
					 AND nrmaxbenef     = $maxBenef";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
			$this->cdmodalidade  = $row['CDMODALIDADE']; 
			$this->cdplano       = $row['CDPLANO'];
			$this->cdtipoplano   = $row['CDTIPOPLANO'];
			$this->nrminbenef    = $row['NRMINBENEF'];
            $this->nrmaxbenef    = $row['NRMAXBENEF'];
            $this->vldesconto    = $row['VLDESCONTO'];
            $this->cduserid      = $row['CDUSERID'];
            $this->dtatualizacao = $row['DTATUALIZACAO'];
			return true;
	    }else{
			return false;
	    }
    } 	
	
    function excluiDesconto($modalidade,$plano,$tipoPlano,$minBenef,$maxBenef){
	    $this->abreConexaoOracleOrquestra();
	    $query = "DELETE 
		  		    FROM $this->tabela
				   WHERE cdmodalidade  = $modalidade 
				     AND cdplano       = $plano						 
					 AND cdtipoplano   = $tipoPlano						 
					 AND nrminbenef    = $minBenef
					 AND nrmaxbenef    = $maxBenef";					 
		$delete = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
    }	
	
}

?>
