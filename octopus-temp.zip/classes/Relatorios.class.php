<?php
class Relatorios extends Utils{
	
	var $tabela = "indicador_ti_departamento";	
	
	function listaDepartamentosByDescricao(){
        $this->abreConexaoMssql();
		$query = "SELECT cddepartamento, nmdepartamento FROM ad_departamento WHERE cdempresa = 1 ORDER BY nmdepartamento ASC";
        $retorno = array();   
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$result = mssql_query( $query, $this->conexaoMssql );			
		while($row = mssql_fetch_array( $result, MSSQL_ASSOC)){
			array_push($retorno,$row);
		}
        return $retorno;		 
    }	

	/* --- PROCESSO DE INCIDENTES --- */
	function geraTabelaIncidentes($departamento,$dataIni,$dataFim){  
	    $this->abreConexaoMssql();	
        mssql_select_db("qualitorv8_prod",$this->conexaoMssql);		
		$incidentes = array();		
	
		$sql = "SELECT MONTH(ch.dtchamado) AS Mes, YEAR(ch.dtchamado) AS Ano, SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))  AS QtdeAbertos
										  FROM hd_chamado ch 
									INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
									INNER JOIN ad_contato co ON(co.cdcliente = 1
															AND co.cdcontato = ch.cdcontato)
									INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)									
										 WHERE eq.cdempresa     = 1
										   AND ch.cdsituacao   <> 8
										   AND ch.cdtipochamado = 1										   
										   AND convert(date,ch.dtchamado) >= CAST(('".$dataIni."') AS DATE)
										   AND convert(date,ch.dtchamado) <= CAST(('".$dataFim."') AS DATE)
										   AND de.cddepartamento   = $departamento
									  GROUP BY MONTH(ch.dtchamado),
									            YEAR(ch.dtchamado)
												   		   ORDER BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)"; 	

														   
	  
		$result = mssql_query( $sql, $this->conexaoMssql );
		
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
			
			  $periodo = str_pad($row['Mes'], 2, '0', STR_PAD_LEFT).$row['Ano']; 
			
			  $incidentes[$periodo]['QtdeAbertos'] = $row['QtdeAbertos'];
		}
		
	   $sqlEncerrados = "SELECT MONTH(ch.dttermino) AS Mes, YEAR(ch.dttermino) AS Ano, SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS QtdeEncerrados
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN ad_contato co ON(co.cdcliente = 1
													AND co.cdcontato = ch.cdcontato)
							INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)							
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 1
								   AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
								   AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)
								   AND de.cddepartamento = $departamento 
						      GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
								ORDER BY MONTH(ch.dttermino), YEAR(ch.dttermino)";							  
		
		$resultEncerrados = mssql_query( $sqlEncerrados, $this->conexaoMssql );
		
		while( $rowEncerrados = mssql_fetch_array( $resultEncerrados, MSSQL_ASSOC) ) {
			
			  $periodoEncerrado = str_pad($rowEncerrados['Mes'], 2, '0', STR_PAD_LEFT).$rowEncerrados['Ano'];	
			
			  $incidentes[$periodoEncerrado]['QtdeEncerrados'] = $rowEncerrados['QtdeEncerrados'];
		}
		
		ksort($incidentes);
		
		return $incidentes;
		
	}
	
	function geraGraficoTotalPrazoIncidentes($departamento,$dataIni,$dataFim){  
		$this->abreConexaoMssql();		
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$incidentesPrazo = array();
		
		$sqlPrazo = "SELECT MONTH(ch.dttermino) AS Mes, YEAR(ch.dttermino) AS Ano, ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))
			   * 100.00 /
			   (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
				  FROM hd_chamado ch2 
			INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
			INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
				   AND co2.cdcontato = ch2.cdcontato)
			INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
				 WHERE eq2.cdempresa = 1
				   AND ch2.cdsituacao <> 8
				   AND ch2.cdtipochamado = 1
				   AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
				   AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
				   AND de2.cddepartamento   = $departamento), 2)  AS 'Prazo'
		FROM hd_chamado ch 
		INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
			INNER JOIN ad_contato co ON(co.cdcliente = 1
				   AND co.cdcontato = ch.cdcontato)
			INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
		WHERE eq.cdempresa = 1
		AND ch.cdsituacao <> 8
		AND ch.cdtipochamado = 1
		AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
        AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)
		AND de.cddepartamento = $departamento
		AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(1 AS BIT)
		GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
		
		$resultPrazo = mssql_query( $sqlPrazo, $this->conexaoMssql );			
		while($rowPrazo = mssql_fetch_array( $resultPrazo, MSSQL_ASSOC)){
			
			$periodoPrazo = str_pad($rowPrazo['Mes'], 2, '0', STR_PAD_LEFT).$rowPrazo['Ano'];	
			$incidentesPrazo[$periodoPrazo] = round($rowPrazo['Prazo'],2);
		}
			
		/*print "<pre>";
		print_r($arrayTemp);
		print "<pre>";*/
		
		ksort($incidentesPrazo);
		
		return $incidentesPrazo;
	}
	
	function geraGraficoSeveridadeIncidentes($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();		
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$incidentesSeveridade = array();
		
		$sqlSeveridade = "SELECT se.nmseveridade AS Severidade,
							 ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								(SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								   FROM hd_chamado ch2 
							 INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
							 INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
								                 	   AND co2.cdcontato = ch2.cdcontato)
							 INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
								  WHERE eq2.cdempresa     = 1
									AND ch2.cdsituacao   <> 8
									AND ch2.cdtipochamado = 1
									AND de2.cddepartamento   = $departamento";
									
									if($acumulado){
										$sqlSeveridade .= " AND convert(date,ch2.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
														    AND convert(date,ch2.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
									}else{
										$sqlSeveridade .= " AND MONTH(ch2.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
														    AND YEAR(ch2.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
									}
									
		                            $sqlSeveridade .= "), 2) AS Resultado
							  FROM hd_chamado ch 
						INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
						INNER JOIN ad_contato co ON(co.cdcliente = 1
											   AND co.cdcontato = ch.cdcontato)
						INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
						INNER JOIN hd_severidade se ON(se.cdseveridade = ch.cdseveridade)
							 WHERE eq.cdempresa     = 1
							   AND ch.cdsituacao   <> 8
							   AND ch.cdtipochamado = 1";
							   
							   if($acumulado){
									$sqlSeveridade .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
													    AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
								}else{
									$sqlSeveridade .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
													    AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
								}
			
			$sqlSeveridade .= " AND de.cddepartamento = $departamento
						  GROUP BY se.nmseveridade
						  ORDER BY se.nmseveridade";
		

		$resultSeveridade = mssql_query( $sqlSeveridade, $this->conexaoMssql );			
		while($rowSeveridade = mssql_fetch_array( $resultSeveridade, MSSQL_ASSOC)){
			$incidentesSeveridade[$rowSeveridade['Severidade']] = round($rowSeveridade['Resultado'],2);
		}		
		
		/*print "<pre>";
		print_r($arrayTemp);
		print "<pre>";*/
		
		ksort($incidentesSeveridade);
		
		return $incidentesSeveridade;
	}
	
	function geraGraficoOrigemIncidentes($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();		
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$incidentesOrigem = array();
		
		$sqlOrigem = "SELECT ori.nmorigem AS Origem,
							 ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								(SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								   FROM hd_chamado ch2 
							 INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
							 INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
								                 	   AND co2.cdcontato = ch2.cdcontato)
							 INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
								  WHERE eq2.cdempresa     = 1
									AND ch2.cdsituacao   <> 8
									AND ch2.cdtipochamado = 1
									AND de2.cddepartamento   = $departamento";
									
									if($acumulado){
										$sqlOrigem .= " AND convert(date,ch2.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
												        AND convert(date,ch2.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
									}else{
										$sqlOrigem .= " AND MONTH(ch2.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
														AND YEAR(ch2.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
									}
									
		                            $sqlOrigem .= "), 2) AS Resultado
							  FROM hd_chamado ch 
						INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
						INNER JOIN ad_contato co ON(co.cdcliente = 1
											   AND co.cdcontato = ch.cdcontato)
						INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
						INNER JOIN hd_origem ori on(ori.cdorigem = ch.cdorigem)
							 WHERE eq.cdempresa     = 1
							   AND ch.cdsituacao   <> 8
							   AND ch.cdtipochamado = 1";
							   
							   if($acumulado){
									$sqlOrigem .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
													AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
								}else{
									$sqlOrigem .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
													AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
								}
			
			$sqlOrigem .= " AND de.cddepartamento = $departamento
						  GROUP BY ori.nmorigem
						  ORDER BY ori.nmorigem";

		$resultOrigem = mssql_query( $sqlOrigem, $this->conexaoMssql );			
		while($rowOrigem = mssql_fetch_array( $resultOrigem, MSSQL_ASSOC)){
			$incidentesOrigem[$rowOrigem['Origem']] = round($rowOrigem['Resultado'],2);
		}		
		
		/*print "<pre>";
		print_r($arrayTemp);
		print "<pre>";*/
		
		ksort($incidentesOrigem);
		
		return $incidentesOrigem;
	}
	
	function quantidadeTotalIncidentesServico($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$totalIncidentes = array();
		$queryTop = "SELECT TOP 10 dbo.consulta_nome_categoria(ch.cdchamado)       AS Categoria,
		 				 SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))      AS Abertura
						FROM hd_chamado ch
				  INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                  INNER JOIN ad_contato co ON(co.cdcliente = 1
                         AND co.cdcontato = ch.cdcontato)
                  INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)				  
					   WHERE ch.cdempresa   = 1
						 AND ch.cdtipochamado = 1
						 AND ch.cdsituacao <> 8";
						 
			if($acumulado){
				$queryTop .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
							   AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
			}else{
				$queryTop .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
							   AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
			}
						 
			$queryTop .= " AND de.cddepartamento = $departamento 
					GROUP BY dbo.consulta_nome_categoria(ch.cdchamado)
					ORDER BY 2 desc";		
		
			$result = mssql_query( $queryTop, $this->conexaoMssql );
			while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
				  $totalIncidentes[$row['Categoria']]['Abertura'] = $row['Abertura'];
			}
			return $totalIncidentes;
    }
	
    function quantidadeTotalIncidentesColaborador($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$totalIncidentes = array();
		$query = "SELECT TOP 10 co.nmcontato                                          AS Contato,
                                COUNT(ch.cdchamado)                                   AS Qtde
                    FROM hd_chamado ch 
              INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
              INNER JOIN ad_contato co ON(co.cdcliente = 1
                     AND co.cdcontato = ch.cdcontato)
              INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
                   WHERE eq.cdempresa = 1
                     AND ch.cdsituacao <> 8
                     AND ch.cdtipochamado = 1";
					 
				if($acumulado){
					$query .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
								AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
				}else{
					$query .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
								AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
				}
			
                $query .= " AND de.cddepartamento = $departamento
                GROUP BY co.nmcontato 
                ORDER BY 2 desc";		
		
			$result = mssql_query( $query, $this->conexaoMssql );
			while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
				  $totalIncidentes[$row['Contato']]['Qtde'] = $row['Qtde'];
			}
			return $totalIncidentes;
    }

    function incidentesAbertos($departamento){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$incidentesAbertos = array();
		$queryAberto = "SELECT ch.cdchamado                            AS Numero,
                               CONVERT(char,ch.dtchamado,103)          AS Data,
							   CONVERT(char,ch.dtprevisaotermino,103)  AS Previsao,
                               ch.dschamado                            AS Descricao,
							   co.nmcontato                            AS Contato,
                               si.nmsituacao                           AS Situacao,
							   si.cdsituacao                           AS CdSituacao
                          FROM hd_chamado ch
                    INNER JOIN hd_equipe eq  ON(eq.cdequipe = ch.cdequipe)
                    INNER JOIN ad_contato co ON(co.cdcliente = 1
                                            AND co.cdcontato = ch.cdcontato)
                    INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)      
                    INNER JOIN hd_situacao si ON(si.cdsituacao = ch.cdsituacao)
                         WHERE ch.cdempresa   = 1
                           AND ch.cdtipochamado = 1
                           AND ch.cdsituacao NOT IN (7,8)
                           AND de.cddepartamento = $departamento";		
		
		$result = mssql_query( $queryAberto, $this->conexaoMssql );
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
			  array_push($incidentesAbertos,$row);
		}
		return $incidentesAbertos;
    }	
	
	/* --- PROCESSO DE REQUISICOES --- */
	function geraTabelaRequisicoes($departamento,$dataIni,$dataFim){  
	    $this->abreConexaoMssql();
        mssql_select_db("qualitorv8_prod",$this->conexaoMssql);		
		$requisicoes = array();		

		$sql = "SELECT MONTH(ch.dtchamado) AS Mes, YEAR(ch.dtchamado) AS Ano, SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))  AS QtdeAbertos
										  FROM hd_chamado ch 
									INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
									INNER JOIN ad_contato co ON(co.cdcliente = 1
															AND co.cdcontato = ch.cdcontato)
									INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)									
										 WHERE eq.cdempresa     = 1
										   AND ch.cdsituacao   <> 8
										   AND ch.cdtipochamado IN (2,3,4,5)										   
										   AND convert(date,ch.dtchamado) >= CAST(('".$dataIni."') AS DATE)
										   AND convert(date,ch.dtchamado) <= CAST(('".$dataFim."') AS DATE)
										   AND de.cddepartamento   = $departamento
									  GROUP BY MONTH(ch.dtchamado),
									            YEAR(ch.dtchamado)
									  ORDER BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)"; 	
	  
		$result = mssql_query( $sql, $this->conexaoMssql );
		
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
		
			$periodo = str_pad($row['Mes'], 2, '0', STR_PAD_LEFT).$row['Ano']; 
			$requisicoes[$periodo]['QtdeAbertos'] = $row['QtdeAbertos'];
		}
		
		$sqlEncerrados = "SELECT MONTH(ch.dttermino) AS Mes, YEAR(ch.dttermino) AS Ano, SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) AS QtdeEncerrados
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN ad_contato co ON(co.cdcliente = 1
													AND co.cdcontato = ch.cdcontato)
							INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)							
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado IN (2,3,4,5)
								   AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
								   AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)
								   AND de.cddepartamento = $departamento 
						      GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
								ORDER BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
		
		$resultEncerrados = mssql_query( $sqlEncerrados, $this->conexaoMssql );
		
		while( $rowEncerrados = mssql_fetch_array( $resultEncerrados, MSSQL_ASSOC) ) {
			  $periodo = str_pad($rowEncerrados['Mes'], 2, '0', STR_PAD_LEFT).$rowEncerrados['Ano'];
			  $requisicoes[$periodo]['QtdeEncerrados'] = $rowEncerrados['QtdeEncerrados'];
		}
		
		ksort($requisicoes);
		
		return $requisicoes;		
	}

	
	function geraGraficoTotalRequisicoesPrazo($departamento,$dataIni,$dataFim){
		$this->abreConexaoMssql();
        mssql_select_db("qualitorv8_prod",$this->conexaoMssql);		
		$requisicoesPrazo = array();		

		$sqlPrazo = "SELECT MONTH(ch.dttermino) AS Mes, YEAR(ch.dttermino) AS Ano, ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))
			   * 100.00 /
			   (SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
				  FROM hd_chamado ch2 
			INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
			INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
				   AND co2.cdcontato = ch2.cdcontato)
			INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
				 WHERE eq2.cdempresa = 1
				   AND ch2.cdsituacao <> 8
				   AND ch2.cdtipochamado IN (2,3,4,5)
				   AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
				   AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
				   AND de2.cddepartamento   = $departamento), 2)  AS 'Prazo'
		FROM hd_chamado ch 
		INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
			INNER JOIN ad_contato co ON(co.cdcliente = 1
				   AND co.cdcontato = ch.cdcontato)
			INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
		WHERE eq.cdempresa = 1
		AND ch.cdsituacao <> 8
		AND ch.cdtipochamado IN (2,3,4,5)
		AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
        AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)
		AND de.cddepartamento = $departamento
		AND dbo.consulta_se_prazo_chamado(ch.cdchamado, dbo.consulta_tipo_compromisso(ch.cdchamado)) = CAST(1 AS BIT)
		GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
		
		$resultPrazo = mssql_query( $sqlPrazo, $this->conexaoMssql );			
		while($rowPrazo = mssql_fetch_array( $resultPrazo, MSSQL_ASSOC)){
			$periodoPrazo = str_pad($rowPrazo['Mes'], 2, '0', STR_PAD_LEFT).$rowPrazo['Ano'];	
			$requisicoesPrazo[$periodoPrazo] = round($rowPrazo['Prazo'],2);
		}
		
		ksort($requisicoesPrazo);
		
		return $requisicoesPrazo;
		
	}

	function geraGraficoSeveridadeRequisicoes($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();		
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$requisicoesSeveridade = array();
		
		$sqlSeveridade = "SELECT se.nmseveridade AS Severidade,
							 ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								(SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								   FROM hd_chamado ch2 
							 INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
							 INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
								                 	   AND co2.cdcontato = ch2.cdcontato)
							 INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
								  WHERE eq2.cdempresa     = 1
									AND ch2.cdsituacao   <> 8
									AND ch2.cdtipochamado IN (2,3,4,5)
									AND de2.cddepartamento   = $departamento";
									
									if($acumulado){
										$sqlSeveridade .= " AND convert(date,ch2.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
														    AND convert(date,ch2.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
									}else{
										$sqlSeveridade .= " AND MONTH(ch2.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
														    AND YEAR(ch2.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
									}
									
		                            $sqlSeveridade .= "), 2) AS Resultado
							  FROM hd_chamado ch 
						INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
						INNER JOIN ad_contato co ON(co.cdcliente = 1
											   AND co.cdcontato = ch.cdcontato)
						INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
						INNER JOIN hd_severidade se ON(se.cdseveridade = ch.cdseveridade)
							 WHERE eq.cdempresa     = 1
							   AND ch.cdsituacao   <> 8
							   AND ch.cdtipochamado IN (2,3,4,5)";
							   
							   if($acumulado){
									$sqlSeveridade .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
													    AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
								}else{
									$sqlSeveridade .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
													    AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
								}
			
			$sqlSeveridade .= " AND de.cddepartamento = $departamento
						  GROUP BY se.nmseveridade
						  ORDER BY se.nmseveridade";

		$resultSeveridade = mssql_query( $sqlSeveridade, $this->conexaoMssql );			
		while($rowSeveridade = mssql_fetch_array( $resultSeveridade, MSSQL_ASSOC)){
			$requisicoesSeveridade[$rowSeveridade['Severidade']] = round($rowSeveridade['Resultado'],2);
		}		
		
		/*print "<pre>";
		print_r($arrayTemp);
		print "<pre>";*/
		
		ksort($requisicoesSeveridade);
		
		return $requisicoesSeveridade;
	}
	
	function geraGraficoOrigemRequisicoes($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();		
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$requisicoesOrigem = array();
		
		$sqlOrigem = "SELECT ori.nmorigem AS Origem,
							 ROUND(SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado)) * 100.00 /
								(SELECT SUM(dbo.consulta_qtde_solicit_chamado(ch2.cdchamado))
								   FROM hd_chamado ch2 
							 INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
							 INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
								                 	   AND co2.cdcontato = ch2.cdcontato)
							 INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
								  WHERE eq2.cdempresa     = 1
									AND ch2.cdsituacao   <> 8
									AND ch2.cdtipochamado IN (2,3,4,5)
									AND de2.cddepartamento   = $departamento";
									
									if($acumulado){
										$sqlOrigem .= " AND convert(date,ch2.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
														AND convert(date,ch2.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
									}else{
										$sqlOrigem .= " AND MONTH(ch2.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
														AND YEAR(ch2.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
									}
									
		                            $sqlOrigem .= "), 2) AS Resultado
							  FROM hd_chamado ch 
						INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
						INNER JOIN ad_contato co ON(co.cdcliente = 1
											   AND co.cdcontato = ch.cdcontato)
						INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
						INNER JOIN hd_origem ori on(ori.cdorigem = ch.cdorigem)
							 WHERE eq.cdempresa     = 1
							   AND ch.cdsituacao   <> 8
							   AND ch.cdtipochamado IN (2,3,4,5)";
							   
							   if($acumulado){
									$sqlOrigem .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
													AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
								}else{
									$sqlOrigem .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
													AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
								}
			
			$sqlOrigem .= " AND de.cddepartamento = $departamento
						  GROUP BY ori.nmorigem
						  ORDER BY ori.nmorigem";

		$resultOrigem = mssql_query( $sqlOrigem, $this->conexaoMssql );			
		while($rowOrigem = mssql_fetch_array( $resultOrigem, MSSQL_ASSOC)){
			$requisicoesOrigem[$rowOrigem['Origem']] = round($rowOrigem['Resultado'],2);
		}		
		
		/*print "<pre>";
		print_r($arrayTemp);
		print "<pre>";*/
		
		ksort($requisicoesOrigem);
		
		return $requisicoesOrigem;
	}

    function quantidadeTotalRequisicoesServico($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$totalRequisicoes = array();
			$queryTop = "SELECT TOP 10 dbo.consulta_nome_categoria(ch.cdchamado)                 AS Categoria,
									   SUM(dbo.consulta_qtde_solicit_chamado(ch.cdchamado))      AS Abertura
						FROM hd_chamado ch
				  INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                  INNER JOIN ad_contato co ON(co.cdcliente = 1
                         AND co.cdcontato = ch.cdcontato)
                  INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)				  
					   WHERE ch.cdempresa   = 1
						 AND ch.cdtipochamado IN (2,3,4,5)
						 AND ch.cdsituacao <> 8";
			
			if($acumulado){
				$queryTop .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
							   AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
			}else{
				$queryTop .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
							   AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
			}
			
			$queryTop .= " AND de.cddepartamento = $departamento 
					GROUP BY dbo.consulta_nome_categoria(ch.cdchamado)
					ORDER BY 2 desc";		
		
			$result = mssql_query( $queryTop, $this->conexaoMssql );
			while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
				  $totalRequisicoes[$row['Categoria']]['Abertura'] = $row['Abertura'];
			}
			return $totalRequisicoes;
    }
	
    function quantidadeTotalRequisicoesColaborador($departamento,$dataInicial,$dataFinal,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);  
		$totalRequisicoes = array();
		$query = "SELECT TOP 10 co.nmcontato                                          AS Contato,
                                COUNT(ch.cdchamado)                                   AS Qtde
                    FROM hd_chamado ch 
              INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
              INNER JOIN ad_contato co ON(co.cdcliente = 1
                     AND co.cdcontato = ch.cdcontato)
              INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
                   WHERE eq.cdempresa = 1
                     AND ch.cdsituacao <> 8
                     AND ch.cdtipochamado IN (2,3,4,5)";
					 
				if($acumulado){
					$query .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataInicial."') AS DATE)
							    AND convert(date,ch.dtchamado) <= CAST(('".$dataFinal."') AS DATE)";
				}else{
					$query .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFinal."') AS DATE))
							    AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFinal."') AS DATE))";
				}

                $query .= " AND de.cddepartamento = $departamento
                GROUP BY co.nmcontato 
                ORDER BY 2 desc";		
		
			$result = mssql_query( $query, $this->conexaoMssql );
			while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
				  $totalRequisicoes[$row['Contato']]['Qtde'] = $row['Qtde'];
			}
			return $totalRequisicoes;
    }	
	
    function requisicoesAbertos($departamento){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql); 
		$requisicoesAbertos = array();
		$queryAberto = "SELECT ch.cdchamado                            AS Numero,
                               tp.nmtipochamado                        AS Tipo,
                               CONVERT(char,ch.dtchamado,103)          AS Data,
                               CONVERT(char,ch.dtprevisaotermino,103)  AS Previsao,
                               ch.dschamado                            AS Descricao,
                               co.nmcontato                            AS Contato,
                               si.nmsituacao                           AS Situacao,
							   si.cdsituacao                           AS CdSituacao
                          FROM hd_chamado ch
                    INNER JOIN hd_equipe eq  ON(eq.cdequipe = ch.cdequipe)
                    INNER JOIN ad_contato co ON(co.cdcliente = 1
                                            AND co.cdcontato = ch.cdcontato)
                    INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)      
                    INNER JOIN hd_situacao si ON(si.cdsituacao = ch.cdsituacao)
                    INNER JOIN hd_tipochamado tp ON(tp.cdtipochamado = ch.cdtipochamado)
                         WHERE ch.cdempresa   = 1
                           AND ch.cdtipochamado IN (2,3,4,5)
                           AND ch.cdsituacao NOT IN (7,8)
                           AND de.cddepartamento = $departamento";	
		
		$result = mssql_query( $queryAberto, $this->conexaoMssql );
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
			  array_push($requisicoesAbertos,$row);
		}
		return $requisicoesAbertos;
    }

	/* --- PROCESSO DE DESENVOLVIMENTO --- */
	function geraTabelaDesenvolvimentos($departamento,$dataIni,$dataFim){  
	    $this->abreConexaoMssql();	
        mssql_select_db("qualitorv8_prod",$this->conexaoMssql);		
		$desenvolvimentos = array();

		$sql = "SELECT MONTH(ch.dtchamado) AS Mes, YEAR(ch.dtchamado) AS Ano, COUNT(ch.cdchamado)  AS QtdeAbertos
										  FROM hd_chamado ch 
									INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
									INNER JOIN ad_contato co ON(co.cdcliente = 1
															AND co.cdcontato = ch.cdcontato)
									INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)									
										 WHERE eq.cdempresa     = 1
										   AND ch.cdsituacao   <> 8
										   AND ch.cdtipochamado = 8										   
										   AND convert(date,ch.dtchamado) >= CAST(('".$dataIni."') AS DATE)
										   AND convert(date,ch.dtchamado) <= CAST(('".$dataFim."') AS DATE)
										   AND de.cddepartamento   = $departamento
									  GROUP BY MONTH(ch.dtchamado),
									            YEAR(ch.dtchamado)
									  ORDER BY MONTH(ch.dtchamado), YEAR(ch.dtchamado)"; 

		$result = mssql_query( $sql, $this->conexaoMssql );
		
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
			$periodo = str_pad($row['Mes'], 2, '0', STR_PAD_LEFT).$row['Ano']; 
			$desenvolvimentos[$periodo]['QtdeAbertos'] = $row['QtdeAbertos'];
		}
		
		$sqlEncerrados = "SELECT MONTH(ch.dttermino) AS Mes, YEAR(ch.dttermino) AS Ano, COUNT(ch.cdchamado) AS QtdeEncerrados
							      FROM hd_chamado ch
							INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
							INNER JOIN ad_contato co ON(co.cdcliente = 1
													AND co.cdcontato = ch.cdcontato)
							INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)							
							     WHERE eq.cdempresa     = 1
							       AND ch.cdsituacao   <> 8
							       AND ch.cdtipochamado = 8
								   AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
								   AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)
								   AND de.cddepartamento = $departamento 
						      GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)
								ORDER BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
		
	    $resultEncerrados = mssql_query( $sqlEncerrados, $this->conexaoMssql );
		
		while( $rowEncerrados = mssql_fetch_array( $resultEncerrados, MSSQL_ASSOC) ) {
			$periodo = str_pad($rowEncerrados['Mes'], 2, '0', STR_PAD_LEFT).$rowEncerrados['Ano']; 
			$desenvolvimentos[$periodo]['QtdeEncerrados'] = $rowEncerrados['QtdeEncerrados'];
		}
		
		ksort($desenvolvimentos);
		
		return $desenvolvimentos;		
	}	
	
	function geraGraficoTotalPrazo($departamento,$dataIni,$dataFim){
		$this->abreConexaoMssql();	
        mssql_select_db("qualitorv8_prod",$this->conexaoMssql);		
		$desenvolvimentosPrazo = array();		

		$sqlPrazo = "SELECT MONTH(ch.dttermino) AS Mes, YEAR(ch.dttermino) AS Ano, ROUND(COUNT(ch.cdchamado)
			   * 100.00 /
			   (SELECT COUNT(ch2.cdchamado)
				  FROM hd_chamado ch2 
			INNER JOIN hd_equipe eq2 ON(eq2.cdequipe = ch2.cdequipe)
			INNER JOIN ad_contato co2 ON(co2.cdcliente = 1
				   AND co2.cdcontato = ch2.cdcontato)
			INNER JOIN ad_departamento de2 ON(de2.cddepartamento = co2.cddepartamento)	
				 WHERE eq2.cdempresa = 1
				   AND ch2.cdsituacao <> 8
				   AND ch2.cdtipochamado = 8
				   AND MONTH(ch2.dttermino) = MONTH(ch.dttermino)
				   AND YEAR(ch2.dttermino)  = YEAR(ch.dttermino)
				   AND de2.cddepartamento   = $departamento), 2)  AS 'Prazo'
		FROM hd_chamado ch 
		INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
			INNER JOIN ad_contato co ON(co.cdcliente = 1
				   AND co.cdcontato = ch.cdcontato)
			INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
		WHERE eq.cdempresa = 1
		AND ch.cdsituacao <> 8
		AND ch.cdtipochamado = 8
		AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
        AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)
		AND de.cddepartamento = $departamento
		AND (ch.dttermino <= ch.dtprevisaotermino
		 OR  ch.dtprevisaotermino is null)
		GROUP BY MONTH(ch.dttermino), YEAR(ch.dttermino)";
					
		
		$resultPrazo = mssql_query( $sqlPrazo, $this->conexaoMssql );			
		while($rowPrazo = mssql_fetch_array($resultPrazo)){
			$periodoPrazo = str_pad($rowPrazo['Mes'], 2, '0', STR_PAD_LEFT).$rowPrazo['Ano'];
			$desenvolvimentosPrazo[$periodoPrazo]['Prazo'] = round($rowPrazo['Prazo'],2);
		}		
		
		/*print "<pre>";
		print_r($desenvolvimentosPrazo);
		print "<pre>";*/
		
		ksort($desenvolvimentosPrazo);
		
		return $desenvolvimentosPrazo;
		
	}	
	
     function quantidadeTotalDesenvolvimentosServico($departamento,$dataIni,$dataFim,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql); 
		$totalDesenvolvimentos = array();
		$queryTop = "SELECT TOP 10 dbo.consulta_nome_categoria(ch.cdchamado)       AS Categoria,
							COUNT(ch.cdchamado)      							   AS Abertura
						FROM hd_chamado ch
				  INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
                  INNER JOIN ad_contato co ON(co.cdcliente = 1
                         AND co.cdcontato = ch.cdcontato)
                  INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)				  
					   WHERE ch.cdempresa   = 1
						 AND ch.cdtipochamado = 8
						 AND ch.cdsituacao <> 8";
						 
				if($acumulado){
					$queryTop .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataIni."') AS DATE)
							       AND convert(date,ch.dtchamado) <= CAST(('".$dataFim."') AS DATE)";
				}else{
					$queryTop .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFim."') AS DATE))
							       AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFim."') AS DATE))";
				}
			
			$queryTop .= " AND de.cddepartamento = $departamento 
					GROUP BY dbo.consulta_nome_categoria(ch.cdchamado)
					ORDER BY 2 desc";		
		
			$result = mssql_query( $queryTop, $this->conexaoMssql );
			while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
				  $totalDesenvolvimentos[$row['Categoria']]['Abertura'] = $row['Abertura'];
			}
			return $totalDesenvolvimentos;
    }
	
    function quantidadeTotalDesenvolvimentosColaborador($departamento,$dataIni,$dataFim,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$totalDesenvolvimentos = array();
		$query = "SELECT TOP 10 co.nmcontato                                          AS Contato,
                                COUNT(ch.cdchamado)                                   AS Qtde
                    FROM hd_chamado ch 
              INNER JOIN hd_equipe eq ON(eq.cdequipe = ch.cdequipe)
              INNER JOIN ad_contato co ON(co.cdcliente = 1
                     AND co.cdcontato = ch.cdcontato)
              INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)
                   WHERE eq.cdempresa = 1
                     AND ch.cdsituacao <> 8
                     AND ch.cdtipochamado = 8";
					 
				if($acumulado){
					$query .= " AND convert(date,ch.dtchamado) >= CAST(('".$dataIni."') AS DATE)
							    AND convert(date,ch.dtchamado) <= CAST(('".$dataFim."') AS DATE)";
				}else{
					$query .= " AND MONTH(ch.dtchamado) = MONTH(CAST(('".$dataFim."') AS DATE))
							    AND YEAR(ch.dtchamado) = YEAR(CAST(('".$dataFim."') AS DATE))";
				}
		
                $query .= " AND de.cddepartamento = $departamento
                GROUP BY co.nmcontato 
                ORDER BY 2 desc";		
		
			$result = mssql_query( $query, $this->conexaoMssql );
			while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
				  $totalDesenvolvimentos[$row['Contato']]['Qtde'] = $row['Qtde'];
			}
			return $totalDesenvolvimentos;
    }

    function desenvolvimentosAbertos($departamento){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$desenvolvimentosAbertos = array();
		$queryAberto = "    SELECT ch.cdchamado                                                                        AS Numero,
								   CONVERT(char,ch.dtchamado,103)                                                      AS Data,
								   ISNULL(CONVERT(char,ch.dtprevisaotermino,103), '')                                  AS Previsao,
								   ch.dschamado                                                                        AS Descricao,
								   ISNULL(ei.nmsubsituacao, 'Aguardando Atendimento')                                  AS Etapa,
								   ROUND(dbo.consulta_tempo_real_etapa_chamado(ch.cdchamado, ei.nrsequencia, 'DIA'),2) AS Tempo,
								   ISNULL(us.nmusuario, '')                                                            AS Resp,
								   co.nmcontato                                                                        AS Contato,
								   si.nmsituacao                                                                       AS Situacao,
								   si.cdsituacao                                                                       AS CdSituacao
							  FROM hd_chamado ch
						INNER JOIN hd_equipe eq  ON(eq.cdequipe = ch.cdequipe)
						INNER JOIN ad_contato co ON(co.cdcliente = 1
						   	  				    AND co.cdcontato = ch.cdcontato)
						INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)      
						INNER JOIN hd_situacao si ON(si.cdsituacao = ch.cdsituacao)
						 LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
						 LEFT JOIN hd_estruturasubsituacaoitem ei ON(ei.nrsequencia = ch.cdsubsituacao)
						     WHERE ch.cdempresa     = 1
							   AND ch.cdtipochamado = 8
							   AND ch.cdsituacao NOT IN (7,8)
							   AND de.cddepartamento = $departamento";		
		
		$result = mssql_query( $queryAberto, $this->conexaoMssql );
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
			  array_push($desenvolvimentosAbertos,$row);
		}
		return $desenvolvimentosAbertos;
    }	
	
    function desenvolvimentosEncerrados($departamento,$dataIni,$dataFim,$acumulado){
		$this->abreConexaoMssql();
		mssql_select_db("qualitorv8_prod",$this->conexaoMssql);
		$desenvolvimentosEncerrados = array();
		$queryEncerrado = "    SELECT ch.cdchamado                                      AS Numero,
								   CONVERT(char,ch.dtchamado,103)                       AS Data,
								   CONVERT(char,ch.dtprevisaotermino,103)               AS Previsao,
								   ch.dschamado                                         AS Descricao,
								   ISNULL(ei.nmsubsituacao, 'Aguardando Atendimento')   AS Etapa,
								   us.nmusuario                                         AS Resp,
								   co.nmcontato                                         AS Contato,
								   si.nmsituacao                                        AS Situacao,
								   si.cdsituacao                                        AS CdSituacao
							  FROM hd_chamado ch
						INNER JOIN hd_equipe eq  ON(eq.cdequipe = ch.cdequipe)
						INNER JOIN ad_contato co ON(co.cdcliente = 1
						   	  				    AND co.cdcontato = ch.cdcontato)
						INNER JOIN ad_departamento de ON(de.cddepartamento = co.cddepartamento)      
						INNER JOIN hd_situacao si ON(si.cdsituacao = ch.cdsituacao)
						INNER JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
						 LEFT JOIN hd_estruturasubsituacaoitem ei ON(ei.nrsequencia = ch.cdsubsituacao)
						     WHERE ch.cdempresa     = 1
							   AND ch.cdtipochamado = 8";
							   
							if($acumulado){
								$queryEncerrado .= " AND convert(date,ch.dttermino) >= CAST(('".$dataIni."') AS DATE)
												     AND convert(date,ch.dttermino) <= CAST(('".$dataFim."') AS DATE)";
							}else{
								$queryEncerrado .= " AND MONTH(ch.dttermino) = MONTH(CAST(('".$dataFim."') AS DATE))
													 AND YEAR(ch.dttermino) = YEAR(CAST(('".$dataFim."') AS DATE))";
							} 
							
							$queryEncerrado .= " AND de.cddepartamento   = $departamento";
		
		$result = mssql_query( $queryEncerrado, $this->conexaoMssql );
		while( $row = mssql_fetch_array( $result, MSSQL_ASSOC) ) {
			  array_push($desenvolvimentosEncerrados,$row);
		}
		return $desenvolvimentosEncerrados;
    }

	function buscaProjetos($departamento){
		$this->abreConexaoOracle();
		$this->abreConexaoMssqlEPM();
		$query = "SELECT ds_departamento FROM indicador_ti_departamento WHERE cd_departamento = $departamento";
		$consulta = oci_parse($this->conexaoOracle, $query); 		
		oci_execute($consulta);			
		$departamentoBusca = oci_fetch_row($consulta);			

		mssql_select_db('ProjectServer_Reporting',$this->conexaoMssqlEPM);
		
		$sqlProjetos = utf8_decode("SELECT DISTINCT(p.ProjectName) AS [Nome do Projeto],
							   p.[Status do Projeto] AS [Status],
							   p.[Departamentos do Projeto] AS [Departamento],
							   p.[Responsável] AS [Responsavel],
							   p.[Patrocinador] AS [Patrocinador],
							   p.ProjectOwnerName AS [Proprietario]
						  FROM dbo.MSP_EpmProject_UserView p
					INNER JOIN dbo.MSP_EpmTask_UserView t 
							ON (p.ProjectUID = t.ProjectUID)
					INNER JOIN dbo.MSP_EpmAssignment_UserView a 
							ON ((a.ProjectUID = p.ProjectUID) 
						   AND  (a.TaskUID = t.TaskUID))
					INNER JOIN dbo.MSP_EpmResource_UserView r 
							ON (a.ResourceUID = r.ResourceUID)
					INNER JOIN dbo.MSP_EpmWorkflowStatusInformation inf
							ON(inf.ProjectUID = p.ProjectUID
						   AND inf.StageStatus NOT IN (0,4))
					INNER JOIN dbo.MSP_EpmWorkflowStage sge
							ON(sge.StageUID = inf.StageUID)
						 WHERE r.EDR LIKE 'Unimed VTRP.Tecnologia da Informação%'
						   AND t.TaskIsActive = 'True'
						   AND sge.StageName <> 'Projeto Encerrado'
						   AND p.[Departamentos do Projeto] = '".$departamentoBusca[0]."'");
						   
		$resultProjetos = mssql_query($sqlProjetos);

		$resultado = array();
		
		
		while($rowProjetos = mssql_fetch_array( $resultProjetos, MSSQL_ASSOC)){		
		
			array_push($resultado,$rowProjetos);
			
		}

		return $resultado;	
	}	
}

?>
