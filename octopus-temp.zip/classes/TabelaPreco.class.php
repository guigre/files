<?php
class TabelaPreco extends Utils{

	var $cdtabpreco;
	var $dstabpreco;  
	var $dtinicio; 
	var $dtfim; 
	var $cduserid;	
	
    var $tabela = "v_tabpreco";
	var $row;
      
    function cadastraTabelaPreco($cdtabpreco,
	                             $dstabpreco, 
	                             $dtinicio,
	                             $dtfim,
	                             $cduserid){
							   
	    $this->abreConexaoOracleOrquestra();
		
		$query = "INSERT INTO $this->tabela (cdtabpreco, 
									         dstabpreco,  
									         dtinicio, 
									         dtfim, 
									         cduserid, 
									         dtatualizacao)
							        VALUES ('$cdtabpreco', 
								   	        '$dstabpreco', 
									        '".date('d-M-Y',strtotime($this->data_mysql($dtinicio)))."', 
									        '".date('d-M-Y',strtotime($this->data_mysql($dtfim)))."', 
									        '$cduserid', 
									        SYSDATE)";
		
		$insert = oci_parse($this->conexaoOracleOrquestra, $query);

		$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
    function atualizaTabelaPreco($cdtabpreco,
	                             $dstabpreco, 
	                             $dtinicio,
	                             $dtfim,
	                             $cduserid){
									 
	    $this->abreConexaoOracleOrquestra();		 
	    $query = "UPDATE $this->tabela 
		 		     SET dstabpreco			= '$dstabpreco',
						 dtinicio           = '".date('d-M-Y',strtotime($this->data_mysql($dtinicio)))."',
						 dtfim              = '".date('d-M-Y',strtotime($this->data_mysql($dtfim)))."', 
					     cduserid           = '$cduserid', 
					     dtatualizacao      = SYSDATE					 
				   WHERE cdtabpreco         = '$cdtabpreco'";				 
						 
		$update = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);		

		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
	}
	
	function listaTabelasPreco(){
		$this->abreConexaoOracleOrquestra();
		$query = "SELECT cdtabpreco, 
						 dstabpreco, 
						 to_char(dtinicio,'dd/mm/yyyy'), 
						 to_char(dtfim,'dd/mm/yyyy'),
						 cduserid, 
						 dtatualizacao
		            FROM $this->tabela";
        $retorno = array();         
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta); 
		while ($row = oci_fetch_row($consulta)){
            array_push($retorno,$row);
        }
        return $retorno;
    }
	
    function buscaTabelaPreco($cdtabpreco){
	    $this->abreConexaoOracleOrquestra();
	    $query = "SELECT cdtabpreco, 
		                 dstabpreco, 
		                 to_char(dtinicio,'dd/mm/yyyy') as DTINICIO,
		                 to_char(dtfim,'dd/mm/yyyy') as DTFIM, 
		                 cduserid, 
		                 dtatualizacao
		  		    FROM $this->tabela
				   WHERE cdtabpreco = '$cdtabpreco'";					 
		$consulta = oci_parse($this->conexaoOracleOrquestra, $query);
		oci_execute($consulta);		
		$row = oci_fetch_assoc($consulta);				   
		
		if(count($row) > 0){
		    $this->cdtabpreco    = $row['CDTABPRECO']; 
            $this->dstabpreco    = $row['DSTABPRECO']; 
            $this->dtinicio      = $row['DTINICIO']; 
            $this->dtfim         = $row['DTFIM'];
            $this->cduserid      = $row['CDUSERID']; 
            $this->dtatualizacao = $row['DTATUALIZACAO'];		
			return true;
	    }else{
			return false;
	    }
    } 	
	
    function excluiTabelaPreco($cdtabpreco){
	    $this->abreConexaoOracleOrquestra();
	    $query = "DELETE 
		  		    FROM $this->tabela
				   WHERE cdtabpreco = '$cdtabpreco'";					 
		$delete = oci_parse($this->conexaoOracleOrquestra, $query);
		$resultado = oci_execute($delete, OCI_NO_AUTO_COMMIT);		
		if($resultado){
			oci_commit($this->conexaoOracleOrquestra);	
			return true;				
		}else{
			oci_rollback($this->conexaoOracleOrquestra);
			return false;
		}
    }
	
}

?>
