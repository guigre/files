<?php
class RAsTecnologia extends Utils{

	function buscaRAs($versao, $atendente){

		//$arrResult = array();	
		
		$wsdl = DIR_FS_WSDL."solicitaRasAbertos.wsdl";
		
		$options = array('trace' => 1,'exceptions' => 1);
		
		$ra = new SoapClient($wsdl,$options); 
		
		try{
			$param = array('st_nrVersaoPar'           => $versao,
						   'st_nmUsuarioAtendentePar' => $atendente); 

			$resultado = (array)$ra->solicitaRAsAbertos($param);

			$conexaoSqlServer = $this->abreConexaoMssql();
			
			if($conexaoSqlServer){
			
				$ras = array();
				
				if(is_array($resultado) && count($resultado) > 0){
					$novosResultado = (array)$resultado[ct_ttAtendimento];
					
					if(count($novosResultado[ct_ttAtendimentoRow]) == 1){
						$ras = $novosResultado;			
					}else{
						$ras = (array)$novosResultado[ct_ttAtendimentoRow];	
					}	
				}
				
				foreach($ras as $value){
				
					$ra = $value->{'st_aa-atendimento'}.'/'.str_pad($value->{'st_nr-atendimento'}, 8, "0", STR_PAD_LEFT);
					
					$arrResult[$ra] = array();
					$arrResult[$ra]['RA'] = $ra;					
					
					$sql = "SELECT ch.cdchamado AS Chamado,
							       us.nmusuario	AS Usuario
							   FROM hd_chamado ch
					      LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
							  WHERE ch.nmtitulochamado like '%RA $ra%'";
			
					$result = mssql_query($sql);
					
					if(mssql_num_rows($result) != 0){
					
						while($row = mssql_fetch_array($result)){

							$arrResult[$ra]['Chamado'] = $row['Chamado'];
							
							if($row['Usuario'] == ''){
								$arrResult[$ra]['Usuario'] = 'SEM RESPONSÁVEL';
							}else{
								$arrResult[$ra]['Usuario'] = utf8_encode($row['Usuario']);
							}
						}
					}else{
							$arrResult[$ra]['Chamado'] = '';
							$arrResult[$ra]['Usuario'] = '';
					}
					
					$sql = "SELECT ch.cdchamado   AS Chamado,
									us.nmusuario	AS Usuario
							   FROM hd_chamado ch
						  LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
							  WHERE ch.dttermino IS NOT NULL
								AND ch.nmtitulochamado = 'Chamado aberto para o RA $ra'";
			
					$result = mssql_query($sql);
					
					if(mssql_num_rows($result) != 0){
					
						$arrResult[$ra]['status'] = 'Pendente';
					}else{
						$arrResult[$ra]['status'] = 'Solucionado';
					}
				}
			}
			
			sort($arrResult);
			
			return $arrResult;

		}catch(SoapFault $exception){
		
			$erro = $exception->detail->FaultDetail->errorMessage;
			return $erro;
		}
	}
	
	
	/*function buscaChamadosRA(){
	
		$retorno = array();
	
		$conexaoSqlServer = $this->abreConexaoMssql();
		
		try{
			if($conexaoSqlServer){
			
				$sql = "SELECT ch.cdchamado 	  AS Chamado,
							   ch.nmtitulochamado AS Titulo,
							   us.nmusuario	      AS Usuario
						   FROM hd_chamado ch
					  LEFT JOIN ad_usuario us ON(us.cdusuario = ch.cdresponsavel)
						  WHERE ch.dttermino IS NULL
							AND ch.nmtitulochamado LIKE 'Chamado aberto para o RA%'
					   ORDER BY ch.nmtitulochamado";
		
				$result = mssql_query($sql);
				
				while($row = mssql_fetch_array($result)){
				
					if($row['Usuario'] == ''){
						array_push($retorno, $row['Chamado'].";".$row['Titulo'].";SEM RESPONSÁVEL");
					}else{
						array_push($retorno, $row['Chamado'].";".$row['Titulo'].";".utf8_encode($row['Usuario']));
					}
				}
				
				return (array)$retorno;
			}
		}catch(SoapFault $exception){
		
			$erro = $exception->detail->FaultDetail->errorMessage;
			return $erro;
		}			
	}*/
}

?>