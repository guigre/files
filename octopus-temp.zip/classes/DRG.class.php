<?php
class DRG extends Utils
{

	function solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,$hospital,$servidor){
		ini_set('default_socket_timeout', 3000);
		$options = array('trace' => 1, 'exceptions' => 1, 'cache_wsdl' => WSDL_CACHE_NONE, 'connection_timeout' => 3000);
		if($servidor == "prot"){
			$wsdl = "http://srv-ws-prot01:8080/wsagplprot/wsagplprot/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/solicitaDadosCustosPaciente/v0"; // PROTOTIPO
		}else{
			$wsdl = "http://srv-ws-prod01:8080/wsagpl/wsagpl/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/solicitaDadosCustosPaciente/v0";
		}
		$custo = new SoapClient($wsdl,$options);		
		try{
			$params = array('st_dtAnorefIni'   => $anoIni,
							'st_dtAnorefFim'   => $anoFim,
							'st_nrPerrefIni'   => $periodoIni,
							'st_nrPerrefFim'   => $periodoFim,
							'st_cdHospitalPar' => $hospital);
			$resultado = $custo->solicitaDadosCustosPaciente($params);
			return $resultado;
		}catch(SoapFault $exception){
			return $exception;			
		}
		
	}

	function enviarDadosDRG($xml,$user,$pass){
		ini_set('default_socket_timeout', 3000);
		$options = array('trace' => 1, 'exceptions' => 1, 'cache_wsdl' => WSDL_CACHE_NONE, 'connection_timeout' => 3000);
		$wsdl = "https://iagwebservice.sigquali.com.br/iagwebservice/enviaDadosCustoPaciente?wsdl";
		$envio = new SoapClient($wsdl,$options);		
		try{
			$params = array('xml'        => $xml,
						    'usuarioIAG' => $user,
						    'senhaIAG'   => $pass);
			$resultado = $envio->enviaDadosCustoPaciente($params);
			return $resultado;
		}catch(SoapFault $exception){
			return $exception;			
		}
		
	}

	function atualizaStatusCustoPaciente($dadosEntrada,$servidor){
		ini_set('default_socket_timeout', 3000);
		$options = array('trace' => 1, 'exceptions' => 1, 'cache_wsdl' => WSDL_CACHE_NONE, 'connection_timeout' => 3000);
		if($servidor == "prot"){
			$wsdl = "http://srv-ws-prot01:8080/wsagplprot/wsagplprot/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/atualizaStatusCustoPaciente/v0";
		}else{
			$wsdl = "http://srv-ws-prod01:8080/wsagpl/wsagpl/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/atualizaStatusCustoPaciente/v0";		
		}
		$custo = new SoapClient($wsdl,$options);		
		try{
			//$params = array('ct_ttCustosEntrada' => $dadosEntrada);

			$resultado = $custo->atualizaStatusCustoPaciente($dadosEntrada);
			return $resultado;
		}catch(SoapFault $exception){
			//return $exception;			
		}
		
	}		
	
}

?>
