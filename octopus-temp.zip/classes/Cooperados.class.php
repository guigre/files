<?php
class Cooperados extends Utils{

	function listaCooperados($programaChamador, $nrVersao){

		$wsdl = "http://srv-ws-prod01:8080/wsagpl/wsagpl/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/solicitaDadosCooperado/v0";
		//$wsdl = "http://srv-ws-prot01:8080/wsagplprot/wsagplprot/wsdl?targetURI=http://ws.unimedvtrp.com.br/ws/wgplapp/solicitaDadosCooperado/v0";
		
		$options = array('trace' => 1,'exceptions' => 1, 'cache_wsdl' => WSDL_CACHE_NONE);
		
		$cooperado = new SoapClient($wsdl,$options); 
		
		try{
			$param = array('st_programaChamador' => $programaChamador,
						   'st_nrVersao' 		 => $nrVersao); 

			$resultado = (array)$cooperado->solicitaDadosCooperado($param);

			$cooperados = array();
				
			if(is_array($resultado) && count($resultado) > 0){
				$novosResultado = (array)$resultado[ct_ttPrestadores];
				
				if(count($novosResultado[ct_ttPrestadoresRow]) == 1){
					$cooperados = $novosResultado;			
				}else{
					$cooperados = (array)$novosResultado[ct_ttPrestadoresRow];	
				}	
			}

			sort($cooperados);
			
			return $cooperados;

		}catch(SoapFault $exception){
		
			$erro = $exception->detail->FaultDetail->errorMessage;
			return $erro;
		}
	}
	
	function incluiSenhaCooperado($crm, $nome, $email, $cpf, $dataNascimento, $idPessoa, $novaSenha){

		if($this->numeroLoginsCooperado($crm) != 0){
			return false;
		}else{

			$sqlInsert = "INSERT INTO SIS004_COOPERATIVA_PESSOA (SIS004_COOPERATIVA_PESSOA_ID,
																 SIS001_COOPERATIVA_ID,
																 SIS004_NOME,
																 SIS004_EMAIL,
																 SIS004_CPF,
																 SIS004_DATA_NASCIMENTO,
																 SIS004_TELEFONE,
																 SIS004_CELULAR,
																 SIS004_CNS,
																 SIS004_ID_EXTERNO)
														 VALUES (SIS004_SEQUENCE.nextval,
																 2,
																 '$nome',
																 '$email',
																 '$cpf',
																 '$dataNascimento',
																 '',
																 '',
																 '',
																 '')";
																 
			$insert = oci_parse($this->conexaoOracleMob, $sqlInsert);
			
			$resultado = oci_execute($insert, OCI_NO_AUTO_COMMIT);
			
			if($resultado){
			
				$sqlInsertSIS006 = "INSERT INTO SIS006_PESSOA_TIPO (SIS006_PESSOA_TIPO_ID,       	
															  SIS004_COOPERATIVA_PESSOA_ID,
															  SIS005_TIPO_ID,              
															  SIS006_MATRICULA,            
															  SIS006_CARTEIRA,             
															  SIS006_LOGIN,                
															  SIS006_SENHA,
															  SIS006_PESSOA)
													  VALUES (SIS006_SEQUENCE.nextVal,
															  SIS004_SEQUENCE.currVal,
															  1,
															  '$crm',
															  '',
															  '$crm',
															  '$novaSenha',
															  '$idPessoa')";
															  
				$insertSIS006 = oci_parse($this->conexaoOracleMob, $sqlInsertSIS006);
				
				$resultado = oci_execute($insertSIS006, OCI_NO_AUTO_COMMIT);
				
				if($resultado){
					oci_commit($this->conexaoOracleMob);
					return true;
				}else{
					oci_rollback($this->conexaoOracleMob);
					return false;
				}
			}else{
				oci_rollback($this->conexaoOracleMob);
				return false;
			}
		}
	}
	
	function alteraSenhaCooperado($crm, $novaSenha){

		if($this->numeroLoginsCooperado($crm) != 1){
			return false;
		}else{
        	$query="UPDATE sis006_pessoa_tipo
					   SET SIS006_SENHA = '$novaSenha'
					 WHERE SIS005_TIPO_ID   = 1
					   AND SIS006_MATRICULA = $crm";

			$update = oci_parse($this->conexaoOracleMob, $query);

			$resultado = oci_execute($update, OCI_NO_AUTO_COMMIT);

			if($resultado){
				oci_commit($this->conexaoOracleMob);
				return true;
			}else{
				oci_rollback($this->conexaoOracleMob);
				return false;
			}
		}
	}
	
	function numeroLoginsCooperado($crm){
	
		$conexao = $this->abreConexaoOracleMob();
		
		$query="SELECT *
		          FROM sis006_pessoa_tipo
				 WHERE SIS005_TIPO_ID   = 1
				   AND SIS006_MATRICULA = $crm";
				   
		$consulta = oci_parse($this->conexaoOracleMob, $query);
		oci_execute($consulta); 
        	
		$nrows = oci_fetch_all($consulta, $res);
		return $nrows;
	}
}

?>