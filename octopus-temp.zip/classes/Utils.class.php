<?php
class Utils{

     var $conexao=NULL;
	 var $conexaoOracle=NULL;
	 var $conexaoOracleOrquestra=NULL;
	 var $conexaoOracleSA=NULL; /* --- SISTEMA DE ATENDIMENTO --- */
	 var $conexaoOracleMob=NULL; /* --- Mobile --- */
	 var $conexaoSqlServer=NULL;
	 var $conexaoSqlServerEPM=NULL;
	 var $conexaoMssql=NULL;
	 var $conexaoMssqlEPM=NULL;
     var $temError;
     var $error;
	 
	 var $tipoConexao = 'mysql';
     
     function abreConexao(){
        if($this->conexao == NULL){
            include("../inc/config.php");			
		    $conexao = ADONewConnection($tipoConexao);
		    if($conexao->PConnect($bdHost,$bdUser,$bdPass,$bancoDados)){
		    	$conexao->debug = $debug;
		    	$this->conexao = $conexao;
		    	return true;
		    }else{
		    	return false;
		    }
		    
        }else{
			return true;
		}
	 }
	 
	 function fechaConexao(){
		$this->conexao->Close();
	 }
	 
     function abreConexaoOracle(){
		if($this->conexaoOracle == NULL){
      include("../inc/config.php");
							
			$conexaoOracle = oci_connect($userOracle, $senhaOracle, $hostOracle, 'AL32UTF8');
			if($conexaoOracle){
		    	$this->conexaoOracle = $conexaoOracle;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }

     function abreConexaoOracleInsert(){
		if($this->conexaoOracle == NULL){
            include("../inc/config.php");
							
			$conexaoOracle = oci_connect($userOracle, $senhaOracle, $hostOracle);
			if($conexaoOracle){
		    	$this->conexaoOracle = $conexaoOracle;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }
	 
     function abreConexaoOracleOrquestra(){
		if($this->conexaoOracleOrquestra == NULL){
            include("../inc/config.php");
							
			$conexaoOracleOrquestra = oci_connect($userOrquestraProt, $senhaOrquestraProt, $hostOrquestraProt, 'AL32UTF8');
			if($conexaoOracleOrquestra){
		    	$this->conexaoOracleOrquestra = $conexaoOracleOrquestra;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }	 

     function abreConexaoOracleOrquestraInsert(){
		if($this->conexaoOracleOrquestra == NULL){
            include("../inc/config.php");
							
			$conexaoOracleOrquestra = oci_connect($userOrquestraProt, $senhaOrquestraProt, $hostOrquestraProt);
			if($conexaoOracleOrquestra){
		    	$this->conexaoOracleOrquestra = $conexaoOracleOrquestra;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }	 
	 
	 function fechaConexaoOracle(){
		oci_close($this->conexaoOracle);
	 }
	 
	 function fechaConexaoOracleOrquestra(){
		oci_close($this->conexaoOracleOrquestra);
	 }	 

     function abreConexaoOracleSA(){
		if($this->conexaoOracleSA == NULL){
            include("../inc/config.php");
			$conexaoOracleSA = oci_connect($userOracleSA, $senhaOracleSA, $hostOracleSA, 'AL32UTF8');
			if($conexaoOracleSA){
		    	$this->conexaoOracleSA = $conexaoOracleSA;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }

	 function fechaConexaoOracleSA(){
		oci_close($this->conexaoOracleSA);
	 }	 
	 
	 function abreConexaoOracleMob(){
		if($this->conexaoOracleMob == NULL){
            include("../inc/config.php");
			$conexaoOracleMob = oci_connect($userOracleMob, $senhaOracleMob, $hostOracleMob);
			if($conexaoOracleMob){
		    	$this->conexaoOracleMob = $conexaoOracleMob;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }
	 
	 function fechaConexaoOracleMob(){
		oci_close($this->conexaoOracleMob);
	 }	 

     function abreConexaoSqlServer(){
		if($this->conexaoSqlServer == NULL){
            include("../inc/config.php");
			$conexaoSqlServer = sqlsrv_connect($hostSqlServer, $infoSqlServer);
			if($conexaoSqlServer){
		    	$this->conexaoSqlServer = $conexaoSqlServer;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }

	 function fechaConexaoSqlServer(){
		sqlsrv_close($this->conexaoSqlServer);
	 }	

     function abreConexaoSqlServerEPM(){
		if($this->conexaoSqlServerEPM == NULL){
            include("../inc/config.php");
			$conexaoSqlServerEPM = sqlsrv_connect($hostSqlServer, $infoSqlServer);
			if($conexaoSqlServerEPM){
		    	$this->conexaoSqlServerEPM = $conexaoSqlServerEPM;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }

	 function fechaConexaoSqlServerEPM(){
		sqlsrv_close($this->conexaoSqlServerEPM);
	 }

     function abreConexaoMssql(){
		if($this->conexaoMssql == NULL){
            include("../inc/config.php");
			$conexaoMssql = mssql_connect($hostMssql,$userMssql,$senhaMssql);
			if($conexaoMssql){
			
				$base = mssql_select_db('qualitorv8_prod',$conexaoMssql);
		    	$this->conexaoMssql = $conexaoMssql;
		    	return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }

	 function fechaConexaoMssql(){
		mssql_close($this->conexaoMssql);
	 }

     function abreConexaoMssqlEPM(){
		if($this->conexaoMssqlEPM == NULL){
            include("../inc/config.php");
			$conexaoMssqlEPM = mssql_connect($hostMssqlEPM,$userMssqlEPM,$senhaMssqlEPM);
			if($conexaoMssqlEPM){
		    	$this->conexaoMssqlEPM = $conexaoMssqlEPM;
				return true;
		    }else{
		    	return false;
		    }		    
        }else{
			return true;
		}
	 }

	 function fechaConexaoMssqlEPM(){
		mssql_close($this->conexaoMssqlEPM);
	 }	 
	  
     function criptografaSenha($senha){
         return sha1($senha);
     }
     
     function verificaSenha($senha){
         if(strlen($senha) >= 8){
             return true;
         }else{
             return false;
         }
     }
     
     function setErrorMsg($msg){
          $this->temError = true;
          $this->error = $msg;
     }

     function getErrorMsg(){
          if($this->temError){
              $this->temError = false;
              return $this->error;
          }
     }


     function retiraCaracterInvalido($string){
            $string = str_replace("'","\'",$string);
            //$string = str_replace("\"","\\\"",$string);
       return $string;
     }

    function voltadata($dias,$datahoje){

    // Desmembra Data -------------------------------------------------------------
    //  if (ereg ("([0-9]{1,2})-([0-9]{1,2})-([0-9]{4})", $datahoje, $sep)) {
      if (ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $datahoje, $sep)) {
      $ano = $sep[1];
      $mes = $sep[2];
      $dia = $sep[3];

      } else {
        echo "<b>Formato Inv�lido de Data - $datahoje</b><br>";
      }

    // Meses que o antecessor tem 31 dias -----------------------------------------

      if($mes == "01" || $mes == "02" || $mes == "04" || $mes == "06" || $mes == "08" || $mes == "09" || $mes == "11"){
        for ($cont = $dias ; $cont > 0 ; $cont--){
        $dia--;
          if($dia == 00){ // Volta o dia para dia 31 .
          $dia = 31;
          $mes = $mes -1; // Diminui um m�s se o dia zerou .
            if($mes == 00){
            $mes = 12;
            $ano = $ano - 1; // Se for Janeiro e subtrair 1 , vai para o ano anterior no m�s de dezembro.
            }
          }
        }
      }

    // Meses que o antecessor tem 30 dias -----------------------------------------

      elseif($mes == "05" || $mes == "07" || $mes == "10" || $mes == "12" ){
        for ($cont = $dias ; $cont > 0 ; $cont--){
        $dia--;
          if($dia == 00){ // Volta o dia para dia 30 .
          $dia = 30;
          $mes = $mes -1; // Diminui um m�s se o dia zerou .
          }
        }
      }

    // M�s que o antecessor � fevereiro -------------------------------------------
      if($ano % 4 == 0 && $ano%100 != 0){ // se for bissexto
        if($mes == "03" ){
          for ($cont = $dias ; $cont > 0 ; $cont--){
          $dia--;
            if($dia == 00){ // Volta o dia para dia 30 .
            $dia = 29;
            $mes = $mes -1; // Diminui um m�s se o dia zerou .
            }
          }
        }
      }//fecha se bissexto...
      else{ // se n�o for bissexto
        if($mes == "03" ){
          for ($cont = $dias ; $cont > 0 ; $cont--){
            $dia--;
            if($dia == 00){ // Volta o dia para dia 30 .
              $dia = 28;
              $mes = $mes -1; // Diminui um m�s se o dia zerou .
            }
          }
        }
      }

    // Confirma Sa�da de 2 d�gitos ------------------------------------------------

      if(strlen($dia) == 1){$dia = "0".$dia;}
      if(strlen($mes) == 1){$mes = "0".$mes;}

    // Monta Sa�da ----------------------------------------------------------------

    $nova_data = $ano."-".$mes."-".$dia;

    return $nova_data;
    } //fecha fun��o

    //
    // == Fun��o para adi��o de datas =============================================
    // ============================================================================
    //

    function somadata($dias,$datahoje){

    // Desmembra Data -------------------------------------------------------------

      if (ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $datahoje, $sep)) {
      $ano = $sep[1];
      $mes = $sep[2];
      $dia = $sep[3];
      } else {
        echo "<b>Formato Inv�lido de Data - $datahoje</b><br>";
      }

      $i = $dias;

      for($i = 0;$i<$dias;$i++){

        if ($mes == "01" || $mes == "03" || $mes == "05" || $mes == "07" || $mes == "08" || $mes == "10" || $mes == "12"){
          if($mes == 12 && $dia == 31){
            $mes = 01;
            $ano++;
            $dia = 00;
          }
        if($dia == 31 && $mes != 12){
          $mes++;
          $dia = 00;
        }
      }//fecha if geral

      if($mes == "04" || $mes == "06" || $mes == "09" || $mes == "11"){
        if($dia == 30){
          $dia = 00;
          $mes++;
        }
      }//fecha if geral

      if($mes == "02"){
        if($ano % 4 == 0 && $ano % 100 != 0){ //ano bissexto
          if($dia == 29){
            $dia = 00;
            $mes++;
          }
        }
        else{
          if($dia == 28){
            $dia = 00;
            $mes++;
          }
        }
      }//FECHA IF DO M�S 2

      $dia++;

      }//fecha o for()

    // Confirma Sa�da de 2 d�gitos ------------------------------------------------

      if(strlen($dia) == 1){$dia = "0".$dia;};
      if(strlen($mes) == 1){$mes = "0".$mes;};

    // Monta Sa�da ----------------------------------------------------------------

    $nova_data = $ano."-".$mes."-".$dia;

    return $nova_data;

    }//fecha a fun��o data


    function data_mysql($data){

     $ano = $data[6].$data[7].$data[8].$data[9];
     $mes = $data[3].$data[4];
     $dia = $data[0].$data[1];

      if(strlen($dia) == 1){$dia = "0".$dia;};
      if(strlen($mes) == 1){$mes = "0".$mes;};

    $nova_data = $ano."-".$mes."-".$dia;

       if ($nova_data=="--"){
         $nova_data="0000-00-00";
       }

    return $nova_data;
    }
    
    function data_mysql_hora($data){

     $ano = $data[6].$data[7].$data[8].$data[9];
     $mes = $data[3].$data[4];
     $dia = $data[0].$data[1];
     $hora = $data[11].$data[12];
     $min = $data[14].$data[15];
     
      if(strlen($dia) == 1){$dia = "0".$dia;};
      if(strlen($mes) == 1){$mes = "0".$mes;};
      if(strlen($hora) == 1){$hora = "0".$hora;};
      if(strlen($min) == 1){$min = "0".$min;};


    	$nova_data = $ano."-".$mes."-".$dia." ".$hora.":".$min;

       if ($nova_data=="--"){
         $nova_data="0000-00-00";
       }

    return $nova_data;
    }
	
    function getAnoData($data){
		$ano = $data[6].$data[7].$data[8].$data[9];
		return $ano;
    }	
	
    function getMesData($data){
		$mes = $data[3].$data[4];
		return $mes;
    }

    function getDiaData($data){
		$dia = $data[0].$data[1];
		return $dia;
    }	


    function formata_data($data){

     $ano = $data[0].$data[1].$data[2].$data[3];
     $mes = $data[5].$data[6];
     $dia = $data[8].$data[9];

      if(strlen($dia) == 1){$dia = "0".$dia;};
      if(strlen($mes) == 1){$mes = "0".$mes;};

    $nova_data = $dia."/".$mes."/".$ano;

    return $nova_data;
    }
    
    function formata_data_hora($data){

     $ano = $data[0].$data[1].$data[2].$data[3];
     $mes = $data[5].$data[6];
     $dia = $data[8].$data[9];
     $hora = $data[11].$data[12];
     $min = $data[14].$data[15];
     
      if(strlen($dia) == 1){$dia = "0".$dia;};
      if(strlen($mes) == 1){$mes = "0".$mes;};
      if(strlen($hora) == 1){$hora = "0".$hora;};
      if(strlen($min) == 1){$min = "0".$min;};

    $nova_data = $dia."/".$mes."/".$ano." ".$hora.":".$min;

    return $nova_data;
    }

    function formata_valores($valor){
        $valor = str_replace(".","",$valor); //onde tiver "," na variavel sera substituida por "."
        $valor = str_replace(",",".",$valor); //onde tiver "," na variavel sera substituida por "."
        $valor = number_format($valor, 2, '.', '');
       // print "val = $valor";

        return $valor;
    }
	
	function formataTexto($texto){
		$texto = str_replace(".","",$texto);
		$texto = str_replace("-","",$texto);
		return $texto;
	}


     //inicio da divisao do ano em semanas
      function findWeekPeriod($yearweek){
       $aPeriod = array();
       $year = substr($yearweek,0,4);
       $week = substr($yearweek,4,2);

       $startDay = Mon;
       $endDay = Sun;

       $startdate =  strtotime('+' . $week . ' week',mktime(0,0,0,1,1,$year));

       $enddate = $startdate;
           while(date("D",$startdate) != $startDay){
               $startdate = mktime(0,0,0,date("m",$startdate),date("d",$startdate)-1, date("Y",$startdate));
           }
           while(date("D",$enddate) != $endDay){
               $enddate = mktime(0,0,0,date("m",$enddate),date("d",$enddate)+1, date("Y",$enddate));
           }

           return array('start' => date('Y-m-d', $startdate),
                         'end'  => date('Y-m-d', $enddate));
           /*
           return array('start' => date('l d/m/y', $startdate),
                         'end'  => date('l d/m/y', $enddate));*/
       return $aPeriod;
    }

    function weeks($year) {
       return date("W",mktime(0,0,0,12,28,$year));
    }


//recebe a data formato brasileiro e rotora no formato americano diminuindo do ano o nro passado como paramentro
function diminuiAnoData($data,$anos){

     $ano=$data[6]."".$data[7]."".$data[8]."".$data[9];
     $ano = $ano-$anos;

     return $ano."-".$data[3]."".$data[4]."-".$data[0]."".$data[1];
}


function CalculaCNPJ($RecebeCNPJ){
   $s="";
   //Retirar todos os caracteres que nao sejam 0-9
   for ($x=1; $x<=strlen($RecebeCNPJ); $x=$x+1){
    $ch=substr($RecebeCNPJ,$x-1,1);
    if (ord($ch)>=48 && ord($ch)<=57){
     $s=$s.$ch;
    }
   }

   $RecebeCNPJ=$s;
   if (strlen($RecebeCNPJ)!=14){
       return false;
   }
   else if ($RecebeCNPJ=="00000000000000"){
         $then;
           return false;
       }
       else{
       //print "-> entrou $s<BR>";
            $Numero[1]=intval(substr($RecebeCNPJ,1-1,1));
            $Numero[2]=intval(substr($RecebeCNPJ,2-1,1));
            $Numero[3]=intval(substr($RecebeCNPJ,3-1,1));
            $Numero[4]=intval(substr($RecebeCNPJ,4-1,1));
            $Numero[5]=intval(substr($RecebeCNPJ,5-1,1));
            $Numero[6]=intval(substr($RecebeCNPJ,6-1,1));
            $Numero[7]=intval(substr($RecebeCNPJ,7-1,1));
            $Numero[8]=intval(substr($RecebeCNPJ,8-1,1));
            $Numero[9]=intval(substr($RecebeCNPJ,9-1,1));
            $Numero[10]=intval(substr($RecebeCNPJ,10-1,1));
            $Numero[11]=intval(substr($RecebeCNPJ,11-1,1));
            $Numero[12]=intval(substr($RecebeCNPJ,12-1,1));
            $Numero[13]=intval(substr($RecebeCNPJ,13-1,1));
            $Numero[14]=intval(substr($RecebeCNPJ,14-1,1));

            $soma=$Numero[1]*5+$Numero[2]*4+$Numero[3]*3+$Numero[4]*2+$Numero[5]*9+$Numero[6]*8+$Numero[7]*7+
            $Numero[8]*6+$Numero[9]*5+$Numero[10]*4+$Numero[11]*3+$Numero[12]*2;
            $soma=$soma-(11*(intval($soma/11)));
           if ($soma==0 || $soma==1){
             $resultado1=0;
           }
           else{
            $resultado1=11-$soma;
           }
           if ($resultado1==$Numero[13]){
                $soma=$Numero[1]*6+$Numero[2]*5+$Numero[3]*4+$Numero[4]*3+$Numero[5]*2+$Numero[6]*9+
                $Numero[7]*8+$Numero[8]*7+$Numero[9]*6+$Numero[10]*5+$Numero[11]*4+$Numero[12]*3+$Numero[13]*2;
                $soma=$soma-(11*(intval($soma/11)));
                if ($soma==0 || $soma==1){
                 $resultado2=0;
                }
               else{
                   $resultado2=11-$soma;
               }
               if ($resultado2==$Numero[14]){
               //print "==> entrou certo -> $resultado2<BR>";
                 return true;
               }
               else{
               //print "==> entrou erro<BR>";
                  return false;
               }
          }
          else{
              return false;
          }
     }
 }

 function validaEmail($email) {
		// First, we check that there's one @ symbol, and that the lengths are right		
		if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) {
			// Email invalid because wrong number of characters in one section, or wrong number of @ symbols.
			return false;
		}
		// Split it into sections to make life easier
		$email_array = explode("@", $email);
		$local_array = explode(".", $email_array[0]);
		for ($i = 0; $i < sizeof($local_array); $i++) {
			if (!ereg("^(([A-Za-z0-9!#$%&'*+/=?^_`{|}~-][A-Za-z0-9!#$%&'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i])) {
				return false;
			}
		}
		if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) { // Check if domain is IP. If not, it should be valid domain name
			$domain_array = explode(".", $email_array[1]);
			if (sizeof($domain_array) < 2) {
				return false; // Not enough parts to domain
			}
			for ($i = 0; $i < sizeof($domain_array); $i++) {
			if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$", $domain_array[$i])) {
				return false;
			}
			}
		}
		return true;
	}

	function formataMensagem($mensagem){
		return substr($mensagem,5);
	}

	public function getRealIpAddress2() {
		if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}		
		else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
	// return user hostname
	public function getRealHost2() {
		if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}		
		else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		$host = @gethostbyaddr($ip);		
		return $host;
	}
	
	function formataCarteira($codigoCarteira){
		for($i=strlen($codigoCarteira);$i<13;$i++){
			$codigoCarteira = "0".$codigoCarteira;
		}
		
		return "0029.".substr($codigoCarteira,0,strlen($codigoCarteira)-1)."-".substr($codigoCarteira,strlen($codigoCarteira)-1,1);
	}
	function limitaString($string,$tamanho){
		$string = rtrim($string);
		if(strlen($string) > $tamanho){
			return substr($string,0,$tamanho)."...";
		}else{
			return $string;
		}
	}
	
	
	
  function getNext($id, $nomeCampo, $tabela) {
        if (!$this->abreConexao()) {
            return -1;
        }
        $query = "SELECT *,$nomeCampo
	            FROM $tabela
			   WHERE $nomeCampo > $id
			ORDER BY $nomeCampo ASC
			   LIMIT 1";
        $rs = $this->conexao->Execute($query);
        if ($rs->recordCount() > 0) {
            $dados = $rs->fetchRow();
            $dados['id'] = $dados[$nomeCampo];
            return $dados;
        } else {
            return 0;
        }
    }
  
 function getPrev($id, $nomeCampo, $tabela) {
        if (!$this->abreConexao()) {
            return -1;
        }
        $query = "SELECT *,$nomeCampo
	            FROM $tabela
			   WHERE $nomeCampo < $id
			ORDER BY $nomeCampo DESC
			   LIMIT 1";
        //$this->conexao->debug=1;
        $rs = $this->conexao->Execute($query);
        if ($rs->recordCount() > 0) {
            $dados = $rs->fetchRow();
            $dados['id'] = $dados[$nomeCampo];
            return $dados;
        } else {
            return 0;
        }
    }
 
 
 function formataFone($fone){
	$fone = str_replace("(","",$fone);
	$fone = str_replace(")","",$fone);
	$fone = str_replace("-","",$fone);
	$fone = str_replace(".","",$fone);
	$fone = str_replace(" ","",$fone);
	if(strlen($fone) == 10){
		$fone = "(".substr($fone,0,2).") ".substr($fone,2,4)."-".substr($fone,6,4); 
	}else{
		return $fone;
	}
	return $fone;
  }
   function formataCpf($cpf){
  	$novoCpf = "000.000.000-00";
  	if(strlen($cpf) == 11){
		$novoCpf = $cpf[0].$cpf[1].$cpf[2].".".$cpf[3].$cpf[4].$cpf[5].".".$cpf[6].$cpf[7].$cpf[8]."-".$cpf[9].$cpf[10];
	}
	return $novoCpf;
  }
  
  function formataCpfCnpj($cpfCnpj){
  	$novoCpfCnpj = "000.000.000-00";
  	if(strlen($cpfCnpj) == 11){
		$novoCpfCnpj = $cpfCnpj[0].$cpfCnpj[1].$cpfCnpj[2].".".$cpfCnpj[3].$cpfCnpj[4].$cpfCnpj[5].".".$cpfCnpj[6].$cpfCnpj[7].$cpfCnpj[8]."-".$cpfCnpj[9].$cpfCnpj[10];
	}else if(strlen($cpfCnpj) == 14){
		$novoCpfCnpj = $cpfCnpj[0].$cpfCnpj[1].".".$cpfCnpj[2].$cpfCnpj[3].$cpfCnpj[4].".".$cpfCnpj[5].$cpfCnpj[6].$cpfCnpj[7]."/".$cpfCnpj[8].$cpfCnpj[9].$cpfCnpj[10].$cpfCnpj[11]."-".$cpfCnpj[12].$cpfCnpj[13];
	}
	return $novoCpfCnpj;
  }
  
  //-- funcoes do painel
  public function getLastId($nomeCampo, $tabela) {
        if ($this->abreConexao()) {
            $query = "SELECT $nomeCampo FROM $tabela WHERE $nomeCampo order by $nomeCampo desc limit 1";
            $rs = $this->conexao->Execute($query);
            if ($rs && $rs->recordCount() > 0) {
                $row = $rs->fetchRow();
                return $row[$nomeCampo];
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }
    
    function converteIsoToUtf($array) {
        foreach ($array as $key => $value) {
            $array[$key] = utf8_encode($value);
        }
        return $array;
    }

    function converteIsoToUtfMatriz($array) {
        foreach ($array as $key => $value) {
            $array[$key] = $this->converteIsoToUtf($value);
        }
        return $array;
    }

    function converteUtfToIso($array) {
        foreach ($array as $key => $value) {
            $array[$key] = utf8_decode($value);
        }
        return $array;
    }

	function mesDiferencaData($ini,$fim){

		$date = new DateTime($ini);
		$acompanhamento = $date->diff(new DateTime($fim));
		$acompanhamento_mostra_anos = $acompanhamento->format('%Y')*12;
		$acompanhamento_mostra_meses = $acompanhamento->format('%m');

		$total_meses = $acompanhamento_mostra_anos+$acompanhamento_mostra_meses;

		return $total_meses + 1;		
		
	}
	
  
}
?>
