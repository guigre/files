<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-key"></i> Usuários
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabela">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->			  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script>

	function atualizaTabela(){		

		$.ajax({
			url: 'ajax/acesso_ti_usuario.php?acao=listaUsuarios',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabela').html(result.tabela);
						
						$("#tabelaUsuarios").DataTable();
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}
	
	atualizaTabela();
	
</script>	  

<?php include("inc/rodape.php"); ?>