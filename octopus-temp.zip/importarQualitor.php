<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-file-text"></i> Importar Dados Qualitor
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Informação da Importação</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>				  
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="mesConsultaImportar" class="col-sm-2 control-label">Mês<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="mesConsultaImportar">
						<option value=''>:: Selecione ::</option>
						<option value='1'>Janeiro</option>
						<option value='2'>Fevereiro</option>
						<option value='3'>Março</option>
						<option value='4'>Abril</option>
						<option value='5'>Maio</option>
						<option value='6'>Junho</option>
						<option value='7'>Julho</option>
						<option value='8'>Agosto</option>
						<option value='9'>Setembro</option>
						<option value='10'>Outubro</option>
						<option value='11'>Novembro</option>
						<option value='12'>Dezembro</option>
                      </select>
					  </div>
                    </div>	
                    <div class="form-group">
                      <label for="anoConsultaImportar" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
					  <div class="col-xs-2">
                      <select class="form-control" id="anoConsultaImportar">
						<option value=''>:: Selecione ::</option>
						<option value='2013'>2013</option>
						<option value='2014'>2014</option>
						<option value='2015'>2015</option>
						<option value='2016'>2016</option>
						<option value='2017'>2017</option>
						<option value='2018'>2018</option>
                      </select>
					  </div>
                    </div> 
                    <div class="box-footer">
						<button type="button" class="btn btn-primary" onclick="javascript:void(importar())" id="btnImportar">Importar</button>&nbsp;&nbsp;
                    </div><!-- /.box-footer -->
					<div class="loaderImportar" style="display:none; text-align:left;">
							&nbsp;&nbsp;&nbsp;<span><img src="img/ajax-loader.gif"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Importando...
					</div>					
                </form>
              </div><!-- /.box -->		  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function importarDados(mes,ano){
		
		$.ajax({
			url: 'ajax/importar.php?acao=importarDados',
			type: 'POST',
			timeout: 1500000,
			dataType: 'json',
			data: {
				'mes' : mes,
				'ano' : ano	
			},			
			beforeSend: function() {
				$('.loaderImportar').show();				
			},
			complete: function() {
				$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						exibeErro('<p>'+result.msg+'</p>');
						
					}else{
										
						exibeErro('<p>'+result.msg+'</p>');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function importar(){
		var mes          = $('#mesConsulta').val();
		var ano          = $('#anoConsulta').val();		
		if(mes == ''){
			exibeErro('<p>Selecione um Mês</p>');
			$('#mesConsulta').focus();						
		}else if(ano == ''){
			exibeErro('<p>Selecione um Ano</p>');
			$('#anoConsulta').focus();						
		}else{
		 	importarDados(mes,ano);
		}
	}
	
</script>	  

<?php include("inc/rodape.php"); ?>

