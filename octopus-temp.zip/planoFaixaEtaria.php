<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Plano x Faixa Etária
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">	
				  <input type="hidden" id="cduserid" value="<?php print $_SESSION['usuario']; ?>">
                  <div class="box-body">	
                    <div class="form-group">
                      <label for="tabelaPrecoCadastro" class="col-sm-2 control-label">Tabela Preço<font color="red">*</font></label>
					  <div class="col-xs-4">
					  <div id="divTabelaPreco">

					  </div>
					  </div>
                    </div>				  
                    <div class="form-group">
                      <label for="modalidadeCadastro" class="col-sm-2 control-label">Modalidade<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="modalidadeCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="planoCadastro" class="col-sm-2 control-label">Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="planoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tipoPlanoCadastro" class="col-sm-2 control-label">Tipo Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="tipoPlanoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="grauParentescoCadastro" class="col-sm-2 control-label">Parentesco</label>
                      <div class="col-xs-4">
					  <div id="divGrauParentesco">

					  </div>
                      </div>
                    </div>		
                    <div class="form-group">
                      <label for="faixaEtariaCadastro" class="col-sm-2 control-label">Nº Faixa Etária<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="faixaEtariaCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="idadeMinimaCadastro" class="col-sm-2 control-label">Idade Mínima<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="idadeMinimaCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="idadeMaximaCadastro" class="col-sm-2 control-label">Idade Máxima<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="idadeMaximaCadastro" placeholder="">
                      </div>
                    </div>		
                    <div class="form-group">
                      <label for="valorFatorFaixaCadastro" class="col-sm-2 control-label">Valor Fator Faixa<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="valorFatorFaixaCadastro" placeholder="">
                      </div>
                    </div>					
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divPlanoFaixaEtaria">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#tabelaPrecoCadastro').val('');
		$('#modalidadeCadastro').val('');
		$('#planoCadastro').val('');
		$('#tipoPlanoCadastro').val('');		
		$('#grauParentescoCadastro').val('0');
		$('#faixaEtariaCadastro').val('');
		$('#idadeMinimaCadastro').val('');
		$('#idadeMaximaCadastro').val('');
		$('#valorFatorFaixaCadastro').val('');
		$('#acao').val('cadastra');
		
		$('#tabelaPrecoCadastro').prop("disabled",false);
		$('#modalidadeCadastro').prop("disabled",false);
		$('#planoCadastro').prop("disabled",false);
		$('#tipoPlanoCadastro').prop("disabled",false);		
		$('#grauParentescoCadastro').prop("disabled",false);
		$('#faixaEtariaCadastro').prop("disabled",false);
		$('#idadeMinimaCadastro').prop("disabled",false);
		$('#idadeMaximaCadastro').prop("disabled",false);		
		$('#valorFatorFaixaCadastro').prop("disabled",false);
	
		$('#tabelaPrecoCadastro').focus();
		
	}

	function salvar(){
		
		var tabelaPrecoCadastro     = $('#tabelaPrecoCadastro').val();
		var modalidadeCadastro      = $('#modalidadeCadastro').val();
		var planoCadastro           = $('#planoCadastro').val();
		var tipoPlanoCadastro       = $('#tipoPlanoCadastro').val();
		var grauParentescoCadastro  = $('#grauParentescoCadastro').val();
		var faixaEtariaCadastro     = $('#faixaEtariaCadastro').val();
		var idadeMinimaCadastro     = $('#idadeMinimaCadastro').val();
		var idadeMaximaCadastro     = $('#idadeMaximaCadastro').val();		
		var valorFatorFaixaCadastro = $('#valorFatorFaixaCadastro').val();
		var acao   	    		    = $('#acao').val();
		var cduserid			    = $('#cduserid').val();
		
		if(tabelaPrecoCadastro == ''){
			exibeErro('<p>Campo <b>(Tabela de Preço)</b> Obrigatório!</p>');
			$('#tabelaPrecoCadastro').focus();
		}else if(modalidadeCadastro == ''){
			exibeErro('<p>Campo <b>(Modalidade)</b> Obrigatório!</p>');
			$('#modalidadeCadastro').focus();
		}else if(planoCadastro == ''){
			exibeErro('<p>Campo <b>(Plano)</b> Obrigatório!</p>');
			$('#planoCadastro').focus();
		}else if(tipoPlanoCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo Plano)</b> Obrigatório!</p>');
			$('#tipoPlanoCadastro').focus();
		}else if(grauParentescoCadastro == ''){
			exibeErro('<p>Campo <b>(Parentesco)</b> Obrigatório!</p>');
			$('#grauParentescoCadastro').focus();
		}else if(faixaEtariaCadastro == ''){
			exibeErro('<p>Campo <b>(Nº Faixa Etária)</b> Obrigatório!</p>');
			$('#faixaEtariaCadastro').focus();
		}else if(idadeMinimaCadastro == ''){
			exibeErro('<p>Campo <b>(Idade Mínima)</b> Obrigatório!</p>');
			$('#idadeMinimaCadastro').focus();
		}else if(idadeMaximaCadastro == ''){
			exibeErro('<p>Campo <b>(Idade Máxima)</b> Obrigatório!</p>');
			$('#idadeMaximaCadastro').focus();
		}else if(valorFatorFaixaCadastro == ''){
			exibeErro('<p>Campo <b>(Valor Fator Faixa)</b> Obrigatório!</p>');
			$('#valorFatorFaixaCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/planoFaixaEtaria.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'tabelaPrecoCadastro'     : tabelaPrecoCadastro,        
					   'modalidadeCadastro'      : modalidadeCadastro,     
					   'planoCadastro'           : planoCadastro,          
					   'tipoPlanoCadastro'       : tipoPlanoCadastro,      
					   'grauParentescoCadastro'  : grauParentescoCadastro, 
					   'faixaEtariaCadastro'     : faixaEtariaCadastro,    
					   'idadeMinimaCadastro'     : idadeMinimaCadastro,    
					   'idadeMaximaCadastro'     : idadeMaximaCadastro,    
					   'valorFatorFaixaCadastro' : valorFatorFaixaCadastro,
					   'acao'   	    		 : acao,   	    		    
					   'cduserid'			     : cduserid
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){	
		$.ajax({
			url: 'ajax/planoFaixaEtaria.php?acao=listaPlanoFaixaEtaria',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divPlanoFaixaEtaria').html(result.tabela);
						
						$("#tabelaPlanoFaixaEtaria").DataTable();
						
					}else{
										
						$('#divPlanoFaixaEtaria').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(tabelaPreco,modalidade,plano,tipoPlano,grauParentesco,faixaEtaria){		
		
		$.ajax({
			url: 'ajax/planoFaixaEtaria.php?acao=buscaPlanoFaixaEtaria',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'tabelaPreco'    : tabelaPreco,
				'modalidade'     : modalidade,
			    'plano'		     : plano,
				'tipoPlano'	     : tipoPlano,				
				'grauParentesco' : grauParentesco,
				'faixaEtaria'    : faixaEtaria
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#tabelaPrecoCadastro').val(result.cdtabpreco);
						$('#modalidadeCadastro').val(result.cdmodalidade);
		                $('#planoCadastro').val(result.cdplano);
		                $('#tipoPlanoCadastro').val(result.cdtipoplano);		                
		                $('#grauParentescoCadastro').val(result.cdgrauparentesco);
		                $('#faixaEtariaCadastro').val(result.nrfaixaetaria);
		                $('#idadeMinimaCadastro').val(result.nridademinima);
		                $('#idadeMaximaCadastro').val(result.nridademaxima);
		                $('#valorFatorFaixaCadastro').val(result.vlfatorfaixa);
						$('#acao').val('atualizar');
						
						$('#tabelaPrecoCadastro').prop("disabled",true);
						$('#modalidadeCadastro').prop("disabled",true);
						$('#planoCadastro').prop("disabled",true);
						$('#tipoPlanoCadastro').prop("disabled",true);						
						$('#grauParentescoCadastro').prop("disabled",true);
						$('#faixaEtariaCadastro').prop("disabled",true);
						
						$('#idadeMinimaCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#tabelaPrecoCadastro').val() != '' && $('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#faixaEtariaCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir o registro?");		
		}else{
			exibeErro('Você deve selecionar um registro primeiro.');
		}
	}
	
	function excluir(){		
		
		if($('#tabelaPrecoCadastro').val() != '' && $('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#faixaEtariaCadastro').val() != ''){
			
			var tabelaPreco     = $('#tabelaPrecoCadastro').val();
			var modalidade      = $('#modalidadeCadastro').val();
			var plano           = $('#planoCadastro').val();
			var tipoPlano       = $('#tipoPlanoCadastro').val();
			var grauParentesco  = $('#grauParentescoCadastro').val();
			var faixaEtaria     = $('#faixaEtariaCadastro').val();
			
			$.ajax({
				url: 'ajax/planoFaixaEtaria.php?acao=excluiPlanoFaixaEtaria',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
						'tabelaPreco'    : tabelaPreco,
						'modalidade'     : modalidade, 
                        'plano'          : plano,      
                        'tipoPlano'      : tipoPlano,                          
                        'grauParentesco' : grauParentesco,
						'faixaEtaria'    : faixaEtaria
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar uma tabela de preço primeiro.');			
		}		
		
	}	
	
	function montaTabelaPreco(){
		
		$.ajax({
			url: 'ajax/tabelaPrecoModulo.php?acao=montaTabelaPreco',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaPreco').html(result.select);
						
					}else{
										
						$('#divTabelaPreco').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}	

	function montaGrauParentesco(){
		
		$.ajax({
			url: 'ajax/planoFaixaEtaria.php?acao=montaGrauParentesco',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divGrauParentesco').html(result.select);
						
					}else{
										
						$('#divGrauParentesco').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	atualizaTabela();
	montaTabelaPreco();
	montaGrauParentesco();
	
	$("#valorFatorFaixaCadastro").maskMoney({thousands:'.', decimal:',', symbolStay: true, allowNegative: true});
	
	$('#tabelaPrecoCadastro').focus();
		
	$('#valorFatorFaixaCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

