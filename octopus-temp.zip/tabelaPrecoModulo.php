<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Tabela Preço x Módulo
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">	
				  <input type="hidden" id="cduserid" value="<?php print $_SESSION['usuario']; ?>">
                  <div class="box-body">			  
                    <div class="form-group">
                      <label for="modalidadeCadastro" class="col-sm-2 control-label">Modalidade<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="modalidadeCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="planoCadastro" class="col-sm-2 control-label">Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="planoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tipoPlanoCadastro" class="col-sm-2 control-label">Tipo Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="tipoPlanoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tabelaPrecoCadastro" class="col-sm-2 control-label">Tabela Preço<font color="red">*</font></label>
					  <div class="col-xs-4">
					  <div id="divTabelaPreco">

					  </div>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="moduloCadastro" class="col-sm-2 control-label">Módulo<font color="red">*</font></label>
                      <div class="col-xs-4">
                        <input type="text" class="form-control" id="moduloCadastro" placeholder="">
                      </div>
                    </div>		
                    <div class="form-group">
                      <label for="valorModuloCadastro" class="col-sm-2 control-label">Valor Módulo<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="valorModuloCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="idadeMinimaCadastro" class="col-sm-2 control-label">Idade Mínima<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="idadeMinimaCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="idadeMaximaCadastro" class="col-sm-2 control-label">Idade Máxima<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="idadeMaximaCadastro" placeholder="">
                      </div>
                    </div>					
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaPrecoModulo">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#modalidadeCadastro').val('');
		$('#planoCadastro').val('');
		$('#tipoPlanoCadastro').val('');
		$('#tabelaPrecoCadastro').val('');
		$('#moduloCadastro').val('');
		$('#valorModuloCadastro').val('');
		$('#idadeMinimaCadastro').val('');
		$('#idadeMaximaCadastro').val('');
		$('#acao').val('cadastra');
		
		$('#modalidadeCadastro').prop("disabled",false);
		$('#planoCadastro').prop("disabled",false);
		$('#tipoPlanoCadastro').prop("disabled",false);
		$('#tabelaPrecoCadastro').prop("disabled",false);
		$('#moduloCadastro').prop("disabled",false);
		$('#valorModuloCadastro').prop("disabled",false);
		$('#idadeMinimaCadastro').prop("disabled",false);
		$('#idadeMaximaCadastro').prop("disabled",false);		
	
		$('#modalidadeCadastro').focus();
		
	}

	function salvar(){
		
		var modalidadeCadastro     = $('#modalidadeCadastro').val();
		var planoCadastro          = $('#planoCadastro').val();
		var tipoPlanoCadastro      = $('#tipoPlanoCadastro').val();
		var tabelaPrecoCadastro    = $('#tabelaPrecoCadastro').val();
		var moduloCadastro         = $('#moduloCadastro').val();
		var valorModuloCadastro    = $('#valorModuloCadastro').val();
		var idadeMinimaCadastro    = $('#idadeMinimaCadastro').val();
		var idadeMaximaCadastro    = $('#idadeMaximaCadastro').val();		
		var acao   	    		   = $('#acao').val();
		var cduserid			   = $('#cduserid').val();
		
		if(modalidadeCadastro == ''){
			exibeErro('<p>Campo <b>(Modalidade)</b> Obrigatório!</p>');
			$('#modalidadeCadastro').focus();
		}else if(planoCadastro == ''){
			exibeErro('<p>Campo <b>(Plano)</b> Obrigatório!</p>');
			$('#planoCadastro').focus();
		}else if(tipoPlanoCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo Plano)</b> Obrigatório!</p>');
			$('#tipoPlanoCadastro').focus();
		}else if(tabelaPrecoCadastro == ''){
			exibeErro('<p>Campo <b>(Tabela de Preço)</b> Obrigatório!</p>');
			$('#tabelaPrecoCadastro').focus();
		}else if(moduloCadastro == ''){
			exibeErro('<p>Campo <b>(Módulo)</b> Obrigatório!</p>');
			$('#moduloCadastro').focus();
		}else if(valorModuloCadastro == ''){
			exibeErro('<p>Campo <b>(Valor Módulo)</b> Obrigatório!</p>');
			$('#valorModuloCadastro').focus();
		}else if(idadeMinimaCadastro == ''){
			exibeErro('<p>Campo <b>(Idade Mínima)</b> Obrigatório!</p>');
			$('#idadeMinimaCadastro').focus();
		}else if(idadeMaximaCadastro == ''){
			exibeErro('<p>Campo <b>(Idade Máxima)</b> Obrigatório!</p>');
			$('#idadeMaximaCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/tabelaPrecoModulo.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'modalidadeCadastro'   : modalidadeCadastro,        
					   'planoCadastro'        : planoCadastro,       
					   'tipoPlanoCadastro'    : tipoPlanoCadastro,   
					   'tabelaPrecoCadastro'  : tabelaPrecoCadastro, 
					   'moduloCadastro'       : moduloCadastro,      
					   'valorModuloCadastro'  : valorModuloCadastro, 
					   'idadeMinimaCadastro'  : idadeMinimaCadastro, 
					   'idadeMaximaCadastro'  : idadeMaximaCadastro, 
					   'acao'   	    	  : acao,   	    		
					   'cduserid'			  : cduserid
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){	
		$.ajax({
			url: 'ajax/tabelaPrecoModulo.php?acao=listaTabelaPrecoModulo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaPrecoModulo').html(result.tabela);
						
						$("#tabelaPrecoModulo").DataTable();
						
					}else{
										
						$('#divTabelaPrecoModulo').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(modalidade,plano,tipoPlano,tabelaPreco,modulo){
		
		
		$.ajax({
			url: 'ajax/tabelaPrecoModulo.php?acao=buscaTabelaPrecoModulo',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'modalidade'  : modalidade,
			    'plano'		  : plano,
				'tipoPlano'	  : tipoPlano,
				'tabelaPreco' : tabelaPreco,
				'modulo'      : modulo
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#modalidadeCadastro').val(result.cdmodalidade);
		                $('#planoCadastro').val(result.cdplano);
		                $('#tipoPlanoCadastro').val(result.cdtipoplano);
		                $('#tabelaPrecoCadastro').val(result.cdtabpreco);
		                $('#moduloCadastro').val(result.cdmodulo);
		                $('#valorModuloCadastro').val(result.vlmodulo);
		                $('#idadeMinimaCadastro').val(result.nridademinima);
		                $('#idadeMaximaCadastro').val(result.nridademaxima);
		                $('#acao').val('atualizar');
						
						$('#modalidadeCadastro').prop("disabled",true);
						$('#planoCadastro').prop("disabled",true);
						$('#tipoPlanoCadastro').prop("disabled",true);
						$('#tabelaPrecoCadastro').prop("disabled",true);
						$('#moduloCadastro').prop("disabled",true);
						
						$('#valorModuloCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#tabelaPrecoCadastro').val() != '' && $('#moduloCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir o registro?");		
		}else{
			exibeErro('Você deve selecionar um registro primeiro.');
		}
	}
	
	function excluir(){		
		
		if($('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#tabelaPrecoCadastro').val() != '' && $('#moduloCadastro').val() != ''){
			
			var modalidade  = $('#modalidadeCadastro').val();
			var plano       = $('#planoCadastro').val();
			var tipoPlano   = $('#tipoPlanoCadastro').val();
			var tabelaPreco = $('#tabelaPrecoCadastro').val();
			var modulo      = $('#moduloCadastro').val();
			
			$.ajax({
				url: 'ajax/tabelaPrecoModulo.php?acao=excluiTabelaPrecoModulo',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
						'modalidade'  : modalidade, 
                        'plano'       : plano,      
                        'tipoPlano'   : tipoPlano,  
                        'tabelaPreco' : tabelaPreco,
                        'modulo'      : modulo
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar uma tabela de preço primeiro.');			
		}		
		
	}	
	
	function montaTabelaPreco(){
		
		$.ajax({
			url: 'ajax/tabelaPrecoModulo.php?acao=montaTabelaPreco',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaPreco').html(result.select);
						
					}else{
										
						$('#divTabelaPreco').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}	
		
	atualizaTabela();
	montaTabelaPreco();
	
	$("#valorModuloCadastro").maskMoney({thousands:'.', decimal:',', symbolStay: true, allowNegative: true});
	
	$('#modalidadeCadastro').focus();
		
	$('#idadeMaximaCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

