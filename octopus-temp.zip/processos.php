<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Processos
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">	
				  <div class="box-body">			  
                    <div class="form-group">
                      <label for="idProcesso" class="col-sm-2 control-label">ID<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="idProcesso" placeholder="" disabled="disabled">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="descricao" class="col-sm-2 control-label">DESCRI&Ccedil;&Atilde;O<font color="red">*</font></label>
                      <div class="col-xs-6">
                        <input type="text" class="form-control" id="descricao" placeholder="">
                      </div>
                    </div>         				
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
				    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;                    
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaProcessos">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		buscaProximoID();
		$('#descricao').val('');
		$('#acao').val('cadastrar');
		$('#descricao').focus();	
				
	}

	function salvar(){
		
		var id        = $('#idProcesso').val();
		var descricao = $('#descricao').val();
		var acao      = $('#acao').val();
		
		if(descricao == ''){
			exibeErro('<p>Campo <b>(DESCRI&Ccedil;&Atilde;O)</b> Obrigatório!</p>');
			$('#descricao').focus();
		}else{
			$.ajax({
				url: 'ajax/processo.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'id'        : id,        
					   'descricao' : descricao,
					   'acao'      : acao
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){	
		$.ajax({
			url: 'ajax/processo.php?acao=listaProcessos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaProcessos').html(result.tabela);
						
						$("#tabelaProcessos").DataTable();
						
					}else{
										
						$('#divTabelaProcessos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(id){
				
		$.ajax({
			url: 'ajax/processo.php?acao=buscaProcesso',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'id' : id
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#idProcesso').val(result.idProcesso);
		                $('#descricao').val(result.descricao);
		                $('#acao').val('atualizar');
						
						$('#descricao').focus();
						
					}else{							
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function buscaProximoID(){
		
		$.ajax({
			url: 'ajax/processo.php?acao=buscaProximoID',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				
				$('#idProcesso').val(result.idProcesso);
				
			}
		});		
		
	}
	
	buscaProximoID();
		
	atualizaTabela();
	
	$('#descricao').focus();
	
	$('#descricao').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

