<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-user"></i> Privilégios
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
					<div>
						<input type="hidden" id="loginExclusao">
						<input type="hidden" id="menuExclusao">
					</div>
					<div class="form-group">
					   <label for="loginCadastro" class="col-sm-2 control-label">Usuários<font color="red">*</font></label>
						<div class="col-xs-8">
							<div id="divUsuarios">

							</div>
						</div>
					</div>
					<div class="form-group">
					   <label for="privilegioCadastro" class="col-sm-2 control-label">Privilégios<font color="red">*</font></label>
						<div class="col-xs-8">
							<div id="divPrivilegios">

							</div>
						</div>
					</div>
			      </div><!-- /.box-body -->
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabela">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->			  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script>

	function novo(){
		
		$('#loginCadastro').val('');
		$('#privilegioCadastro').val('');
		$('#loginExclusao').val('');
		$('#menuExclusao').val('');
		$("#loginCadastro").select2();
		$("#privilegioCadastro").select2();
		$('#loginCadastro').focus();
	}
	
	function montaPrivilegios(){
		
		$.ajax({
			url: 'ajax/privilegio.php?acao=montaPrivilegios',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divPrivilegios').html(result.select);
						
						$(".select2").select2();
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function montaUsuarios(){
		
		$.ajax({
			url: 'ajax/privilegio.php?acao=montaUsuarios',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divUsuarios').html(result.select);
						
						$(".select2").select2();
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}

	function salvar(){
		
		var loginCadastro         = $('#loginCadastro').val();
		var privilegioCadastro    = $('#privilegioCadastro').val();
		
		if(loginCadastro == ''){
			exibeErro('<p>Campo <b>(Usuário)</b> Obrigatório!</p>');
			$('#loginCadastro').focus();
		}else if(privilegioCadastro == ''){
			exibeErro('<p>Campo <b>(Privilégio)</b> Obrigatório!</p>');
			$('#privilegioCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/privilegio.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					   'loginCadastro'         : loginCadastro,
					   'privilegioCadastro'    : privilegioCadastro
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){		

		$.ajax({
			url: 'ajax/privilegio.php?acao=listaPrivilegios',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabela').html(result.tabela);
						
						$("#tabelaPrivilegios").DataTable();
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}
	
	function confirmacao(login, menu){
		$('#loginExclusao').val(login);
		$('#menuExclusao').val(menu);
		exibeExclusao("Você realmente deseja excluir o privilégio?");
	}
	
	function excluir(){
		
		$.ajax({
			url: 'ajax/privilegio.php?acao=excluiPrivilegio',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'login' : $('#loginExclusao').val(),
				'menu'  : $('#menuExclusao').val()
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result){
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						exibeErro('<p>'+result.msg+'</p>');
						atualizaTabela();
						novo();
					}else{
						exibeErro('<p>'+result.msg+'</p>');
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	atualizaTabela();
	montaUsuarios();
	montaPrivilegios();
	
	$('#loginCadastro').focus();
	
</script>	  

<?php include("inc/rodape.php"); ?>