<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-line-chart"></i> Indicadores de TI
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <div class="box">
     		<div class="box-body">

            <div class="col-md-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tabPPR" data-toggle="tab">Indicadores de PPR - 2015</a></li>
                  <li><a href="#tadIncidentes" data-toggle="tab">Processo de Incidentes</a></li>
                  <li><a href="#tabRequisicoes" data-toggle="tab">Processo de Requisições</a></li>
                  <li><a href="#tabDesenvolvimentos" data-toggle="tab">Processo de Desenvolvimentos</a></li>
                  <li><a href="#tabBC" data-toggle="tab">Gestão do Conhecimento </a></li>
                </ul>
                <div class="tab-content">
				
                 <div class="active tab-pane" id="tabPPR">
                    
					<div class="box">
						<div class="box-header">
						  <h3 class="box-title">Filtros da Consulta - <b>Indicadores de PPR - 2015</b></h3>
						</div><!-- /.box-header -->
						
						<form class="form-horizontal">
						  <div class="box-body">
						  <div class="form-group">
						    <label for="mesConsultaPPR" class="col-sm-2 control-label">Mês<font color="red">*</font></label>
						    <div class="col-xs-2">
						    <select class="form-control" id="mesConsultaPPR">
						  	<option value=''>:: Selecione ::</option>
						  	<option value='1'>Janeiro</option>
						  	<option value='2'>Fevereiro</option>
						  	<option value='3'>Março</option>
						  	<option value='4'>Abril</option>
						  	<option value='5'>Maio</option>
						  	<option value='6'>Junho</option>
						  	<option value='7'>Julho</option>
						  	<option value='8'>Agosto</option>
						  	<option value='9'>Setembro</option>
						  	<option value='10'>Outubro</option>
						  	<option value='11'>Novembro</option>
						  	<option value='12'>Dezembro</option>
						    </select>
						    </div>
						  </div>							  
							<div class="form-group">
							  <label for="anoConsultaPPR" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
							  <div class="col-xs-2">
							  <select class="form-control" id="anoConsultaPPR">
								<option value=''>:: Selecione ::</option>
								<option value='2013'>2013</option>
								<option value='2014'>2014</option>
								<option value='2015'>2015</option>
								<option value='2016'>2016</option>
								<option value='2017'>2017</option>
								<option value='2018'>2018</option>
							  </select>
							  </div>
							</div> 	
							<div class="box-footer">
								<button type="button" class="btn btn-primary" onclick="javascript:void(gerar(5))" id="btnConsultar">Gerar Indicadores PPR</button>&nbsp;&nbsp;
							</div><!-- /.box-footer -->
						</form>
					  </div><!-- /.box -->	
				
					  </div>
						<div id="resultadoPPR" style="display:none;">
							  <div class="row">
							  
								 <div id="percentualFinalPPR" style="display:none;"></div>
								 <div id="prazoSolicitacaoDemandas" style="display:none;"></div>	
								 <div id="percentualProjetos" style="display:none;"></div>	
								 
 								 <p>&nbsp;</p>
 								 <p>&nbsp;</p>
								
								 <div id="graficoDocumentosPPR"></div>								
								 
								 <p>&nbsp;</p>
								 <p>&nbsp;</p>
								
								 <div id="graficoPrazoSolicitacaoDemandas"></div>								 
								
							  </div><!-- /.row -->	

						</div>						
					
                  </div><!-- /.tab-pane -->	
				
                  <div class="tab-pane" id="tadIncidentes">
					  
					  <div class="box">
						<div class="box-header">
						  <h3 class="box-title">Filtros da Consulta - <b>Processo de Incidentes</b></h3>
						</div><!-- /.box-header -->
						
						<form class="form-horizontal">
						  <div class="box-body">
						  <div class="form-group">
						    <label for="mesConsulta" class="col-sm-2 control-label">Mês<font color="red">*</font></label>
						    <div class="col-xs-2">
						    <select class="form-control" id="mesConsulta">
						  	<option value=''>:: Selecione ::</option>
						  	<option value='1'>Janeiro</option>
						  	<option value='2'>Fevereiro</option>
						  	<option value='3'>Março</option>
						  	<option value='4'>Abril</option>
						  	<option value='5'>Maio</option>
						  	<option value='6'>Junho</option>
						  	<option value='7'>Julho</option>
						  	<option value='8'>Agosto</option>
						  	<option value='9'>Setembro</option>
						  	<option value='10'>Outubro</option>
						  	<option value='11'>Novembro</option>
						  	<option value='12'>Dezembro</option>
						    </select>
						    </div>
						  </div>							  
							<div class="form-group">
							  <label for="anoConsulta" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
							  <div class="col-xs-2">
							  <select class="form-control" id="anoConsulta">
								<option value=''>:: Selecione ::</option>
								<option value='2013'>2013</option>
								<option value='2014'>2014</option>
								<option value='2015'>2015</option>
								<option value='2016'>2016</option>
								<option value='2017'>2017</option>
								<option value='2018'>2018</option>
							  </select>
							  </div>
							</div> 	
							<div class="box-footer">
								<button type="button" class="btn btn-primary" onclick="javascript:void(gerar(1))" id="btnConsultar">Gerar Incidentes</button>&nbsp;&nbsp;
							</div><!-- /.box-footer -->
						</form>
					  </div><!-- /.box -->					
				
					  </div>
						<div id="resultadoIncidentes" style="display:none;">
							  <div class="row">
							  
								<div id="incidentesAbertos" style="display:none;"></div>
								
								<div id="incidentesEncerrados" style="display:none;"></div>
								
								<div id="incidentesEncerradosPrazo" style="display:none;"></div>
								
								<div id="incidentesEncerradosForaPrazo" style="display:none;"></div>						

								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesAbertos"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesEncerrados"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesPrazo"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesPrazoRepostaSolucao"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesPrincipal"></div>
								
								<p>&nbsp;</p>								
								
								<div id="graficoTotalIncidentesNivel"></div>

								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesReabertos"></div>	
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesSeveridade"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesMaiores90"></div>	
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesBacklog"></div>								
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesServico"></div>	

								<p>&nbsp;</p>
								
								<div id="graficoTotalIncidentesServicoAnual"></div>								
								
							  </div><!-- /.row -->	

						</div>					  
 
                  </div><!-- /.tab-pane -->
				  
                  <div class="tab-pane" id="tabRequisicoes">
				  
					<div class="box">
						<div class="box-header">
						  <h3 class="box-title">Filtros da Consulta - <b>Processo de Requisições</b></h3>
						</div><!-- /.box-header -->
						
						<form class="form-horizontal">
						  <div class="box-body">
						  <div class="form-group">
						    <label for="mesConsultaRequisicoes" class="col-sm-2 control-label">Mês<font color="red">*</font></label>
						    <div class="col-xs-2">
						    <select class="form-control" id="mesConsultaRequisicoes">
						  	<option value=''>:: Selecione ::</option>
						  	<option value='1'>Janeiro</option>
						  	<option value='2'>Fevereiro</option>
						  	<option value='3'>Março</option>
						  	<option value='4'>Abril</option>
						  	<option value='5'>Maio</option>
						  	<option value='6'>Junho</option>
						  	<option value='7'>Julho</option>
						  	<option value='8'>Agosto</option>
						  	<option value='9'>Setembro</option>
						  	<option value='10'>Outubro</option>
						  	<option value='11'>Novembro</option>
						  	<option value='12'>Dezembro</option>
						    </select>
						    </div>
						  </div>							  
							<div class="form-group">
							  <label for="anoConsultaRequisicoes" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
							  <div class="col-xs-2">
							  <select class="form-control" id="anoConsultaRequisicoes">
								<option value=''>:: Selecione ::</option>
								<option value='2013'>2013</option>
								<option value='2014'>2014</option>
								<option value='2015'>2015</option>
								<option value='2016'>2016</option>
								<option value='2017'>2017</option>
								<option value='2018'>2018</option>
							  </select>
							  </div>
							</div> 	
							<div class="box-footer">
								<button type="button" class="btn btn-primary" onclick="javascript:void(gerar(2))" id="btnConsultar">Gerar Requisições</button>&nbsp;&nbsp;
							</div><!-- /.box-footer -->
						</form>
					  </div><!-- /.box -->					
				
					  </div>				  
                    
						<div id="resultadoRequisicoes" style="display:none;">
							  <div class="row">
							  
								<div id="requisicoesAbertas" style="display:none;"></div>
								
								<div id="requisicoesEncerradas" style="display:none;"></div>
								
								<div id="requisicoesEncerradasPrazo" style="display:none;"></div>
								
								<div id="requisicoesEncerradasForaPrazo" style="display:none;"></div>

								<p>&nbsp;</p>
								
								<div id="graficoTotalRequisicoesAbertas" style="width:100%"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalRequisicoesEncerradas"></div>			

								<p>&nbsp;</p>
								
								<div id="graficoPercentualRequisicoesPrazo"></div>								
								
								<p>&nbsp;</p>
								
								<div id="graficoPercentualReqPrazoTipo"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoQtdeReqEncerTipoNivel"></div>
								
								<p>&nbsp;</p>
								
								<div class="col-md-6">
									<div id="graficoRequisicoesAbertasTipo"></div>
								</div>
								<div class="col-md-6">
									<div id="graficoRequisicoesEncerradasTipo"></div>
								</div>
								<div class="col-md-6">
									<div id="graficoPercRequisicoesAbertasTipo"></div>
								</div>
								<div class="col-md-6">
									<div id="graficoPercRequisicoesEncerradasTipo"></div>
								</div>
								<div class="col-md-4">
									<div id="graficoRequisicoesReabertas"></div>
								</div>
								<div class="col-md-4">
									<div id="graficoRequisicoesAbertasServico"></div>
								</div>
								<div class="col-md-4">
									<div id="graficoRequisicoesEncerradasNivel"></div>
								</div>
								
								<p>&nbsp;</p>
								
								<div id="graficoPercReqEncerTipoNivel"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalRequisicoesMaiores90"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalRequisicoesBacklog"></div>
								
							  </div><!-- /.row -->	

						</div>	

                  </div><!-- /.tab-pane -->

                  <div class="tab-pane" id="tabDesenvolvimentos">
				  
						<div class="box">
							<div class="box-header">
								<h3 class="box-title">Filtros da Consulta - <b>Processo de Desenvolvimento</b></h3>
							</div><!-- /.box-header -->
						
							<form class="form-horizontal">
								<div class="box-body">
									<div class="form-group">
										<label for="mesConsultaDesenvolvimento" class="col-sm-2 control-label">Mês<font color="red">*</font></label>
										<div class="col-xs-2">
											<select class="form-control" id="mesConsultaDesenvolvimento">
												<option value=''>:: Selecione ::</option>
												<option value='1'>Janeiro</option>
												<option value='2'>Fevereiro</option>
												<option value='3'>Março</option>
												<option value='4'>Abril</option>
												<option value='5'>Maio</option>
												<option value='6'>Junho</option>
												<option value='7'>Julho</option>
												<option value='8'>Agosto</option>
												<option value='9'>Setembro</option>
												<option value='10'>Outubro</option>
												<option value='11'>Novembro</option>
												<option value='12'>Dezembro</option>
											</select>
										</div>
									</div>							  
									<div class="form-group">
										<label for="anoConsultaDesenvolvimento" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
										<div class="col-xs-2">
											<select class="form-control" id="anoConsultaDesenvolvimento">
												<option value=''>:: Selecione ::</option>
												<option value='2013'>2013</option>
												<option value='2014'>2014</option>
												<option value='2015'>2015</option>
												<option value='2016'>2016</option>
												<option value='2017'>2017</option>
												<option value='2018'>2018</option>
											</select>
										</div>
									</div> 	
									<div class="box-footer">
										<button type="button" class="btn btn-primary" onclick="javascript:void(gerar(3))" id="btnConsultar">Gerar Desenvolvimentos</button>&nbsp;&nbsp;
									</div><!-- /.box-footer -->
								</div>
							</form>
						</div><!-- /.box -->
						
						<div id="resultadoDesenvolvimento" style="display:none;">
							<div class="row">
								<div id="desenvolvimentosAbertos" style="display:none;"></div>
								
								<div id="desenvolvimentosEncerrados" style="display:none;"></div>
								
								<div id="desenvolvimentosEncerradosPrazo" style="display:none;"></div>
								
								<div id="desenvolvimentosEncerradosForaPrazo" style="display:none;"></div>

								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosAbertos" style="width:100%"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosEncerrados" style="width:100%"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosCancelados" style="width:100%"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosPrazo"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosPrazoEFora"></div>
								
								<p>&nbsp;</p>
								
								<div class="col-md-6">
									<div id="graficoTotalDesenvReagendados"></div>
								</div>
								<div class="col-md-6">
									<div id="graficoTotalIncidentesDevidoDesenv"></div>
								</div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosBacklog"></div>
								
								<p>&nbsp;</p>
								
								<div id="graficoTotalDesenvolvimentosEtapa"></div>
								
								<div class="col-md-4">
									<div id="graficoTotalDesenvolvForaPrazoEtapa"></div>
								</div>
								<div class="col-md-4">
									<div id="graficoTotalDesenvolvForaPrazoResp"></div>
								</div>
								<div class="col-md-4">
									<div id="graficoTotalDesenvolvForaPrazoDias"></div>
								</div>
								
							</div>
						</div>
                  </div><!-- /.tab-pane -->

                  <div class="tab-pane" id="tabBC">
                    
						<h2><i class="fa fa-wrench"></i> Gestão do Conhecimento - Under Construction</h2>
					
                  </div><!-- /.tab-pane -->				  
				  
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div><!-- /.col -->				
				
				</div>
              </div><!-- /.box -->
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function buscaTotalAbertos(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#incidentesAbertos').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#00995D"><i class="fa fa-bar-chart" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Incidentes <br> Abertos</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#incidentesAbertos').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	

	function buscaTotalEncerrados(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
		
						$('#incidentesEncerrados').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#00995D"><i class="fa  fa-check-square-o" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Incidentes <br> Encerrados</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#incidentesEncerrados').show();	
						
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function buscaTotalEncerradosPrazo(indicador,ano,prazo){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=totalEncerrados',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'prazo'     : prazo
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){					
						
						$('#incidentesEncerradosPrazo').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#00995D"><i class="fa fa-thumbs-o-up" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Encerrados no <br> Prazo</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#incidentesEncerradosPrazo').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function buscaTotalEncerradosForaPrazo(indicador,ano,prazo){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=totalEncerrados',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
                'prazo'     : prazo  				
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#incidentesEncerradosForaPrazo').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#00995D"><i class="fa fa-thumbs-o-down" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Encerrados Fora <br> Prazo</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#incidentesEncerradosForaPrazo').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function graficoTotalIncidentesAbertos(indicador,ano,tipo){

		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesAbertos';
		}else{
			div = '#graficoTotalIncidentesAbertosModal';
		}	

		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('abertos',ano,0);
									}		
								}							
							},
							title: {
								text: 'Quantidade total de incidentes ABERTOS',
								style: {"font-weight": "bold"},
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#00995D',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#411564',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesEncerrados(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesEncerrados';
		}else{
			div = '#graficoTotalIncidentesEncerradosModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('encerrados',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade total de incidentes ENCERRADOS',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#00995D',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#411564',
								name: 'Resultado ' + ano,
								data: result.valorAtual
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesPrazo(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesPrazo';
		}else{
			div = '#graficoTotalIncidentesPrazoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesPrazo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('prazo',ano,0);
									}		
								}								
							},
							title: {
								text: '% de incidentes encerrados no prazo',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#FFCB08',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#00995D',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesPrazoRespostaSolucao(indicadorInicial,indicadorFinal,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesPrazoRepostaSolucao';
		}else{
			div = '#graficoTotalIncidentesPrazoRepostaSolucaoModal';
		}			
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesPrazoRespostaSolucao',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicadorInicial' : indicadorInicial,
				'indicadorFinal'   : indicadorFinal,
				'ano'              : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('prazoRespostaSolcucao',ano,0);
									}		
								}								
							},
							title: {
								text: '% de incidentes encerrados no prazo (resposta/solução)',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#FFCB08',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#00995D',
								name: 'Resultado Solução',
								data: result.solucoes,
								zIndex: 1
					        }, {
								type: 'column',	
								color: '#411564',
								name: 'Resultado Resposta',
								data: result.respostas,
								zIndex: 1								
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesPrincipal(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesPrincipal';
		}else{
			div = '#graficoTotalIncidentesPrincipalModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('principal',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade total de incidentes abertos serviços principais (sem EOU)',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#00995D',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#411564',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function graficoTotalIncidentesNivel(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesNivel';
		}else{
			div = '#graficoTotalIncidentesNivelModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesNivel',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){

					   $(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('nivel',ano,mes);
									}		
								}								
							},
							title: {
								text: '% de incidentes encerrados por nível de atendimento',
								style: {"font-weight": "bold"}
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Níveis",
								colorByPoint: true,
								data: [{
										name: 'GESTÃO',
										y: result.gestao,
										color: '#00401A'
									  },{
										name: 'N1 (TI)',
										y: result.n1,
										color: '#411564'
									  },{
										name: 'N2 (INFRA)',
										y: result.n2infra,
										color: '#5B5C65'
									  },{
										name: 'N2 (SI)',
										y: result.n2si,
										color: '#682D00'
									  },{
										name: 'N3 (REDES)',
										y: result.n3redes,
										color: '#B1D34B'
									  },{
										name: 'N3 (SI)',
										y: result.n3si,
										color: '#C4CBCF'
									  }
								  ]
							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesReabertos(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesReabertos';
		}else{
			div = '#graficoTotalIncidentesReabertosModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesReabertos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('reabertos',ano,0);
									}		
								}								
							},
							title: {
								text: '% de incidentes reabertos',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#00995D',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#411564',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesSeveridade(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesSeveridade';
		}else{
			div = '#graficoTotalIncidentesSeveridadeModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesSeveridade',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){

					   $(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('severidade',ano,mes);
									}		
								}								
							},
							title: {
								text: '% de incidentes abertos por severidade',
								style: {"font-weight": "bold"}
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Níveis",
								colorByPoint: true,
								data: [{
										name: 'CRÍTICA',
										y: result.critica,
										color: '#00401A'
									  },{
										name: 'ALTA',
										y: result.alta,
										color: '#411564'
									  },{
										name: 'MÉDIA',
										y: result.media,
										color: '#5B5C65'
									  },{
										name: 'BAIXA',
										y: result.baixa,
										color: '#682D00'
									  }
								  ]
							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function graficoTotalIncidentesMaiores90(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesMaiores90';
		}else{
			div = '#graficoTotalIncidentesMaiores90Modal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesMaiores90',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('maiores90',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade de Incidentes em aberto >= 90 dias',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#FFCB08',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#00995D',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesBacklog(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesBacklog';
		}else{
			div = '#graficoTotalIncidentesBacklogModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesBacklog',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('backlog',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade de Incidentes em aberto (backlog)',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#FFCB08',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#00995D',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesServico(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesServico';
		}else{
			div = '#graficoTotalIncidentesServicoModal';
		}			
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesServico',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								height: 500,
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('servicos',ano,mes);
									}		
								}								
							},
							title: {
								text: 'Quantidade de Incidentes abertos por serviço - MENSAL'
							},
							xAxis: {
								categories: result.descricao,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#00995D',
								name: 'Resultado',
								data: result.valores

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalIncidentesServicoAnual(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesServicoAnual';
		}else{
			div = '#graficoTotalIncidentesServicoAnualModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesServicoAnual',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								height: 500,
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('servicosAnual',ano,0);
									}
								}								
							},
							title: {
								text: 'Quantidade de Incidentes abertos por serviço - ANUAL'
							},
							xAxis: {
								categories: result.descricao,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#00995D',
								name: 'Resultado',
								data: result.valores

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	/* --- Requisições --- */
	
	function buscaTotalRequisicoesAbertas(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#requisicoesAbertas').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#F47920"><i class="fa fa-bar-chart" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Requisições <br> Abertas</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#requisicoesAbertas').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function buscaTotalRequisicoesEncerradas(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#requisicoesEncerradas').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#F47920"><i class="fa fa-check-square-o" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Requisições <br> Encerradas</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#requisicoesEncerradas').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function buscaTotalReqEncerradasPrazo(indicador,ano,prazo){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=totalReqEncerradas',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'prazo'     : prazo
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){					
						
						$('#requisicoesEncerradasPrazo').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#F47920"><i class="fa fa-thumbs-o-up" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Encerrados no <br> Prazo</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#requisicoesEncerradasPrazo').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function buscaTotalReqEncerradasForaPrazo(indicador,ano,prazo){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=totalReqEncerradas',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
                'prazo'     : prazo  				
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#requisicoesEncerradasForaPrazo').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#F47920"><i class="fa fa-thumbs-o-down" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Encerrados Fora <br> Prazo</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#requisicoesEncerradasForaPrazo').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalRequisicoesAbertas(indicador,ano,tipo){

		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalRequisicoesAbertas';
		}else{
			div = '#graficoTotalRequisicoesAbertasModal';
		}	

		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalRequisicoesAbertas',ano,0);
									}		
								}
							},
							title: {
								text: 'Quantidade total de requisições ABERTAS',
								style: {"font-weight": "bold"},
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#5B5C65',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalRequisicoesEncerradas(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalRequisicoesEncerradas';
		}else{
			div = '#graficoTotalRequisicoesEncerradasModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalRequisicoesEncerradas',ano,0);
									}		
								}
							},
							title: {
								text: 'Quantidade total de requisições ENCERRADAS',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#5B5C65',
								name: 'Resultado ' + ano,
								data: result.valorAtual
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoPercentualRequisicoesPrazo(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoPercentualRequisicoesPrazo';
		}else{
			div = '#graficoPercentualRequisicoesPrazoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoPercentualRequisicoesPrazo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador'   : indicador,
				'ano'         : ano,		
				'mes'         : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoPercentualRequisicoesPrazo',ano,mes);
									}		
								}				
							},
							title: {
								text: '% de requisições encerradas no prazo',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: ['Requisições'],
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#5B5C65',
								name: 'Resultado ' + ano,
								data: result.valorAtual
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function graficoPercentualReqPrazoTipo(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoPercentualReqPrazoTipo';
		}else{
			div = '#graficoPercentualReqPrazoTipoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoPercentualReqPrazoTipo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoPercentualReqPrazoTipo',ano,mes);
									}		
								}				
							},
							title: {
								text: '% de requisições encerradas no prazo por tipo',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.tipos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#5B5C65',
								name: 'Resultado ' + ano,
								data: result.valorAtual
					        }]

						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoQtdeReqEncerTipoNivel(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoQtdeReqEncerTipoNivel';
		}else{
			div = '#graficoQtdeReqEncerTipoNivelModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoQtdeReqEncerTipoNivel',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoQtdeReqEncerTipoNivel',ano,mes);
									}		
								}				
							},
							title: {
								text: 'Quantidade de requisições encerradas por tipo e nível',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.nivel,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Acesso' ,
								data: result.valorAcesso

							}, {
								color: '#5B5C65',
								name: 'Alteração',
								data: result.valorAlteracao
					        }, {
								color: '#692D00',
								name: 'Dúvida',
								data: result.valorDuvida
					        }, {
								color: '#B1D34B',
								name: 'Melhoria',
								data: result.valorMelhoria
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoRequisicoesAbertasTipo(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoRequisicoesAbertasTipo';
		}else{
			div = '#graficoRequisicoesAbertasTipoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoRequisicoesAbertasTipo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoRequisicoesAbertasTipo',ano,mes);
									}		
								}				
							},
							title: {
								text: 'Quantidade de requisições abertas por tipo',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.tipos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.valor
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoRequisicoesEncerradasTipo(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoRequisicoesEncerradasTipo';
		}else{
			div = '#graficoRequisicoesEncerradasTipoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoRequisicoesEncerradasTipo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoRequisicoesEncerradasTipo',ano,mes);
									}		
								}				
							},
							title: {
								text: 'Quantidade de requisições encerradas por tipo',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.tipos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.valor
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoPercRequisicoesAbertasTipo(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoPercRequisicoesAbertasTipo';
		}else{
			div = '#graficoPercRequisicoesAbertasTipoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoPercRequisicoesAbertasTipo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){

					   $(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoPercRequisicoesAbertasTipo',ano,mes);
									}		
								}								
							},
							title: {
								text: '% de requisições abertas por tipo',
								style: {"font-weight": "bold"}
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Tipos",
								colorByPoint: true,
								data: [{
										name: 'Acesso',
										y: result.valorAcesso,
										color: '#F47920'
									  },{
										name: 'Alteração',
										y: result.valorAlteracao,
										color: '#5B5C65'
									  },{
										name: 'Dúvida',
										y: result.valorDuvida,
										color: '#692D00'
									  },{
										name: 'Melhoria',
										y: result.valorMelhoria,
										color: '#B1D34B'
									  }
								  ]
							}]
						});						
					}else{
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});		
	}
	
	function graficoPercRequisicoesEncerradasTipo(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoPercRequisicoesEncerradasTipo';
		}else{
			div = '#graficoPercRequisicoesEncerradasTipoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoPercRequisicoesEncerradasTipo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){

					   $(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoPercRequisicoesEncerradasTipo',ano,mes);
									}		
								}								
							},
							title: {
								text: '% de requisições encerradas por tipo',
								style: {"font-weight": "bold"}
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Tipos",
								colorByPoint: true,
								data: [{
										name: 'Acesso',
										y: result.valorAcesso,
										color: '#F47920'
									  },{
										name: 'Alteração',
										y: result.valorAlteracao,
										color: '#5B5C65'
									  },{
										name: 'Dúvida',
										y: result.valorDuvida,
										color: '#692D00'
									  },{
										name: 'Melhoria',
										y: result.valorMelhoria,
										color: '#B1D34B'
									  }
								  ]
							}]
						});						
					}else{
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});		
	}
	
	function graficoRequisicoesReabertas(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoRequisicoesReabertas';
		}else{
			div = '#graficoRequisicoesReabertasModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoRequisicoesReabertas',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoRequisicoesReabertas',ano,mes);
									}		
								}				
							},
							title: {
								text: '% de requisições reabertas',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.tipos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.valor
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoRequisicoesAbertasServico(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoRequisicoesAbertasServico';
		}else{
			div = '#graficoRequisicoesAbertasServicoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoRequisicoesAbertasServico',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoRequisicoesAbertasServico',ano,mes);
									}		
								}				
							},
							title: {
								text: 'Quantidade de requisições abertas por serviço - Top 10',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.servicos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.valor
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoRequisicoesEncerradasNivel(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoRequisicoesEncerradasNivel';
		}else{
			div = '#graficoRequisicoesEncerradasNivelModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoRequisicoesEncerradasNivel',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoRequisicoesEncerradasNivel',ano,mes);
									}		
								}				
							},
							title: {
								text: 'Quantidade de requisições encerradas por nível de atendimento',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.nivel,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.valor
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoPercReqEncerTipoNivel(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoPercReqEncerTipoNivel';
		}else{
			div = '#graficoPercReqEncerTipoNivelModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoPercReqEncerTipoNivel',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoPercReqEncerTipoNivel',ano,mes);
									}		
								}				
							},
							title: {
								text: '% de requisições encerradas por nível de atendimento',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.nivel,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#F47920',
								name: 'Total' ,
								data: result.valorTotal

							}, {
								color: '#5B5C65',
								name: 'Acesso' ,
								data: result.valorAcesso

							}, {
								color: '#692D00',
								name: 'Alteração',
								data: result.valorAlteracao
					        }, {
								color: '#B1D34B',
								name: 'Dúvida',
								data: result.valorDuvida
					        }, {
								color: '#FFF0C7',
								name: 'Melhoria',
								data: result.valorMelhoria
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoTotalRequisicoesMaiores90(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalRequisicoesMaiores90';
		}else{
			div = '#graficoTotalRequisicoesMaiores90Modal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalRequisicoesMaiores90',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalRequisicoesMaiores90',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade de requisições em aberto >= 90 dias',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#FFCB08',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#F47920',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});		
	}	
	
	function graficoTotalRequisicoesBacklog(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalRequisicoesBacklog';
		}else{
			div = '#graficoTotalRequisicoesBacklogModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalRequisicoesBacklog',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalRequisicoesBacklog',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade de requisições em aberto (backlog)',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#FFCB08',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#F47920',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});		
	}	
	
	/* --- Desenvolvimento --- */
	function buscaTotalDesenvolvimentosAbertos(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#desenvolvimentosAbertos').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#A3238E"><i class="fa fa-bar-chart" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Desenvolvimentos<br>Abertos</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#desenvolvimentosAbertos').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function buscaTotalDesenvolvimentosEncerrados(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#desenvolvimentosEncerrados').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#A3238E"><i class="fa fa-check-square-o" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Desenvolvimentos<br>Encerrados</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#desenvolvimentosEncerrados').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function buscaTotalDesenvEncerradosPrazo(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){					
						
						$('#desenvolvimentosEncerradosPrazo').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#A3238E"><i class="fa fa-thumbs-o-up" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Encerrados no<br>Prazo</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#desenvolvimentosEncerradosPrazo').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function buscaTotalDesenvEncerradosForaPrazo(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=total',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#desenvolvimentosEncerradosForaPrazo').html('<div class="col-md-3 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#A3238E"><i class="fa fa-thumbs-o-down" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Total Encerrados<br>Fora Prazo</span>' +
													 '<span class="info-box-number">'+result.total+'</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#desenvolvimentosEncerradosForaPrazo').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function graficoTotalDesenvolvimentosAbertos(indicador,ano,tipo){

		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosAbertos';
		}else{
			div = '#graficoTotalDesenvolvimentosAbertosModal';
		}	

		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosAbertos',ano,0);
									}		
								}							
							},
							title: {
								text: 'Quantidade total de desenvolvimentos ABERTOS',
								style: {"font-weight": "bold"},
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#A3238E',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#C4CBCF',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function graficoTotalDesenvolvimentosEncerrados(indicador,ano,tipo){

		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosEncerrados';
		}else{
			div = '#graficoTotalDesenvolvimentosEncerradosModal';
		}	

		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosEncerrados',ano,0);
									}		
								}							
							},
							title: {
								text: 'Quantidade total de desenvolvimentos ENCERRADOS',
								style: {"font-weight": "bold"},
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#A3238E',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#C4CBCF',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalDesenvolvimentosCancelados(indicador,ano,tipo){

		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosCancelados';
		}else{
			div = '#graficoTotalDesenvolvimentosCanceladosModal';
		}	

		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotal',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosCancelados',ano,0);
									}		
								}							
							},
							title: {
								text: 'Quantidade total de desenvolvimentos CANCELADOS',
								style: {"font-weight": "bold"},
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#A3238E',
								name: 'Resultado ' + (ano - 1),
								data: result.valorAnterior

							}, {
								color: '#C4CBCF',
								name: 'Resultado ' + ano,
								data: result.valorAtual

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoTotalDesenvolvimentosPrazo(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosPrazo';
		}else{
			div = '#graficoTotalDesenvolvimentosPrazoModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvimentosPrazo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosPrazo',ano,0);
									}		
								}								
							},
							title: {
								text: '% de desenvolvimentos encerrados no prazo',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#C4CBCF',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano,
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function graficoTotalDesenvolvimentosPrazoEFora(indicadorIni,indicadorFim,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosPrazoEFora';
		}else{
			div = '#graficoTotalDesenvolvimentosPrazoEForaModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvimentosPrazoEFora',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicadorIni' : indicadorIni,
				'indicadorFim' : indicadorFim,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosPrazoEFora',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade de desenvolvimentos encerrados no prazo e fora',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'line',
								color: '#C4CBCF',
								name: 'Fora Prazo',
								data: result.fora,
								zIndex: 2

							}, {
								type: 'line',	
								color: '#A3238E',
								name: 'No Prazo',
								data: result.prazo,
								zIndex: 1
					        }]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function graficoTotalDesenvReagendados(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvReagendados';
		}else{
			div = '#graficoTotalDesenvReagendadosModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvReagendados',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,		
				'mes'       : mes		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvReagendados',ano,mes);
									}		
								}				
							},
							title: {
								text: 'Quantidade de reagendamentos em desenvolvimentos',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.tipos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b> {point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								}
							},
							series: [{
								color: '#A3238E',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.valor
					        }]
						});						
						
					}else{
										
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
	}
	
	function graficoTotalIncidentesDevidoDesenv(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalIncidentesDevidoDesenv';
		}else{
			div = '#graficoTotalIncidentesDevidoDesenvModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalIncidentesDevidoDesenv',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalIncidentesDevidoDesenv',ano,0);
									}		
								}								
							},
							title: {
								text: 'Quantidade incidentes devido desenvolvimentos',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano,
								data: result.resultados,
								zIndex: 1
					        }]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	
	function graficoTotalDesenvolvimentosBacklog(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosBacklog';
		}else{
			div = '#graficoTotalDesenvolvimentosBacklogModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvimentosBacklog',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosBacklog',ano,mes);
									}		
								}								
							},
							title: {
								text: 'Quantidade de Desenvolvimentos em aberto (backlog)',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.situacoes,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#C4CBCF',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.resultados,
								zIndex: 1
					        }]
						});						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});		
	}
	
	function graficoTotalDesenvolvimentosEtapa(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvimentosEtapa';
		}else{
			div = '#graficoTotalDesenvolvimentosEtapaModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvimentosEtapa',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvimentosEtapa',ano,mes);
									}		
								}								
							},
							title: {
								text: 'Quantidade de desenvolvimentos abertos por etapa',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.etapas,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.resultados,
								zIndex: 1
					        }]
						});
					}else{
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	function graficoTotalDesenvolvForaPrazoEtapa(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvForaPrazoEtapa';
		}else{
			div = '#graficoTotalDesenvolvForaPrazoEtapaModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvForaPrazoEtapa',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvForaPrazoEtapa',ano,mes);
									}		
								}								
							},
							title: {
								text: 'Quantidade de desenvolvimentos atrasados por etapa',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.etapas,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.resultados,
								zIndex: 1
					        }]
						});
					}else{
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	function graficoTotalDesenvolvForaPrazoResp(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvForaPrazoResp';
		}else{
			div = '#graficoTotalDesenvolvForaPrazoRespModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvForaPrazoResp',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvForaPrazoResp',ano,mes);
									}		
								}								
							},
							title: {
								text: 'Quantidade de desenvolvimentos atrasados por responsável',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.responsaveis,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.resultados,
								zIndex: 1
					        }]
						});
					}else{
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	function graficoTotalDesenvolvForaPrazoDias(indicador,ano,mes,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoTotalDesenvolvForaPrazoDias';
		}else{
			div = '#graficoTotalDesenvolvForaPrazoDiasModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoTotalDesenvolvForaPrazoDias',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano,
				'mes'       : mes
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('graficoTotalDesenvolvForaPrazoDias',ano,mes);
									}		
								}								
							},
							title: {
								text: 'Quantidade de desenvolvimentos atrasados por qtde. de dias',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.dias,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'column',	
								color: '#A3238E',
								name: 'Resultado ' + ano + '/' + mes,
								data: result.resultados,
								zIndex: 1
					        }]
						});
					}else{
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	/* --- PPR --- */
	
	function buscaPercentualFinalPPR(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=percentualFinalPPR',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#percentualFinalPPR').html('<div class="col-md-4 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#B1D34B"><i class="fa fa-pencil-square-o" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">% Total Documentos Revisados</span>' +
													 '<span class="info-box-number">Meta: '+result.meta+'%</span>' +
													 '<span class="info-box-number">Resultado: '+result.resultado+'%</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#percentualFinalPPR').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function buscaPrazoSolcitacaoDemanda(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=prazoSolicitacaoDemandas',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#prazoSolicitacaoDemandas').html('<div class="col-md-4 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#B1D34B"><i class="fa fa-share-square" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">% Total Prazo Solicitações/Demandas</span>' +
													 '<span class="info-box-number">Meta: '+result.meta+'%</span>' +
													 '<span class="info-box-number">Resultado: '+result.resultado+'%</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#prazoSolicitacaoDemandas').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoDocumentosPPR(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoDocumentosPPR';
		}else{
			div = '#graficoDocumentosPPRModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoDocumentosPPR',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('documentosPpr',ano,0);
									}		
								}								
							},
							title: {
								text: 'PPR - % de documentos revisados pelo criador (1x por ano)',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#5B5C65',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#B1D34B',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function graficoPrazoSolicitacaoDemandas(indicador,ano,tipo){
		
		var div = '';
		
		if(tipo == 'normal'){
			div = '#graficoPrazoSolicitacaoDemandas';
		}else{
			div = '#graficoPrazoSolicitacaoDemandasModal';
		}		
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=graficoPrazoSolicitacaoDemandas',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano		
			},
			beforeSend: function() {
				//$('.loaderIncidentes').show();
			},
			complete: function() {
				//$('.loaderIncidentes').hide();				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								zoomType: 'xy',
								events:{
									click: function(e) {
										abrirModalGrafico('solicitacaoDemandas',ano,0);
									}		
								}								
							},
							title: {
								text: 'PPR - % de prazo de solicitações/demandas para TI',
								style: {"font-weight": "bold"}
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Resultado'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									},
									groupPadding: 0.1
								},
								spline: {
										lineWidth: 4,
										states: {
											hover: {
												lineWidth: 5
											}
										},
										marker: {
											enabled: false
										}
									}								
							},
							series: [{
								type: 'spline',
								color: '#5B5C65',
								name: 'Meta',
								data: result.metas,
								zIndex: 2

							}, {
								type: 'column',	
								color: '#B1D34B',
								name: 'Resultado',
								data: result.resultados,
								zIndex: 1
					        }]

						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}		
	
	function buscaPercentualProjetos(indicador,ano){
		
		$.ajax({
			url: 'ajax/indicadorTI.php?acao=percentualProjetos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'ano'       : ano	
			},			
			beforeSend: function() {
				//$('.loaderImportar').show();				
			},
			complete: function() {
				//$('.loaderImportar').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#percentualProjetos').html('<div class="col-md-4 col-sm-6 col-xs-12">' +
													 '<div class="info-box" style="background-color:#C4CBCF;">' +
													 '<span class="info-box-icon" style="background-color:#B1D34B"><i class="fa fa-codepen" style="color:#ffffff;"></i></span>' +
													 '<div class="info-box-content">' +
													 '<span class="info-box-text">Percentual de Projetos Concluídos TI</span>' +
													 '<span class="info-box-number">Meta: '+result.meta+'%</span>' +
													 '<span class="info-box-number">Resultado: '+result.resultado+'%</span>' +
													 '</div>' +
													 '</div>' +
							                         '</div>');
													 
						$('#percentualProjetos').show();							 
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	
	function gerar(tipo){
		
		var tipo = tipo; // 1 - Incidentes | 2 - Requisições | 3 - Desenvolvimentos | 4 - Mudanças | 5 - PPR
		
		var totalAbertos    = 0;
		var totalEncerrados = 0;
		
		if(tipo == 1){
			
			var mes = $('#mesConsulta').val();
			var ano = $('#anoConsulta').val();
			
			if(mes == ''){
				exibeErro('<p>Selecione um Mês</p>');
				$('#mesConsulta').focus();						
			}else if(ano == ''){
				exibeErro('<p>Selecione um Ano</p>');
				$('#anoConsulta').focus();						
			}else{
				$('#resultadoIncidentes').show();
				buscaTotalAbertos(43,ano);
				buscaTotalEncerrados(120,ano);			
				buscaTotalEncerradosPrazo(37,ano,'Prazo');			
				buscaTotalEncerradosForaPrazo(37,ano,'Fora Prazo');
				graficoTotalIncidentesAbertos(43,ano,'normal');				
				graficoTotalIncidentesEncerrados(120,ano,'normal');				
				graficoTotalIncidentesPrazo(30,ano,'normal');
				graficoTotalIncidentesPrazoRespostaSolucao(123,124,ano,'normal');
				graficoTotalIncidentesPrincipal(133,ano,'normal');
				graficoTotalIncidentesNivel(33,ano,mes,'normal');
				graficoTotalIncidentesReabertos(28,ano,'normal');
				graficoTotalIncidentesSeveridade(27,ano,mes,'normal');
				graficoTotalIncidentesMaiores90(34,ano,'normal');
				graficoTotalIncidentesBacklog(34,ano,'normal');
				graficoTotalIncidentesServico(35,ano,mes,'normal');			
				graficoTotalIncidentesServicoAnual(35,ano,'normal');			
			}
		}
		if(tipo == 2){
			var mes = $('#mesConsultaRequisicoes').val();
			var ano = $('#anoConsultaRequisicoes').val();
			
			if(mes == ''){
				exibeErro('<p>Selecione um Mês</p>');
				$('#mesConsultaRequisicoes').focus();						
			}else if(ano == ''){
				exibeErro('<p>Selecione um Ano</p>');
				$('#anoConsultaRequisicoes').focus();						
			}else{
				$('#resultadoRequisicoes').show();
				buscaTotalRequisicoesAbertas(80,ano);			
				buscaTotalRequisicoesEncerradas(121,ano);
				buscaTotalReqEncerradasPrazo(75,ano,'Prazo');
				buscaTotalReqEncerradasForaPrazo(75,ano,'Fora Prazo');
				graficoTotalRequisicoesAbertas(80,ano,'normal');
				graficoTotalRequisicoesEncerradas(121,ano,'normal');
				graficoPercentualRequisicoesPrazo(69,ano,mes,'normal');
				graficoPercentualReqPrazoTipo(69,ano,mes,'normal');
				graficoQtdeReqEncerTipoNivel(74,ano,mes,'normal');
				graficoRequisicoesAbertasTipo(72,ano,mes,'normal');
				graficoRequisicoesEncerradasTipo(79,ano,mes,'normal');
				graficoPercRequisicoesAbertasTipo(64,ano,mes,'normal');
				graficoPercRequisicoesEncerradasTipo(68,ano,mes,'normal');
				graficoRequisicoesReabertas(65,ano,mes,'normal');
				graficoRequisicoesAbertasServico(77,ano,mes,'normal');
				graficoRequisicoesEncerradasNivel(76,ano,mes,'normal');
				graficoPercReqEncerTipoNivel(70,ano,mes,'normal');
				graficoTotalRequisicoesMaiores90(71,ano,'normal');
				graficoTotalRequisicoesBacklog(71,ano,'normal');
			}			
			
				
		}
		if(tipo == 3){
			var mes = $('#mesConsultaDesenvolvimento').val();
			var ano = $('#anoConsultaDesenvolvimento').val();
			
			if(mes == ''){
				exibeErro('<p>Selecione um Mês</p>');
				$('#mesConsultaDesenvolvimento').focus();						
			}else if(ano == ''){
				exibeErro('<p>Selecione um Ano</p>');
				$('#anoConsultaDesenvolvimento').focus();						
			}else{
				$('#resultadoDesenvolvimento').show();
				buscaTotalDesenvolvimentosAbertos(115,ano);
				buscaTotalDesenvolvimentosEncerrados(17,ano);
				buscaTotalDesenvEncerradosPrazo(135,ano);
				buscaTotalDesenvEncerradosForaPrazo(136,ano);
				graficoTotalDesenvolvimentosAbertos(115,ano,'normal');
				graficoTotalDesenvolvimentosEncerrados(17,ano,'normal');
				graficoTotalDesenvolvimentosCancelados(137,ano,'normal');
				graficoTotalDesenvolvimentosPrazo(12,ano,'normal');
				graficoTotalDesenvolvimentosPrazoEFora(135,136,ano,'normal');
				graficoTotalDesenvReagendados(131,ano,mes,'normal');
				graficoTotalIncidentesDevidoDesenv(13,ano,'normal');
				graficoTotalDesenvolvimentosBacklog(15,ano,mes,'normal');
				graficoTotalDesenvolvimentosEtapa(138,ano,mes,'normal');
				graficoTotalDesenvolvForaPrazoEtapa(151,ano,mes,'normal');
				graficoTotalDesenvolvForaPrazoResp(152,ano,mes,'normal');
				graficoTotalDesenvolvForaPrazoDias(153,ano,mes,'normal');
			}
		}
		if(tipo == 4){
			
		}
		if(tipo == 5){

			var mes = $('#mesConsultaPPR').val();
			var ano = $('#anoConsultaPPR').val();		
			
			if(mes == ''){
				exibeErro('<p>Selecione um Mês</p>');
				$('#mesConsulta').focus();						
			}else if(ano == ''){
				exibeErro('<p>Selecione um Ano</p>');
				$('#anoConsulta').focus();						
			}else{
				$('#resultadoPPR').show();
				buscaPercentualFinalPPR(143,ano);
				buscaPrazoSolcitacaoDemanda(146,ano);				
				buscaPercentualProjetos(119,ano);				
				graficoDocumentosPPR(143,ano,'normal');
				graficoPrazoSolicitacaoDemandas(146,ano,'normal');
				
			}			
		}

	}
	
	function abrirModalGrafico(tipo,ano,mes){
		
		if(tipo == 'abertos'){
			graficoTotalIncidentesAbertos(43,ano,'modal');			
			$('#dialog-incidentes-abertos').on('shown',function(){}).modal();
		}
		if(tipo == 'encerrados'){
			graficoTotalIncidentesEncerrados(120,ano,'modal');			
			$('#dialog-incidentes-encerrados').on('shown',function(){}).modal();
		}
		if(tipo == 'prazo'){
			graficoTotalIncidentesPrazo(30,ano,'modal');			
			$('#dialog-incidentes-prazo').on('shown',function(){}).modal();
		}		
		if(tipo == 'prazoRespostaSolcucao'){
			graficoTotalIncidentesPrazoRespostaSolucao(123,124,ano,'modal');			
			$('#dialog-incidentes-prazo-resposta-solucao').on('shown',function(){}).modal();
		}
		if(tipo == 'principal'){
			graficoTotalIncidentesPrincipal(133,ano,'modal');			
			$('#dialog-incidentes-principal').on('shown',function(){}).modal();
		}
		if(tipo == 'nivel'){
			graficoTotalIncidentesNivel(33,ano,mes,'modal');			
			$('#dialog-incidentes-nivel').on('shown',function(){}).modal();
		}
		if(tipo == 'reabertos'){
			graficoTotalIncidentesReabertos(28,ano,'modal');			
			$('#dialog-incidentes-reabertos').on('shown',function(){}).modal();
		}		
		if(tipo == 'severidade'){
			graficoTotalIncidentesSeveridade(27,ano,mes,'modal');			
			$('#dialog-incidentes-severidade').on('shown',function(){}).modal();
		}	
		if(tipo == 'maiores90'){
			graficoTotalIncidentesMaiores90(34,ano,'modal');			
			$('#dialog-incidentes-maiores90').on('shown',function(){}).modal();
		}		
		if(tipo == 'backlog'){
			graficoTotalIncidentesBacklog(34,ano,'modal');			
			$('#dialog-incidentes-backlog').on('shown',function(){}).modal();
		}
		if(tipo == 'servicos'){
			graficoTotalIncidentesServico(35,ano,mes,'modal');			
			$('#dialog-incidentes-servicos').on('shown',function(){}).modal();
		}
		if(tipo == 'servicosAnual'){
			graficoTotalIncidentesServicoAnual(35,ano,'modal');			
			$('#dialog-incidentes-servicos-anual').on('shown',function(){}).modal();
		}	
		if(tipo == 'documentosPpr'){
			graficoDocumentosPPR(143,ano,'modal');			
			$('#dialog-documentos-ppr').on('shown',function(){}).modal();
		}	
		if(tipo == 'solicitacaoDemandas'){
			graficoPrazoSolicitacaoDemandas(146,ano,'modal');			
			$('#dialog-solicitacao-demandas').on('shown',function(){}).modal();
		}
		
		if(tipo == 'graficoTotalRequisicoesAbertas'){
			graficoTotalRequisicoesAbertas(80,ano,'modal');			
			$('#dialog-total-req-abertas').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalRequisicoesEncerradas'){
			graficoTotalRequisicoesEncerradas(121,ano,'modal');
			$('#dialog-total-req-encerradas').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoPercentualRequisicoesPrazo'){
			graficoPercentualRequisicoesPrazo(69,ano,mes,'modal');
			$('#dialog-percentual-req-prazo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoPercentualReqPrazoTipo'){
			graficoPercentualReqPrazoTipo(69,ano,mes,'modal');
			$('#dialog-perc-req-prazo-tipo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoQtdeReqEncerTipoNivel'){
			graficoQtdeReqEncerTipoNivel(74,ano,mes,'modal');
			$('#dialog-qtde-req-encer-tipo-nivel').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoRequisicoesAbertasTipo'){
			graficoRequisicoesAbertasTipo(72,ano,mes,'modal');
			$('#dialog-req-abertas-tipo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoRequisicoesEncerradasTipo'){
			graficoRequisicoesEncerradasTipo(79,ano,mes,'modal');
			$('#dialog-req-encerradas-tipo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoPercRequisicoesAbertasTipo'){
			graficoPercRequisicoesAbertasTipo(64,ano,mes,'modal');
			$('#dialog-perc-req-abertas-tipo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoPercRequisicoesEncerradasTipo'){
			graficoPercRequisicoesEncerradasTipo(68,ano,mes,'modal');
			$('#dialog-perc-req-encerradas-tipo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoRequisicoesReabertas'){
			graficoRequisicoesReabertas(65,ano,mes,'modal');
			$('#dialog-requisicoes-reabertas').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoRequisicoesAbertasServico'){
			graficoRequisicoesAbertasServico(77,ano,mes,'modal');
			$('#dialog-requisicoes-abertas-servico').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoRequisicoesEncerradasNivel'){
			graficoRequisicoesEncerradasNivel(76,ano,mes,'modal');
			$('#dialog-requisicoes-encerradas-nivel').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoPercReqEncerTipoNivel'){
			graficoPercReqEncerTipoNivel(70,ano,mes,'modal');
			$('#dialog-perc-req-encer-tipo-nivel').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalRequisicoesMaiores90'){
			graficoTotalRequisicoesMaiores90(71,ano,'modal');
			$('#dialog-requisicoes-maiores90').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalRequisicoesBacklog'){
			graficoTotalRequisicoesBacklog(71,ano,'modal');
			$('#dialog-requisicoes-backlog').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosAbertos'){
			graficoTotalDesenvolvimentosAbertos(115,ano,'modal');
			$('#dialog-desenvolvimentos-abertos').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosEncerrados'){
			graficoTotalDesenvolvimentosEncerrados(17,ano,'modal');
			$('#dialog-desenvolvimentos-encerrados').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosCancelados'){
			graficoTotalDesenvolvimentosCancelados(137,ano,'modal');
			$('#dialog-desenvolvimentos-cancelados').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosPrazo'){
			graficoTotalDesenvolvimentosPrazo(12,ano,'modal');
			$('#dialog-desenvolvimentos-prazo').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosPrazoEFora'){
			graficoTotalDesenvolvimentosPrazoEFora(135,136,ano,'modal');
			$('#dialog-desenvolvimentos-prazo-e-fora').on('shown',function(){}).modal();
		}
		
		if(tipo == 'graficoTotalDesenvReagendados'){
			graficoTotalDesenvReagendados(131,ano,mes,'modal');
			$('#dialog-desenvolvimentos-reagendados').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalIncidentesDevidoDesenv'){
			graficoTotalIncidentesDevidoDesenv(13,ano,'modal');
			$('#dialog-incidentes-devido-desenv').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosBacklog'){
			graficoTotalDesenvolvimentosBacklog(15,ano,mes,'modal');
			$('#dialog-desenvolvimentos-backlog').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvimentosEtapa'){
			graficoTotalDesenvolvimentosEtapa(138,ano,mes,'modal');
			$('#dialog-desenvolvimentos-etapa').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvForaPrazoEtapa'){
			graficoTotalDesenvolvForaPrazoEtapa(151,ano,mes,'modal');
			$('#dialog-desenvolv-fora-prazo-etapa').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvForaPrazoResp'){
			graficoTotalDesenvolvForaPrazoResp(152,ano,mes,'modal');
			$('#dialog-desenvolv-fora-prazo-resp').on('shown',function(){}).modal();
		}
		if(tipo == 'graficoTotalDesenvolvForaPrazoDias'){
			graficoTotalDesenvolvForaPrazoDias(153,ano,mes,'modal');
			$('#dialog-desenvolv-fora-prazo-dias').on('shown',function(){}).modal();
		}
	}	
</script>


<?php include("inc/rodape.php"); ?>

