<?php
$conexaoSqlServer = mssql_connect('srvdb9','sa','unimed029');
$base = mssql_select_db('Qualitor_PROD',$conexaoSqlServer);

var_dump($base);

?>