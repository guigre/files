<?php
/*$conexaoSqlServer = mssql_connect('srvdb9','sa','unimed029');

var_dump($conexaoSqlServer);

$base = mssql_select_db('Qualitor_PROD',$conexaoSqlServer);*/

$hostOracleSA  = "sccard.unimedvtrp.com.br";
$userOracleSA  = "datacenter";
$senhaOracleSA = "datacenterrac";

$conex = oci_connect($userOracleSA, $senhaOracleSA, $hostOracleSA);

var_dump($conex);

if( $conex ) {
     echo "Connection established.<br />";
}else{
     echo "Connection could not be established.<br />";
}
?>



