<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Descontos
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">	
				  <input type="hidden" id="cduserid" value="<?php print $_SESSION['usuario']; ?>">
                  <div class="box-body">			  
                    <div class="form-group">
                      <label for="modalidadeCadastro" class="col-sm-2 control-label">Modalidade<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="modalidadeCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="planoCadastro" class="col-sm-2 control-label">Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="planoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tipoPlanoCadastro" class="col-sm-2 control-label">Tipo Plano<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="tipoPlanoCadastro" placeholder="">
                      </div>
                    </div>	
                    <div class="form-group">
                      <label for="minBenefCadastro" class="col-sm-2 control-label">Nº Mínimo Benef.<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="minBenefCadastro" placeholder="">
                      </div>
                    </div>						
                    <div class="form-group">
                      <label for="maxBenefCadastro" class="col-sm-2 control-label">Nº Máximo Benef.<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="number" class="form-control" id="maxBenefCadastro" placeholder="">
                      </div>
                    </div>
	                <div class="form-group">
                      <label for="valorDescontoCadastro" class="col-sm-2 control-label">Valor Desconto<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="valorDescontoCadastro" placeholder="">
                      </div>
                    </div>
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaDescontos">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#modalidadeCadastro').val('');
		$('#planoCadastro').val('');
		$('#tipoPlanoCadastro').val('');
		$('#minBenefCadastro').val('');
		$('#maxBenefCadastro').val('');
		$('#valorDescontoCadastro').val('');
		$('#acao').val('cadastra');
		
		$('#modalidadeCadastro').prop("disabled",false);
		$('#planoCadastro').prop("disabled",false);
		$('#tipoPlanoCadastro').prop("disabled",false);
		$('#minBenefCadastro').prop("disabled",false);
		$('#maxBenefCadastro').prop("disabled",false);
		$('#valorDescontoCadastro').prop("disabled",false);		
	
		$('#modalidadeCadastro').focus();
		
	}

	function salvar(){
		
		var modalidadeCadastro     = $('#modalidadeCadastro').val();
		var planoCadastro          = $('#planoCadastro').val();
		var tipoPlanoCadastro      = $('#tipoPlanoCadastro').val();
		var minBenefCadastro       = $('#minBenefCadastro').val();
		var maxBenefCadastro       = $('#maxBenefCadastro').val();
		var valorDescontoCadastro  = $('#valorDescontoCadastro').val();
		var acao   	    		   = $('#acao').val();
		var cduserid			   = $('#cduserid').val();
		
		if(modalidadeCadastro == ''){
			exibeErro('<p>Campo <b>(Modalidade)</b> Obrigatório!</p>');
			$('#modalidadeCadastro').focus();
		}else if(planoCadastro == ''){
			exibeErro('<p>Campo <b>(Plano)</b> Obrigatório!</p>');
			$('#planoCadastro').focus();
		}else if(tipoPlanoCadastro == ''){
			exibeErro('<p>Campo <b>(Tipo Plano)</b> Obrigatório!</p>');
			$('#tipoPlanoCadastro').focus();
		}else if(minBenefCadastro == ''){
			exibeErro('<p>Campo <b>(Nº Mínimo Benef.)</b> Obrigatório!</p>');
			$('#minBenefCadastro').focus();
		}else if(maxBenefCadastro == ''){
			exibeErro('<p>Campo <b>(Nº Máximo Benef.)</b> Obrigatório!</p>');
			$('#maxBenefCadastro').focus();
		}else if(valorDescontoCadastro == ''){
			exibeErro('<p>Campo <b>(Valor Desconto)</b> Obrigatório!</p>');
			$('#valorDescontoCadastro').focus();
		}else{

			$.ajax({
				url: 'ajax/desconto.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'modalidadeCadastro'    : modalidadeCadastro,        
					   'planoCadastro'         : planoCadastro,         
					   'tipoPlanoCadastro'     : tipoPlanoCadastro,     
					   'minBenefCadastro'      : minBenefCadastro,        
					   'maxBenefCadastro'      : maxBenefCadastro,           
					   'valorDescontoCadastro' : valorDescontoCadastro,
					   'acao'    			   : acao,
					   'cduserid'			   : cduserid
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){	
		$.ajax({
			url: 'ajax/desconto.php?acao=listaDescontos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaDescontos').html(result.tabela);
						
						$("#tabelaDescontos").DataTable({
							    "language": {
								"decimal": ",",
								"thousands": "."
								},
								"order": [[ 0, 'asc' ], [ 1, 'asc' ], [ 2, 'asc' ], [ 3, 'asc' ], [ 4, 'asc' ]],
								"iDisplayLength" : 200
						});
						
					}else{
										
						$('#divTabelaDescontos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(modalidade,plano,tipoPlano,minBenef,maxBenef){
		
		$.ajax({
			url: 'ajax/desconto.php?acao=buscaDesconto',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'modalidade' : modalidade,
			    'plano'		 : plano,
				'tipoPlano'	 : tipoPlano,
				'minBenef'   : minBenef,
				'maxBenef'   : maxBenef
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#modalidadeCadastro').val(result.cdmodalidade);
		                $('#planoCadastro').val(result.cdplano);
		                $('#tipoPlanoCadastro').val(result.cdtipoplano);
		                $('#minBenefCadastro').val(result.nrminbenef);
		                $('#maxBenefCadastro').val(result.nrmaxbenef);
		                $('#valorDescontoCadastro').val(result.vldesconto);
		                $('#acao').val('atualizar');
						
						$('#modalidadeCadastro').prop("disabled",true);
						$('#planoCadastro').prop("disabled",true);
						$('#tipoPlanoCadastro').prop("disabled",true);
						$('#minBenefCadastro').prop("disabled",true);
						$('#maxBenefCadastro').prop("disabled",true);
						
						$('#valorDescontoCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#minBenefCadastro').val() != '' && $('#maxBenefCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir o desconto?");		
		}else{
			exibeErro('Você deve selecionar um desconto primeiro.');
		}
	}
	
	function excluir(){		
		
		if($('#modalidadeCadastro').val() != '' && $('#planoCadastro').val() != '' && $('#tipoPlanoCadastro').val() != '' && $('#minBenefCadastro').val() != '' && $('#maxBenefCadastro').val() != ''){
			
			var modalidade = $('#modalidadeCadastro').val();
			var plano      = $('#planoCadastro').val();
			var tipoPlano  = $('#tipoPlanoCadastro').val();
			var minBenef   = $('#minBenefCadastro').val();
			var maxBenef   = $('#minBenefCadastro').val();
			
			$.ajax({
				url: 'ajax/desconto.php?acao=excluiDesconto',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
						'modalidade' : modalidade, 
                        'plano'      : plano,      
                        'tipoPlano'  : tipoPlano,                          
                        'minBenef'   : minBenef,
						'maxBenef'   : maxBenef
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar uma tabela de preço primeiro.');			
		}		
		
	}
		
	atualizaTabela();
	
	$('#modalidadeCadastro').focus();
	
	$("#valorDescontoCadastro").maskMoney({thousands:'.', decimal:',', symbolStay: true, allowNegative: true});
	
	$('#valorDescontoCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

