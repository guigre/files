<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-sticky-note"></i> Tabela de Preço
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
				  <input type="hidden" id="acao" value="cadastrar">	
				  <input type="hidden" id="cduserid" value="<?php print $_SESSION['usuario']; ?>">
                  <div class="box-body">			  
                    <div class="form-group">
                      <label for="codigoTabelaPrecoCadastro" class="col-sm-2 control-label">Código Tabela Preço<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="codigoTabelaPrecoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="descricaoTabelaPrecoCadastro" class="col-sm-2 control-label">Descrição Tabela Preço<font color="red">*</font></label>
                      <div class="col-xs-4">
                        <input type="text" class="form-control" id="descricaoTabelaPrecoCadastro" placeholder="">
                      </div>
                    </div>	
                    <div class="form-group">
                      <label for="inicioCadastro" class="col-sm-2 control-label">Data Inicial<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="inicioCadastro" placeholder="">
                      </div>
                    </div>						
                    <div class="form-group">
                      <label for="fimCadastro" class="col-sm-2 control-label">Data Final<font color="red">*</font></label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="fimCadastro" placeholder="">
                      </div>
                    </div>                 					
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaPreco">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#codigoTabelaPrecoCadastro').val('');
		$('#descricaoTabelaPrecoCadastro').val('');
		$('#inicioCadastro').val('');
		$('#fimCadastro').val('');
		$('#acao').val('cadastra');
		
		$('#codigoTabelaPrecoCadastro').prop("disabled",false);		
	
		$('#codigoTabelaPrecoCadastro').focus();
		
	}

	function salvar(){
		
		var codigoTabelaPrecoCadastro    = $('#codigoTabelaPrecoCadastro').val();
		var descricaoTabelaPrecoCadastro = $('#descricaoTabelaPrecoCadastro').val();
		var inicioCadastro               = $('#inicioCadastro').val();
		var fimCadastro                  = $('#fimCadastro').val();
		var acao   	    		         = $('#acao').val();
		var cduserid			         = $('#cduserid').val();
		
		if(codigoTabelaPrecoCadastro == ''){
			exibeErro('<p>Campo <b>(Código Tabela Preço)</b> Obrigatório!</p>');
			$('#codigoTabelaPrecoCadastro').focus();
		}else if(descricaoTabelaPrecoCadastro == ''){
			exibeErro('<p>Campo <b>(Descrição Tabela Preço)</b> Obrigatório!</p>');
			$('#descricaoTabelaPrecoCadastro').focus();
		}else if(inicioCadastro == ''){
			exibeErro('<p>Campo <b>(Data Inicial)</b> Obrigatório!</p>');
			$('#inicioCadastro').focus();
		}else if(fimCadastro == ''){
			exibeErro('<p>Campo <b>(Data Final)</b> Obrigatório!</p>');
			$('#fimCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/tabelaPreco.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {'codigoTabelaPrecoCadastro'    : codigoTabelaPrecoCadastro,        
					   'descricaoTabelaPrecoCadastro' : descricaoTabelaPrecoCadastro,
					   'inicioCadastro'               : inicioCadastro,        
					   'fimCadastro'                  : fimCadastro,
					   'cduserid'		              : cduserid,
					   'acao'    				      : acao
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){	
		$.ajax({
			url: 'ajax/tabelaPreco.php?acao=listaTabelasPreco',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaPreco').html(result.tabela);
						
						$("#tabelaPreco").DataTable();
						
					}else{
										
						$('#divTabelaPreco').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(cdtabpreco){	
		
		$.ajax({
			url: 'ajax/tabelaPreco.php?acao=buscaTabelaPreco',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'cdtabpreco' : cdtabpreco
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#codigoTabelaPrecoCadastro').val(result.cdtabpreco);
		                $('#descricaoTabelaPrecoCadastro').val(result.dstabpreco);
		                $('#inicioCadastro').val(result.dtinicio);
		                $('#fimCadastro').val(result.dtfim);
		                $('#acao').val('atualizar');
						
						$('#codigoTabelaPrecoCadastro').prop("disabled",true);
						
						$('#descricaoTabelaPrecoCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#codigoTabelaPrecoCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir a tabela de preço?");		
		}else{
			exibeErro('Você deve selecionar uma tabela de preço primeiro.');
		}
	}
		
	
	function excluir(){		
		
		if($('#codigoTabelaPrecoCadastro').val() != ''){
			
			var codigo = $('#codigoTabelaPrecoCadastro').val();
			
			$.ajax({
				url: 'ajax/tabelaPreco.php?acao=excluiTabelaPreco',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					'cdtabpreco' : codigo				
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar uma tabela de preço primeiro.');			
		}		
		
	}
	
	atualizaTabela();
	
	$('#codigoTabelaPrecoCadastro').focus();
	
	$('#inicioCadastro').inputmask('dd/mm/yyyy',{"placeholder": "","yearrange":{minyear: 1600, maxyear: 9999}});		
	$('#fimCadastro').inputmask('dd/mm/yyyy',{"placeholder": "","yearrange":{minyear: 1600, maxyear: 9999}});		
	
	$('#fimCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	}); 
	
</script>	  

<?php include("inc/rodape.php"); ?>

