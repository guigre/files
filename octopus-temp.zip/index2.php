<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Página Inicial
			 <small>Seja Bem-Vindo ao Painel Administrativo OCTOPUS!</small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php include("inc/rodape.php"); ?>