<?php include("inc/topo.php"); ?>
	<form method="post" action="http://www.unimedvtrp.com.br/cgi-bin/webssl/dep/spweb003a" name="acessar" target="_blank" id="myForm">
	<!--<form method="post" action="http://srv-prgs-prod02/cgi-bin/web/WService=wgpldts11prot/dep/spweb003a" name="acessar" target="_blank" id="myForm">-->
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					<i class="fa fa-lock"></i> Acesso Restrito Cooperado
				</h1>
			</section>

			<!-- Main content -->
			<section class="content">

				<!-- Your Page Content Here -->
			  
				<!-- Horizontal Form -->
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Simulação de acesso restrito do cooperado</h3>&nbsp;&nbsp;
					</div><!-- /.box-header -->
					<div>
						<input type="hidden" name="codigoPrestador">
						<input type="hidden" name="senhaPrestador">
						<input type="hidden" name="usuarioAtendente">
						<input type="hidden" name="senhaAtendente">
					</div>
					<div class="box-body" id="divTabela">
					</div><!-- /.box-body -->
				</div><!-- /.box -->
				<div class="box" id="divRetorno">
					
				</div><!-- /.box -->
			</section><!-- /.content -->
		</div><!-- /.content-wrapper -->
	</form>
<script>

	function iniciaTela(){
		document.acessar.codigoPrestador.value = "";
		document.acessar.senhaPrestador.value = "";
		document.acessar.usuarioAtendente.value = "";
		document.acessar.senhaAtendente.value = "";
	}
	
	function validaForm(theForm,crm){
	
		var enviar = "yes";
		
		theForm.codigoPrestador.value = crm;
		theForm.usuarioAtendente.value = '<?php print $_SESSION['usuario']; ?>';
		theForm.senhaAtendente.value = '<?php print md5($_SESSION['usuario'].md5($_SESSION['senha']).date("d/m/Y")); ?>';
		
		/*var senhaantes = '<?php print md5($_SESSION['senha']); ?>';*/
		
		if (theForm.codigoPrestador.value == ""){
			alert("Campo Código obrigatório.");
			enviar = "no";
		}

		if ((theForm.senhaPrestador.value == "") && (enviar == "yes")){
			
			if ((theForm.usuarioAtendente.value == "") || (theForm.senhaAtendente.value == "")){
				alert("Campo Senha obrigatório.");
				enviar = "no";
			}
		}

		if (enviar == "yes"){
		
			/*alert(theForm.codigoPrestador.value + "\n" +
			      theForm.senhaPrestador.value    + "\n" +
				  senhaantes                      + "\n" +
			      theForm.usuarioAtendente.value  + "\n" +
			      theForm.senhaAtendente.value);*/

			theForm.submit();
		}
	}
	
	function incluiAlteraSenha(acao, cooperado, crm, email, cpf, dataNascimento, idPessoa){
	
		$('#divRetorno').html('');
		
		var htmlAlteracao = "<div class='box-header'>";
		
		if(acao == 1){
			htmlAlteracao += "<h3 class='box-title'>Inclusão de senha cooperado <font color='red'>(Aplicativo Cooperado, Portal Cooperado e Acesso Restrito)</font></h3>";
		}else{
			htmlAlteracao += "<h3 class='box-title'>Alteração de senha cooperado <font color='red'>(Aplicativo Cooperado, Portal Cooperado e Acesso Restrito)</font></h3>";
		}
		
		htmlAlteracao += "</div><!-- /.box-header -->"
						+   "<div class='box-body' id='divSaida'>"
						+	   "<div class='box box-info'>"
						+	 	"<div class='box-header with-border'>" 
						+	 		"<h3 class='box-title'>" + cooperado + " - CRM " + crm + "</h3>&nbsp;&nbsp;"
						+	 	"</div><!-- /.box-header -->"
						+	 	"<!-- form start -->"
						+	 	"<form class='form-horizontal'>"
						+	 		"<div class='box-body'>"
						+				"<div>"
						+				"<input type='hidden' id='crmCooperado' value='" + crm + "'>"
						+				"<input type='hidden' id='nomeCooperado' value='" + cooperado + "'>"
						+				"<input type='hidden' id='emailCooperado' value='" + email + "'>"
						+				"<input type='hidden' id='cpfCooperado' value='" + cpf + "'>"
						+				"<input type='hidden' id='dataNascimentoCooperado' value='" + dataNascimento + "'>"
						+				"<input type='hidden' id='idPessoaCooperado' value='" + idPessoa + "'>"
						+				"</div>"
						+	 			"<div class='form-group'>"
						+	 				"<label for='novaSenhaCooperado' class='col-sm-2 control-label'>Nova Senha Cooperado</label>"
						+	 				"<div class='col-xs-16'>"
						+	 					"<input type='password' name='novaSenhaCooperado' id='novaSenhaCooperado'>"
						+	 				"</div>"
						+	 			"</div>"
						+	 			"<div class='form-group'>"
						+	 				"<label for='confirmaSenhaCooperado' class='col-sm-2 control-label'>Confirma Senha Cooperado</label>"
						+	 				"<div class='col-xs-16'>"
						+	 					"<input type='password' name='confirmaSenhaCooperado' id='confirmaSenhaCooperado'>"
						+	 				"</div>"
						+	 			"</div>"
						+	 		"</div><!-- /.box-body -->"
						+	 		"<div class='box-footer'>";
						
		if(acao == 1){
			htmlAlteracao += "<button type='button' class='btn btn-primary' onclick='javascript:void(validaCamposSenha(" + acao + "," + crm + ",\"" + cooperado + "\"))'><i class='fa fa-check'></i> Incluir</button>";
		}else{
			htmlAlteracao += "<button type='button' class='btn btn-primary' onclick='javascript:void(validaCamposSenha(" + acao + "," + crm + ",\"" + cooperado + "\"))'><i class='fa fa-check'></i> Alterar</button>";
		}				
						
		htmlAlteracao += 	 			"<div id='loading'></div>"
						+	 		"</div><!-- /.box-footer -->"
						+	 	"</form>"
						+	 "</div><!-- /.box -->"
						+ "</div><!-- /.box-body -->"
		
		$('#divRetorno').html(htmlAlteracao);
	}
	
	function validaCamposSenha(acao, crm, cooperado){
		
		if ($('#novaSenhaCooperado').val().length < 6){
			exibeErro('<p>Campo <b>(Nova Senha Cooperado)</b> deve possuir pelo menos 6 caracteres!</p>');
			$('#novaSenhaCooperado').focus();
		}else{
			var novaSenhaCooperado = $.md5($('#novaSenhaCooperado').val());
			var confirmaSenhaCooperado = $.md5($('#confirmaSenhaCooperado').val());
			
			if(novaSenhaCooperado == ''){
				exibeErro('<p>Campo <b>(Nova Senha Cooperado)</b> Obrigatório!</p>');
				$('#novaSenhaCooperado').focus();
			}else if(confirmaSenhaCooperado == ''){
				exibeErro('<p>Campo <b>(Confirma Senha Cooperado)</b> Obrigatório!</p>');
				$('#mensagemEnvio').focus();
			}else if($('#novaSenhaCooperado').val() != $('#confirmaSenhaCooperado').val()){
				exibeErro('<p>Senhas não conferem!</p>');
				$('#mensagemEnvio').focus();
			}else{
				if(acao == 1){
					exibeConfirmaInclusao('Tem certeza que gostaria de incluir a senha do(a) Dr(a). ' + cooperado + ' (CRM ' + crm + ')?');
				}else{
					exibeConfirmaAlteracao('Tem certeza que gostaria de alterar a senha do(a) Dr(a). ' + cooperado + ' (CRM ' + crm + ')?');
				}
			}
		}
	}
	
	function alteraSenhaBancoDados(){
	
		var crm = $('#crmCooperado').val();
		var novaSenhaCooperado = $.md5($('#novaSenhaCooperado').val());
		
		$.ajax({
			url: 'ajax/cooperado.php?acao=alteraSenhaCooperado',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				   'crm' : crm,
				   'novaSenhaCooperado' : novaSenhaCooperado
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						exibeErro('<p>Senha alterada com sucesso!</p>');
					}else{
						exibeErro('<p>Erro ao alterar senha. Por favor tente novamente em instantes.</p>');
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	function incluiSenhaBancoDados(){
	
		var crm = $('#crmCooperado').val();
		var nome = $('#nomeCooperado').val();
		var email = $('#emailCooperado').val();
	    var cpf = $('#cpfCooperado').val();
		var dataNascimento = $('#dataNascimentoCooperado').val();
		var idPessoa = $('#idPessoaCooperado').val();
		var novaSenhaCooperado = $.md5($('#novaSenhaCooperado').val());
		
		$.ajax({
			url: 'ajax/cooperado.php?acao=incluiSenhaCooperado',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				   'crm' : crm,
				   'nome' : nome,
				   'email' : email,
				   'cpf' : cpf,
				   'dataNascimento' : dataNascimento,
				   'idPessoa' : idPessoa,
				   'novaSenhaCooperado' : novaSenhaCooperado
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						exibeErro('<p>Senha incluída com sucesso!</p>');
						iniciaTela();
						atualizaTabela();
						$('#divRetorno').html('');
					}else{
						exibeErro('<p>Erro ao incluir senha. Por favor tente novamente em instantes.</p>');
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
			}
		});
	}
	
	function atualizaTabela(){		

		$.ajax({
			url: 'ajax/cooperado.php?acao=listaCooperados',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabela').html(result.tabela);
						
						$("#tabelaCooperados").DataTable({
							"language": {
								"paginate": {
									"previous": "Anterior",
									"next": "Próximo"
								},
								"lengthMenu": "Mostre _MENU_ registros por página",
								"loadingRecords": "Carregando...",
								"processing": "Processando...",
								"search": "Procurar:",
								"zeroRecords": "Nada encontrado - desculpe",
								"info": "Mostrando página _PAGE_ de _PAGES_",
								"infoEmpty": "Sem registros"
							},
							"pagingType": "simple_numbers",
							"order": [ [2, "desc"], [1, "asc"]]
						});
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	}
	
	iniciaTela();
	atualizaTabela();
	
</script>	  

<?php include("inc/rodape.php"); ?>