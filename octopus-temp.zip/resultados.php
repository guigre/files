<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-file-text"></i> Resultado dos Indicadores
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="codigoCadastro" class="col-sm-2 control-label">Código</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="codigoCadastro" placeholder="" disabled>
                      </div>
                    </div>				  
                    <div class="form-group">
                      <label for="indicadorCadastro" class="col-sm-2 control-label">Indicador<font color="red">*</font></label>
                      <div class="col-xs-8">
					    <div id="divIndicador">
                        
						</div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="semanaCadastro" class="col-sm-2 control-label">Semana</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="semanaCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="mesCadastro" class="col-sm-2 control-label">Mês</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="mesCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="anoCadastro" class="col-sm-2 control-label">Ano<font color="red">*</font></label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="anoCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="detalheIndicador" class="col-sm-2 control-label">Detalhe Indicador</label>
                      <div class="col-xs-8">
                        <input type="text" class="form-control" id="detalheIndicador" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="detalheIndicador2" class="col-sm-2 control-label">Detalhe Indicador 2</label>
                      <div class="col-xs-8">
                        <input type="text" class="form-control" id="detalheIndicador2" placeholder="">
                      </div>
                    </div>	
                    <div class="form-group">
                      <label for="metaCadastro" class="col-sm-2 control-label">Meta</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="metaCadastro" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="resultadoCadastro" class="col-sm-2 control-label">Resultado</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="resultadoCadastro" placeholder="">
                      </div>
                    </div>					
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Filtros para Consulta</h3>&nbsp;&nbsp;				  
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">				  
                    <div class="form-group">
                      <label for="indicadorCadastro" class="col-sm-2 control-label">Indicador</label>
                      <div class="col-xs-8">
					    <div id="divIndicadorConsulta">
                        
						</div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="mesConsulta" class="col-sm-2 control-label">Mês</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="mesConsulta" placeholder="">
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="anoConsulta" class="col-sm-2 control-label">Ano</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="anoConsulta" placeholder="">
                      </div>
					</div>  
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(consultar())">Consultar</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->	

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabelaResultado">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#codigoCadastro').val('');
		$('#indicadorCadastro').val('');
		$('#indicadorCadastro').attr("disabled",false);
		$('#semanaCadastro').val('');
		$('#mesCadastro').val('');
		$('#anoCadastro').val('');
		$('#detalheIndicador').val('');
		$('#detalheIndicador2').val('');
		$('#metaCadastro').val('');
		$('#resultadoCadastro').val('');
	
		$('#indicadorCadastro').focus();
		
	}
	
	function montaIndicador(){
		
		$.ajax({
			url: 'ajax/resultado.php?acao=montaIndicador',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divIndicador').html(result.select);
						
					}else{
										
						$('#divIndicador').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function montaIndicadorConsulta(){
		
		$.ajax({
			url: 'ajax/resultado.php?acao=montaIndicadorConsulta',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divIndicadorConsulta').html(result.select);
						
					}else{
										
						$('#divIndicadorConsulta').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}	

	function salvar(){
		
		var codigoCadastro    = $('#codigoCadastro').val();
		var indicadorCadastro = $('#indicadorCadastro').val();
		var semanaCadastro    = $('#semanaCadastro').val();
		var mesCadastro       = $('#mesCadastro').val();
		var anoCadastro       = $('#anoCadastro').val();
		var detalheIndicador  = $('#detalheIndicador').val();
		var detalheIndicador2 = $('#detalheIndicador2').val();
		var metaCadastro      = $('#metaCadastro').val();
		var resultadoCadastro = $('#resultadoCadastro').val();
		
		if(indicadorCadastro == ''){
			exibeErro('<p>Campo <b>(Indicador)</b> Obrigatório!</p>');
			$('#indicadorCadastro').focus();
		}else if(anoCadastro == ''){
			exibeErro('<p>Campo <b>(Ano)</b> Obrigatório!</p>');
			$('#anoCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/resultado.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					   'codigoCadastro'    : codigoCadastro,   
					   'indicadorCadastro' : indicadorCadastro,
					   'semanaCadastro'    : semanaCadastro,   
					   'mesCadastro'       : mesCadastro,      
					   'anoCadastro'       : anoCadastro,      
					   'detalheIndicador'  : detalheIndicador,  
					   'detalheIndicador2' : detalheIndicador2, 
					   'metaCadastro'      : metaCadastro,     
					   'resultadoCadastro' : resultadoCadastro
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							novo();
							consultar();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
		
	function editar(id,id_resultado){
		
		$.ajax({
			url: 'ajax/resultado.php?acao=buscaResultado',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'id'           : id,
				'id_resultado' : id_resultado	
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#codigoCadastro').val(result.id_resultado);
						$('#indicadorCadastro').val(result.id);	
						$('#indicadorCadastro').attr("disabled",true);
						$('#semanaCadastro').val(result.semana);	
						$('#mesCadastro').val(result.mes);	
						$('#anoCadastro').val(result.ano);	
						$('#detalheIndicador').val(result.detalheIndicador);	
						$('#metaCadastro').val(result.meta);	
						$('#resultadoCadastro').val(result.resultado);	
						$('#detalheIndicador2').val(result.detalheIndicador2);	
						
						$('#semanaCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function consultar(){
		
		var indicador = $('#indicadorConsulta').val();
		var mes       = $('#mesConsulta').val();
		var ano       = $('#anoConsulta').val();
		
		$.ajax({
			url: 'ajax/resultado.php?acao=buscaResultadoFiltro',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'indicador' : indicador,
				'mes'       : mes,
				'ano'       : ano		
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaResultado').html(result.tabela);
						
						$("#tabelaResultados").DataTable();
						
					}else{
										
						$('#divTabelaResultado').html('Sem Results.....');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}	
	
	function confirmacao(){
		if($('#codigoCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir o indicador?");		
		}else{
			exibeErro('Você deve selecionar um indicador primeiro.');
		}
	}
	
	function excluir(){		
		
		if($('#codigoCadastro').val() != ''){
			
			var codigo = $('#codigoCadastro').val();
			
			$.ajax({
				url: 'ajax/indicador.php?acao=desativaIndicador',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					'codigo' : codigo				
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar um indicador primeiro.');			
		}		
		
	}
	
	//atualizaTabela();
	montaIndicador();
	montaIndicadorConsulta();
	
	$('#indicadorCadastro').focus();
	
	$('#statusCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

