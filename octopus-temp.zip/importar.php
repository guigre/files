<?php
$arquivo = file("C:\\xampp\\htdocs\\octopus-temp\\perguntas.csv");

foreach($arquivo as $line)
{
	
	$campos = explode(";",$line);		
	
	$id        = $campos[0];
	$descricao = trim(utf8_encode($campos[1]));
		
	print "insert into v_perguntas (id, descricao)
	                        values ('$id', '$descricao');<br>";
	

}

?>