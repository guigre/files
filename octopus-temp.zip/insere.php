<?php
print "INSERT INTO usuarios (nome,email,login,senha,tipo,status) VALUES ('Guilherme Gregory','guilherme.gregory@unimedvtrp.com.br','ggregory','e3adbdc9b5e413b746adb576d894dca09fd1fd83','a','a')";
?>