<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-user"></i> Usuários
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Cadastro</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="codigoCadastro" class="col-sm-2 control-label">Código</label>
                      <div class="col-xs-1">
                        <input type="text" class="form-control" id="codigoCadastro" placeholder="" disabled>
                      </div>
                    </div>				  
                    <div class="form-group">
                      <label for="usuarioCadastro" class="col-sm-2 control-label">Nome Completo<font color="red">*</font></label>
                      <div class="col-xs-4">
                        <input type="text" class="form-control" id="usuarioCadastro" placeholder="">
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="emailCadastro" class="col-sm-2 control-label">Email</label>
                      <div class="col-xs-4">
                        <input type="email" class="form-control" id="emailCadastro" placeholder="">
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="loginCadastro" class="col-sm-2 control-label">Login<font color="red">*</font></label>
                      <div class="col-xs-4">
                        <input type="text" class="form-control" id="loginCadastro" placeholder="">
                      </div>
                    </div>					
					
                    <div class="form-group">
                      <label for="privilegioCadastro" class="col-sm-2 control-label">Tipo<font color="red">*</font></label>
					  <div class="col-xs-4">
                      <select class="form-control" id="privilegioCadastro">
                        <option value="A">Administrador</option>
                        <option value="U">Usuário</option>
                      </select>
					  </div>
                    </div>					
                    <div class="form-group">
                      <label for="statusCadastro" class="col-sm-2 control-label">Status<font color="red">*</font></label>
					  <div class="col-xs-4">
                      <select class="form-control" id="statusCadastro">
                        <option value="A">Ativo</option>
                        <option value="I">Inativo</option>
                      </select>
					  </div>
                    </div>
                  <div class="form-group">
                   <label for="statusCadastro" class="col-sm-2 control-label">Departamentos</label>
				    <div class="col-xs-8">
					<div id="divDepartamentos">

					</div>
                  </div><!-- /.form-group -->					
			      </div><!-- /.box-body -->
                  <div class="box-footer">
				    <button type="button" class="btn btn-primary" onclick="javascript:void(novo())">Novo</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-success" onclick="javascript:void(salvar())">Salvar</button>&nbsp;&nbsp;
                    <button type="button" class="btn btn-danger" onclick="javascript:void(confirmacao())">Excluir</button>&nbsp;&nbsp;
                  </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divTabela">
				
                </div><!-- /.box-body -->
              </div><!-- /.box -->			  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function novo(){
		
		$('#codigoCadastro').val('');
		$('#usuarioCadastro').val('');
		$('#emailCadastro').val('');
		$('#loginCadastro').val('');
		$('#loginCadastro').removeAttr("disabled");
		$('#privilegioCadastro').val('A');
		$('#statusCadastro').val('A');
		$('#departamentosCadastro').val('');
	
		$(".select2").select2();
	
		$('#usuarioCadastro').focus();
		
	}
	
	function montaDepartamentos(){
		
		$.ajax({
			url: 'ajax/usuario.php?acao=montaDepartamentos',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divDepartamentos').html(result.select);
						
						$(".select2").select2();
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}

	function salvar(){
		
		var codigoCadastro        = $('#codigoCadastro').val();
		var usuarioCadastro       = $('#usuarioCadastro').val();
		var emailCadastro         = $('#emailCadastro').val();
		var loginCadastro         = $('#loginCadastro').val();
		var privilegioCadastro    = $('#privilegioCadastro').val();
		var statusCadastro        = $('#statusCadastro').val();
		var departamentosCadastro = $('#departamentosCadastro').val();
		
		if(usuarioCadastro == ''){
			exibeErro('<p>Campo <b>(Nome Completo)</b> Obrigatório!</p>');
			$('#usuarioCadastro').focus();
		}else if(loginCadastro == ''){
			exibeErro('<p>Campo <b>(Login)</b> Obrigatório!</p>');
			$('#loginCadastro').focus();
		}else{
			$.ajax({
				url: 'ajax/usuario.php?acao=salvar',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					   'codigoCadastro'        : codigoCadastro,
					   'usuarioCadastro'       : usuarioCadastro,
					   'emailCadastro'         : emailCadastro,
					   'loginCadastro'         : loginCadastro,
					   'privilegioCadastro'    : privilegioCadastro,
					   'statusCadastro'        : statusCadastro,
					   'departamentosCadastro' : departamentosCadastro
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}
	
	}
	
	function atualizaTabela(){		

		$.ajax({
			url: 'ajax/usuario.php?acao=listaUsuarios',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabela').html(result.tabela);
						
						$("#tabelaUsuarios").DataTable();
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	
	}	
	
	function editar(codigo){
		
		$.ajax({
			url: 'ajax/usuario.php?acao=buscaUsuario',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			data: {
				'codigo' : codigo				
			},
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#codigoCadastro').val(result.codigo);		
						$('#usuarioCadastro').val(result.usuario);		
						$('#emailCadastro').val(result.email);		
						$('#loginCadastro').val(result.login);		
						$('#privilegioCadastro').val(result.privilegio);		
						$('#statusCadastro').val(result.status);
						$('#departamentosCadastro').val(result.departamentos);
						
						$(".select2").select2();
						
						$('#loginCadastro').attr("disabled",true);
						$('#usuarioCadastro').focus();
						
					}else{
										
						
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}
	
	function confirmacao(){
		if($('#codigoCadastro').val() != ''){
			exibeExclusao("Você realmente deseja excluir o usuário?");		
		}else{
			exibeErro('Você deve selecionar um usuário primeiro.');
		}
	}
	
	function excluir(){		
		
		if($('#codigoCadastro').val() != ''){
			
			var codigo = $('#codigoCadastro').val();
			
			$.ajax({
				url: 'ajax/usuario.php?acao=desativaUsuario',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					'codigo' : codigo				
				},
				beforeSend: function() {
					
				},
				complete: function() {
					
				},
				error: function(xhr, ajaxOptions, thrownError) {
					console.log(thrownError);
				},
				success: function(result) {
					//console.log(result);
					if(result != null){
						if(result.ok == 1){
							exibeErro('<p>'+result.msg+'</p>');
							atualizaTabela();
							novo();
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});			
			
		}else{
			exibeErro('Você deve selecionar um usuário primeiro.');			
		}		
		
	}
	
	atualizaTabela();
	montaDepartamentos();
	
	$('#usuarioCadastro').focus();
	
	$('#statusCadastro').keypress(function(e) {
		if(e.which == 13) {
			salvar();
		}
	});	  
	
</script>	  

<?php include("inc/rodape.php"); ?>

