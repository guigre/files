<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sistema Octopus Unimed VTRP</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/font-awesome-4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
	
	<script src="inc/lwScripts.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
        <b>Sistema Octopus</b>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Acesso Restrito</p>
       <!-- <form action="index2.php" method="post"> -->
          <div class="form-group has-feedback">
            <input type="login" class="form-control" placeholder="Usu&aacute;rio" id="login">
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Senha" id="senha">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-4" style="width:100%">
              <button type="button" class="btn btn-danger btn-block btn-flat" style="background-color:#00995D;border-color:#00995D;" onclick="javascript:void(login())">Entrar</button>
            </div><!-- /.col -->
          </div>
			<div class="loaderLogin" style="display:none;">
					<span><img src="img/ajax-loader.gif"></span>
			</div>		  
      <!--  </form> -->
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script>
	
	$(document).ready(function() {  

		$('#login').focus();
	  
	});	
	
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });

	function login(){		
		if($('#login').val() != '' && $('#senha').val() != '' ){
			$.ajax({
				url: 'ajax/usuario.php?acao=login',
				type: 'POST',
				timeout: 15000,
				dataType: 'json',
				data: {
					'login' : $('#login').val(),
					'senha' : $('#senha').val()
				},
				beforeSend: function() {
					$('.loaderLogin').show();
				},
				complete: function() {
					$('.loaderLogin').hide();								
				},
				error: function(xhr, ajaxOptions, thrownError) {
					
				},
				success: function(result) {
					console.log(result);
					if(result != null){
						if(result.ok == 1){
							window.open('index2.php','_self');
						}else{
							exibeErro('<p>'+result.msg+'</p>');
						}
					}else{
						exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
					}
					
				}
			});
		}else{
			exibeErro('<p>Por favor, preencha os campos <b>E-MAIL</b> e <b>SENHA</b>.</p>');
		}
		
	} 
	
	$('#senha').keypress(function(e) {
		if(e.which == 13) {
			login();
		}
	});	
	  
    </script>
	
	<!-- ERROR MODAL BOX -->
	<div class="modal fade" id="dialog-error" style='display:none;'>
		<div class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"><i class='fa fa-warning'></i> Aviso</h4>
			</div>
			<div class="modal-body" id=dialogErrorMsg>
				
			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-default" data-dismiss="modal" >Fechar</button>
			</div>
		  </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	  </div><!-- /.modal -->
	<!-- ERROR MODAL BOX : FIM -->	
	
  </body>
</html>
