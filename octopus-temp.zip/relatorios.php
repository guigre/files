<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-file-text"></i> Relatório dos Indicadores
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Filtros do Relatório</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>				  
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">				  
                    <div class="form-group">
                      <label for="departamentoConsulta" class="col-sm-2 control-label">Departamento<font color="red">*</font></label>
                      <div class="col-xs-4">
					    <div id="divDepartamento">
                        
						</div>
                      </div>
                    </div>
                  <div class="form-group">
                     <label for="periodo" class="col-sm-2 control-label">Período<font color="red">*</font></label>
                    <div class="input-group col-xs-3" style="padding-left:15px !important; ">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                      <input type="text" class="form-control pull-right" id="periodo">
                    </div><!-- /.input group -->
                  </div><!-- /.form group -->
                    <div class="form-group">
                      <label for="acumulado" class="col-sm-2 control-label"></label>
					  <div class="col-xs-6">
						  <div class="checkbox">
							<label>
							  <input type="checkbox" id="acumulado" value="acumulado">
							  Acumular Valores
							</label>
						  </div>
					  </div> 
                    </div>				  
					<div id="tipoConsulta">
						<div class="form-group">
						  <label for="tipoConsulta" class="col-sm-2 control-label">Categorias<font color="red">*</font></label>
						  <div class="col-xs-6">
							  <div class="checkbox">
								<label>
								  <input type="checkbox" id="processoIndicentes" value="processoIndicentes" checked>
								  Processo de Incidentes
								</label>
							  </div>
							  <div class="checkbox">
								<label>
								  <input type="checkbox" id="processoRequisicoes" value="processoRequisicoes" checked>
								  Processo de Requisições
								</label>
							  </div>
							  <div class="checkbox">
								<label>
								  <input type="checkbox" id="processoDesenvolvimentos" value="processoDesenvolvimento" checked>
								  Processo de Desenvolvimento
								</label>
							  </div>
							  <div class="checkbox">
								<label>
								  <input type="checkbox" id="checkProjetos" value="checkProjetos" checked>
								  Projetos
								</label>
							  </div>							  
						  </div>
						</div>	
					</div>
                    <div class="box-footer">
						<button type="button" class="btn btn-primary" onclick="javascript:void(consultar())" id="btnConsultar">Consultar</button>&nbsp;&nbsp;
						<button type="button" class="btn btn-success" onclick="javascript:void(visualizar())" id="btnVisualizar">Visualizar Resultado</button>&nbsp;&nbsp;
                    </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  
                </div><!-- /.box-header -->
                <div class="box-body" id="divRelatorioIncidentes" style="display:none;">
				    <h2 style='background-color:#00995D; color:#ffffff;' id="tituloIncidentes">Processo de Incidentes</h2> 
					<div id="totalIncidentes"></div>
					<div id="totalIncidentesPrazo"></div>
					<div class="col-md-6">
						<div id="totalIncidentesSeveridade"></div>
					</div>
					<div class="col-md-6">
						<div id="totalIncidentesOrigem"></div>
					</div>
					<div id="divTabelaTotalIncidentesServico"></div>
					<div id="divTabelaTotalIncidentesColaborador"></div>
					<div class="box-body" id="divTabelaIncidentesAbertos"></div>						
					<div class="loaderIncidentes" style="display:none;">
							<span><img src="img/ajax-loader.gif"></span>
					</div>					
                </div><!-- /.box-body -->
                <div class="box-body" id="divRelatorioRequisicoes" style="display:none;">
				    <h2 style='background-color:#F47920; color:#ffffff;' id="tituloRequisicoes">Processo de Requisições</h2> 
					<div id="totalRequisicoes"></div>
					<div id="totalRequisicoesPrazo"></div>
					<div class="col-md-6">
						<div id="totalRequisicoesSeveridade"></div>
					</div>
					<div class="col-md-6">
						<div id="totalRequisicoesOrigem"></div>
					</div>
					<div id="divTabelaTotalRequisicoesServico"></div>					
					<div id="divTabelaTotalRequisicoesColaborador"></div>
					<div class="box-body" id="divTabelaRequisicoesAbertos"></div>					
					<div class="loaderRequisicoes" style="display:none;">
							<span><img src="img/ajax-loader.gif"></span>
					</div>					
                </div><!-- /.box-body -->	
                <div class="box-body" id="divRelatorioDesenvolvimentos" style="display:none;">
				    <h2 style='background-color:#A3238E; color:#ffffff;' id="tituloDesenvolvimento">Processo de Desenvolvimentos</h2> 
					<div id="totalDesenvolvimentos"></div>
					<div id="totalDesenvolvimentosPrazo"></div>
					<div id="divTabelaTotalDesenvolvimentosServico"></div>					
					<div id="divTabelaTotalDesenvolvimentosColaborador"></div>
					<div class="box-body" id="divTabelaDesenvolvimentosAbertos"></div>
					<div class="box-body" id="divTabelaDesenvolvimentosEncerrados"></div>
					<div class="loaderDesenvolvimentos" style="display:none;">
							<span><img src="img/ajax-loader.gif"></span>
					</div>					
                </div><!-- /.box-body -->
                <div class="box-body" id="divRelatorioProjetos" style="display:none;">
				    <h2 style='background-color:#A6A6A6; color:#ffffff;' id="tituloProjeto">Projetos</h2> 
					<div class="box-body" id="divProjetos"></div>
					<div class="loaderProjetos" style="display:none;">
							<span><img src="img/ajax-loader.gif"></span>
					</div>					
                </div><!-- /.box-body -->

				
			
				
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function limpaDivs(){
		
		$('#totalIncidentes').html('');
		$('#totalIncidentesPrazo').html('');
		$('#totalIncidentesSeveridade').html('');
		$('#totalIncidentesOrigem').html('');
		$('#divTabelaTotalIncidentesServico').html('');
		$('#divTabelaTotalIncidentesColaborador').html('');
		$('#divTabelaIncidentesAbertos').html('');
		
		$('#totalRequisicoes').html('');
		$('#totalRequisicoesPrazo').html('');
		$('#totalRequisicoesSeveridade').html('');
		$('#totalRequisicoesOrigem').html('');
		$('#divTabelaTotalRequisicoesServico').html('');
		$('#divTabelaTotalRequisicoesColaborador').html('');
		$('#divTabelaRequisicoesAbertos').html('');
				
		$('#totalDesenvolvimentos').html('');
		$('#totalDesenvolvimentosPrazo').html('');
		$('#divTabelaTotalDesenvolvimentosServico').html('');
		$('#divTabelaTotalDesenvolvimentosColaborador').html('');
		$('#divTabelaDesenvolvimentosAbertos').html('');		
		
		$('#divProjetos').html('');
		
	}

	function montaDepartamento(){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=montaDepartamentos',
			type: 'POST',
			timeout: 15000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divDepartamento').html(result.select);
						
					}else{
										
						$('#divDepartamento').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});
		
	}

	function totalIncidentes(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalIncidentes';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaIncidentes',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo		
			},
			beforeSend: function() {
				$('.loaderIncidentes').show();
			},
			complete: function() {
				$('.loaderIncidentes').hide();
				$('#totalIncidentes').append('<p>&nbsp;</p>');
				if(!modal) totalIncidentesPrazo(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalIncidentes(departamento,periodo,acumulado,true);
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: 'Quantidade Total de Incidentes'
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Incidentes'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#00995D',
								name: 'Qtde Abertos',
								data: result.abertos

							}, {
								color: '#411564',
								name: 'Qtde Encerrados',
								data: result.encerrados

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function totalIncidentesPrazo(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalIncidentesPrazo';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaIncidentesPrazo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo
			},
			beforeSend: function() {
				$('.loaderIncidentes').show();				
			},
			complete: function() {
				$('.loaderIncidentes').hide();
				$('#totalIncidentesPrazo').append('<p>&nbsp;</p>');
				if(!modal) totalIncidentesSeveridade(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$(div).highcharts({
							chart: {
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalIncidentesPrazo(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: '% Total de Incidentes no Prazo',
								x: -20 //center
							},
							xAxis: {
								categories: result.meses
							},
							yAxis: {
								title: {
									text: 'Valores %'
								},								
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}],
								min: -25,
								max: 125
							},
							legend: {
								layout: 'vertical',
								align: 'right',
								verticalAlign: 'middle',
								borderWidth: 0
							},
							plotOptions: {
								line: {
									dataLabels: {
										enabled: true,
										formatter: function() {
											return this.point.y + ' %';
										}										
									}
																		
								}
							},							
							series: [{
								color: '#00995D',
								name: 'Prazo',
								data: result.prazo
							}]
						});						

					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function totalIncidentesSeveridade(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalIncidentesSeveridade';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaIncidentesSeveridade',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderIncidentes').show();				
			},
			complete: function() {
				$('.loaderIncidentes').hide();
				$('#totalIncidentesSeveridade').append('<p>&nbsp;</p>');
				if(!modal) totalIncidentesOrigem(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = '% de incidentes abertos por severidade';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalIncidentesSeveridade(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Severidade",
								colorByPoint: true,
								data: [{
										name: 'CRÍTICA',
										y: result.critica,
										color: '#00401A'
									  },{
										name: 'ALTA',
										y: result.alta,
										color: '#411564'
									  },{
										name: 'MÉDIA',
										y: result.media,
										color: '#5B5C65'
									  },{
										name: 'BAIXA',
										y: result.baixa,
										color: '#682D00'
									  }
								  ]
							}]
						});

					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function totalIncidentesOrigem(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalIncidentesOrigem';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaIncidentesOrigem',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderIncidentes').show();				
			},
			complete: function() {
				$('.loaderIncidentes').hide();
				$('#totalIncidentesOrigem').append('<p>&nbsp;</p>');
				if(!modal) quantidadeTotalIncidentesServico(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = '% de incidentes abertos por origem';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalIncidentesOrigem(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Origem",
								colorByPoint: true,
								data: [{
										name: 'Portal Web',
										y: result.PortalWeb,
										color: '#00401A'
									  },{
										name: 'Telefone',
										y: result.Telefone,
										color: '#411564'
									  },{
										name: 'Presencial',
										y: result.Presencial,
										color: '#5B5C65'
									  },{
										name: 'E-mail',
										y: result.Email,
										color: '#682D00'
									  }
								  ]
							}]
						});

					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function quantidadeTotalIncidentesServico(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#divTabelaTotalIncidentesServico';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=quantidadeTotalIncidentesServico',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},			
			beforeSend: function() {
				$('.loaderIncidentes').show();				
			},
			complete: function() {
				$('.loaderIncidentes').hide();
				$('#divTabelaTotalIncidentesServico').append('<p>&nbsp;</p>');
				if(!modal) quantidadeTotalIncidentesColaborador(departamento,periodo,acumulado,false);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = 'Qtde. de Incidentes Abertos por Serviços - TOP 10';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											quantidadeTotalIncidentesServico(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							xAxis: {
								categories: result.servicos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Incidentes'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#00995D',
								name: 'Quantidade',
								data: result.resultados

							}]
						});
						
					}else{
										
						$('#divTabelaTotalIncidentesServico').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function quantidadeTotalIncidentesColaborador(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#divTabelaTotalIncidentesColaborador';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=quantidadeTotalIncidentesColaborador',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'	   : periodo,
				'acumulado'	   : acumulado
			},			
			beforeSend: function() {
				$('.loaderIncidentes').show();				
			},
			complete: function() {
				$('.loaderIncidentes').hide();
				$('#divTabelaTotalIncidentesColaborador').append('<p>&nbsp;</p>');
				if(!modal) incidentesAbertos(departamento);	
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = 'Qtde. de Incidentes Abertos por Colaborador - TOP 10';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											quantidadeTotalIncidentesColaborador(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							xAxis: {
								categories: result.colaborador,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Incidentes'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#00995D',
								name: 'Quantidade',
								data: result.resultados

							}]
						});			
						
					}else{
										
						$('#divTabelaTotalIncidentesColaborador').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function incidentesAbertos(departamento){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=incidentesAbertos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento	
			},			
			beforeSend: function() {
				$('.loaderIncidentes').show();				
			},
			complete: function() {
				$('.loaderIncidentes').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaIncidentesAbertos').html(result.tabela);
						
						var table = $('#tabelaIncidentesAbertos').DataTable({        
									"language": {
													"lengthMenu": "_MENU_ Registros por página",
													"zeroRecords": "Nenhum registro encontrado",
													"info": "Página _PAGE_ de _PAGES_",
													"infoEmpty": "Nenhum registro encontrado",
													"infoFiltered": "(Filtrado de um total de _MAX_ registros)",
													"search" : "Buscar:"
												}
									});
 
						table.on( 'draw', function () {
							var body = $( table.table().body() );
					 
							body.unhighlight();
							body.highlight( table.search() );  
						});
								
					}else{
										
						$('#divTabelaIncidentesAbertos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function totalRequisicoes(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalRequisicoes';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaRequisicoes',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderRequisicoes').show();
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
				$('#totalRequisicoes').append('<p>&nbsp;</p>');
				if(!modal) totalRequisicoesPrazo(departamento,periodo,acumulado,false);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){	

					   $(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalRequisicoes(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: 'Quantidade Total de Requisições'
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Requisições'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#F47920',
								name: 'Qtde Abertos',
								data: result.abertos

							}, {
								color: '#5B5C65',
								name: 'Qtde Encerrados',
								data: result.encerrados

							}]
						});						
						
					}else{
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function totalRequisicoesPrazo(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalRequisicoesPrazo';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaRequisicoesPrazo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderRequisicoes').show();				
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
				$('#totalRequisicoesPrazo').append('<p>&nbsp;</p>');
				if(!modal) totalRequisicoesSeveridade(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$(div).highcharts({
							chart: {
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalRequisicoesPrazo(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: '% Total de Requisições no Prazo',
								x: -20 //center
							},
							xAxis: {
								categories: result.meses
							},
							yAxis: {
								title: {
									text: 'Valores %'
								},								
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}],
								min: -25,
								max: 125
							},
							legend: {
								layout: 'vertical',
								align: 'right',
								verticalAlign: 'middle',
								borderWidth: 0
							},
							plotOptions: {
								line: {
									dataLabels: {
										enabled: true,
										formatter: function() {
											return this.point.y + ' %';
										}										
									}
																		
								}
							},							
							series: [{
								color: '#F47920',
								name: 'Prazo',
								data: result.prazo
							}]
						});						

					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function totalRequisicoesSeveridade(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalRequisicoesSeveridade';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaRequisicoesSeveridade',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'	   : periodo,
				'acumulado'    : acumulado				
			},
			beforeSend: function() {
				$('.loaderRequisicoes').show();				
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
				$('#totalRequisicoesSeveridade').append('<p>&nbsp;</p>');
				if(!modal) totalRequisicoesOrigem(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = '% de requisições abertas por severidade';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalRequisicoesSeveridade(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Severidade",
								colorByPoint: true,
								data: [{
										name: 'CRÍTICA',
										y: result.critica,
										color: '#00401A'
									  },{
										name: 'ALTA',
										y: result.alta,
										color: '#411564'
									  },{
										name: 'MÉDIA',
										y: result.media,
										color: '#5B5C65'
									  },{
										name: 'BAIXA',
										y: result.baixa,
										color: '#682D00'
									  }
								  ]
							}]
						});						

					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function totalRequisicoesOrigem(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalRequisicoesOrigem';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaRequisicoesOrigem',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderRequisicoes').show();				
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
				$('#totalRequisicoesOrigem').append('<p>&nbsp;</p>');
				if(!modal) quantidadeTotalRequisicoesServico(departamento,periodo,acumulado,false);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = '% de requisições abertas por origem';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								plotBackgroundColor: null,
								plotBorderWidth: null,
								plotShadow: false,
								type: 'pie',
								zoomType: 'xy',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalRequisicoesOrigem(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							tooltip: {
								pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
							},
							plotOptions: {
								pie: {
									allowPointSelect: true,
									cursor: 'pointer',
									dataLabels: {
										enabled: true,
										format: '<b>{point.name}</b>: {point.percentage:.2f} %',
										style: {
											color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
										}
									}
								}
							},
							series: [{
								name: "Origem",
								colorByPoint: true,
								data: [{
										name: 'Portal Web',
										y: result.PortalWeb,
										color: '#00401A'
									  },{
										name: 'Telefone',
										y: result.Telefone,
										color: '#411564'
									  },{
										name: 'Presencial',
										y: result.Presencial,
										color: '#5B5C65'
									  },{
										name: 'E-mail',
										y: result.Email,
										color: '#682D00'
									  }
								  ]
							}]
						});		
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function quantidadeTotalRequisicoesServico(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#divTabelaTotalRequisicoesServico';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=quantidadeTotalRequisicoesServico',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderRequisicoes').show();
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
				$('#divTabelaTotalRequisicoesServico').append('<p>&nbsp;</p>');
				if(!modal) quantidadeTotalRequisicoesColaborador(departamento,periodo,acumulado,false);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = 'Qtde. de Requisições Abertas por Serviços - TOP 10';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											quantidadeTotalRequisicoesServico(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							xAxis: {
								categories: result.servicos,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Requisições'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#F47920',
								name: 'Quantidade',
								data: result.resultados

							}]
						});
						
					}else{
										
						$('#divTabelaTotalRequisicoesServico').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function quantidadeTotalRequisicoesColaborador(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#divTabelaTotalRequisicoesColaborador';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=quantidadeTotalRequisicoesColaborador',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},			
			beforeSend: function() {
				$('.loaderRequisicoes').show();				
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
				$('#divTabelaTotalRequisicoesColaborador').append('<p>&nbsp;</p>');
				if(!modal) requisicoesAbertos(departamento);	
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
					
						var titulo = 'Qtde. de Requisições Abertas por Colaborador - TOP 10';
						
						if(acumulado == 0){
							titulo += ' - ' + result.mes;
						}else{
							titulo += ' - Acumulado';
						}
						
						$(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											quantidadeTotalRequisicoesColaborador(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: titulo
							},
							xAxis: {
								categories: result.colaborador,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Requisições'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#F47920',
								name: 'Quantidade',
								data: result.resultados

							}]
						});
						
					}else{
										
						$('#divTabelaTotalRequisicoesColaborador').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function requisicoesAbertos(departamento){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=requisicoesAbertos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento	
			},			
			beforeSend: function() {
				$('.loaderRequisicoes').show();				
			},
			complete: function() {
				$('.loaderRequisicoes').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaRequisicoesAbertos').html(result.tabela);
						
						var table = $('#tabelaRequisicoesAbertos').DataTable({        
									"language": {
												"lengthMenu": "_MENU_ Registros por página",
												"zeroRecords": "Nenhum registro encontrado",
												"info": "Página _PAGE_ de _PAGES_",
												"infoEmpty": "Nenhum registro encontrado",
												"infoFiltered": "(Filtrado de um total de _MAX_ registros)",
												"search": "Buscar:"
											}
									});							
								
						table.on( 'draw', function () {
							var body = $( table.table().body() );
					 
							body.unhighlight();
							body.highlight( table.search() );  
						});
						
					}else{
										
						$('#divTabelaRequisicoesAbertos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function totalDesenvolvimentos(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalDesenvolvimentos';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaDesenvolvimentos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderDesenvolvimentos').show();
			},
			complete: function() {
				$('.loaderDesenvolvimentos').hide();
				$('#totalDesenvolvimentos').append('<p>&nbsp;</p>');
				if(!modal) totalDesenvolvimentosPrazo(departamento,periodo,acumulado,false);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
					   $(div).highcharts({
							chart: {
								type: 'column',
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalDesenvolvimentos(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: 'Quantidade Total de Desenvolvimentos'
							},
							xAxis: {
								categories: result.meses,
								crosshair: true
							},
							yAxis: {
								min: 0,
								title: {
									text: 'Nº Desenvolvimentos'
								}
							},
							tooltip: {
								headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
								pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
									'<td style="padding:0"><b>{point.y:1f}</b></td></tr>',
								footerFormat: '</table>',
								shared: true,
								useHTML: true
							},
							plotOptions: {
								column: {
									pointPadding: 0.1,
									borderWidth: 0,
									dataLabels: {
										enabled: true
									}
								}
							},
							series: [{
								color: '#A3238E',
								name: 'Qtde Abertos',
								data: result.abertos

							}, {
								color: '#C4CBCF',
								name: 'Qtde Encerrados',
								data: result.encerrados

							}]
						});						
						
					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function totalDesenvolvimentosPrazo(departamento,periodo,acumulado,modal){
		
		var div = '';
		
		if(!modal){
			div = '#totalDesenvolvimentosPrazo';
		}else{
			div = '#graficoModalGenerico';
		}
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaDesenvolvimentosPrazo',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},
			beforeSend: function() {
				$('.loaderDesenvolvimentos').show();				
			},
			complete: function() {
				$('.loaderDesenvolvimentos').hide();
				$('#totalDesenvolvimentosPrazo').append('<p>&nbsp;</p>');
				if(!modal) quantidadeTotalDesenvolvimentosServico(departamento,periodo,acumulado);				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$(div).highcharts({
							chart: {
								events:{
									click: function(e) {
										if(!modal){
											$('#graficoModalGenerico').html('');
											totalDesenvolvimentosPrazo(departamento,periodo,acumulado,true);			
											$('#dialog-generico').on('shown',function(){}).modal();
										}
									}		
								}
							},
							title: {
								text: '% Total de Desenvolvimentos no Prazo',
								x: -20 //center
							},
							xAxis: {
								categories: result.meses
							},
							yAxis: {
								title: {
									text: 'Valores %'
								},								
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}],
								min: -25,
								max: 125
							},
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'middle',
								borderWidth: 0
							},
							plotOptions: {
								line: {
									dataLabels: {
										enabled: true,
										formatter: function() {
											return this.point.y + ' %';
										}										
									}
																		
								}
							},							
							series: [{
								color: '#A3238E',
								name: 'No Prazo',
								data: result.prazo
							}]
						});						

					}else{
										

						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function quantidadeTotalDesenvolvimentosServico(departamento,periodo,acumulado){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=quantidadeTotalDesenvolvimentosServico',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado
			},			
			beforeSend: function() {
				$('.loaderDesenvolvimentos').show();				
			},
			complete: function() {
				$('.loaderDesenvolvimentos').hide();
				$('#divTabelaTotalDesenvolvimentosServico').append('<p>&nbsp;</p>');
				quantidadeTotalDesenvolvimentosColaborador(departamento,periodo,acumulado);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaTotalDesenvolvimentosServico').html(result.tabela);
						
						        $('#tabelaTotalDesenvolvimentosServico').DataTable({
										  "paging": false,
										  "lengthChange": false,
										  "searching": false,
										  "ordering": true,
										  "info": false,
										  "autoWidth": false,
										  "order": [[ 1, "desc" ]]
								});
						
					}else{
										
						$('#divTabelaTotalDesenvolvimentosServico').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function quantidadeTotalDesenvolvimentosColaborador(departamento,periodo,acumulado){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=quantidadeTotalDesenvolvimentosColaborador',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'    : acumulado				
			},			
			beforeSend: function() {
				$('.loaderDesenvolvimentos').show();				
			},
			complete: function() {
				$('.loaderDesenvolvimentos').hide();
				$('#divTabelaTotalDesenvolvimentosColaborador').append('<p>&nbsp;</p>');
				desenvolvimentosAbertos(departamento,periodo,acumulado);	
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaTotalDesenvolvimentosColaborador').html(result.tabela);
						
						$('#tabelaTotalDesenvolvimentosColaborador').DataTable({
									  "paging": false,
									  "lengthChange": false,
									  "searching": false,
									  "ordering": true,
									  "info": false,
									  "autoWidth": false,
									  "order": [[ 1, "desc" ]]
									});						
						
					}else{
										
						$('#divTabelaTotalDesenvolvimentosColaborador').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function desenvolvimentosAbertos(departamento,periodo,acumulado){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=desenvolvimentosAbertos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento	
			},			
			beforeSend: function() {
				$('.loaderDesenvolvimentos').show();				
			},
			complete: function() {
				$('.loaderDesenvolvimentos').hide();
				desenvolvimentosEncerrados(departamento,periodo,acumulado);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaDesenvolvimentosAbertos').html(result.tabela);
						
						var table = $('#tabelaDesenvolvimentosAbertos').DataTable({        
									"language": {
												"lengthMenu": "_MENU_ Registros por página",
												"zeroRecords": "Nenhum registro encontrado",
												"info": "Página _PAGE_ de _PAGES_",
												"infoEmpty": "Nenhum registro encontrado",
												"infoFiltered": "(Filtrado de um total de _MAX_ registros)",
												"search" : "Buscar:"
												}
									});

						table.on( 'draw', function () {
									var body = $( table.table().body() );
							 
									body.unhighlight();
									body.highlight( table.search() );  
								});
						
					}else{
										
						$('#divTabelaDesenvolvimentosAbertos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function desenvolvimentosEncerrados(departamento,periodo,acumulado){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=desenvolvimentosEncerrados',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo,
				'acumulado'	   : acumulado
			},			
			beforeSend: function() {
				$('.loaderDesenvolvimentos').show();				
			},
			complete: function() {
				$('.loaderDesenvolvimentos').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabelaDesenvolvimentosEncerrados').html(result.tabela);
						
						var table = $('#tabelaDesenvolvimentosEncerrados').DataTable({        
									"language": {
												"lengthMenu": "_MENU_ Registros por página",
												"zeroRecords": "Nenhum registro encontrado",
												"info": "Página _PAGE_ de _PAGES_",
												"infoEmpty": "Nenhum registro encontrado",
												"infoFiltered": "(Filtrado de um total de _MAX_ registros)",
												"search" : "Buscar:"
											}
									});	

						table.on( 'draw', function () {
									var body = $( table.table().body() );
							 
									body.unhighlight();
									body.highlight( table.search() );  
								});
						
					}else{
										
						$('#divTabelaDesenvolvimentosEncerrados').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}	
	
	function buscaProjetos(departamento,periodo){
		
		$.ajax({
			url: 'ajax/relatorio.php?acao=buscaProjetos',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'departamento' : departamento,
				'periodo'      : periodo
			},
			beforeSend: function() {
				$('.loaderProjetos').show();				
			},
			complete: function() {
				$('.loaderProjetos').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				
				if(result != null){
					
					if(result.ok == 1){
						
						console.log(result);
						
						$('#divProjetos').html(result.tabela);
						
					}else{
										
						$('#divProjetos').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}

	function consultar(){
		
		console.log($('#periodo').val());
		console.log($('#acumulado').prop("checked"));
		
		
		//alert('Coming Soon!!!!');
		
		var departamento = $('#departamentoConsulta').val();
		var periodo      = $('#periodo').val();
		var acumulado;
		
		if($('#acumulado').prop("checked") == true){
			acumulado = 1;
		}else{
			acumulado = 0;
		}

		if(departamento == ''){
			exibeErro('<p>Selecione um Departamento</p>');
			$('#departamentoConsulta').focus();						
		}else if(periodo == ''){
			exibeErro('<p>Selecione um período</p>');
			$('#departamentoConsulta').focus();
		}else if(!$('#processoIndicentes').prop("checked") && !$('#processoRequisicoes').prop("checked") && !$('#processoDesenvolvimentos').prop("checked") && !$('#checkProjetos').prop("checked")){
			exibeErro('<p>Selecione pelo menos um TIPO</p>');
		}else{
			limpaDivs();			
			$('#divRelatorioIncidentes').hide();
			$('#divRelatorioRequisicoes').hide();
			$('#divRelatorioDesenvolvimentos').hide();
			$('#divRelatorioProjetos').hide();
			if($('#processoIndicentes').prop("checked")){
				$('#divRelatorioIncidentes').show();
				totalIncidentes(departamento,periodo,acumulado,false);
			}
			if($('#processoRequisicoes').prop("checked")){
				$('#divRelatorioRequisicoes').show();
				totalRequisicoes(departamento,periodo,acumulado,false);
			}
			if($('#processoDesenvolvimentos').prop("checked")){
				$('#divRelatorioDesenvolvimentos').show();
				totalDesenvolvimentos(departamento,periodo,acumulado,false);
			}
			if($('#checkProjetos').prop("checked")){
				$('#divRelatorioProjetos').show();
				buscaProjetos(departamento,periodo);
			}			
		}
		
	}
	
	montaDepartamento();
	
</script>	  

<?php include("inc/rodape.php"); ?>

