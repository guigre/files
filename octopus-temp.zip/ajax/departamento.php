<?php
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/Departamentos.class.php");
session_start();

//$_GET['acao'] = 'buscaDepartamento';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaDepartamentos'){
	listaDepartamentos();
}else if($_GET['acao']  == 'buscaDepartamento'){
	buscaDepartamento();
}else if($_GET['acao']  == 'desativaDepartamento'){
	desativaDepartamento();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$codigo    = $_POST['codigoCadastro'];
	$descricao = $_POST['descricaoCadastro'];
	
	/*$codigo = "";
	$descricao = "Departamento Teste";*/

	$departamento = new Departamentos();
	
	if($codigo == ""){ // Cadastra
		if(!$departamento->existeDepartamento($descricao)){
			if($departamento->cadastraDepartamento($descricao)){
				$ok = 1;
				$msg = "Departamentos Cadastrado com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao cadastrar o departamento, verificar com o Administrador do sistema.";
			}
		}else{
			$msg = "Este departamento já existe no sistema.";
			$ok = 0;	
		}
	}else{ // Atualiza
		if($departamento->atualizaDepartamento($codigo,$descricao)){
			$ok = 1;
			$msg = "Departamento Atualizado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao atualizar o departamento, verificar com o Administrador do sistema.";			
		}
	}	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaDepartamentos(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$tabela = "";
	
	$departamento = new Departamentos();
	
	$departamentos = $departamento->listaDepartamentos();
	
	$tabela .= "<table id='tabelaDepartamentos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>C&oacute;digo</th>
                        <th>Departamentos</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($departamentos as $dados){
	
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaDepartamento(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 7;	
		
    $departamento = new Departamentos();
	
	$dados = $departamento->buscaDepartamento($codigo);	
	
	if($dados){		
		$retorno['codigo']    = $departamento->codigo;
		$retorno['descricao'] = utf8_encode($departamento->descricao);
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);		
	
}

function desativaDepartamento(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 1;	
		
    $departamento = new Departamentos();
	
	$dados = $departamento->desativaDepartamento($codigo);		
	
	if($dados){		
		$msg = "Departamento Excluído com Sucesso!";
		$ok = 1;		
	}else{
		$msg = "Problemas ao excluir o departamento, verificar com o Administrador do sistema.";
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}
?>