<?php
set_time_limit(240);
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/RelatoriosSA.class.php");
session_start();

//Math.round(number).toFixed(2);
//$_GET['acao'] = 'consultasPadrao';

if($_GET['acao']  == 'consultasPadrao'){
	consultasPadrao();
}

function mesDescricao($mes){
	
	$mesDescricao = "";
	
	switch ($mes) {
		case 1:
			$mesDescricao = "Janeiro";
			break;
		case 2:
			$mesDescricao = "Fevereiro";
			break;
		case 3:
			$mesDescricao = "Março";
			break;
		case 4:
			$mesDescricao = "Abril";
			break;
		case 5:
			$mesDescricao = "Maio";
			break;
		case 6:
			$mesDescricao = "Junho";
			break;
		case 7:
			$mesDescricao = "Julho";
			break;
		case 8:
			$mesDescricao = "Agosto";
			break;
		case 9:
			$mesDescricao = "Setembro";
			break;
		case 10:
			$mesDescricao = "Outubro";
			break;
		case 11:
			$mesDescricao = "Novembro";
			break;
		case 12:
			$mesDescricao = "Dezembro";
			break;			
	}
	
	return $mesDescricao;
	
}

function consultasPadrao(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$prestador   = $_POST['prestador'];
	$dataInicial = $_POST['dataInicial'];
	$dataFinal   = $_POST['dataFinal'];
	
	/*$prestador   = 2920000023;
	$dataInicial = "01/09/2015";
	$dataFinal   = "30/09/2015";	*/
	
	$relatorio = new RelatoriosSA();
	
	$resultado = $relatorio->consultasPadrao($prestador,$dataInicial,$dataFinal);
	
	$tabela .= "<h3>Consultas Pradrao</h3>
	            <table id='tabelaConsultasPadrao' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Guia</th>
                        <th>Cartao</th>
                        <th>Nome</th>
                        <th>Dt.Nasc.</th>
                        <th>Cod.Prest.Exec.</th>
                        <th>Nome Prest.Exec.</th>
                        <th>Cod.Item</th>
                        <th>Desc.Item</th>
                        <th>Dt.Entrada</th>
                        <th>Dt.Finalizacao</th>                        
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($resultado as $key => $dados){
		
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
                       <td>".$dados[5]."</td>
                       <td>".$dados[6]."</td>
                       <td>".$dados[7]."</td>
                       <td>".$dados[8]."</td>
                       <td>".$dados[9]."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	
	
	/*print "<pre>";
	print_r($resultado);
	print "</pre>";*/
	
	$retorno['tabela'] = utf8_encode($tabela);
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	//$retorno['total']  = $resultado;
	echo json_encode($retorno);
}

?>