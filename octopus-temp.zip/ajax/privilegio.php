<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Privilegios.class.php");
session_start();

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaPrivilegios'){
	listaPrivilegios();
}else if($_GET['acao']  == 'montaUsuarios'){
	montaUsuarios();
}else if($_GET['acao']  == 'montaPrivilegios'){
	montaPrivilegios();
}else if($_GET['acao']  == 'excluiPrivilegio'){
	excluiPrivilegio();
}

function montaUsuarios(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$usuarios = $_SESSION['lista_nome_usuarios'];
	
	$select .= "<select class='form-control select2' multiple='multiple' data-placeholder='Selecione o Usuário' style='width:100%;' id='loginCadastro'>";
	
	foreach($usuarios as $key => $dados){
	
		$select .= "<option value=$key>$dados</option>";
		$ok = 1;
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

function montaPrivilegios(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	//var_dump(utf8_encode(MENUS));
	
	$menus = explode(",",utf8_encode(MENUS));
	
	$select .= "<select class='form-control select2' multiple='multiple' data-placeholder='Selecione o Privilégio' style='width:100%;' id='privilegioCadastro'>";
	
	foreach($menus as $dados){
	
		$select .= "<option value='$dados'>$dados</option>";
		$ok = 1;
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$todoslogins      = $_POST['loginCadastro'];
	$todosprivilegios = $_POST['privilegioCadastro'];
	
	//$todoslogins      = array('aluzzi');
	//$todosprivilegios = array('Sistema Antendimento');
	
	$ok = 1;
	$msg = "Privilégio Cadastrado com Sucesso!";
	
	foreach($todoslogins as $login){
	
		foreach($todosprivilegios as $privilegio){
		
			$privilegios = new Privilegios();
	
			if(!$privilegios->existePrivilegio($login, $privilegio)){
				
				if(!$privilegios->cadastraPrivilegio($login,$privilegio)){
					$ok = 0;
					$msg = "Problemas ao cadastrar o privilégio, verificar com o Administrador do sistema.";
					break;
				}
			}
		}
	}
	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaPrivilegios(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$privilegio = new Privilegios();
	
	$privilegios = $privilegio->listaPrivilegios();
	
	$tabela .= "<table id='tabelaPrivilegios' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Login</th>
                        <th>Menu</th>
                        <th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($privilegios as $dados){
	
		$login = $dados[0];
		$menu = $dados[1];
		
		$tabela .= "<tr>
                       <td>$login</td>
                       <td>$menu</td>
					   <td><button type='button' class='btn btn-danger btn-xs' onclick='javascript:void(confirmacao(\"$login\",\"$menu\"))'>Excluir</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}


function excluiPrivilegio(){
	$ok = 0;
	$msg = "";
	
	$login = $_POST['login'];
	$menu  = $_POST['menu'];
	
	$ok = 1;
	$msg = "Privilégio Excluído com Sucesso!";
	
	$privilegios = new Privilegios();
	
	if($privilegios->existePrivilegio($login, $menu)){
				
		if(!$privilegios->excluiPrivilegio($login, $menu)){
			$ok = 0;
			$msg = "Problemas ao excluir o privilégio, verificar com o Administrador do sistema.";
		}
	}
	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}
?>