<?php
	/*ini_set('display_errors', "on");
	ini_set('error_reporting', E_ALL & ~E_NOTICE);*/
	include_once '../sms/human_gateway_client_api/HumanClientMain.php';
	session_start();

	//$_GET['acao'] = 'enviar';

	if($_GET['acao']  == 'enviar'){
		envia();
	}
	
function envia(){
	
	$retorno = array();
	$results = array();
	
	$data          = $_POST['data'];
	$mensagemEnvio = utf8_decode($_POST['mensagemEnvio']);
	
	// Instancia multiplo envio com conta e senha da Unimed
	$humanMultipleSend = new HumanMultipleSend("unimedvtrp.hg", "csnyzc");
	
	// Montar Lista no lay-out B
	$msg_list = '';
	foreach ($data as $lista){
	
		foreach($lista as $numero){
			$msg_list .= "55".$numero.";".$mensagemEnvio.";Unimed VTRP\n";
		}
	}
	
	// Faz a chamada usando lay-out B
	$response = $humanMultipleSend->sendMultipleList(HumanMultipleSend::TYPE_B, $msg_list);

	foreach ($response as $resp) {
		
		array_push($results, $resp->getCode() . " - " . $resp->getMessage());
	}
	
	$retorno['envioMsg'] = $results;
	echo json_encode($retorno);
}

	
	

	
?>