<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Indicadores.class.php");
session_start();

//$_GET['acao'] = 'montaResponsavel';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaIndicadores'){
	listaIndicadores();
}else if($_GET['acao']  == 'buscaIndicador'){
	buscaIndicador();
}else if($_GET['acao']  == 'desativaIndicador'){
	desativaIndicador();
}else if($_GET['acao']  == 'montaResponsavel'){
	montaResponsavel();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$codigo        = $_POST['codigoCadastro'];
	$indicadorCad  = $_POST['indicadorCadastro'];
	$classificacao = $_POST['classificacaoCadastro'];
	$grupo         = $_POST['grupoCadastro'];
	$periodicidade = $_POST['periodCadastro'];
	$responsavel   = $_POST['responsavelCadastro'];
	$tipo          = $_POST['tipoCadastro'];
	$forma_calculo = $_POST['formaCalculoCadastro'];
	$origem        = $_POST['origemCadastro'];
	$observacao    = $_POST['observacaoCadastro'];
	
	/*$codigo        = "";	
	$indicadorCad  = "Indicador Teste";
	$classificacao = "Classificação Teste";
	$grupo         = "Grupo Teste";
	$periodicidade = "Periodicidade Teste";
	$responsavel   = 1;
	$tipo          = "Tipo Teste";
	$forma_calculo = "Forma Teste";
	$origem        = "Origem Teste";
	$observacao    = "Observacao Teste";*/
	
	$indicador = new Indicadores();
	
	if($codigo == ""){ // Cadastra		
		if($indicador->cadastraIndicador($indicadorCad,$classificacao,$grupo,$periodicidade,$forma_calculo,$origem,$observacao,$responsavel,$tipo)){
			$ok = 1;
			$msg = "Indicador Cadastrado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao cadastrar o indicador, verificar com o Administrador do sistema.";
		}		
	}else{ // Atualiza
		if($indicador->atualizaIndicador($codigo,$indicadorCad,$classificacao,$grupo,$periodicidade,$forma_calculo,$origem,$observacao,$responsavel,$tipo)){
			$ok = 1;
			$msg = "Indicador Atualizado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao atualizar o indicador, verificar com o Administrador do sistema.";			
		}
	}	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaIndicadores(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$indicador = new Indicadores();
	$usuario = new Usuarios();
	
	$indicadores = $indicador->listaIndicadores();
	
	$tabela .= "<table id='tabelaIndicadores' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Respons&aacute;vel</th>
                        <th>C&oacute;digo</th>
                        <th>Indicador</th>
                        <th>Classifica&ccedil;&atilde;o</th>
                        <th>Grupo</th>
                        <th>Periodicidade</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($indicadores as $dados){
		
		$usuarios = $usuario->buscaUsuario($dados[8]);
		
		$tabela .= "<tr>
                       <td>".$usuario->ds_usuario."</td>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaIndicador(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 1;	
		
    $indicador = new Indicadores();
	
	$dados = $indicador->buscaIndicador($codigo);	
	
	if($dados){		
		$retorno['codigo']        = $indicador->id;
		$retorno['indicador']     = utf8_encode($indicador->ds_indicador);
		$retorno['classificacao'] = utf8_encode($indicador->ds_classificacao);
		$retorno['grupo']         = utf8_encode($indicador->ds_grupo);
		$retorno['periodicidade'] = utf8_encode($indicador->ds_periodicidade);
		$retorno['forma_calculo'] = $indicador->ds_forma_calculo;
		$retorno['origem']        = $indicador->ds_origem;
		$retorno['observacao']    = $indicador->ds_observacao;
        $retorno['responsavel']   = $indicador->id_responsavel;
		$retorno['tipo']          = utf8_encode($indicador->ds_tipo);
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);		
	
}

function desativaIndicador(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 1;	
		
    $indicador = new Indicadores();
	
	$dados = $indicador->desativaIndicador($codigo);	
	
	if($dados){		
		$msg = "Indicador Excluído com Sucesso!";
		$ok = 1;		
	}else{
		$msg = "Problemas ao excluir o indicador, verificar com o Administrador do sistema.";
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function montaResponsavel(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$usuario = new Usuarios();
	
	$usuarios = $usuario->listaUsuarios();
	
	$select .= "<select class='form-control' id='responsavelCadastro'>
	            <option value=''>:: Selecione ::</option>";
	
	foreach($usuarios as $dados){
		
		$select .= "<option value=$dados[0]>$dados[1]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

?>