<?php
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/Cooperados.class.php");
session_start();

//$_GET['acao']  = 'listaCooperados';

if($_GET['acao']  == 'listaCooperados'){
	listaCooperados();
}

function listaCooperados(){

	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$cooperado = new Cooperados();
	
	$cooperados = $cooperado->listaCooperados('Intranet',0);
	
	//var_dump($cooperados);
	
	$tabela .= "<table id='tabelaCooperados' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>CRM</th>
                        <th>Cooperado</th>
                        <th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
				
	foreach($cooperados as $dados){
	
		$crm = $dados->{'st_cd-prestador'};
		$cooperado = $dados->{'st_nm-prestador'};
		
		$tabela .= "<tr>
                       <td>$crm</td>
                       <td>$cooperado</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(validaForm(document.acessar,\"$crm\"))'>Simular</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	//var_dump($tabela);
	
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
	
	
}
?>