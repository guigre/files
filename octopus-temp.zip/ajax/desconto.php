<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Descontos.class.php");
session_start();

//$_GET['acao'] = 'salvar';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaDescontos'){
	listaDescontos();
}else if($_GET['acao']  == 'buscaDesconto'){
	buscaDesconto();
}else if($_GET['acao']  == 'excluiDesconto'){
	excluiDesconto();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$utils = new Utils();
	
	$modalidadeCadastro     = $_POST['modalidadeCadastro'];    
    $planoCadastro          = $_POST['planoCadastro'];         
    $tipoPlanoCadastro      = $_POST['tipoPlanoCadastro'];     
    $minBenefCadastro       = $_POST['minBenefCadastro'];           
    $maxBenefCadastro       = $_POST['maxBenefCadastro'];
    $valorDescontoCadastro  = $_POST['valorDescontoCadastro'];
	$acao                   = $_POST['acao'];
    $cduserid				= $_POST['cduserid'];

	/*$modalidadeCadastro     = 7;    
    $planoCadastro          = 2;         
    $tipoPlanoCadastro      = 21;     
    $minBenefCadastro       = 1;           
    $maxBenefCadastro       = 1;
    $valorDescontoCadastro  = 1.00;
	$acao                   = "cadastrar";
    $cduserid				= "ggregory";*/
	
	$desconto = new Descontos();

	if($acao == "cadastrar"){
		
		if($desconto->cadastraDesconto($modalidadeCadastro,     
										$planoCadastro,          
										$tipoPlanoCadastro,      
										$minBenefCadastro,      
										$maxBenefCadastro,       
										$valorDescontoCadastro,  
										$cduserid)){
			$ok = 1;
			$msg = "Desconto Cadastrado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao cadastrar o desconto, verificar com o Administrador do sistema.";
		}
		
	}
	
	if($acao == "atualizar"){
		
		if($desconto->atualizaDesconto($modalidadeCadastro,     
										$planoCadastro,          
										$tipoPlanoCadastro,      
										$minBenefCadastro,      
										$maxBenefCadastro,       
										$valorDescontoCadastro,  
										$cduserid)){										 
			$ok = 1;
			$msg = "Desconto Atualizado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao atualizar o desconto, verificar com o Administrador do sistema.";			
		}		
		
	}
	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}


function listaDescontos(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$desconto = new Descontos();
	
	$desconto = $desconto->listaDescontos();
	
	/*print "<pre>";
	print_r($planos);
	print "<pre>";*/
	
	$tabela .= "<table id='tabelaDescontos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>MD</th>
                        <th>PL</th>
                        <th>TP</th>
						<th>Min Benef.</th>
						<th>Max Benef.</th>
						<th>Valor Desconto</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($desconto as $dados){
		
		//print $dados[3]."<br>";
		
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
					   <td>".(float)number_format($dados[5], 2, ".", ",")."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0].",".$dados[1].",".$dados[2].",".$dados[3].",".$dados[4]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaDesconto(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$modalidade = $_POST['modalidade'];
	$planoForm  = $_POST['plano'];
	$tipoPlano  = $_POST['tipoPlano'];
	$minBenef   = $_POST['minBenef'];
	$maxBenef   = $_POST['maxBenef'];
	
	$retorno['modalidade'] = $modalidade;
	$retorno['planoForm']  = $planoForm; 
	$retorno['tipoPlano']  = $tipoPlano; 
	$retorno['minBenef']   = $minBenef; 
	$retorno['maxBenef']   = $maxBenef;  
	
	
    $desconto = new Descontos();
	
	$dados = $desconto->buscaDesconto($modalidade,$planoForm,$tipoPlano,$minBenef,$maxBenef);	
	
	if($dados){		
		$retorno['cdmodalidade']  = $desconto->cdmodalidade;     
	    $retorno['cdplano']       = $desconto->cdplano;          
	    $retorno['cdtipoplano']   = $desconto->cdtipoplano;      
	    $retorno['nrminbenef']    = $desconto->nrminbenef;   
	    $retorno['nrmaxbenef']    = $desconto->nrmaxbenef;   
	    $retorno['vldesconto']    = $desconto->vldesconto;
	    $retorno['cduserid']      = $desconto->cduserid;        
	    $retorno['dtatualizacao'] = $desconto->dtatualizacao;
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

function excluiDesconto(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$modalidade = $_POST['modalidade'];
	$planoForm  = $_POST['plano'];
	$tipoPlano  = $_POST['tipoPlano'];
	$minBenef   = $_POST['minBenef'];
	$maxBenef   = $_POST['maxBenef'];
	
    $desconto = new Descontos();
	
	if($desconto->excluiDesconto($modalidade,$plano,$tipoPlano,$minBenef,$maxBenef)){
		$ok = 1;		
		$msg = "Desconto exclu&iacute;do com sucesso.";
	}else{
		$ok = 0;
		$msg = "N&atilde;o foi poss&iacute;vel excluir. Este desconto j&aacute; est&aacute; sendo utilizado em outro cadastro.";
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

?>