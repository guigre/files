<?php
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/Cooperados.class.php");
session_start();

//$_GET['acao']  = 'incluiSenhaCooperado';

if($_GET['acao']  == 'listaCooperados'){
	listaCooperados();
}else if($_GET['acao']  == 'alteraSenhaCooperado'){
	alteraSenhaCooperado();
}else if($_GET['acao']  == 'incluiSenhaCooperado'){
	incluiSenhaCooperado();
}

function listaCooperados(){

	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$cooperado = new Cooperados();
	
	$cooperados = $cooperado->listaCooperados('Intranet',0);
	
	//var_dump($cooperados);
	
	$tabela .= "<table id='tabelaCooperados' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>CRM</th>
                        <th>Cooperado</th>
                        <th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
				
	foreach($cooperados as $dados){
	
		$crm = $dados->{'st_cd-prestador'};
		$nomeCoop = $dados->{'st_nm-prestador'};
		$email = $dados->{'st_nm-email'};
		$cpf = $dados->{'st_nr-cgc-cpf'};
		$dataNascimento = $dados->{'st_dt-nascimento'};
		$idPessoa = $dados->{'st_id-pessoa'};
		
		$nrLoginsOracle = $cooperado->numeroLoginsCooperado($crm);
		
		if($nrLoginsOracle == 0){
			$tabela .= "<tr>
				   <td>$crm</td>
				   <td>$nomeCoop</td>
				   <td>
						<button type='button' class='btn btn-primary btn-xs' onclick='javascript:void(validaForm(document.acessar,\"$crm\"))'>Simular</button>
						<button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(incluiAlteraSenha(\"1\",\"$nomeCoop\",\"$crm\",\"$email\",\"$cpf\",\"$dataNascimento\",\"$idPessoa\"))'>Incluir senha</button>
				   </td>
				</tr>";
		}else{
			$tabela .= "<tr>
				   <td>$crm</td>
				   <td>$nomeCoop</td>
				   <td>
						<button type='button' class='btn btn-primary btn-xs' onclick='javascript:void(validaForm(document.acessar,\"$crm\"))'>Simular</button>
						<button type='button' class='btn btn-success btn-xs' onclick='javascript:void(incluiAlteraSenha(\"2\",\"$nomeCoop\",\"$crm\",\"$email\",\"$cpf\",\"$dataNascimento\",\"$idPessoa\"))'>Alterar senha</button>
				   </td>
				</tr>";
		}
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	//var_dump($tabela);
	
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
	
	
}

function incluiSenhaCooperado(){

	$utils = new Utils();
	
	$crm = $_POST['crm'];
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$cpf = $_POST['cpf'];
	$dataNascimento = $utils->formata_data($_POST['dataNascimento']);
	$idPessoa = $_POST['idPessoa'];
	$novaSenhaCooperado = $_POST['novaSenhaCooperado'];
	
	/*$crm = 99999999;
	$nome = 'DIEGO MULLER';
	$email = 'diego.muller@unimedvtrp.com.br';
	$cpf = '00610647008';
	$dataNascimento = '24/06/1985';
	$idPessoa = '123456';
	$novaSenhaCooperado = 'teste';*/
	
	$cooperado = new Cooperados();
	
	$cooperados = $cooperado->incluiSenhaCooperado($crm, $nome, $email, $cpf, $dataNascimento, $idPessoa, $novaSenhaCooperado);
	
	if($cooperados){
		$retorno['ok'] = 1;
	}else{
		$retorno['ok'] = 0;
	}
	
	echo json_encode($retorno);
}

function alteraSenhaCooperado(){

	$crm = $_POST['crm'];
	$novaSenhaCooperado = $_POST['novaSenhaCooperado'];
	
	$cooperado = new Cooperados();
	
	$cooperados = $cooperado->alteraSenhaCooperado($crm,$novaSenhaCooperado);
	//$cooperados = $cooperado->alteraSenhaCooperado(3220,'senhanova');
	
	if($cooperados){
		$retorno['ok'] = 1;
	}else{
		$retorno['ok'] = 0;
	}
	
	echo json_encode($retorno);
}
?>