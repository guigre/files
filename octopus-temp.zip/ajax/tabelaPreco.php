<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/TabelaPreco.class.php");
session_start();

//$_GET['acao'] = 'listaTabelasPreco';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaTabelasPreco'){
	listaTabelasPreco();
}else if($_GET['acao']  == 'buscaTabelaPreco'){
	buscaTabelaPreco();
}else if($_GET['acao']  == 'excluiTabelaPreco'){
	excluiTabelaPreco();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$utils = new Utils();
	
	$codigoTabelaPrecoCadastro    = $_POST['codigoTabelaPrecoCadastro'];    
    $descricaoTabelaPrecoCadastro = $_POST['descricaoTabelaPrecoCadastro'];
    $inicioCadastro               = $utils->data_mysql($_POST['inicioCadastro']);        
    $fimCadastro                  = $utils->data_mysql($_POST['fimCadastro']);           
    $cduserid				      = $_POST['cduserid'];
    $acao                         = $_POST['acao'];
	
	$tabelaPreco = new TabelaPreco();
	
	if($acao == "cadastrar"){		
			
		if(strtotime($inicioCadastro) > strtotime($fimCadastro)){
			$ok = 0;
			$mes = "Data Inicial maior que a Data Final.";
		}else{

			$inicioCadastro = $utils->formata_data($inicioCadastro);
			$fimCadastro = $utils->formata_data($fimCadastro);			
			
			if($tabelaPreco->cadastraTabelaPreco($codigoTabelaPrecoCadastro,    
									             $descricaoTabelaPrecoCadastro,     
									             $inicioCadastro,        
									             $fimCadastro,
									             $cduserid)){
				$ok = 1;
				$msg = "Tabela de Pre&ccedil;o Cadastrada com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao cadastrar a tabela de pre&ccedil;o, verificar com o Administrador do sistema.";
			}		
		
		}
		
	}	
	
	if($acao == "atualizar"){
		
		if(strtotime($inicioCadastro) > strtotime($fimCadastro)){
			$ok = 0;
			$mes = "Data Inicial maior que a Data Final.";
		}else{		
			$inicioCadastro = $utils->formata_data($inicioCadastro);
			$fimCadastro = $utils->formata_data($fimCadastro);			
		
			if($tabelaPreco->atualizaTabelaPreco($codigoTabelaPrecoCadastro,    
									             $descricaoTabelaPrecoCadastro,     
									             $inicioCadastro,        
									             $fimCadastro,
									             $cduserid)){
				$ok = 1;
				$msg = "Tabela de Pre&ccedil;o Atualizada com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao atualizar a tabela de pre&ccedil;o, verificar com o Administrador do sistema.";			
			}
		
		}
	}
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaTabelasPreco(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$tabelaPreco = new TabelaPreco();
	
	$tabelas = $tabelaPreco->listaTabelasPreco();
	
	$tabela = "<table id='tabelaPreco' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>C&oacute;digo Tabela</th>
                        <th>Descri&ccedil;&atilde;o</th>
						<th>In&iacute;cio</th>
						<th>Fim</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($tabelas as $dados){
		
		//print $dados[3]."<br>";
		
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(\"".$dados[0]."\"))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaTabelaPreco(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$cdtabpreco = $_POST['cdtabpreco'];
	
    $tabelaPreco = new TabelaPreco();
	
	$dados = $tabelaPreco->buscaTabelaPreco($cdtabpreco);	
	
	if($dados){		
		$retorno['cdtabpreco']    = $tabelaPreco->cdtabpreco;     
	    $retorno['dstabpreco']    = $tabelaPreco->dstabpreco;
	    $retorno['dtinicio']      = $tabelaPreco->dtinicio;   
	    $retorno['dtfim']         = $tabelaPreco->dtfim;      
	    $retorno['cduserid']      = $tabelaPreco->cduserid;        
	    $retorno['dtatualizacao'] = $tabelaPreco->dtatualizacao;
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

function excluiTabelaPreco(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$cdtabpreco = $_POST['cdtabpreco'];
	
    $tabelaPreco = new TabelaPreco();
	
	if($tabelaPreco->excluiTabelaPreco($cdtabpreco)){
		$ok = 1;		
		$msg = "Tabela de pre&ccedil;o exclu&iacute;da com sucesso.";
	}else{
		$ok = 0;
		$msg = "N?o foi poss&iacute;vel excluir a tabela de pre&ccedil;o. Ela est&aacute; sendo utilizada por registro.";
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

?>