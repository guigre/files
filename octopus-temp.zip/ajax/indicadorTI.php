<?php
//error_reporting(E_ALL  ^ E_NOTICE);
//ini_set('display_errors','On');
set_time_limit(240);
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/IndicadoresTI.class.php");
session_start();

//Math.round(number).toFixed(2);
//$_GET['acao'] = 'graficoTotalIncidentesSeveridade';

if($_GET['acao']  == 'total'){
	total();
}else if($_GET['acao']  == 'totalEncerrados'){
	totalEncerrados();
}else if($_GET['acao']  == 'totalReqEncerradas'){
	totalReqEncerradas();
}else if($_GET['acao']  == 'graficoTotal'){
	graficoTotal();
}else if($_GET['acao']  == 'graficoTotalIncidentesPrazo'){
	graficoTotalIncidentesPrazo();
}else if($_GET['acao']  == 'graficoTotalIncidentesPrazoRespostaSolucao'){
	graficoTotalIncidentesPrazoRespostaSolucao();
}else if($_GET['acao']  == 'graficoTotalIncidentesReabertos'){
	graficoTotalIncidentesReabertos();
}else if($_GET['acao']  == 'graficoTotalIncidentesNivel'){
	graficoTotalIncidentesNivel();
}else if($_GET['acao']  == 'graficoTotalIncidentesSeveridade'){
	graficoTotalIncidentesSeveridade();
}else if($_GET['acao']  == 'graficoTotalIncidentesMaiores90'){
	graficoTotalIncidentesMaiores90();
}else if($_GET['acao']  == 'graficoTotalIncidentesBacklog'){
	graficoTotalIncidentesBacklog();
}else if($_GET['acao']  == 'graficoTotalIncidentesServico'){
	graficoTotalIncidentesServico();
}else if($_GET['acao']  == 'graficoTotalIncidentesServicoAnual'){
	graficoTotalIncidentesServicoAnual();
}else if($_GET['acao']  == 'graficoDocumentosPPR'){
	graficoDocumentosPPR();
}else if($_GET['acao']  == 'percentualFinalPPR'){
	percentualFinalPPR();
}else if($_GET['acao']  == 'graficoPrazoSolicitacaoDemandas'){
	graficoPrazoSolicitacaoDemandas();
}else if($_GET['acao']  == 'prazoSolicitacaoDemandas'){
	prazoSolicitacaoDemandas();
}else if($_GET['acao']  == 'percentualProjetos'){
	percentualProjetos();
}else if($_GET['acao']  == 'graficoPercentualRequisicoesPrazo'){
	graficoPercentualRequisicoesPrazo();
}else if($_GET['acao']  == 'graficoPercentualReqPrazoTipo'){
	graficoPercentualReqPrazoTipo();
}else if($_GET['acao']  == 'graficoQtdeReqEncerTipoNivel'){
	graficoQtdeReqEncerTipoNivel();
}else if($_GET['acao']  == 'graficoRequisicoesAbertasTipo'){
	graficoRequisicoesAbertasTipo();
}else if($_GET['acao']  == 'graficoRequisicoesEncerradasTipo'){
	graficoRequisicoesEncerradasTipo();
}else if($_GET['acao']  == 'graficoPercRequisicoesAbertasTipo'){
	graficoPercRequisicoesAbertasTipo();
}else if($_GET['acao']  == 'graficoPercRequisicoesEncerradasTipo'){
	graficoPercRequisicoesEncerradasTipo();
}else if($_GET['acao']  == 'graficoRequisicoesReabertas'){
	graficoRequisicoesReabertas();
}else if($_GET['acao']  == 'graficoRequisicoesAbertasServico'){
	graficoRequisicoesAbertasServico();
}else if($_GET['acao']  == 'graficoRequisicoesEncerradasNivel'){
	graficoRequisicoesEncerradasNivel();
}else if($_GET['acao']  == 'graficoPercReqEncerTipoNivel'){
	graficoPercReqEncerTipoNivel();
}else if($_GET['acao']  == 'graficoTotalRequisicoesMaiores90'){
	graficoTotalRequisicoesMaiores90();
}else if($_GET['acao']  == 'graficoTotalRequisicoesBacklog'){
	graficoTotalRequisicoesBacklog();
}else if($_GET['acao']  == 'graficoTotalDesenvolvimentosPrazo'){
	graficoTotalDesenvolvimentosPrazo();
}else if($_GET['acao']  == 'graficoTotalDesenvolvimentosPrazoEFora'){
	graficoTotalDesenvolvimentosPrazoEFora();
}else if($_GET['acao']  == 'graficoTotalDesenvReagendados'){
	graficoTotalDesenvReagendados();
}else if($_GET['acao']  == 'graficoTotalIncidentesDevidoDesenv'){
	graficoTotalIncidentesDevidoDesenv();
}else if($_GET['acao']  == 'graficoTotalDesenvolvimentosBacklog'){
	graficoTotalDesenvolvimentosBacklog();
}else if($_GET['acao']  == 'graficoTotalDesenvolvimentosEtapa'){
	graficoTotalDesenvolvimentosEtapa();
}else if($_GET['acao']  == 'graficoTotalDesenvolvForaPrazoEtapa'){
	graficoTotalDesenvolvForaPrazoEtapa();
}else if($_GET['acao']  == 'graficoTotalDesenvolvForaPrazoResp'){
	graficoTotalDesenvolvForaPrazoResp();
}else if($_GET['acao']  == 'graficoTotalDesenvolvForaPrazoDias'){
	graficoTotalDesenvolvForaPrazoDias();
}

function mesDescricao($mes){
	
	$mesDescricao = "";
	
	switch ($mes) {
		case 1:
			$mesDescricao = "Janeiro";
			break;
		case 2:
			$mesDescricao = "Fevereiro";
			break;
		case 3:
			$mesDescricao = "Março";
			break;
		case 4:
			$mesDescricao = "Abril";
			break;
		case 5:
			$mesDescricao = "Maio";
			break;
		case 6:
			$mesDescricao = "Junho";
			break;
		case 7:
			$mesDescricao = "Julho";
			break;
		case 8:
			$mesDescricao = "Agosto";
			break;
		case 9:
			$mesDescricao = "Setembro";
			break;
		case 10:
			$mesDescricao = "Outubro";
			break;
		case 11:
			$mesDescricao = "Novembro";
			break;
		case 12:
			$mesDescricao = "Dezembro";
			break;			
	}
	
	return $mesDescricao;
	
}

function total(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicador = 120;
	$ano = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->total($indicador,$ano);
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['total']  = $resultado;
	echo json_encode($retorno);
}

function totalEncerrados(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$prazo     = $_POST['prazo'];
	
	/*$indicador = 37;
	$ano = 2015;
	$prazo = "Fora Prazo";*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->totalEncerrados($indicador,$ano,$prazo);
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['total']  = $resultado;
	echo json_encode($retorno);
}

function totalReqEncerradas(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$prazo     = $_POST['prazo'];
	
	/*$indicador = 37;
	$ano = 2015;
	$prazo = "Fora Prazo";*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->totalReqEncerradas($indicador,$ano,$prazo);
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['total']  = $resultado;
	echo json_encode($retorno);
}

function totalRequisicoesEncerradasPrazo(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicador = 76;
	$ano = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->totalRequisicoesEncerradasPrazo($indicador,$ano);
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['total']  = $resultado;
	echo json_encode($retorno);
}


function graficoTotal(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$valorAnterior = array();
	$valorAtual = array();
	$meses = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$anoAtual     = $_POST['ano'];
	$anoAnterior  = $_POST['ano'] - 1;
	
	/*$indicadorPar = 80;
	$anoAtual     = 2015;
	$anoAnterior  = 2014;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadorAtual    = $indicador->graficoTotal($indicadorPar,$anoAtual); /* --- Busca Incidentes Ano da Seleção --- */
	$indicadorAnterior = $indicador->graficoTotal($indicadorPar,$anoAnterior); /* --- Busca Incidentes Ano Anterior da Seleção --- */
	
	$numeroMeses = count($indicadorAtual);
	
	if($numeroMeses > 0){
		
		while($i <= 12){
			
			if(count($indicadorAtual[$i]) > 0){
				array_push($valorAtual, $indicadorAtual[$i]);
			}else{
				array_push($valorAtual, 0);
			}
			if(count($indicadorAnterior[$i]) > 0){
				array_push($valorAnterior, $indicadorAnterior[$i]);
			}else{
				array_push($valorAnterior, 0);
			}			
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['valorAtual']    = $valorAtual;
		$retorno['valorAnterior'] = $valorAnterior;
		$retorno['meses']         = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesPrazo(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	/*$indicadorPar = 30;
	$ano     = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesPrazo($indicadorPar,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
	
		$meta = $indicadores[$numeroMeses]['meta'];
	
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($meta > 0){
					array_push($metas, (double)$meta);	
				}else{
					array_push($metas, $meta);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, (double)$meta);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesPrazoRespostaSolucao(){
	$ok = 0;
	$msg = "";
	$retorno   = array();
	$respostas = array();
	$solucoes  = array();
	$metas     = array();
	$meses     = array();
	$i = 1;
	
	$indicadorInicial = $_POST['indicadorInicial'];
	$indicadorFinal   = $_POST['indicadorFinal'];
	$ano              = $_POST['ano'];
	
	/*$indicadorInicial = 123;
	$indicadorFinal   = 124; 
	$ano              = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesPrazoRepostaSolucao($indicadorInicial,$indicadorFinal,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		$meta = $indicadores[$numeroMeses]['meta'];
		
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['resposta'] > 0){
					array_push($respostas, (double)str_replace(",",".",$indicadores[$i]['resposta']));	
					array_push($metas, (double)str_replace(",",".",$meta));	
				}else{
					array_push($respostas, 0);
					array_push($metas, (double)str_replace(",",".",$meta));
				}
				if($indicadores[$i]['solucao'] > 0){
					array_push($solucoes, (double)str_replace(",",".",$indicadores[$i]['solucao']));
				}else{
					array_push($solucoes, 0);
				}				
			}else{
				array_push($respostas, 0);
				array_push($solucoes, 0);
				array_push($metas, (double)str_replace(",",".",$meta));
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']     = $metas;
		$retorno['respostas'] = $respostas;
		$retorno['solucoes']  = $solucoes;
		$retorno['meses']     = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesNivel(){
	$ok = 0;
	$msg = "";
	$niveis = array();
	$valores = array();
	$retorno = array();
	
	$retorno['gestao'] = 0;
	$retorno['n1'] = 0;
	$retorno['n2infra'] = 0;
	$retorno['n2si'] = 0;
	$retorno['n3redes'] = 0;
	$retorno['n3si'] = 0;
	
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 33;
	$ano          = 2015;
	$mes          = 8;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesNivel($indicadorPar,$ano,$mes); 
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";	*/
	
	foreach($indicadores as $key => $dados){
		
		if(utf8_encode($key) == "GESTÃO"){
			$retorno['gestao'] = $dados;
		}
		if($key == "N1 - (TI)"){
			$retorno['n1'] = $dados;
		}
		if($key == "N2 - (INFRA)"){
			$retorno['n2infra'] = $dados;
		}
		if($key == "N2 - (SI)"){
			$retorno['n2si'] = $dados;
		}
		if($key == "N3 - (REDES)"){
			$retorno['n3redes'] = $dados;
		}
		if($key == "N3 - (SI)"){
			$retorno['n3si'] = $dados;
		}
		$ok = 1;
	}
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesReabertos(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$valorAnterior = array();
	$valorAtual = array();
	$meses = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$anoAtual     = $_POST['ano'];
	$anoAnterior  = $_POST['ano'] - 1;
	
	/*$indicadorPar = 28;
	$anoAtual     = 2015;
	$anoAnterior  = 2014;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadorAtual    = $indicador->graficoTotalIncidentesReabertos($indicadorPar,$anoAtual); /* --- Busca Incidentes Ano da Seleção --- */
	$indicadorAnterior = $indicador->graficoTotalIncidentesReabertos($indicadorPar,$anoAnterior); /* --- Busca Incidentes Ano Anterior da Seleção --- */
	
	$numeroMeses = count($indicadorAtual);
	
	if($numeroMeses > 0){
		
		while($i <= 12){
			
			if(count($indicadorAtual[$i]) > 0){
				array_push($valorAtual, $indicadorAtual[$i]);
			}else{
				array_push($valorAtual, 0);
			}
			if(count($indicadorAnterior[$i]) > 0){
				array_push($valorAnterior, $indicadorAnterior[$i]);
			}else{
				array_push($valorAnterior, 0);
			}			
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['valorAtual']    = $valorAtual;
		$retorno['valorAnterior'] = $valorAnterior;
		$retorno['meses']         = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesSeveridade(){
	$ok = 0;
	$msg = "";
	$niveis = array();
	$valores = array();
	$retorno = array();
	
	$retorno['critica'] = 0;
	$retorno['alta']    = 0;
	$retorno['media']   = 0;
	$retorno['baixa']   = 0;
	
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 27;
	$ano          = 2016;
	$mes          = 4;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesSeveridade($indicadorPar,$ano,$mes); 
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	foreach($indicadores as $key => $dados){
		
		if($key == "Crítica"){
			$retorno['critica'] = $dados;
		}
		if($key == "Alta"){
			$retorno['alta'] = $dados;
		}
		if($key == "Média"){
			$retorno['media'] = $dados;
		}
		if($key == "Baixa"){
			$retorno['baixa'] = $dados;
		}
		$ok = 1;
	}
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesMaiores90(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	/*$indicadorPar = 34;
	$ano          = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesMaiores90($indicadorPar,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		$meta = $indicadores[$numeroMeses]['meta'];
		
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['meta'] > 0){
					array_push($metas, (double)$meta);	
				}else{
					array_push($metas, 0);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, (double)$meta);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesBacklog(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	/*$indicadorPar = 34;
	$ano          = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesBacklog($indicadorPar,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		$meta = $indicadores[$numeroMeses]['meta'];
		
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['meta'] > 0){
					array_push($metas, (double)$meta);	
				}else{
					array_push($metas, 0);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, (double)$meta);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalIncidentesServico(){
	$ok = 0;
	$msg = "";
	$retorno   = array();
	$descricao = array();
	$valores   = array();
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 35;
	$ano          = 2015;
	$mes          = 9;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesServico($indicadorPar,$ano,$mes);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		foreach($indicadores as $key => $dados){
			array_push($descricao,$key);
			array_push($valores,$dados);
			$ok = 1;
		}
		
	}else{
		$ok = 0;		
	}
	$retorno['ok']        = $ok;
	$retorno['msg']       = ($msg);
	$retorno['descricao'] = $descricao;
	$retorno['valores']   = $valores;
	echo json_encode($retorno);
}

function graficoTotalIncidentesServicoAnual(){
	$ok = 0;
	$msg = "";
	$retorno   = array();
	$descricao = array();
	$valores   = array();
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	/*$indicadorPar = 35;
	$ano          = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesServicoAnual($indicadorPar,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		foreach($indicadores as $key => $dados){
			array_push($descricao,$key);
			array_push($valores,$dados);
			$ok = 1;
		}
		
	}else{
		$ok = 0;		
	}
	$retorno['ok']        = $ok;
	$retorno['msg']       = ($msg);
	$retorno['descricao'] = $descricao;
	$retorno['valores']   = $valores;
	echo json_encode($retorno);
}

function percentualFinalPPR(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicador = 143;
	$ano = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->percentualFinalPPR($indicador,$ano);
	
	$retorno['ok']        = $ok;
	$retorno['msg']       = ($msg);
	$retorno['resultado'] = $resultado['resultado'];
	$retorno['meta']      = $resultado['meta'];
	echo json_encode($retorno);
}

function graficoDocumentosPPR(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	/*$indicadorPar = 143;
	$ano          = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoDocumentosPPR($indicadorPar,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		while($i <= $numeroMeses){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['meta'] > 0){
					array_push($metas, (double)$indicadores[$i]['meta']);	
				}else{
					array_push($metas, 0);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, 0);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function prazoSolicitacaoDemandas(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicador = 146;
	$ano = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->prazoSolicitacaoDemandas($indicador,$ano);
	
	$retorno['ok']        = $ok;
	$retorno['msg']       = ($msg);
	$retorno['resultado'] = $resultado['resultado'];
	$retorno['meta']      = $resultado['meta'];
	echo json_encode($retorno);
}

function graficoPrazoSolicitacaoDemandas(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	/*$indicadorPar = 146;
	$ano          = 2015;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoPrazoSolicitacaoDemandas($indicadorPar,$ano);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		while($i <= $numeroMeses){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['meta'] > 0){
					array_push($metas, (double)$indicadores[$i]['meta']);	
				}else{
					array_push($metas, 0);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, 0);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function percentualProjetos(){
	$ok = 1;
	$msg = "";
	$retorno = array();
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicador = 119;
	$ano = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->percentualProjetos($indicador,$ano);
	
	$retorno['ok']        = $ok;
	$retorno['msg']       = ($msg);
	$retorno['resultado'] = $resultado['resultado'];
	$retorno['meta']      = $resultado['meta'];
	echo json_encode($retorno);
}

function graficoPercentualRequisicoesPrazo(){
	$ok            = 1;
	$msg           = "";
	$retorno       = array();
	$valorAnterior = array();
	$valorAtual    = array();
	$anos          = array();
	
	$indicador   = $_POST['indicador'];
	$anoAnterior = $_POST['ano'] - 1;
	$anoAtual    = $_POST['ano'];
	$mes         = $_POST['mes'];
	
	/*$indicador   = 69;
	$anoAnterior = 2014;
	$anoAtual    = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultadoAtual    = $indicadorTI->graficoPercentualRequisicoesPrazo($indicador,$anoAtual,$mes,"Requisicao");
	$resultadoAnterior = $indicadorTI->graficoPercentualRequisicoesPrazo($indicador,$anoAnterior,$mes,"Requisicao");
	
	foreach($resultadoAtual as $key => $dados){
		
		array_push($valorAtual,$dados);
		array_push($anos,$key);
		
	}
	foreach($resultadoAnterior as $key => $dados){
		
		array_push($valorAnterior,$dados);
		array_push($anos,$key);
		
	}	
	
	$retorno['ok']            = $ok;
	$retorno['msg']           = ($msg);
	$retorno['valorAtual']    = $valorAtual;
	$retorno['valorAnterior'] = $valorAnterior;
	echo json_encode($retorno);
}

function graficoPercentualReqPrazoTipo(){
	
	$ok = 0;
	$msg = "";
	$retorno       = array();
	$valorAtual    = array();
	$valorAnterior = array();
	$tipos         = array();
	$tipo          = array("Requisição (Acesso)","Requisição (Alteração)","Requisição (Dúvida)","Requisição (Melhoria)");
	$i             = 0;

	$indicador    = $_POST['indicador'];
	$anoAtual     = $_POST['ano'];
	$anoAnterior  = $_POST['ano'] - 1;
	$mes          = $_POST['mes'];
	
	/*$indicador   = 69;
	$anoAtual    = 2016;
	$anoAnterior = 2015;
	$mes         = 4;*/
	
	
	$indicadorTI = new IndicadoresTI();
	
	$resultadoAtual = $indicadorTI->graficoPercentualReqPrazoTipo($indicador,$anoAtual,$mes);
	$resultadoAnterior = $indicadorTI->graficoPercentualReqPrazoTipo($indicador,$anoAnterior,$mes);
	
	while($i < 4){
	
		if(count($resultadoAtual[$tipo[$i]]) > 0){
			if($resultadoAtual[$tipo[$i]] > 0){
				array_push($valorAtual, (double)str_replace(",",".",$resultadoAtual[$tipo[$i]]));
			}else{
				array_push($valorAtual, 0);
			}
		}else{
			array_push($valorAtual, 0);
		}
		
		if(count($resultadoAnterior[$tipo[$i]]) > 0){
			if($resultadoAnterior[$tipo[$i]] > 0){
				array_push($valorAnterior, (double)str_replace(",",".",$resultadoAnterior[$tipo[$i]]));	
			}else{
				array_push($valorAnterior, 0);
			}
		}else{
			array_push($valorAnterior, 0);
		}
		
		array_push($tipos,$tipo[$i]);
		$ok = 1;
		$i++;
	}
	
	$retorno['tipos']         = $tipos;
	$retorno['valorAnterior'] = $valorAnterior;
	$retorno['valorAtual']    = $valorAtual;
	$retorno['ok']            = $ok;
	$retorno['msg']           = $msg;
	echo json_encode($retorno);
}

function graficoQtdeReqEncerTipoNivel(){

	$ok = 0;
	$msg = "";
	$retorno        = array();
	$valorAcesso    = array();
	$valorAlteracao = array();
	$valorDuvida    = array();
	$valorMelhoria  = array();
	$nivel          = array();
	$tipo           = array("Requisição (Acesso)","Requisição (Alteração)","Requisição (Dúvida)","Requisição (Melhoria)");
	

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 74;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoQtdeReqEncerTipoNivel($indicador,$ano,$mes);
	
	
	foreach($resultado as $key => $dados){
	
		array_push($nivel, $key);
		
		$i = 0;
		
		while($i < 4){
		
			if(count($dados[$tipo[$i]]) > 0){
				
				if($tipo[$i] == "Requisição (Acesso)"){
					array_push($valorAcesso, (double)$dados[$tipo[$i]]);
				}else if($tipo[$i] == "Requisição (Alteração)"){
					array_push($valorAlteracao, (double)$dados[$tipo[$i]]);
				}else if($tipo[$i] == "Requisição (Dúvida)"){
					array_push($valorDuvida, (double)$dados[$tipo[$i]]);
				}else if($tipo[$i] == "Requisição (Melhoria)"){
					array_push($valorMelhoria, (double)$dados[$tipo[$i]]);
				}
			}else{
			
				if($tipo[$i] == "Requisição (Acesso)"){
					array_push($valorAcesso, 0);
				}else if($tipo[$i] == "Requisição (Alteração)"){
					array_push($valorAlteracao, 0);
				}else if($tipo[$i] == "Requisição (Dúvida)"){
					array_push($valorDuvida, 0);
				}else if($tipo[$i] == "Requisição (Melhoria)"){
					array_push($valorMelhoria, 0);
				}
			}
			$ok = 1;
			$i++;
		}
	}
	
	$retorno['nivel']          = $nivel;
	$retorno['valorAcesso']    = $valorAcesso;
	$retorno['valorAlteracao'] = $valorAlteracao;
	$retorno['valorDuvida']    = $valorDuvida;
	$retorno['valorMelhoria']  = $valorMelhoria;
	
	
	
	/*var_dump($retorno['nivel']         );
	var_dump($retorno['valorAcesso']   );
	var_dump($retorno['valorAlteracao']);
	var_dump($retorno['valorDuvida']   );
	var_dump($retorno['valorMelhoria'] );*/
	
	$retorno['ok']             = $ok;
	$retorno['msg']            = $msg;
	echo json_encode($retorno);
}

function graficoRequisicoesAbertasTipo(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();
	$valor   = array();
	$tipos   = array();
	$i       = 0;

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 72;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoRequisicoesAbertasTipo($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
		
		array_push($valor,(double)$dados);
		array_push($tipos,$key);
		$ok = 1;
	}

	$retorno['tipos'] = $tipos;
	$retorno['valor'] = $valor;
	$retorno['ok']    = $ok;
	$retorno['msg']   = $msg;
	echo json_encode($retorno);
}

function graficoRequisicoesEncerradasTipo(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();
	$valor   = array();
	$tipos   = array();
	$i       = 0;

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 72;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoRequisicoesEncerradasTipo($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
		
		array_push($valor,(double)$dados);
		array_push($tipos,$key);
		$ok = 1;
	}

	$retorno['tipos'] = $tipos;
	$retorno['valor'] = $valor;
	$retorno['ok']    = $ok;
	$retorno['msg']   = $msg;
	echo json_encode($retorno);
}

function graficoPercRequisicoesAbertasTipo(){
	$ok = 0;
	$msg = "";
	$niveis = array();
	$valores = array();
	$retorno = array();
	
	$retorno['valorAcesso']    = 0;
	$retorno['valorAlteracao'] = 0;
	$retorno['valorDuvida']    = 0;
	$retorno['valorMelhoria']  = 0;
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador = 64;
	$ano          = 2015;
	$mes          = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$indicadores = $indicadorTI->graficoPercRequisicoesAbertasTipo($indicador,$ano,$mes); 
	
	foreach($indicadores as $key => $dados){
		
		if($key == "Requisição (Acesso)"){
			$retorno['valorAcesso'] = $dados;
		}
		if($key == "Requisição (Alteração)"){
			$retorno['valorAlteracao'] = $dados;
		}
		if($key == "Requisição (Dúvida)"){
			$retorno['valorDuvida'] = $dados;
		}
		if($key == "Requisição (Melhoria)"){
			$retorno['valorMelhoria'] = $dados;
		}
		$ok = 1;
	}
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function graficoPercRequisicoesEncerradasTipo(){
	$ok = 0;
	$msg = "";
	$niveis = array();
	$valores = array();
	$retorno = array();
	
	$retorno['valorAcesso']    = 0;
	$retorno['valorAlteracao'] = 0;
	$retorno['valorDuvida']    = 0;
	$retorno['valorMelhoria']  = 0;
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador = 68;
	$ano          = 2015;
	$mes          = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$indicadores = $indicadorTI->graficoPercRequisicoesEncerradasTipo($indicador,$ano,$mes); 
	
	foreach($indicadores as $key => $dados){
		
		if($key == "Requisição (Acesso)"){
			$retorno['valorAcesso'] = $dados;
		}
		if($key == "Requisição (Alteração)"){
			$retorno['valorAlteracao'] = $dados;
		}
		if($key == "Requisição (Dúvida)"){
			$retorno['valorDuvida'] = $dados;
		}
		if($key == "Requisição (Melhoria)"){
			$retorno['valorMelhoria'] = $dados;
		}
		$ok = 1;
	}
	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function graficoRequisicoesReabertas(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();
	$valor   = array();
	$tipos   = array();
	$i       = 0;

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 65;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoRequisicoesReabertas($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
		
		array_push($valor,(double)$dados);
		array_push($tipos,$key);
		$ok = 1;
	}

	$retorno['tipos'] = $tipos;
	$retorno['valor'] = $valor;
	$retorno['ok']    = $ok;
	$retorno['msg']   = $msg;
	echo json_encode($retorno);
}

function graficoRequisicoesAbertasServico(){
	
	$ok = 0;
	$msg = "";
	$retorno  = array();
	$valor    = array();
	$servicos = array();
	$i        = 0;

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 65;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoRequisicoesAbertasServico($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
		
		array_push($valor,(double)$dados);
		array_push($servicos,$key);
		$ok = 1;
	}

	$retorno['servicos'] = $servicos;
	$retorno['valor']    = $valor;
	$retorno['ok']       = $ok;
	$retorno['msg']      = $msg;
	echo json_encode($retorno);
}

function graficoRequisicoesEncerradasNivel(){
	
	$ok = 0;
	$msg = "";
	$retorno  = array();
	$valor    = array();
	$nivel    = array();
	$i        = 0;

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 65;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoRequisicoesEncerradasNivel($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
		
		array_push($valor,(double)$dados);
		array_push($nivel,$key);
		$ok = 1;
	}

	$retorno['nivel'] = $nivel;
	$retorno['valor'] = $valor;
	$retorno['ok']    = $ok;
	$retorno['msg']   = $msg;
	echo json_encode($retorno);
}

function graficoPercReqEncerTipoNivel(){

	$ok = 0;
	$msg = "";
	$retorno        = array();
	$valorTotal     = array();
	$valorAcesso    = array();
	$valorAlteracao = array();
	$valorDuvida    = array();
	$valorMelhoria  = array();
	$nivel          = array();
	$tipo           = array("Requisicao","Requisição (Acesso)","Requisição (Alteração)","Requisição (Dúvida)","Requisição (Melhoria)");
	

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 70;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoPercReqEncerTipoNivel($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
	
		array_push($nivel, $key);
		
		$i = 0;
		
		while($i < 5){
		
			if(count($dados[$tipo[$i]]) > 0){
				
				if($tipo[$i] == "Requisicao"){
					array_push($valorTotal, (double)str_replace(",",".",$dados[$tipo[$i]]));
				}else if($tipo[$i] == "Requisição (Acesso)"){
					array_push($valorAcesso, (double)str_replace(",",".",$dados[$tipo[$i]]));
				}else if($tipo[$i] == "Requisição (Alteração)"){
					array_push($valorAlteracao, (double)str_replace(",",".",$dados[$tipo[$i]]));
				}else if($tipo[$i] == "Requisição (Dúvida)"){
					array_push($valorDuvida, (double)str_replace(",",".",$dados[$tipo[$i]]));
				}else if($tipo[$i] == "Requisição (Melhoria)"){
					array_push($valorMelhoria, (double)str_replace(",",".",$dados[$tipo[$i]]));
				}
			}else{
			
				if($tipo[$i] == "Requisicao"){
					array_push($valorTotal, (double)str_replace(",",".",$dados[$tipo[$i]]));
				}else if($tipo[$i] == "Requisição (Acesso)"){
					array_push($valorAcesso, 0);
				}else if($tipo[$i] == "Requisição (Alteração)"){
					array_push($valorAlteracao, 0);
				}else if($tipo[$i] == "Requisição (Dúvida)"){
					array_push($valorDuvida, 0);
				}else if($tipo[$i] == "Requisição (Melhoria)"){
					array_push($valorMelhoria, 0);
				}
			}
			$ok = 1;
			$i++;
		}
	}
	
	$retorno['nivel']          = $nivel;
	$retorno['valorTotal']     = $valorTotal;
	$retorno['valorAcesso']    = $valorAcesso;
	$retorno['valorAlteracao'] = $valorAlteracao;
	$retorno['valorDuvida']    = $valorDuvida;
	$retorno['valorMelhoria']  = $valorMelhoria;
	$retorno['ok']             = $ok;
	$retorno['msg']            = $msg;
	echo json_encode($retorno);
}

function graficoTotalRequisicoesMaiores90(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicadorPar = 34;
	$ano          = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$indicadores = $indicadorTI->graficoTotalRequisicoesMaiores90($indicador,$ano);
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		$meta = $indicadores[$numeroMeses]['meta'];
		
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['meta'] > 0){
					array_push($metas, (double)$meta);	
				}else{
					array_push($metas, 0);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, (double)$meta);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalRequisicoesBacklog(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	
	/*$indicadorPar = 34;
	$ano          = 2015;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$indicadores = $indicadorTI->graficoTotalRequisicoesBacklog($indicador,$ano);
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
		
		$meta = $indicadores[$numeroMeses]['meta'];
		
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['meta'] > 0){
					array_push($metas, (double)$meta);	
				}else{
					array_push($metas, 0);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, (double)$meta);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvolvimentosPrazo(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$metas      = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	//$indicadorPar = 12;
	//$ano     = 2016;
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvimentosPrazo($indicadorPar,$ano);
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
	
		$meta = $indicadores[$numeroMeses]['meta'];
	
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($meta > 0){
					array_push($metas, (double)$meta);	
				}else{
					array_push($metas, $meta);
				}
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
				array_push($metas, (double)$meta);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['metas']      = $metas;
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvolvimentosPrazoEFora(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$prazo   = array();
	$fora    = array();
	$meses   = array();
	$i = 1;
	
	$indicadorIniPar = $_POST['indicadorIni'];
	$indicadorFimPar = $_POST['indicadorFim'];
	$ano             = $_POST['ano'];
	
	/*$indicadorIniPar = 135;
	$indicadorFimPar = 136;
	$ano             = 2016;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvimentosPrazoEFora($indicadorIniPar,$indicadorFimPar,$ano);
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
	
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['prazo'] > 0){
					array_push($prazo, (double)$indicadores[$i]['prazo']);
				}else{
					array_push($prazo, 0);
				}
				if($indicadores[$i]['fora'] > 0){
					array_push($fora, (double)$indicadores[$i]['fora']);
				}else{
					array_push($fora, 0);
				}				
			}else{
				array_push($prazo, 0);
				array_push($fora, 0);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}
		
		$retorno['prazo'] = $prazo;
		$retorno['fora']  = $fora;
		$retorno['meses'] = $meses;
	
	}else{
		$ok = 0;		
	}
	
	/*print "<pre>";
	print_r($retorno);
	print "</pre>";*/
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvReagendados(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();
	$valor   = array();
	$tipos   = array();
	$i       = 0;

	$indicador = $_POST['indicador'];
	$ano       = $_POST['ano'];
	$mes       = $_POST['mes'];
	
	/*$indicador   = 72;
	$ano         = 2015;
	$mes         = 9;*/
	
	$indicadorTI = new IndicadoresTI();
	
	$resultado = $indicadorTI->graficoTotalDesenvReagendados($indicador,$ano,$mes);
	
	foreach($resultado as $key => $dados){
		
		array_push($valor,(double)$dados);
		array_push($tipos,$key);
		$ok = 1;
	}

	$retorno['tipos'] = $tipos;
	$retorno['valor'] = $valor;
	$retorno['ok']    = $ok;
	$retorno['msg']   = $msg;
	echo json_encode($retorno);
}

function graficoTotalIncidentesDevidoDesenv(){
	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$meses      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	
	//$indicadorPar = 12;
	//$ano     = 2016;
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalIncidentesDevidoDesenv($indicadorPar,$ano);
	
	$numeroMeses = count($indicadores);
	
	if($numeroMeses > 0){
	
		while($i <= 12){
			
			if(count($indicadores[$i]) > 0){
				if($indicadores[$i]['resultado'] > 0){
					array_push($resultados, (double)$indicadores[$i]['resultado']);
				}else{
					array_push($resultados, 0);
				}				
			}else{
				array_push($resultados, 0);
			}
			$mesDescricao = mesDescricao($i);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
		}	
		$retorno['resultados'] = $resultados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvolvimentosBacklog(){

	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$situacoes  = array();
	$metas      = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 15;
	$ano     = 2016;
	$mes     = 03;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvimentosBacklog($indicadorPar,$ano, $mes);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	//var_dump($indicadores);
	
	foreach($indicadores as $key => $dados){
		
		array_push($situacoes, $key);
		array_push($resultados, (double)$dados['resultado']);
		array_push($metas, (double)$dados['meta']);

		$ok = 1;
	}
	
	$retorno['resultados'] = $resultados;
	$retorno['situacoes']  = $situacoes;
	$retorno['metas']      = $metas;
	
	/*print "<pre>";
	print_r($retorno);
	print "</pre>";*/
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvolvimentosEtapa(){

	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$etapas     = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 138;
	$ano     = 2016;
	$mes     = 03;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvimentosEtapa($indicadorPar,$ano, $mes);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	//var_dump($indicadores);
	
	foreach($indicadores as $key => $dados){
		
		array_push($etapas, $key);
		array_push($resultados, (double)$dados);

		$ok = 1;
	}
	
	$retorno['resultados'] = $resultados;
	$retorno['etapas']     = $etapas;
	
	/*print "<pre>";
	print_r($retorno);
	print "</pre>";*/
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}


function graficoTotalDesenvolvForaPrazoEtapa(){

	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$etapas     = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 138;
	$ano     = 2016;
	$mes     = 03;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvForaPrazoEtapa($indicadorPar,$ano, $mes);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	//var_dump($indicadores);
	
	foreach($indicadores as $key => $dados){
		
		array_push($etapas, $key);
		array_push($resultados, (double)$dados);

		$ok = 1;
	}
	
	$retorno['resultados'] = $resultados;
	$retorno['etapas']     = $etapas;
	
	/*print "<pre>";
	print_r($retorno);
	print "</pre>";*/
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvolvForaPrazoResp(){

	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$responsaveis = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 138;
	$ano     = 2016;
	$mes     = 03;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvForaPrazoResp($indicadorPar,$ano, $mes);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	//var_dump($indicadores);
	
	foreach($indicadores as $key => $dados){
		
		array_push($responsaveis, $key);
		array_push($resultados, (double)$dados);

		$ok = 1;
	}
	
	$retorno['resultados']   = $resultados;
	$retorno['responsaveis'] = $responsaveis;
	
	/*print "<pre>";
	print_r($retorno);
	print "</pre>";*/
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function graficoTotalDesenvolvForaPrazoDias(){

	$ok = 0;
	$msg = "";
	$retorno    = array();
	$resultados = array();
	$dias       = array();
	$i = 1;
	
	$indicadorPar = $_POST['indicador'];
	$ano          = $_POST['ano'];
	$mes          = $_POST['mes'];
	
	/*$indicadorPar = 138;
	$ano     = 2016;
	$mes     = 03;*/
	
	$indicador = new IndicadoresTI();
	
	$indicadores = $indicador->graficoTotalDesenvolvForaPrazoDias($indicadorPar,$ano, $mes);
	
	/*print "<pre>";
	print_r($indicadores);
	print "</pre>";*/
	
	//var_dump($indicadores);
	
	foreach($indicadores as $key => $dados){
		
		array_push($dias, $key);
		array_push($resultados, (double)$dados);

		$ok = 1;
	}
	
	$retorno['resultados']   = $resultados;
	$retorno['dias'] = $dias;
	
	/*print "<pre>";
	print_r($retorno);
	print "</pre>";*/
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}


?>