<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Planos.class.php");
include("../classes/TabelaPreco.class.php");
include("../classes/PlanoFaixaEtaria.class.php");
session_start();

//$_GET['acao'] = 'listaTabelaPrecoModulo';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaPlanoFaixaEtaria'){
	listaPlanoFaixaEtaria();
}else if($_GET['acao']  == 'buscaPlanoFaixaEtaria'){
	buscaPlanoFaixaEtaria();
}else if($_GET['acao']  == 'montaTabelaPreco'){
	montaTabelaPreco();
}else if($_GET['acao']  == 'montaGrauParentesco'){
	montaGrauParentesco();
}else if($_GET['acao']  == 'excluiPlanoFaixaEtaria'){
	excluiPlanoFaixaEtaria();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$utils = new Utils();
	
	$tabelaPrecoCadastro      = $_POST['tabelaPrecoCadastro'];
	$modalidadeCadastro       = $_POST['modalidadeCadastro'];    
    $planoCadastro            = $_POST['planoCadastro'];         
    $tipoPlanoCadastro        = $_POST['tipoPlanoCadastro'];
    $grauParentescoCadastro   = $_POST['grauParentescoCadastro']; 
	$faixaEtariaCadastro	  = $_POST['faixaEtariaCadastro'];	
    $idadeMinimaCadastro      = $_POST['idadeMinimaCadastro'];  
    $idadeMaximaCadastro      = $_POST['idadeMaximaCadastro'];
    $valorFaixaEtariaCadastro = $_POST['valorFaixaEtariaCadastro'];	
	$acao                     = $_POST['acao'];

	$planoFaixaEtaria = new PlanoFaixaEtaria();
	
	if($acao == "cadastrar"){
				
		$valida = $planoFaixaEtaria->existePlano($modalidadeCadastro,$planoCadastro,$tipoPlanoCadastro);		
				
		if($valida){		
				
			if($planoFaixaEtaria->cadastraPlanoFaixaEtaria($tabelaPrecoCadastro,
			                                               $modalidadeCadastro,  
														   $planoCadastro,       
														   $tipoPlanoCadastro,
														   $grauParentescoCadastro, 
														   $faixaEtariaCadastro,
														   $idadeMinimaCadastro, 
														   $idadeMaximaCadastro,
														   $valorFaixaEtariaCadastro)){
				$ok = 1;
				$msg = "Planos X Faixa Et&aacute;ria Cadastrada com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao cadastrar, verificar com o Administrador do sistema.";
			}	
		
		}else{
			$ok = 0;
			$msg = "Esta estrutura n&atilde;o consta no cadastro de planos, verifique uma estrutura existente ou cadastre uma nova.";
		}
		
	}
	
	if($acao == "atualizar"){
		
			if($planoFaixaEtaria->atualizaPlanoFaixaEtaria($tabelaPrecoCadastro,
			                                               $modalidadeCadastro,  
														   $planoCadastro,       
														   $tipoPlanoCadastro,
														   $grauParentescoCadastro, 
														   $faixaEtariaCadastro,
														   $idadeMinimaCadastro, 
														   $idadeMaximaCadastro,
														   $valorFaixaEtariaCadastro)){
				$ok = 1;
				$msg = "Planos X Faixa Et&aacute;ria Atualizada com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao atualizar, verificar com o Administrador do sistema.";
			}
		
		
	}
	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaPlanoFaixaEtaria(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$planoFaixaEtaria = new PlanoFaixaEtaria();
	
	$registros = $planoFaixaEtaria->listaPlanoFaixaEtaria();
	
	/*print "<pre>";
	print_r($planos);
	print "<pre>";*/
	
	$tabela .= "<table id='tabelaPlanoFaixaEtaria' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
					    <th>Tabela Pre&ccedil;o</th>
                        <th>MD</th>
                        <th>PL</th>
                        <th>TP</th>						
						<th>Parentesco</th>
						<th>Nº Faixa Et&aacute;ria</th>
						<th>Idade M&iacute;nima</th>
						<th>Idade M&aacute;xima</th>
						<th>Valor</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($registros as $dados){
		
		//print $dados[3]."<br>";
		
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
                       <td>".$dados[5]."</td>
                       <td>".$dados[6]."</td>
                       <td>".$dados[7]."</td>
                       <td>".$dados[8]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(\"".$dados[0]."\",".$dados[1].",".$dados[2].",".$dados[3].",".$dados[4].",".$dados[5]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaPlanoFaixaEtaria(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$tabelaPreco    = $_POST['tabelaPreco'];
	$modalidade     = $_POST['modalidade'];
	$planoForm      = $_POST['plano'];
	$tipoPlano      = $_POST['tipoPlano'];
	$grauParentesco = $_POST['grauParentesco'];
	$faixaEtaria    = $_POST['faixaEtaria'];
	
    $planoFaixaEtaria = new PlanoFaixaEtaria();
	
	$dados = $planoFaixaEtaria->buscaPlanoFaixaEtaria($tabelaPreco,$modalidade,$planoForm,$tipoPlano,$grauParentesco,$faixaEtaria);	
	
	if($dados){		
		$retorno['cdtabpreco']       = $planoFaixaEtaria->cdtabpreco;
		$retorno['cdmodalidade']     = $planoFaixaEtaria->cdmodalidade;     
	    $retorno['cdplano']          = $planoFaixaEtaria->cdplano;          
	    $retorno['cdtipoplano']      = $planoFaixaEtaria->cdtipoplano;
	    $retorno['cdgrauparentesco'] = $planoFaixaEtaria->cdgrauparentesco;      
	    $retorno['nrfaixaetaria']    = $planoFaixaEtaria->nrfaixaetaria; 
	    $retorno['nridademinima']    = $planoFaixaEtaria->nridademinima;       
	    $retorno['nridademaxima']    = $planoFaixaEtaria->nridademaxima;
	    $retorno['vlfatorfaixa']     = $planoFaixaEtaria->vlfatorfaixa;
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

function excluiPlanoFaixaEtaria(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$tabelaPreco    = $_POST['tabelaPreco'];
	$modalidade     = $_POST['modalidade'];
	$planoForm      = $_POST['plano'];
	$tipoPlano      = $_POST['tipoPlano'];
	$grauParentesco = $_POST['grauParentesco'];
	$faixaEtaria    = $_POST['faixaEtaria'];
	
    $planoFaixaEtaria = new PlanoFaixaEtaria();
	
	if($planoFaixaEtaria->excluiPlanoFaixaEtaria($tabelaPreco,$modalidade,$planoForm,$tipoPlano,$grauParentesco,$faixaEtaria)){
		$ok = 1;		
		$msg = "Registro exclu&iacute;do com sucesso.";
	}else{
		$ok = 0;
		$msg = "N&atilde;o foi poss&iacute;vel excluir. Este registro j&aacute; est&aacute; sendo utilizado em outro cadastro.";
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

function montaTabelaPreco(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$tabelaPreco = new TabelaPreco();
	
	$resultado = $tabelaPreco->listaTabelasPreco();
	
	$select .= "<select class='form-control' id='tabelaPrecoCadastro'>
	            <option value=''>:: Selecione ::</option>";
	
	foreach($resultado as $dados){
		
		$select .= "<option value=$dados[0]>$dados[0]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

function montaGrauParentesco(){
	$ok = 1;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
		
	$select = "<select class='form-control' id='grauParentescoCadastro'>
	           <option value='0'>:: Selecione ::</option>
	           <option value='1'>Titular</option>
	           <option value='2'>Cônjuge</option>
	           <option value='3'>Companheiro(a)</option>
	           <option value='10'>Filho(a)</option>
	           <option value='50'>Pai/Mãe</option>
	           <option value='51'>Sogro(a)</option>
	           <option value='60'>Outros</option>
			   </select>";		
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

?>