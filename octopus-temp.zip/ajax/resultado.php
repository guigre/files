<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Resultados.class.php");
include("../classes/Indicadores.class.php");
session_start();

//$_GET['acao'] = 'salvar';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaResultados'){
	listaResultados();
}else if($_GET['acao']  == 'buscaResultado'){
	buscaResultado();
}else if($_GET['acao']  == 'buscaResultadoFiltro'){
	buscaResultadoFiltro();
}else if($_GET['acao']  == 'desativaResultado'){
	desativaResultado();
}else if($_GET['acao']  == 'montaIndicador'){
	montaIndicador();
}else if($_GET['acao']  == 'montaIndicadorConsulta'){
	montaIndicadorConsulta();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$idResultado       = $_POST['codigoCadastro'];
	$idIndicador       = $_POST['indicadorCadastro'];
	$semana            = $_POST['semanaCadastro'];
	$mes               = $_POST['mesCadastro'];
	$ano               = $_POST['anoCadastro'];
	$detalheIndicador  = $_POST['detalheIndicador'];
	$meta              = $_POST['metaCadastro'];
	$resultadoPar      = $_POST['resultadoCadastro'];
	$detalheIndicador2 = $_POST['detalheIndicador2'];
	
    /*$idResultado       = 3;
	$id                = 119;
	$semana            = 0;
	$mes               = 0;
	$ano               = 2015;
	$detalheIndicador  = "";
	$meta              = 100;
	$resultadoPar      = 50;
	$detalheIndicador2 = "";*/
	
	$resultado = new Resultados();
	
	if($idResultado == ""){ // Cadastra		
		if($resultado->cadastraResultado($idIndicador,$semana,$mes,$ano,$detalheIndicador,$meta,$resultadoPar,$detalheIndicador2)){
			$ok = 1;
			$msg = "Resultado Cadastrado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao cadastrar o resultado, verificar com o Administrador do sistema.";
		}		
	}else{ // Atualiza	
		if($resultado->atualizaResultado($idResultado,$idIndicador,$semana,$mes,$ano,$detalheIndicador,$meta,$resultadoPar,$detalheIndicador2)){
			$ok = 1;
			$msg = "Resultado Atualizado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao atualizar o resultado, verificar com o Administrador do sistema.";			
		}
	}	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaIndicadores(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$indicador = new Indicadores();
	$usuario = new Usuarios();
	
	$indicadores = $indicador->listaIndicadores();
	
	$tabela .= "<table id='tabelaIndicadores' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Respons&aacute;vel</th>
                        <th>C&oacute;digo</th>
                        <th>Indicador</th>
                        <th>Classifica&ccedil;&atilde;o</th>
                        <th>Grupo</th>
                        <th>Periodicidade</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($indicadores as $dados){
		
		$usuarios = $usuario->buscaUsuario($dados[8]);
		
		$tabela .= "<tr>
                       <td>".$usuario->ds_usuario."</td>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function buscaResultado(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$id           = $_POST['id'];
	$id_resultado = $_POST['id_resultado'];
		
	//$codigo = 1;	
		
    $resultado = new Resultados();
	
	$dados = $resultado->buscaResultado($id,$id_resultado);	
	
	if($dados){		
		$retorno['id']                = $resultado->id;
		$retorno['id_resultado']      = $resultado->id_resultado;
		$retorno['semana']            = $resultado->nr_semana;
		$retorno['mes']               = $resultado->nr_mes;
		$retorno['ano']               = $resultado->nr_ano;
		$retorno['detalheIndicador']  = $resultado->ds_detalhe_indicador;
		$retorno['meta']              = $resultado->nr_meta;
		$retorno['resultado']         = $resultado->nr_resultado;
        $retorno['detalheIndicador2'] = $resultado->ds_detalhe_indicador2;
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);		
	
}

function buscaResultadoFiltro(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$indicadorId = $_POST['indicador'];
	$mes         = $_POST['mes'];
	$ano         = $_POST['ano'];
	
	/*$indicadorId = 1;
	$mes         = 6;
	$ano         = 2013;*/
		
    $resultado = new Resultados();
	
	$resultados = $resultado->buscaResultadoFiltro($indicadorId, $mes, $ano);	
	
	$tabela .= "<table id='tabelaResultados' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Semana</th>
                        <th>M&ecirc;s</th>
                        <th>Ano</th>
                        <th>Meta</th>
                        <th>Detalhe Indicador</th>
                        <th>Detalhe Indicador 2</th>
                        <th>Resultado</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($resultados as $dados){
		
		$tabela .= "<tr>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
                       <td>".$dados[6]."</td>
                       <td>".$dados[5]."</td>
                       <td>".$dados[8]."</td>
                       <td>".$dados[7]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0].",".$dados[1]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	
	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);		
	
}

function desativaIndicador(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 1;	
		
    $indicador = new Indicadores();
	
	$dados = $indicador->desativaIndicador($codigo);	
	
	if($dados){		
		$msg = "Indicador Excluído com Sucesso!";
		$ok = 1;		
	}else{
		$msg = "Problemas ao excluir o indicador, verificar com o Administrador do sistema.";
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function montaIndicador(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$indicador = new Indicadores();
	
	$indicadores = $indicador->listaIndicadores();
	
	$select .= "<select class='form-control' id='indicadorCadastro'>
	            <option value=''>:: Selecione ::</option>";
	
	foreach($indicadores as $dados){
		
		$select .= "<option value=$dados[0]>$dados[0] - $dados[1]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

function montaIndicadorConsulta(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$indicador = new Indicadores();
	
	$indicadores = $indicador->listaIndicadores();
	
	$select .= "<select class='form-control' id='indicadorConsulta'>
	            <option value=''>:: Selecione ::</option>";
	
	foreach($indicadores as $dados){
		
		$select .= "<option value=$dados[0]>$dados[0] - $dados[1]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

/*function valida_ldap($srv, $usu, $pass)
{
    $ldap_server = $srv;
    $auth_user   = $usu."@unimedvtrp.com.br";
    $auth_pass   = $pass;
	
    // Tenta se conectar com o servidor
    if (!($connect = @ldap_connect($ldap_server))){
	
		return 0;	   
			   
    }

    // Tenta autenticar no servidor
    if (!($bind = @ldap_bind($connect, $auth_user, $auth_pass))) {
	
		return 0;
		
    } else {
		
		$_SESSION['usuario'] = $usu;
		$_SESSION['senha']   = $auth_pass;
				
		return 1;
		
    }

} // fim funcao conectar ldap

function login(){

	$server = "unimedvtrp.com.br";

	$ok = 0;
	$msg = "";

	$usuario = addslashes(strip_tags($_POST['usuario']));
	$senha   = addslashes(strip_tags($_POST['senha']));
	
	$retorno = array();

	if (valida_ldap($server, $usuario, $senha) == 1){
		
		$retorno['ok'] = 1;	
			
	}else{
	
		$msg = "Usuário e/ou senha incorreto(s).";
	
		$retorno['msg'] = $msg;	
	
	}
	
	echo json_encode($retorno);
}*/

?>