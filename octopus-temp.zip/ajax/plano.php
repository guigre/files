<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Planos.class.php");
session_start();

//$_GET['acao'] = 'salvar';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaPlanos'){
	listaPlanos();
}else if($_GET['acao']  == 'buscaPlano'){
	buscaPlano();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$utils = new Utils();
	
	$modalidadeCadastro     = $_POST['modalidadeCadastro'];    
    $planoCadastro          = $_POST['planoCadastro'];         
    $tipoPlanoCadastro      = $_POST['tipoPlanoCadastro'];     
    $inicioCadastro         = $utils->data_mysql($_POST['inicioCadastro']);        
    $fimCadastro            = $utils->data_mysql($_POST['fimCadastro']);           
    $abrangenciaCadastro    = $_POST['abrangenciaCadastro'];   
    $tipoPessoaCadastro     = $_POST['tipoPessoaCadastro'];    
    $participacaoCadastro   = $_POST['participacaoCadastro'];  
    $simulaCadastro         = $_POST['simulaCadastro'];  
    $cduserid				= $_POST['cduserid']; 	
    $contratacaoCadastro    = $_POST['contratacaoCadastro'];   
    $produtoCadastro        = $_POST['produtoCadastro'];       
    $acomodacaoCadastro     = $_POST['acomodacaoCadastro'];    
    $formaPagamentoCadastro = $_POST['formaPagamentoCadastro'];
    $registroCadastro       = $_POST['registroCadastro'];      
    $segmentacaoCadastro    = $_POST['segmentacaoCadastro'];   
    $descricaoPlanoCadastro = $_POST['descricaoPlanoCadastro'];
    $acao                   = $_POST['acao'];

	/*$modalidadeCadastro     = 7;
	$planoCadastro          = 2;
	$tipoPlanoCadastro      = 21;
	$inicioCadastro         = $utils->data_mysql("01/02/2015");
    $fimCadastro            = $utils->data_mysql("31/12/2099");   
	$acao                   = "cadastrar";*/	
	
	$plano = new Planos();
	
	if($acao == "findar"){
		
		if(strtotime($inicioCadastro) > strtotime($fimCadastro)){
			$ok = 0;
			$msg = "A data final deve ser maior que a data inicial.";
		}else{		
			$inicioCadastro = $utils->formata_data($inicioCadastro);
			$fimCadastro = $utils->formata_data($fimCadastro);
		
			if($plano->findarPlano($modalidadeCadastro,
								   $planoCadastro,     
								   $tipoPlanoCadastro, 
								   $inicioCadastro,    
								   $fimCadastro,
								   $cduserid)){

				$ok = 1;
				$msg = "Plano Findado com Sucesso.";					   
			}else{
				$ok = 0;
				$msg = "Problemas ao findar o plano, verificar com o Administrador do sistema.";
			}     

		}		
		
		
	}
	
	if($acao == "cadastrar"){
		
		$validade = buscaValidadePlano($modalidadeCadastro,$planoCadastro,$tipoPlanoCadastro);
		
		if(count($validade) == 0){
			
			if(strtotime($inicioCadastro) > strtotime($fimCadastro)){
				$ok = 0;
				$mes = "Data Inicial maior que a Data Final.";
			}else{

				$inicioCadastro = $utils->formata_data($inicioCadastro);
				$fimCadastro = $utils->formata_data($fimCadastro);			
				
				if($plano->cadastraPlano($modalidadeCadastro,    
										 $planoCadastro,         
										 $tipoPlanoCadastro,     
										 $inicioCadastro,        
										 $fimCadastro,           
										 $abrangenciaCadastro,   
										 $tipoPessoaCadastro,    
										 $participacaoCadastro,  
										 $simulaCadastro,
										 $cduserid,
										 $contratacaoCadastro,   
										 $produtoCadastro,       
										 $acomodacaoCadastro,    
										 $formaPagamentoCadastro,
										 $registroCadastro,      
										 $segmentacaoCadastro,   
										 $descricaoPlanoCadastro)){
					$ok = 1;
					$msg = "Plano Cadastrado com Sucesso!";
				}else{
					$ok = 0;
					$msg = "Problemas ao cadastrar o plano, verificar com o Administrador do sistema.";
				}		
			
			}
			
		}else{
			
			if(strtotime($inicioCadastro) > strtotime($fimCadastro)){
				$ok = 0;
				$mes = "Data Inicial maior que a Data Final.";
			}else{			
			
				$dataValidade = $utils->data_mysql($validade[0]['DATA']);
				
				if(strtotime($inicioCadastro) > strtotime($dataValidade)){
					
					$inicioCadastro = $utils->formata_data($inicioCadastro);
					$fimCadastro = $utils->formata_data($fimCadastro);				
					
					if($plano->cadastraPlano($modalidadeCadastro,    
											 $planoCadastro,         
											 $tipoPlanoCadastro,     
											 $inicioCadastro,        
											 $fimCadastro,           
											 $abrangenciaCadastro,   
											 $tipoPessoaCadastro,    
											 $participacaoCadastro,  
											 $simulaCadastro,        
											 $cduserid,
											 $contratacaoCadastro,   
											 $produtoCadastro,       
											 $acomodacaoCadastro,    
											 $formaPagamentoCadastro,
											 $registroCadastro,      
											 $segmentacaoCadastro,   
											 $descricaoPlanoCadastro)){
						$ok = 1;
						$msg = "Plano Cadastrado com Sucesso!";
					}else{
						$ok = 0;
						$msg = "Problemas ao cadastrar o plano, verificar com o Administrador do sistema.";
					}
				}else{
					$ok = 0;
					$msg = "Data Inicial (".$utils->formata_data($inicioCadastro).") menor que a Data Final (".$utils->formata_data($dataValidade)."), verifique se a estrutura atual já foi findada.";				
				}
			
			}
			
		}	
		
	}
	
	if($acao == "atualizar"){
		
		if(strtotime($inicioCadastro) > strtotime($fimCadastro)){
			$ok = 0;
			$mes = "Data Inicial maior que a Data Final.";
		}else{		
			$inicioCadastro = $utils->formata_data($inicioCadastro);
			$fimCadastro = $utils->formata_data($fimCadastro);			
		
			if($plano->atualizaPlano($modalidadeCadastro,    
									 $planoCadastro,         
									 $tipoPlanoCadastro,     
									 $inicioCadastro,        
									 $fimCadastro,           
									 $abrangenciaCadastro,   
									 $tipoPessoaCadastro,    
									 $participacaoCadastro,  
									 $simulaCadastro,
									 $cduserid,		
									 $contratacaoCadastro,   
									 $produtoCadastro,       
									 $acomodacaoCadastro,    
									 $formaPagamentoCadastro,
									 $registroCadastro,      
									 $segmentacaoCadastro,   
									 $descricaoPlanoCadastro)){
				$ok = 1;
				$msg = "Plano Atualizado com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao atualizar o plano, verificar com o Administrador do sistema.";			
			}
		
		}
	}
	
	
	
	
	

	/*$modalidadeCadastro     = "99";
	$planoCadastro          = "99";
	$tipoPlanoCadastro      = "99";
	$inicioCadastro         = "20/01/2017";
	$fimCadastro            = "31/12/9999";
	$abrangenciaCadastro    = "Regional";
	$tipoPessoaCadastro     = "F";
	$participacaoCadastro   = "S";
	$simulaCadastro         = "N";
	$cduserid				= "ggregory";
	$contratacaoCadastro    = "Individual/Familiar";
	$produtoCadastro        = "Assitencial";
	$acomodacaoCadastro     = "N/A";
	$formaPagamentoCadastro = "Pre-Pagamento";
	$registroCadastro       = "702411998";
	$segmentacaoCadastro    = "Ambulatorial";
	$descricaoPlanoCadastro = "AR-CP REGIONAL MAXI";
	$atualiza               = ""; */
	
	
	
	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function buscaValidadePlano($modalidade, $planoForm, $tipoPlano){
	$ok = 0;
	$msg = "";
	
	$plano = new Planos();
	
	$result = $plano->buscaValidadePlano($modalidade, $planoForm, $tipoPlano);
	
	return $result;	
}

function listaPlanos(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$plano = new Planos();
	
	$planos = $plano->listaPlanos();
	
	/*print "<pre>";
	print_r($planos);
	print "<pre>";*/
	
	$tabela .= "<table id='tabelaPlanos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>MD</th>
                        <th>PL</th>
                        <th>TP</th>
						<th>In&iacute;cio</th>
						<th>Fim</th>
						<th>Abrang&ecirc;ncia</th>
						<th>Contrata&ccedil;&atilde;o</th>
						<th>Produto</th>
						<th>Acomoda&ccedil;&atilde;o</th>
						<th>Registro</th>
						<th>Segmenta&ccedil;&atilde;o</th>						
						<th>Plano</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($planos as $dados){
		
		//print $dados[3]."<br>";
		
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[2]."</td>
                       <td>".$dados[3]."</td>
                       <td>".$dados[4]."</td>
                       <td>".$dados[5]."</td>
                       <td>".$dados[11]."</td>
                       <td>".$dados[12]."</td>
                       <td>".$dados[13]."</td>
                       <td>".$dados[15]."</td>
                       <td>".$dados[16]."</td>
                       <td>".$dados[17]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0].",".$dados[1].",".$dados[2].",\"".$dados[3]."\"))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaPlano(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$modalidade = $_POST['modalidade'];
	$planoForm  = $_POST['plano'];
	$tipoPlano  = $_POST['tipoPlano'];
	$dataInicio = $_POST['dataInicio'];
	
/*	$retorno['modalidade'] = $modalidade;
	$retorno['plano']      = $plano;     
	$retorno['tipoPlano']  = $tipoPlano; 
	$retorno['dataInicio'] = $dataInicio;*/
	
	/*$modalidade = 7;
	$planoForm = 2;
	$tipoPlano = 21;
	$dataInicio = "01/11/2014";*/
	
    $plano = new Planos();
	
	$dados = $plano->buscaPlano($modalidade,$planoForm,$tipoPlano,$dataInicio);	
	
	if($dados){		
		$retorno['cdmodalidade']       = $plano->cdmodalidade;     
	    $retorno['cdplano']            = $plano->cdplano;          
	    $retorno['cdtipoplano']        = $plano->cdtipoplano;      
	    $retorno['dtiniciocomerc']     = $plano->dtiniciocomerc;   
	    $retorno['dtfimcomerc']        = $plano->dtfimcomerc;      
	    $retorno['dsareageografica']   = $plano->dsareageografica; 
	    $retorno['tipopessoa']         = $plano->tipopessoa;       
	    $retorno['lgparticipacao']     = $plano->lgparticipacao;   
	    $retorno['lgsimulaapp']        = $plano->lgsimulaapp;      
	    $retorno['cduserid']           = $plano->cduserid;        
	    $retorno['dtatualizacao']      = $plano->dtatualizacao;    
	    $retorno['dstipocontratacao']  = $plano->dstipocontratacao;
	    $retorno['dsproduto']          = $plano->dsproduto;        
	    $retorno['dsacomodacao']       = $plano->dsacomodacao;     
	    $retorno['dsformapagto']       = $plano->dsformapagto;     
	    $retorno['cdregistro']         = $plano->cdregistro;       
	    $retorno['dssegmentacao']      = $plano->dssegmentacao;    
	    $retorno['dsplano']            = $plano->dsplano;
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);	
	
}

?>