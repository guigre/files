<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/DemonstrativoPagto.class.php");
session_start();

/*
$_GET['acao'] = 'listaDemonstrativos';
$_GET['dir'] = 'C:/xampp/htdocs/octopus-temp/arquivos/';
$_GET['anoConsulta'] = null;
$_GET['mesConsulta'] = null;
$_GET['prestadorConsultaIni'] = 3220;
$_GET['prestadorConsultaFim'] = 3220;
*/

if($_GET['acao'] == 'listaDemonstrativos'){
	listaDemonstrativos($_GET['dir'], $_GET['anoConsulta'], $_GET['mesConsulta'], $_GET['prestadorConsultaIni'], $_GET['prestadorConsultaFim']);
}else{
	if($_GET['acao'] == 'excluiDemonstrativo'){
		excluiDemonstrativo();
	}else{
		if($_GET['acao'] == 'excluiDemonstrativoMassa'){
			excluiDemonstrativoMassa();
		}
	}
}

function listaDemonstrativos($dir, $anoConsulta, $mesConsulta, $prestadorConsultaIni, $prestadorConsultaFim){
	
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$demonstrativo = new Demonstrativos();
	
	$demonstrativos = $demonstrativo->listaDemonstrativosPagto($dir);
	
	/*print "<pre>";
	print_r($demonstrativos);
	print "<pre>";*/
	
	$tabela .= "<table id='tabelaDemonstrativos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Ano Compet&ecirc;ncia</th>
						<th>M&ecirc;s Compet&ecirc;ncia</th>
						<th>C&oacute;digo Prestador</th>
						<th>Nome Prestador</th>
						<th>Arquivo</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	$count = 1;
	
	foreach($demonstrativos as $dados){
		
		//var_dump($prestadorConsulta);
		//var_dump($dados[2]);
		
		if(($anoConsulta == null || $anoConsulta == $dados[0])
		&& ($mesConsulta == null || $mesConsulta == $dados[1])
		&& ($prestadorConsultaIni == null || $prestadorConsultaIni <= $dados[2])
		&& ($prestadorConsultaFim == null || $prestadorConsultaFim >= $dados[2])){
			
			$tabela .= "<tr>
						   <td>".$dados[0]."</td>
						   <td>".$dados[1]."</td>
						   <td>".$dados[2]."</td>
						   <td>".$dados[3]."</td>
						   <td>".$dados[4]."</td>
						   <td><button id='btnAbrir$count' type='button' class='btn btn-success btn-xs' onclick='javascript:void(abrir(\"".$dados[4]."\"))'>Abrir</button>";
						   
						    if(isset($_SESSION['menu_exclui_demonstrativo']) && $_SESSION['menu_exclui_demonstrativo']){
							
								$tabela .= "&nbsp;&nbsp;<button id='btnExcluir$count' type='button' class='btn btn-danger btn-xs' onclick='javascript:void(confirmacao(\"".$dados[4]."\"))'>Excluir</button>";
							}
						   
			$tabela .= "	</td>
						</tr>";
					
			$count++;
		
			$ok = 1;
		}
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function excluiDemonstrativo(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$dir = $_POST['dir'];
	$file = $_POST['file'];
		
	if(is_file($dir.$file)) {
		if(unlink($dir.$file)){		
			$msg = "Demonstrativo Excluído com Sucesso!";
			$ok = 1;		
		}else{
			$msg = "Problemas ao excluir o demonstrativo, favor verificar com o administrador do sistema.";
			$ok = 0;
		}
	}

	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function excluiDemonstrativoMassa(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$dir = $_POST['dir'];
	$anoConsulta = $_POST['anoConsulta'];
	$mesConsulta = $_POST['mesConsulta'];
	$prestadorConsultaIni = $_POST['prestadorConsultaIni'];
	$prestadorConsultaFim = $_POST['prestadorConsultaFim'];
	
	$demonstrativo = new Demonstrativos();
	$demonstrativos = $demonstrativo->listaDemonstrativosPagto($dir);
	
	$count = 0;
	$successCount = 0;
	
	foreach($demonstrativos as $dados){
		
		if(($anoConsulta == null || $anoConsulta == $dados[0])
		&& ($mesConsulta == null || $mesConsulta == $dados[1])
		&& ($prestadorConsultaIni == null || $prestadorConsultaIni <= $dados[2])
		&& ($prestadorConsultaFim == null || $prestadorConsultaFim >= $dados[2])){
			
			if(is_file($dir.$dados[4])) {
				if(unlink($dir.$dados[4])){		
					$successCount++;
				}
			}
			$count++;
		}
	}
			
	if($count == 0) {
		$msg = "Não encontrados demonstrativos para excluir.";
		$ok = 0;
	}else{
			if($count == $successCount) {
				$msg = $successCount." Demonstrativo(s) Excluído(s) com Sucesso!";
				$ok = 1;		
			}else{
				$msg = "Problemas ao excluir demonstrativos, favor verificar com o administrador do sistema.";
				$ok = 0;
			}
	}

	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

?>