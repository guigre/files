<?php
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/DRG.class.php");
session_start();
//ini_set('display_errors', 1);
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
Usuário: guilherme.gregory
Senha: Si6~]}Su
*/


//$_GET['acao']  = 'enviarDRG';

if($_GET['acao']  == 'solicitaDadosCustosPaciente'){
	solicitaDadosCustosPaciente();
}else if($_GET['acao']  == 'enviarDadosDRG'){
	enviarDadosDRG();
}else if($_GET['acao']  == 'gerarArquivoCSV'){
	gerarArquivoCSV();
}else if($_GET['acao']  == 'atualizaDRG'){
	atualizaDRG();
}else if($_GET['acao']  == 'enviarDRG'){
	enviaDRG();
}

function atualizaDRG(){

	$user = "324_V4L3s-TSt";
	$pass = "gTT3";
	$pass .= "$";
	$pass .= "uk1W";

	//$xml = htmlentities($xml);

	$xml = "<loteCustoPaciente><CustoPaciente> <codigo>1</codigo> <numeroAutorizacao>1602419252</numeroAutorizacao> <numeroAtendimento></numeroAtendimento>
<acao>SUBSTITUIR</acao><ItemCustoPaciente> <codigoItemConsumo>31307060</codigoItemConsumo> <descricaoItemConsumo>LAPAROSCOPIA GINECOLOGICA COM OU SEM BIOPSIA (INCLUI A CROMO</descricaoItemConsumo>
<codigoGrupoConsumo>998</codigoGrupoConsumo> <quantidadeItemConsumo>1</quantidadeItemConsumo> <dataConsumo>2016-11-21T15:05:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario>
<valorCustoTotal>100</valorCustoTotal> <valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> <valorCustoVariavelIndireto></valorCustoVariavelIndireto>
<valorCustoFixoIndireto></valorCustoFixoIndireto> <valorDeducoes></valorDeducoes>
<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> <valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>5460</codigoFornecedor>
<descricaoFornecedor>TELMO ANTONIO PADILHA GARCIA</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
<CustoPaciente> <codigo>51</codigo> <numeroAutorizacao>2260856</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> <acao>SUBSTITUIR</acao><ItemCustoPaciente> <codigoItemConsumo>31005497</codigoItemConsumo>
<descricaoItemConsumo>COLECISTECTOMIA SEM COLANGIOGRAFIA POR VIDEOLAPAROSCOPIA</descricaoItemConsumo> <codigoGrupoConsumo>998</codigoGrupoConsumo> <quantidadeItemConsumo>1</quantidadeItemConsumo>
<dataConsumo>2016-11-24T08:05:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> <valorCustoTotal>100</valorCustoTotal> <valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto>
<valorCustoVariavelIndireto></valorCustoVariavelIndireto> <valorCustoFixoIndireto></valorCustoFixoIndireto> <valorDeducoes></valorDeducoes> <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
<valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>34735</codigoFornecedor> <descricaoFornecedor>GUSTAVO GRUN</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
<CustoPaciente> <codigo>151</codigo> <numeroAutorizacao>2305561</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> <acao>SUBSTITUIR</acao><ItemCustoPaciente>
<codigoItemConsumo>31103456</codigoItemConsumo> <descricaoItemConsumo>TUMOR VESICAL - RESSECCAO ENDOSCOPICA</descricaoItemConsumo> <codigoGrupoConsumo>998</codigoGrupoConsumo>
<quantidadeItemConsumo>1</quantidadeItemConsumo> <dataConsumo>2016-11-17T14:45:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> <valorCustoTotal>100</valorCustoTotal>
<valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> <valorCustoVariavelIndireto></valorCustoVariavelIndireto> <valorCustoFixoIndireto></valorCustoFixoIndireto>
<valorDeducoes></valorDeducoes> <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> <valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>30946</codigoFornecedor>
<descricaoFornecedor>FELIPE GORNICKI SCHNEIDER</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
<CustoPaciente> <codigo>212</codigo> <numeroAutorizacao>1600597171</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> <acao>SUBSTITUIR</acao><ItemCustoPaciente>
<codigoItemConsumo>40804038</codigoItemConsumo> <descricaoItemConsumo>RX DA ARTICULACAO COXOFEMORAL (QUADRIL)</descricaoItemConsumo> <codigoGrupoConsumo>4</codigoGrupoConsumo>
<quantidadeItemConsumo>1</quantidadeItemConsumo> <dataConsumo>2016-11-30T07:27:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> <valorCustoTotal>100</valorCustoTotal>
<valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> <valorCustoVariavelIndireto></valorCustoVariavelIndireto> <valorCustoFixoIndireto></valorCustoFixoIndireto>
<valorDeducoes></valorDeducoes> <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> <valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>20000023</codigoFornecedor>
<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
</loteCustoPaciente>";

//	$xml_object = simplexml_load_string($xml);

	$DRG = new DRG();

	$rs = $DRG->enviarDadosDRG($xml,$user,$pass);

	$xml_object = simplexml_load_string($rs->{'return'});

	print "<pre>";
	print_r($xml_object);
	print "</pre>";


}


function solicitaDadosCustosPaciente(){
	$ok = 0;
	$msg = "";

	$dadosSaida  = array();
	$saidaTabela = array();
	$retorno = array();
	$tabela = "";

	$anoIni     = $_POST['anoIni'];
	$anoFim     = $_POST['anoFim'];
	$periodoIni = $_POST['periodoIni'];
	$periodoFim = $_POST['periodoFim'];
	$hospital   = $_POST['hospital'];

	/*$anoIni     = 2017;
	$anoFim     = 2017;
	$periodoIni = 101;
	$periodoFim = 102;
	$hospital   = 261;*/

	$DRG = new DRG();

	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,$hospital,"prod");

	//$retorno['resultado'] = $resultado;

	$tabela = "<table id='tabelaDados' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Senha</th>
						<th>Unidade</th>
						<th>Carteira</th>
                        <th>Nome Paciente</th>
						<th>Qtde Itens</th>
						<th>Vl Total</th>
                      </tr>
                    </thead>
                    <tbody>";

	$senha = "senhaInicial";

	$count = 1;

	$aux = 0;

	$num = 1;

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){

				//if($dados->{'cd-prestador-drg'} == $hospital){

					$dadosSaida[$count]['cd-remessa']                 = $dados->{'cd-remessa'};
					$dadosSaida[$count]['ds-senha']                   = $dados->{'ds-senha'};
					$dadosSaida[$count]['nr-atendimento']             = $dados->{'nr-atendimento'};
					$dadosSaida[$count]['ds-acao']                    = $dados->{'ds-acao'};
					$dadosSaida[$count]['cd-item-consumo']            = $dados->{'cd-item-consumo'};
					$dadosSaida[$count]['ds-item-consumo']            = $dados->{'ds-item-consumo'};
					$dadosSaida[$count]['cd-grupo-consumo']           = $dados->{'cd-grupo-consumo'};
					$dadosSaida[$count]['qt-item-consumo']            = $dados->{'qt-item-consumo'};
					$dadosSaida[$count]['ds-data-hora']               = $dados->{'ds-data-hora'};
					$dadosSaida[$count]['vl-unitario-consumo']        = $dados->{'vl-unitario-consumo'};
					$dadosSaida[$count]['vl-total-consumo']           = $dados->{'vl-total-consumo'};
					$dadosSaida[$count]['vl-custo-variavel-direto']   = $dados->{'vl-custo-variavel-direto'};
					$dadosSaida[$count]['vl-custo-fixo-direto']       = $dados->{'vl-custo-fixo-direto'};
					$dadosSaida[$count]['vl-custo-variavel-indireto'] = $dados->{'vl-custo-variavel-indireto'};
					$dadosSaida[$count]['vl-custo-fixo-indireto']     = $dados->{'vl-custo-fixo-indireto'};
					$dadosSaida[$count]['vl-deducoes']                = $dados->{'vl-deducoes'};
					$dadosSaida[$count]['qt-receita']                 = $dados->{'qt-receita'};
					$dadosSaida[$count]['vl-unitario-receita']        = $dados->{'vl-unitario-receita'};
					$dadosSaida[$count]['vl-total-receita']           = $dados->{'vl-total-receita'};
					$dadosSaida[$count]['cd-prestador']               = $dados->{'cd-prestador'};
					$dadosSaida[$count]['ds-prestador']               = $dados->{'ds-prestador'};
					$dadosSaida[$count]['cd-prestador-drg']           = $dados->{'cd-prestador-drg'};
					$dadosSaida[$count]['ds-usuario-iag']             = $dados->{'ds-usuario-iag'};
					$dadosSaida[$count]['ds-senha-iag']               = $dados->{'ds-usuario-iag'};

					$count++;

					if($dados->{'nm-paciente'} != $nome){
						$nome = $dados->{'nm-paciente'};
						$aux++;

						$saidaTabela[$aux]['senha']      = $dados->{'ds-senha'};
						$saidaTabela[$aux]['unidade']    = $dados->{'cd-unidade-carteira'};
						$saidaTabela[$aux]['carteira']   = str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT);
						$saidaTabela[$aux]['nome']       = $dados->{'nm-paciente'};
						$saidaTabela[$aux]['quantidade'] = $dados->{'qt-item-consumo'};
						$saidaTabela[$aux]['valor']      = $dados->{'vl-total-consumo'};

					}else{

						if($saidaTabela[$aux]['nome'] === $dados->{'nm-paciente'}){

							$saidaTabela[$aux]['quantidade'] = $saidaTabela[$aux]['quantidade'] + $dados->{'qt-item-consumo'};
							$saidaTabela[$aux]['valor']      = $saidaTabela[$aux]['valor'] + str_replace(",",".",$dados->{'vl-total-consumo'});

							$nome = $dados->{'nm-paciente'};

						}

					}

				//}

			}

		}

	}

	//$retorno['saidaTabela'] = $saidaTabela;


	foreach($saidaTabela as $saidaDados){

		$tabela .= "<tr>
					<td>".$saidaDados['senha']."</td>
					<td>".$saidaDados['unidade']."</td>
					<td>".$saidaDados['carteira']."</td>
					<td>".$saidaDados['nome']."</td>
					<td>".$saidaDados['quantidade']."</td>
					<td>R$ ".number_format(str_replace(".",".",$saidaDados['valor']),2,',','.')."</td>
					</tr>";
		$ok = 1;

	}

	$tabela .= "</tbody></table>";


	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	$retorno['tabela'] = $tabela;
	$retorno['saida'] = $dadosSaida;

	echo json_encode($retorno);
}

function enviarDadosDRG(){
	$ok = 0;
	$msg = "";

	$dadosSaida    = array();
	$saidaTabela   = array();
	$dadosControle = array();
	$tabela        = "";
	$gerouErro     = false;

	$utils = new Utils();

	/*$anoIni         = $_POST['anoIni'];
	$anoFim         = $_POST['anoFim'];
	$periodoIni     = $_POST['periodoIni'];
	$periodoFim     = $_POST['periodoFim'];
	$arquivoEntrada = $_POST['arquivoEntrada'];
	$hospital       = $_POST['hospital'];*/

	$anoIni = 2018;
	$anoFim = 2018;
	$periodoIni = 031;
	$periodoFim = 032;
	$hospital = 264;
	//$arquivoEntrada = "custoPaciente-11-2018_a_11-2018-264-110714.csv";
	$arquivoEntrada = "";

	//$arquivoErro = "/var/www/html/octopus-temp/arquivos/php/files/custos-nao-importados.csv";
	$arquivoErro = "c://xampp//htdocs//octopus-temp//arquivos//php//files//custos-nao-importados.csv";

	$erro = fopen($arquivoErro,"w");

	fwrite($erro,"COD. REMESSA;SENHA;PRESTADOR DRG;USUARIO IAG;SENHA IAG;CARTEIRA;NOME;NR. ATENDIMENTO;ACAO;COD.ITEM CONSUMO;DESC.ITEM CONSUMO;COD.GRUPO CONSUMO;QTDE ITEM CONSUMO;DATA E HORA;VL.UNITARIO ITEM CONSUMO;VL.TOTAL ITEM CONSUMO;VL.CUSTO VARIAVEL DIRETO;VL.CUSTO FIXO DIRETO;VL.CUSTO VARIAVEL INDIRETO;VL.CUSTO FIXO INDIRETO;VL.DEDUCOES;QTDE RECEITA;VL.UNITARIO RECEITA;VL.TOTAL RECEITA;COD.PRESTADOR;DESC.PRESTADOR;UNIDADE;UNIDADE PRESTADORA;TRANSACAO;NR SERIE DOC ORIGINAL;NR DOC ORIGINAL;NR DOC SISTEMA;TIPO INSUMO;INSUMO;NR PROCESSO;NR SEQ DIGITACAO;NR DRG;DESCRICAO ERRO\n");

	$senhas = null;

	if($arquivoEntrada != ""){

		//$path = "/var/www/html/octopus-temp/arquivos/php/files/".$arquivoEntrada;
		$path = "c://xampp//htdocs//octopus-temp//arquivos//php//files//".$arquivoEntrada;

		$file = fopen($path,"r");

		$count = 0;

		while (!feof ($file)) {
			$linha = fgets($file,4096);

			if($count != 0){
				$vetor =  explode(";",$linha);

				$senhas[$vetor['26'].'-'.$vetor['27'].'-'.$vetor['28'].'-'.$vetor['29'].'-'.$vetor['30'].'-'.$vetor['31'].'-'.$vetor['32'].'-'.$vetor['33'].'-'.$vetor['34'].'-'.$vetor['35']] = $vetor['1'];

				$count++;
			}else{
				$count++;
			}
		}

	}

		/*print "<pre>";
		print_r($senhas);
		print "<pre>";*/

	/*$user = "324_V4L3s-TSt";
	$pass = "gTT3";
	$pass .= "$";
	$pass .= "uk1W";*/

	$ct_ttCustosEntradaRow = array();

	$DRG = new DRG();

	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,$hospital,"prod");

		/*print "<pre>";
		print_r($resultado);
		print "<pre>";		*/

	$xml = "<loteCustoPaciente>";

	$senha = "";

	$count = 1;

	$auxPrestador = 1;

	$prestador = "";

	$aux = 1;
	$lote = 1;

	$finalizouLote = false;

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){

				//if($dados->{'cd-prestador-drg'} == $hospital){

		print "<pre>";
		print_r($dados);
		print "<pre>";

				//}

					if($senhas != null){

						$indice  = $dados->{'cd-unidade'}.'-';
						$indice .= $dados->{'cd-unidade-prestadora'}.'-';
						$indice .= $dados->{'cd-transacao'}.'-';
						$indice .= $dados->{'nr-serie-doc-original'}.'-';
						$indice .= $dados->{'nr-doc-original'}.'-';
						$indice .= $dados->{'nr-doc-sistema'}.'-';
						$indice .= $dados->{'cd-tipo-insumo'}.'-';
						$indice .= $dados->{'cd-insumo'}.'-';
						$indice .= $dados->{'nr-processo'}.'-';
						$indice .= $dados->{'nr-seq-digitacao'};

						$senhaEnvio = $senhas[$indice];

					}else{

						$senhaEnvio = $dados->{'ds-senha'};

					}

					$dataHora =  $utils->data_mysql(substr($dados->{'ds-data-hora'},0,10))."T".substr($dados->{'ds-data-hora'},11).":00";

					if($finalizouLote){

						$xml = "<loteCustoPaciente>";

						$xml .= "<CustoPaciente>
								<codigo>".$dados->{'cd-remessa'}."</codigo>
								<numeroAutorizacao>".$senhaEnvio."</numeroAutorizacao>
								<numeroAtendimento></numeroAtendimento>
								<acao>INCLUIR</acao>";

						$xml .= "<ItemCustoPaciente>
								 <codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
								 <descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
								 <codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
								 <quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
								 <dataConsumo>$dataHora</dataConsumo>
								 <valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
								 <valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
								 <valorCustoVariavelDireto></valorCustoVariavelDireto>
								 <valorCustoFixoDireto></valorCustoFixoDireto>
								 <valorCustoVariavelIndireto></valorCustoVariavelIndireto>
								 <valorCustoFixoIndireto></valorCustoFixoIndireto>
								 <valorDeducoes></valorDeducoes>
								 <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
								 <valorReceitaUnitario></valorReceitaUnitario>
								 <valorReceitaTotal></valorReceitaTotal>
								 <codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
								 <descricaoFornecedor>".trim($dados->{'ds-prestador'})."</descricaoFornecedor>
								 </ItemCustoPaciente>";

						$senha = $dados->{'ds-senha'};

						$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};
						$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
						$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
						$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
						$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
						$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
						$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
						$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
						$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
						$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

						$aux++;

						//$count = 1;

						$finalizouLote = false;

					}else{

						if($senha !== $senhaEnvio){

							if($count != 1){
								$xml .= "</CustoPaciente>";
								$aux = 1;
							}

							$xml .= "<CustoPaciente>
									<codigo>".$dados->{'cd-remessa'}."</codigo>
									<numeroAutorizacao>".$senhaEnvio."</numeroAutorizacao>
									<numeroAtendimento></numeroAtendimento>
									<acao>INCLUIR</acao>";

							$xml .= "<ItemCustoPaciente>
									<codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
									<descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
									<codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
									<quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
									<dataConsumo>$dataHora</dataConsumo>
									<valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
									<valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
									<descricaoFornecedor>".trim($dados->{'ds-prestador'})."</descricaoFornecedor>
									</ItemCustoPaciente>";

							$senha = $senhaEnvio;

							$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};
							$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
							$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
							$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
							$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
							$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
							$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
							$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
							$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
							$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

							$aux++;

						}else{

							if($count == 1){

								$xml .= "<CustoPaciente>
										<codigo>".$dados->{'cd-remessa'}."</codigo>
										<numeroAutorizacao>".$senhaEnvio."</numeroAutorizacao>
										<numeroAtendimento></numeroAtendimento>
										<acao>INCLUIR</acao>";

							}

							$xml .= "<ItemCustoPaciente>
									<codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
									<descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
									<codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
									<quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
									<dataConsumo>$dataHora</dataConsumo>
									<valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
									<valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
									<descricaoFornecedor>".trim($dados->{'ds-prestador'})."</descricaoFornecedor>
									</ItemCustoPaciente>";

							$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};
							$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
							$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
							$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
							$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
							$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
							$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
							$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
							$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
							$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

							$aux++;

							}

							$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};
							$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
							$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
							$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
							$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
							$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
							$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
							$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
							$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
							$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

							$aux++;

							if((strlen($xml) >= 500000 || ($prestador != $dados->{'cd-prestador-drg'})) && $auxPrestador > 1){
								$xml .= "</CustoPaciente>";
								$xml .= "</loteCustoPaciente>";

								print "<pre>";
								print_r(htmlentities($xml));
								print "</pre>";

								$prestador = $dados->{'cd-prestador-drg'};
								$auxPrestador++;

								$finalizouLote = true;

								$senha = $senhaEnvio;

								$user = $dados->{'ds-usuario-iag'};
								$pass = $dados->{'ds-senha-iag'};

								/*$rs = $DRG->enviarDadosDRG($xml,$user,$pass);

								$xml_object = simplexml_load_string($rs->{'return'});

								foreach($xml_object->{'CustoPaciente'} as $dadosRetorno){


									if($dadosRetorno->{"codigoErro"} == ""){

										$autorizacao = (string)$dadosRetorno->{'numeroAutorizacao'};

										foreach($dadosControle[$autorizacao] as $valores){

											$item = array('st_cd-unidade'             => $valores['cdUnidade'],
														  'st_cd-unidade-prestadora'  => $valores['cdUnidadePrestadora'],
														  'st_cd-transacao'           => $valores['cdTransacao'],
														  'st_nr-serie-doc-original'  => $valores['nrSerieDocOriginal'],
														  'st_nr-doc-original'        => $valores['nrDocOriginal'],
														  'st_nr-doc-sistema'         => $valores['nrDocSistema'],
														  'st_cd-tipo-insumo'         => $valores['cdTipoInsumo'],
														  'st_cd-insumo'              => $valores['cdInsumo'],
														  'st_nr-processo'            => $valores['nrProcesso'],
														  'st_nr-seq-digitacao'       => $valores['nrSeqDigitacao']);

											array_push($ct_ttCustosEntradaRow,$item);

										}

										$status = array('ct_ttCustosEntrada' => array('ct_ttCustosEntradaRow' => $ct_ttCustosEntradaRow));

										$result = $DRG->atualizaStatusCustoPaciente($status);

									}else{

										$escreve  = $dados->{'cd-remessa'}.";";
										$escreve .= $senhaEnvio.";";
										$escreve .= $dados->{'cd-prestador-drg'}.";";
										$escreve .= $dados->{'ds-usuario-iag'}.";";
										$escreve .= $dados->{'ds-senha-iag'}.";";
										$escreve .= $dados->{'cd-unidade-carteira'}."".str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT).";";
										$escreve .= $dados->{'nm-paciente'}.";";
										$escreve .= ";";
										$escreve .= "INCLUIR;";
										$escreve .= $dados->{'cd-item-consumo'}.";";
										$escreve .= trim($dados->{'ds-item-consumo'}).";";
										$escreve .= $dados->{'cd-grupo-consumo'}.";";
										$escreve .= $dados->{'qt-item-consumo'}.";";
										$escreve .= $dados->{'ds-data-hora'}.";";
										$escreve .= $dados->{'vl-unitario-consumo'}.";";
										$escreve .= $dados->{'vl-total-consumo'}.";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= $dados->{'cd-prestador'}.";";
										$escreve .= trim($dados->{'ds-prestador'}).";";
										$escreve .= $dados->{'cd-unidade'}.";";
										$escreve .= $dados->{'cd-unidade-prestadora'}.";";
										$escreve .= $dados->{'cd-transacao'}.";";
										$escreve .= $dados->{'nr-serie-doc-original'}.";";
										$escreve .= $dados->{'nr-doc-original'}.";";
										$escreve .= $dados->{'nr-doc-sistema'}.";";
										$escreve .= $dados->{'cd-tipo-insumo'}.";";
										$escreve .= $dados->{'cd-insumo'}.";";
										$escreve .= $dados->{'nr-processo'}.";";
										$escreve .= $dados->{'nr-seq-digitacao'}.";";
										$escreve .= ";";
										$escreve .= trim($dadosRetorno->{'descricaoErro'})."\n";

										fwrite($erro,$escreve);

										$gerouErro = true;

									}


									//print ($dados->{'numeroAutorizacao'}) . "<br>";


								}	*/

						}else{
								$prestador = $dados->{'cd-prestador-drg'};
								$auxPrestador++;
						}

					}

					$count++;

				//}

			}

		}

	}
    $xml .= "</CustoPaciente>";
	$xml .= "</loteCustoPaciente>";

	print "<pre>";
	print_r(htmlentities($xml));
	print "</pre>";

	/*$user = $dados->{'ds-usuario-iag'};
	$pass = $dados->{'ds-senha-iag'};

	$rs = $DRG->enviarDadosDRG($xml,$user,$pass);

	$xml_object = simplexml_load_string($rs->{'return'});

	foreach($xml_object->{'CustoPaciente'} as $dadosRetorno){


		if($dadosRetorno->{"codigoErro"} == ""){

			$autorizacao = (string)$dadosRetorno->{'numeroAutorizacao'};

			foreach($dadosControle[$autorizacao] as $valores){

				$item = array('st_cd-unidade'             => $valores['cdUnidade'],
								'st_cd-unidade-prestadora'  => $valores['cdUnidadePrestadora'],
								'st_cd-transacao'           => $valores['cdTransacao'],
								'st_nr-serie-doc-original'  => $valores['nrSerieDocOriginal'],
								'st_nr-doc-original'        => $valores['nrDocOriginal'],
								'st_nr-doc-sistema'         => $valores['nrDocSistema'],
								'st_cd-tipo-insumo'         => $valores['cdTipoInsumo'],
								'st_cd-insumo'              => $valores['cdInsumo'],
								'st_nr-processo'            => $valores['nrProcesso'],
								'st_nr-seq-digitacao'       => $valores['nrSeqDigitacao']);

				array_push($ct_ttCustosEntradaRow,$item);

			}

			$status = array('ct_ttCustosEntrada' => array('ct_ttCustosEntradaRow' => $ct_ttCustosEntradaRow));

			$result = $DRG->atualizaStatusCustoPaciente($status);

		}else{

			$escreve  = $dados->{'cd-remessa'}.";";
			$escreve .= $senhaEnvio.";";
			$escreve .= $dados->{'cd-prestador-drg'}.";";
			$escreve .= $dados->{'ds-usuario-iag'}.";";
			$escreve .= $dados->{'ds-senha-iag'}.";";
			$escreve .= $dados->{'cd-unidade-carteira'}."".str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT).";";
			$escreve .= $dados->{'nm-paciente'}.";";
			$escreve .= ";";
			$escreve .= "INCLUIR;";
			$escreve .= $dados->{'cd-item-consumo'}.";";
			$escreve .= trim($dados->{'ds-item-consumo'}).";";
			$escreve .= $dados->{'cd-grupo-consumo'}.";";
			$escreve .= $dados->{'qt-item-consumo'}.";";
			$escreve .= $dados->{'ds-data-hora'}.";";
			$escreve .= $dados->{'vl-unitario-consumo'}.";";
			$escreve .= $dados->{'vl-total-consumo'}.";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= $dados->{'cd-prestador'}.";";
			$escreve .= trim($dados->{'ds-prestador'}).";";
			$escreve .= $dados->{'cd-unidade'}.";";
			$escreve .= $dados->{'cd-unidade-prestadora'}.";";
			$escreve .= $dados->{'cd-transacao'}.";";
			$escreve .= $dados->{'nr-serie-doc-original'}.";";
			$escreve .= $dados->{'nr-doc-original'}.";";
			$escreve .= $dados->{'nr-doc-sistema'}.";";
			$escreve .= $dados->{'cd-tipo-insumo'}.";";
			$escreve .= $dados->{'cd-insumo'}.";";
			$escreve .= $dados->{'nr-processo'}.";";
			$escreve .= $dados->{'nr-seq-digitacao'}.";";
			$escreve .= ";";
			$escreve .= trim($dadosRetorno->{'descricaoErro'})."\n";

			fwrite($erro,$escreve);

			$gerouErro = true;

		}


	}*/

	$retorno = array();

	$retorno['ok'] = 1;

	if($gerouErro){
		$retorno['gerouErro']   = $gerouErro;
		$retorno['arquivoErro'] = "custos-nao-importados.csv";
	}


	echo json_encode($retorno);




}

function gerarArquivoCSV(){

	$ok = 1;
	$msg = "";

	$dadosSaida  = array();
	$saidaTabela = array();
	$tabela = "";

	$anoIni         = $_POST['anoIni'];
	$anoFim         = $_POST['anoFim'];
	$periodoIni     = $_POST['periodoIni'];
	$periodoFim     = $_POST['periodoFim'];
	$arquivoEntrada = $_POST['arquivoEntrada'];
	$hospital       = $_POST['hospital'];

	$hora = date("His");

	/*$anoIni     = 2018;
	$anoFim     = 2018;
	$periodoIni = 71;
	$periodoFim = 71;
	$hospital   = 264;*/
	//$arquivoEntrada = "teste_drg_set.csv";

	//$path = "c:/xampp/htdocs/html/octopus-temp/arquivos/php/files/".$arquivoEntrada;

	//print $path;

	$path = "/var/www/html/octopus-temp/arquivos/php/files/senhas-".$periodoIni."-".$anoIni."_a_".$periodoFim."-".$anoFim."-".$hospital."-".$hora.".csv";
	//$path = "c://xampp//htdocs//octopus-temp//arquivos//php//files//senhas-".$periodoIni."-".$anoIni."_a_".$periodoFim."-".$anoFim."-".$hospital."-".$hora.".csv";

	//print $path;

	$arquivo = "senhas-".$periodoIni."-".$anoIni."_a_".$periodoFim."-".$anoFim."-".$hospital."-".$hora.".csv";

	$arquivoSaida = fopen($path,"w");

	$cabecalho  = "cd-unidade-carteira;cd-carteira;nm-paciente;dt-internacao;senha\n";

	$escrita = fwrite($arquivoSaida,$cabecalho);

	$senhas = null;

	$DRG = new DRG();

	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,$hospital,"prod");

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){

					if($dados->{'ds-senha'} == ""){

						  $senhas[$dados->{'cd-unidade-carteira'}.";".$dados->{'cd-carteira'}.";".$dados->{'nm-paciente'}.";".$dados->{'dt-internacao'}] = "";

						  //$escrita = fwrite($arquivoSaida,$dados->{'cd-unidade-carteira'}.";".$dados->{'cd-carteira'}.";".$dados->{'nm-paciente'}.";".$dados->{'dt-internacao'}.";\n");

					}

			}

		}

	}

	foreach($senhas as $key => $linhas){

		$escrita = fwrite($arquivoSaida,$key.";\n");

	}

	fclose($arquivoSaida);

	$retorno['ok']      = $ok;
	$retorno['arquivo'] = $arquivo;

	echo json_encode($retorno);

}

function enviaDRG(){

	$ok = 0;
	$msg = "";
	$retorno = array();

	$arrayInfo = array();

	$dadosSaida    = array();
	$saidaTabela   = array();
	$dadosControle = array();
	$tabela        = "";
	$gerouErro     = false;

	$hora = date("His");

	$utils = new Utils();

	$anoIni         = $_POST['anoIni'];
	$anoFim         = $_POST['anoFim'];
	$periodoIni     = $_POST['periodoIni'];
	$periodoFim     = $_POST['periodoFim'];
	$arquivoEntrada = $_POST['arquivoEntrada'];
	$hospital       = $_POST['hospital'];

	/*$anoIni = 2018;
	$anoFim = 2018;
	$periodoIni = 71;
	$periodoFim = 71;
	$hospital = 264;
	$arquivoEntrada = "senhas-71-2018_a_71-2018-264-160057.csv";*/
	//$arquivoEntrada = "";

	$arquivoSaida = "/var/www/html/octopus-temp/arquivos/php/files/custos-importados-".$periodoIni."-".$anoIni."_a_".$periodoFim."-".$anoFim."-".$hospital."-".$hora.".csv";
	//$arquivoSaida = "c://xampp//htdocs//octopus-temp//arquivos//php//files//custos-importados.csv";
	$arquivoFront = "custos-importados-".$periodoIni."-".$anoIni."_a_".$periodoFim."-".$anoFim."-".$hospital."-".$hora.".csv";
	//$arquivoSaida = "c://xampp//htdocs//octopus-temp//arquivos//php//files//custos-importados-".$periodoIni."-".$anoIni."_a_".$periodoFim."-".$anoFim."-".$hospital."-".$hora.".csv";

	$importado = fopen($arquivoSaida,"w");

	fwrite($importado,"SENHA;DESCRICAO\n");

	$senhas = null;

	if($arquivoEntrada != ""){

		$path = "/var/www/html/octopus-temp/arquivos/php/files/".$arquivoEntrada;
		//$path = "c://xampp//htdocs//octopus-temp//arquivos//php//files//".$arquivoEntrada;

		$file = fopen($path,"r");

		$count = 0;

		while (!feof ($file)) {

			$linha = fgets($file,4096);

			if($count != 0){
				$vetor =  explode(";",$linha);

				$senhas[$vetor['0'].';'.$vetor['1'].';'.$vetor['2'].';'.$vetor['3']] = $vetor['4'];

				$count++;

			}else{

				$count++;

			}
		}
	}

/*	print "<pre>";
	print_r($senhas);
	print "</pre>";*/

	$DRG = new DRG();

	$senha = "senhaInicial";
	$inicioLote = true;
	$xml = "";


	$resultadoSenhas = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,$hospital,"prod");

	foreach($resultadoSenhas as $resultadoParcialSenhas){

		foreach($resultadoParcialSenhas as $registrosSenhas){

			foreach($registrosSenhas as $dadosSenhasBusca){

				if($dadosSenhasBusca->{'ds-senha'} != ""){

					$vetorSenhas[$dadosSenhasBusca->{'ds-senha'}] = $dadosSenhasBusca->{'ds-senha'};

				}else{

					if($arquivoEntrada != ""){

						$vetorSenhas[trim($senhas[$dadosSenhasBusca->{'cd-unidade-carteira'}.";".$dadosSenhasBusca->{'cd-carteira'}.";".$dadosSenhasBusca->{'nm-paciente'}.";".$dadosSenhasBusca->{'dt-internacao'}])] = trim($senhas[$dadosSenhasBusca->{'cd-unidade-carteira'}.";".$dadosSenhasBusca->{'cd-carteira'}.";".$dadosSenhasBusca->{'nm-paciente'}.";".$dadosSenhasBusca->{'dt-internacao'}]);

					//$vetorSemSenhas[$dadosSenhasBusca->{'cd-carteira'}] = $dadosSenhasBusca->{'cd-carteira'}.";".$dadosSenhasBusca->{'nm-paciente'};


				  }

				}

			}

		}

	}

/*	print "<pre>";
	print_r($vetorSenhas);
	print "</pre>";*/

	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,$hospital,"prod");


	$arraySaida = array();

	$arrayQtde = array();

foreach($vetorSenhas as $keySenhas => $dadosSenhas){

	$senha = trim($dadosSenhas);
	$inicioLote = true;
	$xml = "";

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){

				if(trim($dados->{'ds-senha'}) == "" && $arquivoEntrada != ""){
					//print trim($senhas[$dados->{'cd-unidade-carteira'}.";".$dados->{'cd-carteira'}.";".$dados->{'nm-paciente'}.";".$dados->{'dt-internacao'}])."<br>";
					$senhaCorreta = trim($senhas[$dados->{'cd-unidade-carteira'}.";".$dados->{'cd-carteira'}.";".$dados->{'nm-paciente'}.";".$dados->{'dt-internacao'}]);
				}else{
					$senhaCorreta = trim($dados->{'ds-senha'});
				}

				//print $dados->{'ds-senha'}."<br>";
				//print $dadosSenhas."<br><br><br>";

				//print $dados->{'vl-unitario-consumo'}."<br>";

				//$senhaNova = "";

				//if(trim($dados->{'ds-senha'}) == $senha){
				if($senhaCorreta == $senha){

					//print "aqui<br>";

				//if($dados->{'ds-senha'} != ""){
				if($senhaCorreta != ""){

				//	$pass = $dados->{'ds-senha-iag'};

					$dataHora =  $utils->data_mysql(substr($dados->{'ds-data-hora'},0,10))."T".substr($dados->{'ds-data-hora'},11).":00";

					if($inicioLote){

						$user = $dados->{'ds-usuario-iag'};
						$unidade = $dados->{'cd-unidade-carteira'};
						$carteira = $dados->{'cd-carteira'};
						$nome = $dados->{'nm-paciente'};
						$dataInternacao = $dados->{'dt-internacao'};

						$arrayInfo[$dados->{'ds-senha'}] = $unidade.".".$carteira . " - " . $nome . " - " . $dataInternacao;

						$xml .= "<loteCustoPaciente>
						        <CustoPaciente>
									<codigo>".$dados->{'cd-remessa'}."</codigo>
									<numeroAutorizacao>".$senhaCorreta."</numeroAutorizacao>
									<numeroAtendimento></numeroAtendimento>
									<acao>SUBSTITUIR</acao>";

							$xml .= "<ItemCustoPaciente>
									<codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
									<descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
									<codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
									<quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
									<dataConsumo>$dataHora</dataConsumo>
									<valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
									<valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
									<descricaoFornecedor>".trim(str_replace("&","e",$dados->{'ds-prestador'}))."</descricaoFornecedor>
									</ItemCustoPaciente>";

						$inicioLote = false;
						//$senha = $dados->{'ds-senha'};
						$senha =$senhaCorreta;

						$arrayQtde[$senha] = 1;

					}else{

							$arrayQtde[$dados->{'ds-senha'}]++;

						//if($senha != $dados->{'ds-senha'}){

						//	$xml .= "</CustoPaciente></loteCustoPaciente>";

						//	$inicioLote = true;
						//	$senha = "senhaInicial";

						//}else{

							$xml .= "<ItemCustoPaciente>
									<codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
									<descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
									<codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
									<quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
									<dataConsumo>$dataHora</dataConsumo>
									<valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
									<valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
									<descricaoFornecedor>".trim(str_replace("&","e",$dados->{'ds-prestador'}))."</descricaoFornecedor>
									</ItemCustoPaciente>";

						//}


					}

				}

			}


			}

		}

	}

	$xml .= "</CustoPaciente></loteCustoPaciente>";

	//$user = "BrUN0B0rn-264";
	$pass = "hhtY3";
	$pass .= "$";
	$pass .= "G91";
	$options = array('trace' => 1, 'exceptions' => 1, 'cache_wsdl' => WSDL_CACHE_NONE, 'connection_timeout' => 3000);
	$wsdl = "https://iagwebservice.sigquali.com.br/iagwebservice/enviaDadosCustoPaciente?wsdl";

			try{
				$envio = new SoapClient($wsdl,$options);
				$paramsDrg = array('xml'        => $xml,
								'usuarioIAG' => $user,
								'senhaIAG'   => $pass);
				$resultadoDrg = $envio->enviaDadosCustoPaciente($paramsDrg);

				$xml_object = simplexml_load_string($resultadoDrg->{'return'});

				array_push($arraySaida,$xml_object);
				$ok = 1;
			}catch(SoapFault $exceptionDrg){

				//array_push($arraySaida,$exceptionDrg);
			}

}
/*
print "<pre>";
print_r(htmlentities($xml));
print "</pre>";*/



foreach($arraySaida as $dadosRetorno){

	foreach($dadosRetorno->{'CustoPaciente'} as $dadosFinais){


	//2297091517

		if($dadosFinais->{"codigoErro"} != ""){

			//if($dadosFinais->{"codigoErro"} == 2){

				fwrite($importado,$dadosFinais->{'numeroAutorizacao'} . ";" . $arrayInfo["".$dadosFinais->{'numeroAutorizacao'}.""] . " ----> " . utf8_decode(trim($dadosFinais->{'descricaoErro'}))."\n");

			//}else{

			//	fwrite($importado,$dadosFinais->{'numeroAutorizacao'} . ";" . utf8_decode(trim($dadosFinais->{'descricaoErro'}))."\n");

			//}

		}else{

			fwrite($importado,$dadosFinais->{'numeroAutorizacao'} . ";" ."Custo Importado com Sucesso\n");

		}


	}

}

fclose($arquivoSaida);

$retorno['arquivo'] = $arquivoFront;
$retorno['ok'] = $ok;

echo json_encode($retorno);

//var_dump($arraySaida->{'CustoPaciente'});



	/*print "<pre>";
	print_r(htmlentities($xml));
	print "</pre>";*/

}

?>
