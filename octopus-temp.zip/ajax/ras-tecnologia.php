<?php
//ini_set('display_errors', "on");
//ini_set('error_reporting', E_ALL & ~E_NOTICE);
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/RAsTecnologia.class.php");
session_start();

if($_GET['acao']  == 'buscaRAs'){
	buscaRAs();
}/*else if($_GET['acao']  == 'buscaChamadosRA'){
	buscaChamadosRA();
}*/

function buscaRAs(){

	$retorno = array();
	$lista = array();
    
	$atendente = $_POST['atendente'];
	//$atendente = 'tecnologia';
	
	$web = new RAsTecnologia();
	
	$ras = $web->buscaRAs(0,$atendente);
	
	if(is_array($ras)){
		$ok = 1;
	}else{
		$ok = 0;
	}
	
	$retorno['ok']  = $ok;
	$retorno['ras'] = $ras;
	echo json_encode($retorno);
}

/*function buscaChamadosRA(){

	$retorno = array();
    
	$web = new RAsTecnologia();
	
	$chamados = $web->buscaChamadosRA();
	$chamados = (array)$chamados;
	
	if(is_array($chamados) && count($chamados) > 0){
		$ok = 1;
	}else{
		$ok = 0;
	}
	
	$retorno['ok']       = $ok;
	$retorno['chamados'] = $chamados;
	echo json_encode($retorno);
}*/

?>