<?php
print date("H:i:s");
?>