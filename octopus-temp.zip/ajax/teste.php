<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Planos.class.php");

$plano = new Planos();

	$planos = $plano->listaPlanos();

print "<pre>";
print_r($planos);
print "<pre>";

?>