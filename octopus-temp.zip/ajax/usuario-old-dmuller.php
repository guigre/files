<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Departamentos.class.php");
include("../classes/Privilegios.class.php");
session_start();

//$_GET['acao']  = 'login';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'login'){
	login();
}else if($_GET['acao']  == 'listaUsuarios'){
	listaUsuarios();
}else if($_GET['acao']  == 'buscaUsuario'){
	buscaUsuario();
}else if($_GET['acao']  == 'desativaUsuario'){
	desativaUsuario();
}else if($_GET['acao']  == 'montaDepartamentos'){
	montaDepartamentos();
}else if($_GET['acao']  == 'montaResponsavel'){
	montaResponsavel();
}

function salvar(){
	$ok = 0;
	$msg = "";
	
	$codigo        = $_POST['codigoCadastro'];
	$usuarioCad    = $_POST['usuarioCadastro'];
	$email         = $_POST['emailCadastro'];
	$login         = $_POST['loginCadastro'];
	$privilegio    = $_POST['privilegioCadastro'];
	$status        = $_POST['statusCadastro'];
	$departamentos = $_POST['departamentosCadastro'];
	
	/*$codigo        = "";
	$departamentos = array("5","7","20");*/	
	
	$usuario = new Usuarios();
	
	if($codigo == ""){ // Cadastra
		if(!$usuario->existeUsuario($login)){
			if($usuario->cadastraUsuario($usuarioCad,$login,"",$privilegio,$email,$status,$departamentos)){
				$ok = 1;
				$msg = "Usuário Cadastrado com Sucesso!";
			}else{
				$ok = 0;
				$msg = "Problemas ao cadastrar o usuário, verificar com o Administrador do sistema.";
			}
		}else{
			$msg = "Este usuário já existe no sistema.";
			$ok = 0;	
		}
	}else{ // Atualiza
		if($usuario->atualizaUsuario($codigo,$usuarioCad,$privilegio,$email,$status,$departamentos)){
			$ok = 1;
			$msg = "Usuário Atualizado com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao atualizar o usuário, verificar com o Administrador do sistema.";			
		}
	}	
	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

/*function login(){
	$ok = 0;
	$msg = "";

	$login = addslashes(strip_tags($_POST['login']));
	$senha = addslashes(strip_tags($_POST['senha']));
	
    //$login = "ggregory";
	//$senha = "unimed";
	
	$usuario = new Usuarios();
	
	$retorno = array();
		
	if($usuario->loginSistema($login,$senha)){
		$_SESSION['nome']  = "".$usuario->ds_usuario;	
		$_SESSION['login'] = "".$usuario->ds_login;
		$_SESSION['iniciou'] = "sim";
		$_SESSION['id']    = "".$usuario->id;	
		$ok = 1;
	}else{
		$msg = "E-mail e/ou senha inv&aacute;lida";
	}
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}*/

function listaUsuarios(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$usuario = new Usuarios();
	
	$usuarios = $usuario->listaUsuarios();
	
	$tabela .= "<table id='tabelaUsuarios' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>C&oacute;digo</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Tipo</th>
                        <th>Status</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($usuarios as $dados){
		
		if($dados[4] == "A"){
			$privilegio = "Administrador";
		}else{
			$privilegio = "Usuário";
		}
		if($dados[6] == "A"){
			$status = "Ativo";
		}else{
			$status = "Inativo";
		}
		
		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
                       <td>".$dados[5]."</td>
                       <td>$privilegio</td>
                       <td>$status</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0]."))'>Editar</button></td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaUsuario(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 1;	
		
    $usuario = new Usuarios();
	
	$dados = $usuario->buscaUsuario($codigo);	
	
	if($dados){		
		$retorno['codigo']        = $usuario->id;
		$retorno['usuario']       = $usuario->ds_usuario;
		$retorno['email']         = $usuario->ds_email;
		$retorno['login']         = $usuario->ds_login;
		$retorno['privilegio']    = $usuario->ds_privilegio;
		$retorno['status']        = $usuario->ds_status;
		$retorno['departamentos'] = $usuario->departamentos;
		$ok = 1;		
	}else{
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);		
	
}

function desativaUsuario(){
	
	$ok = 0;
	$msg = "";
	$retorno = array();	
	
	$codigo = $_POST['codigo'];
		
	//$codigo = 1;	
		
    $usuario = new Usuarios();
	
	$dados = $usuario->desativaUsuario($codigo);	
	
	if($dados){		
		$msg = "Usuário Excluído com Sucesso!";
		$ok = 1;		
	}else{
		$msg = "Problemas ao excluir o usuário, verificar com o Administrador do sistema.";
		$ok = 0;
	}	
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function montaDepartamentos(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$departamento = new Departamentos();
	
	$departamentos = $departamento->listaDepartamentosByDescricao();
	
	$select .= "<select class='form-control select2' multiple='multiple' data-placeholder='Selecione o Departamento' style='width:100%;' id='departamentosCadastro'>";
	
	foreach($departamentos as $dados){
		
		$select .= "<option value=$dados[0]>$dados[1]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

function montaResponsavel(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$usuario = new Usuarios();
	
	$usuarios = $usuario->listaUsuarios();
	
	$select .= "<select class='form-control' id='responsavelCadastro'>
	            <option value=''>:: Selecione ::</option>";
	
	foreach($usuarios as $dados){
		
		$select .= "<option value=$dados[0]>$dados[1]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = $select;
	echo json_encode($retorno);
}

function valida_ldap($srv, $usu, $pass)
{
    $ldap_server = $srv;
	
	$LDAPUser = "cn=ldap,ou=Sede,dc=unimedvtrp,dc=com,dc=br";        //A valid Active Directory login
	$LDAPUserPassword = "unimedvtrp";
	$SearchFor=$usu;           //What string do you want to find?

    $auth_user   = $usu."@unimedvtrp.com.br";
    $auth_pass   = $pass;
	$dn = "dc=unimedvtrp,dc=com,dc=br"; //Put your Base DN here
	$LDAPFieldsToFind = array("displayname", "samaccountname", "mail");
	
    // Tenta se conectar com o servidor
    if (!($connect = @ldap_connect($ldap_server))){
	
		return 0;	   
			   
    }
	
	ldap_set_option($connect, LDAP_OPT_PROTOCOL_VERSION, 3);  //Set the LDAP Protocol used by your AD service
	ldap_set_option($connect, LDAP_OPT_REFERRALS, 0);         //This was necessary for my AD to do anything
	ldap_set_option($connect, LDAP_OPT_SIZELIMIT, 1000);

    // Tenta autenticar no servidor
    if (!($bind = @ldap_bind($connect, $auth_user, $auth_pass))) {
	
		return 0;
		
    } else {
		
		$_SESSION['usuario'] = $usu;
		$_SESSION['senha']   = $auth_pass;
		$_SESSION['iniciou'] = 'sim';
		$_SESSION['menu_indic_gerais'] = false;
		$_SESSION['menu_indic_ti'] = false;
		$_SESSION['menu_sis_aten'] = false;
		$_SESSION['menu_privilegios'] = false;
		$_SESSION['menu_sms'] = false;
		$_SESSION['menu_ras_ti'] = false;
		$_SESSION['menu_controle_acesso_ti'] = false;
		$_SESSION['menu_acesso_restrito'] = false;
		$_SESSION['lista_nome_usuarios'] = '';
		$_SESSION['lista_email_usuarios'] = '';
		
		/*$filter="(&(objectclass=*))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['name'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['name'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
				break;
			}
		}*/
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Butia,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Cachoeirinha,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Charqueadas,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Encantado,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Estrela,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Lajeado,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Rio de Janeiro,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Rio Pardo,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Santa Cruz do Sul,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores São Jerônimo,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores São Paulo,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Taquari,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Teutonia,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Uberlândia,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		$filter="(&(objectClass=person)(memberof=CN=\*Colaboradores Venancio Aires,OU=Grupos de Distribuicao,OU=Contatos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			$_SESSION['lista_nome_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['displayname'][0];
			$_SESSION['lista_email_usuarios'][$info[$x]['samaccountname'][0]] .= $info[$x]['mail'][0];
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['nome'] = $info[$x]['displayname'][0];
				$_SESSION['mail'] = $info[$x]['mail'][0];
			}
		}
		
		//var_dump($_SESSION['lista_nome_usuarios']);
		asort($_SESSION['lista_nome_usuarios']);
		
		$filter="(&(objectClass=person)(memberof=CN=Tecnologia da Informação,OU=Areas,OU=Grupos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
		
			if ($info[$x]['samaccountname'][0] == $SearchFor){
			       $_SESSION['menu_indic_ti'] = true;
				$_SESSION['menu_ras_ti'] = true;
				$_SESSION['menu_controle_acesso_ti'] = true;
				break;
			}
		}
		
		/*$filter="(&(objectClass=person)(memberof=CN=Promoção à Saúde,OU=Areas,OU=Grupos,DC=unimedvtrp,DC=com,DC=br)(!(userAccountControl=66050))(!(userAccountControl=614)))";
		$sr=ldap_search($connect, $dn, $filter, $LDAPFieldsToFind);
		$info = ldap_get_entries($connect, $sr);
		
		for ($x=0; $x<$info["count"]; $x++) {
			if ($info[$x]['samaccountname'][0] == $SearchFor){
				$_SESSION['menu_sms'] = true;
				break;
			}
		}*/
		
		$privilegios = new Privilegios();
		
		if($privilegios->existePrivilegio($usu, 'Indicadores Gerais')){
			$_SESSION['menu_indic_gerais'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'Indicadores TI')){
			$_SESSION['menu_indic_ti'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'Sistema Atendimento')){
			$_SESSION['menu_sis_aten'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'Privilégios')){
			$_SESSION['menu_privilegios'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'SMS')){
			$_SESSION['menu_sms'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'menu_ras_ti')){
			$_SESSION['menu_ras_ti'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'Simula Acesso Coop')){
			$_SESSION['menu_acesso_restrito'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'Comercialização')){
			$_SESSION['menu_comercializacao'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'Controle Acessos TI')){
			$_SESSION['menu_controle_acesso_ti'] = true;
		}
		if($privilegios->existePrivilegio($usu, 'DRG')){
			$_SESSION['menu_drg'] = true;
		}				
		
		return 1;
    }

} // fim funcao conectar ldap

function login(){

	$server = "unimedvtrp.com.br";

	$ok = 0;
	$msg = "";

	$login = addslashes(strip_tags($_POST['login']));
	$senha = addslashes(strip_tags($_POST['senha']));
	
	//$login = "dmuller";
	//$senha = "";
	
	$retorno = array();
	
	if (valida_ldap($server, $login, $senha) == 1){
		
		$retorno['ok'] = 1;	
			
	}else{
	
		$msg = "Usuário e/ou senha incorreto(s).";
	
		$retorno['msg'] = $msg;	
	
	}
	
	echo json_encode($retorno);
}

?>