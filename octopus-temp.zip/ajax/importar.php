<?php
set_time_limit(0);
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/SQL.class.php");
session_start();

//Math.round(number).toFixed(2);
$_GET['acao'] = 'importarDados';

if($_GET['acao']  == 'importarDados'){
	importarDados();
}

function importarDados(){

	$utils = new Utils();
	$utils->abreConexaoOracle();
	$ok = 0;
	$msg = "";
	$retorno = array();
	$array = array();
	
	
	
	//$mes = $_POST['mes'];
	//$ano = $_POST['ano'];
	
	$mes = "02";
	$ano = "2017";
	
	
	$sql = new SQL();
	$sqlInd = oci_parse($utils->conexaoOracle, "SELECT id, ds_indicador FROM indicador_ti ORDER BY id ASC");
	oci_execute($sqlInd);		
	
	
	while($row = oci_fetch_row($sqlInd)){

		//sleep(5);		
	
		$sql->buscaIndicador($row[0], $mes, $ano, $utils->conexaoOracle);
	
		$ok = 1;
	
	}
	
	if($sql->geraArquivoErros()){
		$msg = "Alguns indicadores não foram importados. Verifique no arquivo de erros no C:/temp/erros-indicadores.csv";
		$ok  = 0;
	}else{
		$msg = "Dados Importados com Sucesso.";
		$ok  = 1; 
	} 
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

?>