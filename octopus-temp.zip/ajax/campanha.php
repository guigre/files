<?php
include("../inc/config.php");
include("../lib/adodb/adodb.inc.php");
include("../classes/Utils.class.php");
include("../classes/Usuarios.class.php");
include("../classes/Campanha.class.php");
session_start();

//$_GET['acao'] = 'listaPerguntas';

if($_GET['acao']  == 'salvar'){
	salvar();
}else if($_GET['acao']  == 'listaCampanhas'){
	listaCampanhas();
}else if($_GET['acao']  == 'buscaCampanha'){
	buscaCampanha();
}else if ($_GET['acao'] == 'buscaProximoID'){
	buscaProximoID();
}

function salvar(){
	$ok = 0;
	$msg = "";

	$utils = new Utils();

	$idCampanha = $_POST['idCampanha'];
  $descricao  = $_POST['descricao'];
	$dataInicio = $_POST['dataInicio'];
	$dataFim    = $_POST['dataFim'];
	$acao       = $_POST['acao'];

	$campanha = new Campanha();

	if($acao == "cadastrar"){

		if($campanha->cadastraCampanha($idCampanha,
									   						   $descricao,
																 	 $dataInicio,
																 	 $dataFim)){
			$ok = 1;
			$msg = "Campanha Cadastrada com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao cadastrar a campanha, verificar com o Administrador do sistema.";
		}

	}

	if($acao == "atualizar"){

		if($campanha->atualizaCampanha($idCampanha,
								       					   $descricao,
																 	 $dataInicio,
																   $dataFim)){
			$ok = 1;
			$msg = "Campanha Atualizada com Sucesso!";
		}else{
			$ok = 0;
			$msg = "Problemas ao atualizar a campanha, verificar com o Administrador do sistema.";
		}


	}

	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function listaCampanhas(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";

	$campanha = new Campanha();

	$campanhas = $campanha->listaCampanhas();

	$tabela .= "<table id='tabelaCampanhas' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>DESCRI&Ccedil;&Atilde;O</th>
												<th>DATA INICIO</th>
												<th>DATA FIM</th>
						<th>&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>";

	foreach($campanhas as $dados){

		//print $dados[3]."<br>";

		$tabela .= "<tr>
                       <td>".$dados[0]."</td>
                       <td>".$dados[1]."</td>
											 <td>".$dados[2]."</td>
											 <td>".$dados[3]."</td>
					   <td><button type='button' class='btn btn-warning btn-xs' onclick='javascript:void(editar(".$dados[0]."))'>Editar</button></td>
                    </tr>";

		$ok = 1;
	}

	$tabela .= "</tbody></table>";

	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

function buscaCampanha(){

	$ok = 0;
	$msg = "";
	$retorno = array();

	$idCampanha = $_POST['idCampanha'];

  $campanha = new Campanha();

	$dados = $campanha->buscaCampanha($idCampanha);

	if($dados){
		$retorno['idCampanha'] = $campanha->idCampanha;
	  $retorno['descricao']  = $campanha->descricao;
		$retorno['dataInicio'] = $campanha->dataInicio;
		$retorno['dataFim']    = $campanha->dataFim;
		$ok = 1;
	}else{
		$ok = 0;
	}
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);

}

function buscaProximoID(){

	$ok = 0;
	$msg = "";
	$retorno = array();

  $campanha = new Campanha();

	$idCampanha = $campanha->buscaProximoID();

	$retorno['ok']         = $ok;
	$retorno['msg']        = ($msg);
	$retorno['idCampanha'] = $idCampanha;
	echo json_encode($retorno);

}

?>
