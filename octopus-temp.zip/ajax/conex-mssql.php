<?php
	$conexaoEPM = mssql_connect('srvdb9','indicador_epm','unimed029@');
	$baseEPM = mssql_select_db('ProjectServer_Reporting',$conexaoEPM);
	
	$sqlProjetos = utf8_decode("SELECT DISTINCT(p.ProjectName),
					       p.[Status do Projeto],
						   p.[Departamentos do Projeto],
						   p.[Responsável],
						   p.[Patrocinador],
						   p.ProjectOwnerName
					  FROM dbo.MSP_EpmProject_UserView p
				INNER JOIN dbo.MSP_EpmTask_UserView t 
						ON (p.ProjectUID = t.ProjectUID)
				INNER JOIN dbo.MSP_EpmAssignment_UserView a 
						ON ((a.ProjectUID = p.ProjectUID) 
					   AND  (a.TaskUID = t.TaskUID))
				INNER JOIN dbo.MSP_EpmResource_UserView r 
                        ON (a.ResourceUID = r.ResourceUID)
				INNER JOIN dbo.MSP_EpmWorkflowStatusInformation inf
						ON(inf.ProjectUID = p.ProjectUID
					   AND inf.StageStatus NOT IN (0,4))
				INNER JOIN dbo.MSP_EpmWorkflowStage sge
						ON(sge.StageUID = inf.StageUID)
					 WHERE r.EDR LIKE 'Unimed VTRP.Tecnologia da Informa%'
					   AND t.TaskIsActive = 'True'
					   AND sge.StageName <> 'Projeto Encerrado'
					   AND p.[Departamentos do Projeto] = 'Auditoria em Saúde'");

print $sqlProjetos."<br>";						
					   
					   
	$resultProjetos = mssql_query($sqlProjetos);
	
	var_dump($resultProjetos);	
?>