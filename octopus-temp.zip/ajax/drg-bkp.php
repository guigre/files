<?php
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/DRG.class.php");
session_start();
//ini_set('display_errors', 1);
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
Usuário: guilherme.gregory
Senha: Si6~]}Su
*/


//$_GET['acao']  = 'solicitaDadosCustosPaciente';

if($_GET['acao']  == 'solicitaDadosCustosPaciente'){
	solicitaDadosCustosPaciente();
}else if($_GET['acao']  == 'enviarDadosDRG'){
	enviarDadosDRG();
}else if($_GET['acao']  == 'gerarArquivoCSV'){
	gerarArquivoCSV();
}else if($_GET['acao']  == 'atualizaDRG'){
	atualizaDRG();

}

function atualizaDRG(){

	$user = "324_V4L3s-TSt";
	$pass = "gTT3";
	$pass .= "$";
	$pass .= "uk1W";

	//$xml = htmlentities($xml);

	$xml = "<loteCustoPaciente><CustoPaciente> <codigo>1</codigo> <numeroAutorizacao>1602419252</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> 
<acao>SUBSTITUIR</acao><ItemCustoPaciente> <codigoItemConsumo>31307060</codigoItemConsumo> <descricaoItemConsumo>LAPAROSCOPIA GINECOLOGICA COM OU SEM BIOPSIA (INCLUI A CROMO</descricaoItemConsumo> 
<codigoGrupoConsumo>998</codigoGrupoConsumo> <quantidadeItemConsumo>1</quantidadeItemConsumo> <dataConsumo>2016-11-21T15:05:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> 
<valorCustoTotal>100</valorCustoTotal> <valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> <valorCustoVariavelIndireto></valorCustoVariavelIndireto> 
<valorCustoFixoIndireto></valorCustoFixoIndireto> <valorDeducoes></valorDeducoes> 
<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> <valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>5460</codigoFornecedor> 
<descricaoFornecedor>TELMO ANTONIO PADILHA GARCIA</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
<CustoPaciente> <codigo>51</codigo> <numeroAutorizacao>2260856</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> <acao>SUBSTITUIR</acao><ItemCustoPaciente> <codigoItemConsumo>31005497</codigoItemConsumo> 
<descricaoItemConsumo>COLECISTECTOMIA SEM COLANGIOGRAFIA POR VIDEOLAPAROSCOPIA</descricaoItemConsumo> <codigoGrupoConsumo>998</codigoGrupoConsumo> <quantidadeItemConsumo>1</quantidadeItemConsumo> 
<dataConsumo>2016-11-24T08:05:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> <valorCustoTotal>100</valorCustoTotal> <valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> 
<valorCustoVariavelIndireto></valorCustoVariavelIndireto> <valorCustoFixoIndireto></valorCustoFixoIndireto> <valorDeducoes></valorDeducoes> <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> 
<valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>34735</codigoFornecedor> <descricaoFornecedor>GUSTAVO GRUN</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
<CustoPaciente> <codigo>151</codigo> <numeroAutorizacao>2305561</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> <acao>SUBSTITUIR</acao><ItemCustoPaciente> 
<codigoItemConsumo>31103456</codigoItemConsumo> <descricaoItemConsumo>TUMOR VESICAL - RESSECCAO ENDOSCOPICA</descricaoItemConsumo> <codigoGrupoConsumo>998</codigoGrupoConsumo> 
<quantidadeItemConsumo>1</quantidadeItemConsumo> <dataConsumo>2016-11-17T14:45:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> <valorCustoTotal>100</valorCustoTotal> 
<valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> <valorCustoVariavelIndireto></valorCustoVariavelIndireto> <valorCustoFixoIndireto></valorCustoFixoIndireto> 
<valorDeducoes></valorDeducoes> <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> <valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>30946</codigoFornecedor> 
<descricaoFornecedor>FELIPE GORNICKI SCHNEIDER</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
<CustoPaciente> <codigo>212</codigo> <numeroAutorizacao>1600597171</numeroAutorizacao> <numeroAtendimento></numeroAtendimento> <acao>SUBSTITUIR</acao><ItemCustoPaciente> 
<codigoItemConsumo>40804038</codigoItemConsumo> <descricaoItemConsumo>RX DA ARTICULACAO COXOFEMORAL (QUADRIL)</descricaoItemConsumo> <codigoGrupoConsumo>4</codigoGrupoConsumo> 
<quantidadeItemConsumo>1</quantidadeItemConsumo> <dataConsumo>2016-11-30T07:27:00</dataConsumo> <valorCustoUnitario>100</valorCustoUnitario> <valorCustoTotal>100</valorCustoTotal> 
<valorCustoVariavelDireto></valorCustoVariavelDireto> <valorCustoFixoDireto></valorCustoFixoDireto> <valorCustoVariavelIndireto></valorCustoVariavelIndireto> <valorCustoFixoIndireto></valorCustoFixoIndireto> 
<valorDeducoes></valorDeducoes> <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo> <valorReceitaUnitario></valorReceitaUnitario> <valorReceitaTotal></valorReceitaTotal> <codigoFornecedor>20000023</codigoFornecedor> 
<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
</ItemCustoPaciente>
</CustoPaciente>
</loteCustoPaciente>";

//	$xml_object = simplexml_load_string($xml);

	$DRG = new DRG();		

	$rs = $DRG->enviarDadosDRG($xml,$user,$pass);

	$xml_object = simplexml_load_string($rs->{'return'});

	print "<pre>";
	print_r($xml_object);
	print "</pre>";


}


function solicitaDadosCustosPaciente(){
	$ok = 0;
	$msg = "";

	$dadosSaida  = array();
	$saidaTabela = array();
	$tabela = "";

	$anoIni     = $_POST['anoIni'];
	$anoFim     = $_POST['anoFim'];
	$periodoIni = $_POST['periodoIni'];
	$periodoFim = $_POST['periodoFim'];
	$hospital   = $_POST['hospital'];

	/*$anoIni     = 2017;
	$anoFim     = 2017;
	$periodoIni = 41;
	$periodoFim = 42;
	$hospital   = "264";*/

	$DRG = new DRG();
	
	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,"prod");


	$tabela = "<table id='tabelaDados' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Senha</th>
						<th>Unidade</th>
						<th>Carteira</th>
                        <th>Nome Paciente</th>
						<th>Qtde Itens</th>
						<th>Vl Total</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	$senha = "";	

	$count = 1;			

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){
				
				if($dados->{'cd-prestador-drg'} == $hospital){
				
					$dadosSaida[$count]['cd-remessa']                 = $dados->{'cd-remessa'};
					$dadosSaida[$count]['ds-senha']                   = $dados->{'ds-senha'};
					$dadosSaida[$count]['nr-atendimento']             = $dados->{'nr-atendimento'};
					$dadosSaida[$count]['ds-acao']                    = $dados->{'ds-acao'};
					$dadosSaida[$count]['cd-item-consumo']            = $dados->{'cd-item-consumo'};
					$dadosSaida[$count]['ds-item-consumo']            = $dados->{'ds-item-consumo'};
					$dadosSaida[$count]['cd-grupo-consumo']           = $dados->{'cd-grupo-consumo'};
					$dadosSaida[$count]['qt-item-consumo']            = $dados->{'qt-item-consumo'};
					$dadosSaida[$count]['ds-data-hora']               = $dados->{'ds-data-hora'};
					$dadosSaida[$count]['vl-unitario-consumo']        = $dados->{'vl-unitario-consumo'};
					$dadosSaida[$count]['vl-total-consumo']           = $dados->{'vl-total-consumo'};
					$dadosSaida[$count]['vl-custo-variavel-direto']   = $dados->{'vl-custo-variavel-direto'};
					$dadosSaida[$count]['vl-custo-fixo-direto']       = $dados->{'vl-custo-fixo-direto'};
					$dadosSaida[$count]['vl-custo-variavel-indireto'] = $dados->{'vl-custo-variavel-indireto'};
					$dadosSaida[$count]['vl-custo-fixo-indireto']     = $dados->{'vl-custo-fixo-indireto'};
					$dadosSaida[$count]['vl-deducoes']                = $dados->{'vl-deducoes'};
					$dadosSaida[$count]['qt-receita']                 = $dados->{'qt-receita'}; 
					$dadosSaida[$count]['vl-unitario-receita']        = $dados->{'vl-unitario-receita'};
					$dadosSaida[$count]['vl-total-receita']           = $dados->{'vl-total-receita'};
					$dadosSaida[$count]['cd-prestador']               = $dados->{'cd-prestador'};
					$dadosSaida[$count]['ds-prestador']               = $dados->{'ds-prestador'}; 
					$dadosSaida[$count]['cd-prestador-drg']           = $dados->{'cd-prestador-drg'};
					$dadosSaida[$count]['ds-usuario-iag']             = $dados->{'ds-usuario-iag'};
					$dadosSaida[$count]['ds-senha-iag']               = $dados->{'ds-usuario-iag'};

					$count++;

					

					if($dados->{'ds-senha'} != $senha){
						$senha = $dados->{'ds-senha'};

						$saidaTabela[$senha]['senha']      = $senha;
						$saidaTabela[$senha]['unidade']    = $dados->{'cd-unidade-carteira'};
						$saidaTabela[$senha]['carteira']   = str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT);
						$saidaTabela[$senha]['nome']       = $dados->{'nm-paciente'};
						$saidaTabela[$senha]['quantidade'] = $dados->{'qt-item-consumo'};
						$saidaTabela[$senha]['valor']      = $dados->{'vl-total-consumo'};

					}else{

						if($saidaTabela[$senha]['senha'] === $dados->{'ds-senha'}){

							$saidaTabela[$senha]['quantidade'] = $saidaTabela[$senha]['quantidade'] + $dados->{'qt-item-consumo'};
							$saidaTabela[$senha]['valor']      = $saidaTabela[$senha]['valor'] + str_replace(",",".",$dados->{'vl-total-consumo'});	

							$senha = $dados->{'ds-senha'};						

						}	

					}

				}	

			}			

		}

	}

	foreach($saidaTabela as $saidaDados){

		$tabela .= "<tr>
					<td>".$saidaDados['senha']."</td>
					<td>".$saidaDados['unidade']."</td>
					<td>".$saidaDados['carteira']."</td>
					<td>".$saidaDados['nome']."</td>
					<td>".$saidaDados['quantidade']."</td>
					<td>R$ ".number_format(str_replace(".",".",$saidaDados['valor']),2,',','.')."</td>
					</tr>";				
		$ok = 1;

	}

	$tabela .= "</tbody></table>";


	/*print "<pre>";
	print_r($tabela);
	print "<pre>";*/



	$retorno = array();
	$retorno['ok'] = $ok;
	$retorno['msg'] = ($msg);
	$retorno['tabela'] = $tabela;
	$retorno['saida'] = $dadosSaida;

	echo json_encode($retorno);
}

function enviarDadosDRG(){
	$ok = 0;
	$msg = "";

	$dadosSaida    = array();
	$saidaTabela   = array();
	$dadosControle = array();
	$tabela        = "";
	$gerouErro     = false; 

	$utils = new Utils();

	$anoIni         = $_POST['anoIni'];
	$anoFim         = $_POST['anoFim'];
	$periodoIni     = $_POST['periodoIni'];
	$periodoFim     = $_POST['periodoFim'];
	$arquivoEntrada = $_POST['arquivoEntrada'];
	$hospital       = $_POST['hospital'];

	/*$anoIni = 2017;
	$anoFim = 2017;
	$periodoIni = 051;
	$periodoFim = 052;
	$arquivoEntrada = "";*/

	$arquivoErro = "/var/www/html/octopus-temp/arquivos/php/files/custos-nao-importados.csv";

	$erro = fopen($arquivoErro,"w");

	fwrite($erro,"COD. REMESSA;SENHA;PRESTADOR DRG;USUARIO IAG;SENHA IAG;CARTEIRA;NOME;NR. ATENDIMENTO;ACAO;COD.ITEM CONSUMO;DESC.ITEM CONSUMO;COD.GRUPO CONSUMO;QTDE ITEM CONSUMO;DATA E HORA;VL.UNITARIO ITEM CONSUMO;VL.TOTAL ITEM CONSUMO;VL.CUSTO VARIAVEL DIRETO;VL.CUSTO FIXO DIRETO;VL.CUSTO VARIAVEL INDIRETO;VL.CUSTO FIXO INDIRETO;VL.DEDUCOES;QTDE RECEITA;VL.UNITARIO RECEITA;VL.TOTAL RECEITA;COD.PRESTADOR;DESC.PRESTADOR;UNIDADE;UNIDADE PRESTADORA;TRANSACAO;NR SERIE DOC ORIGINAL;NR DOC ORIGINAL;NR DOC SISTEMA;TIPO INSUMO;INSUMO;NR PROCESSO;NR SEQ DIGITACAO;NR DRG;DESCRICAO ERRO\n");

	$senhas = null;

	if($arquivoEntrada != ""){

		$path = "/var/www/html/octopus-temp/arquivos/php/files/".$arquivoEntrada;	

		$file = fopen($path,"r");

		$count = 0;

		while (!feof ($file)) {
			$linha = fgets($file,4096);

			if($count != 0){
				$vetor =  explode(";",$linha);

				$senhas[$vetor['26'].'-'.$vetor['27'].'-'.$vetor['28'].'-'.$vetor['29'].'-'.$vetor['30'].'-'.$vetor['31'].'-'.$vetor['32'].'-'.$vetor['33'].'-'.$vetor['34'].'-'.$vetor['35']] = $vetor['1'];

				$count++;
			}else{
				$count++;
			}
		}

	}

	/*$user = "324_V4L3s-TSt";
	$pass = "gTT3";
	$pass .= "$";
	$pass .= "uk1W";*/
	
	$ct_ttCustosEntradaRow = array();

	$DRG = new DRG();

	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,"prod");

	

	$xml = "<loteCustoPaciente>";

	$senha = "";

	$count = 1;

	$auxPrestador = 1;

	$prestador = "";

	$aux = 1;
	$lote = 1;

	$finalizouLote = false;

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){

				if($dados->{'cd-prestador-drg'} == $hospital){			

		/*print "<pre>";
		print_r($dados);
		print "<pre>";				

				}*/

					if($senhas != null){

						$indice  = $dados->{'cd-unidade'}.'-';
						$indice .= $dados->{'cd-unidade-prestadora'}.'-';
						$indice .= $dados->{'cd-transacao'}.'-';
						$indice .= $dados->{'nr-serie-doc-original'}.'-';
						$indice .= $dados->{'nr-doc-original'}.'-';
						$indice .= $dados->{'nr-doc-sistema'}.'-';
						$indice .= $dados->{'cd-tipo-insumo'}.'-';
						$indice .= $dados->{'cd-insumo'}.'-';
						$indice .= $dados->{'nr-processo'}.'-';
						$indice .= $dados->{'nr-seq-digitacao'};

						$senhaEnvio = $senhas[$indice];

					}else{

						$senhaEnvio = $dados->{'ds-senha'};

					}
				
					$dataHora =  $utils->data_mysql(substr($dados->{'ds-data-hora'},0,10))."T".substr($dados->{'ds-data-hora'},11).":00";

					if($finalizouLote){

						$xml = "<loteCustoPaciente>";	

						$xml .= "<CustoPaciente>
								<codigo>".$dados->{'cd-remessa'}."</codigo>
								<numeroAutorizacao>".$senhaEnvio."</numeroAutorizacao>
								<numeroAtendimento></numeroAtendimento>
								<acao>INCLUIR</acao>";

						$xml .= "<ItemCustoPaciente>
								 <codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
								 <descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
								 <codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
								 <quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
								 <dataConsumo>$dataHora</dataConsumo>
								 <valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
								 <valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
								 <valorCustoVariavelDireto></valorCustoVariavelDireto>
								 <valorCustoFixoDireto></valorCustoFixoDireto>
								 <valorCustoVariavelIndireto></valorCustoVariavelIndireto>
								 <valorCustoFixoIndireto></valorCustoFixoIndireto>
								 <valorDeducoes></valorDeducoes>
								 <quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
								 <valorReceitaUnitario></valorReceitaUnitario>
								 <valorReceitaTotal></valorReceitaTotal>
								 <codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
								 <descricaoFornecedor>".trim($dados->{'ds-prestador'})."</descricaoFornecedor>
								 </ItemCustoPaciente>";

						$senha = $dados->{'ds-senha'};

						$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};	 
						$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
						$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
						$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
						$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
						$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
						$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
						$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
						$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
						$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

						$aux++;					

						//$count = 1;

						$finalizouLote = false;			





					}else{

						if($senha !== $senhaEnvio){

							if($count != 1){
								$xml .= "</CustoPaciente>";
								$aux = 1;
							}

							$xml .= "<CustoPaciente>
									<codigo>".$dados->{'cd-remessa'}."</codigo>
									<numeroAutorizacao>".$senhaEnvio."</numeroAutorizacao>
									<numeroAtendimento></numeroAtendimento>
									<acao>INCLUIR</acao>";

							$xml .= "<ItemCustoPaciente>
									<codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
									<descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
									<codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
									<quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
									<dataConsumo>$dataHora</dataConsumo>
									<valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
									<valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
									<descricaoFornecedor>".trim($dados->{'ds-prestador'})."</descricaoFornecedor>
									</ItemCustoPaciente>";

							$senha = $senhaEnvio;	

							$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};	 
							$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
							$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
							$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
							$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
							$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
							$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
							$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
							$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
							$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

							$aux++;	

						}else{

							if($count == 1){

								$xml .= "<CustoPaciente>
										<codigo>".$dados->{'cd-remessa'}."</codigo>
										<numeroAutorizacao>".$senhaEnvio."</numeroAutorizacao>
										<numeroAtendimento></numeroAtendimento>
										<acao>INCLUIR</acao>";

							}

							$xml .= "<ItemCustoPaciente>
									<codigoItemConsumo>".$dados->{'cd-item-consumo'}."</codigoItemConsumo>
									<descricaoItemConsumo>".trim($dados->{'ds-item-consumo'})."</descricaoItemConsumo>
									<codigoGrupoConsumo>".$dados->{'cd-grupo-consumo'}."</codigoGrupoConsumo>
									<quantidadeItemConsumo>".$dados->{'qt-item-consumo'}."</quantidadeItemConsumo>
									<dataConsumo>$dataHora</dataConsumo>
									<valorCustoUnitario>".$dados->{'vl-unitario-consumo'}."</valorCustoUnitario>
									<valorCustoTotal>".$dados->{'vl-total-consumo'}."</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>".$dados->{'cd-prestador'}."</codigoFornecedor>
									<descricaoFornecedor>".trim($dados->{'ds-prestador'})."</descricaoFornecedor>
									</ItemCustoPaciente>";

							$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};	 
							$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
							$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
							$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
							$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
							$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
							$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
							$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
							$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
							$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

							$aux++;									

							}							 

							$dadosControle[$senha][$aux]['cdUnidade']           = $dados->{'cd-unidade'};	 
							$dadosControle[$senha][$aux]['cdUnidadePrestadora'] = $dados->{'cd-unidade-prestadora'};
							$dadosControle[$senha][$aux]['cdTransacao']         = $dados->{'cd-transacao'};
							$dadosControle[$senha][$aux]['nrSerieDocOriginal']  = $dados->{'nr-serie-doc-original'};
							$dadosControle[$senha][$aux]['nrDocOriginal']       = $dados->{'nr-doc-original'};
							$dadosControle[$senha][$aux]['nrDocSistema']        = $dados->{'nr-doc-sistema'};
							$dadosControle[$senha][$aux]['cdTipoInsumo']        = $dados->{'cd-tipo-insumo'};
							$dadosControle[$senha][$aux]['cdInsumo']            = $dados->{'cd-insumo'};
							$dadosControle[$senha][$aux]['nrProcesso']          = $dados->{'nr-processo'};
							$dadosControle[$senha][$aux]['nrSeqDigitacao']      = $dados->{'nr-seq-digitacao'};

							$aux++;					

							if((strlen($xml) >= 500000 || ($prestador != $dados->{'cd-prestador-drg'})) && $auxPrestador > 1){
								$xml .= "</CustoPaciente>";
								$xml .= "</loteCustoPaciente>";	

								/*print "<pre>";
								print_r(htmlentities($xml));
								print "</pre>";*/

								$prestador = $dados->{'cd-prestador-drg'};
								$auxPrestador++;			

								$finalizouLote = true;	

								$senha = $senhaEnvio;	

								$user = $dados->{'ds-usuario-iag'};
								$pass = $dados->{'ds-senha-iag'};	

								$rs = $DRG->enviarDadosDRG($xml,$user,$pass);							

								$xml_object = simplexml_load_string($rs->{'return'});

								foreach($xml_object->{'CustoPaciente'} as $dadosRetorno){


									if($dadosRetorno->{"codigoErro"} == ""){
										
										$autorizacao = (string)$dadosRetorno->{'numeroAutorizacao'};

										foreach($dadosControle[$autorizacao] as $valores){

											$item = array('st_cd-unidade'             => $valores['cdUnidade'],
														  'st_cd-unidade-prestadora'  => $valores['cdUnidadePrestadora'],
														  'st_cd-transacao'           => $valores['cdTransacao'],
														  'st_nr-serie-doc-original'  => $valores['nrSerieDocOriginal'],
														  'st_nr-doc-original'        => $valores['nrDocOriginal'],
														  'st_nr-doc-sistema'         => $valores['nrDocSistema'],
														  'st_cd-tipo-insumo'         => $valores['cdTipoInsumo'],
														  'st_cd-insumo'              => $valores['cdInsumo'],
														  'st_nr-processo'            => $valores['nrProcesso'],
														  'st_nr-seq-digitacao'       => $valores['nrSeqDigitacao']);	
																		
											array_push($ct_ttCustosEntradaRow,$item);

										}

										$status = array('ct_ttCustosEntrada' => array('ct_ttCustosEntradaRow' => $ct_ttCustosEntradaRow));

										$result = $DRG->atualizaStatusCustoPaciente($status);

									}else{
										
										$escreve  = $dados->{'cd-remessa'}.";";
										$escreve .= $senhaEnvio.";";
										$escreve .= $dados->{'cd-prestador-drg'}.";";
										$escreve .= $dados->{'ds-usuario-iag'}.";";
										$escreve .= $dados->{'ds-senha-iag'}.";";
										$escreve .= $dados->{'cd-unidade-carteira'}."".str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT).";";
										$escreve .= $dados->{'nm-paciente'}.";";																		
										$escreve .= ";";
										$escreve .= "INCLUIR;";
										$escreve .= $dados->{'cd-item-consumo'}.";";
										$escreve .= trim($dados->{'ds-item-consumo'}).";";
										$escreve .= $dados->{'cd-grupo-consumo'}.";";
										$escreve .= $dados->{'qt-item-consumo'}.";";
										$escreve .= $dados->{'ds-data-hora'}.";";
										$escreve .= $dados->{'vl-unitario-consumo'}.";";
										$escreve .= $dados->{'vl-total-consumo'}.";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= ";";
										$escreve .= $dados->{'cd-prestador'}.";";
										$escreve .= trim($dados->{'ds-prestador'}).";";
										$escreve .= $dados->{'cd-unidade'}.";";           
										$escreve .= $dados->{'cd-unidade-prestadora'}.";";
										$escreve .= $dados->{'cd-transacao'}.";";
										$escreve .= $dados->{'nr-serie-doc-original'}.";";
										$escreve .= $dados->{'nr-doc-original'}.";";
										$escreve .= $dados->{'nr-doc-sistema'}.";";
										$escreve .= $dados->{'cd-tipo-insumo'}.";";
										$escreve .= $dados->{'cd-insumo'}.";";
										$escreve .= $dados->{'nr-processo'}.";";
										$escreve .= $dados->{'nr-seq-digitacao'}.";";
										$escreve .= ";";
										$escreve .= trim($dadosRetorno->{'descricaoErro'})."\n";

										fwrite($erro,$escreve);

										$gerouErro = true;

									}

									
									//print ($dados->{'numeroAutorizacao'}) . "<br>";
									

								}									 

						}else{
								$prestador = $dados->{'cd-prestador-drg'};
								$auxPrestador++;						
						}	

					}

					$count++;

				}

			}		

		}

	}
    $xml .= "</CustoPaciente>";
	$xml .= "</loteCustoPaciente>";

	/*print "<pre>";
	print_r(htmlentities($xml));
	print "</pre>";*/

	$user = $dados->{'ds-usuario-iag'};
	$pass = $dados->{'ds-senha-iag'};	

	$rs = $DRG->enviarDadosDRG($xml,$user,$pass);							

	$xml_object = simplexml_load_string($rs->{'return'});

	foreach($xml_object->{'CustoPaciente'} as $dadosRetorno){


		if($dadosRetorno->{"codigoErro"} == ""){
			
			$autorizacao = (string)$dadosRetorno->{'numeroAutorizacao'};

			foreach($dadosControle[$autorizacao] as $valores){

				$item = array('st_cd-unidade'             => $valores['cdUnidade'],
								'st_cd-unidade-prestadora'  => $valores['cdUnidadePrestadora'],
								'st_cd-transacao'           => $valores['cdTransacao'],
								'st_nr-serie-doc-original'  => $valores['nrSerieDocOriginal'],
								'st_nr-doc-original'        => $valores['nrDocOriginal'],
								'st_nr-doc-sistema'         => $valores['nrDocSistema'],
								'st_cd-tipo-insumo'         => $valores['cdTipoInsumo'],
								'st_cd-insumo'              => $valores['cdInsumo'],
								'st_nr-processo'            => $valores['nrProcesso'],
								'st_nr-seq-digitacao'       => $valores['nrSeqDigitacao']);	
											
				array_push($ct_ttCustosEntradaRow,$item);

			}

			$status = array('ct_ttCustosEntrada' => array('ct_ttCustosEntradaRow' => $ct_ttCustosEntradaRow));

			$result = $DRG->atualizaStatusCustoPaciente($status);

		}else{
			
			$escreve  = $dados->{'cd-remessa'}.";";
			$escreve .= $senhaEnvio.";";
			$escreve .= $dados->{'cd-prestador-drg'}.";";
			$escreve .= $dados->{'ds-usuario-iag'}.";";
			$escreve .= $dados->{'ds-senha-iag'}.";";
			$escreve .= $dados->{'cd-unidade-carteira'}."".str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT).";";
			$escreve .= $dados->{'nm-paciente'}.";";						
			$escreve .= ";";
			$escreve .= "INCLUIR;";
			$escreve .= $dados->{'cd-item-consumo'}.";";
			$escreve .= trim($dados->{'ds-item-consumo'}).";";
			$escreve .= $dados->{'cd-grupo-consumo'}.";";
			$escreve .= $dados->{'qt-item-consumo'}.";";
			$escreve .= $dados->{'ds-data-hora'}.";";
			$escreve .= $dados->{'vl-unitario-consumo'}.";";
			$escreve .= $dados->{'vl-total-consumo'}.";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= ";";
			$escreve .= $dados->{'cd-prestador'}.";";
			$escreve .= trim($dados->{'ds-prestador'}).";";
			$escreve .= $dados->{'cd-unidade'}.";";           
			$escreve .= $dados->{'cd-unidade-prestadora'}.";";
			$escreve .= $dados->{'cd-transacao'}.";";
			$escreve .= $dados->{'nr-serie-doc-original'}.";";
			$escreve .= $dados->{'nr-doc-original'}.";";
			$escreve .= $dados->{'nr-doc-sistema'}.";";
			$escreve .= $dados->{'cd-tipo-insumo'}.";";
			$escreve .= $dados->{'cd-insumo'}.";";
			$escreve .= $dados->{'nr-processo'}.";";
			$escreve .= $dados->{'nr-seq-digitacao'}.";";
			$escreve .= ";";
			$escreve .= trim($dadosRetorno->{'descricaoErro'})."\n";						

			fwrite($erro,$escreve);

			$gerouErro = true;

		}
	

	}

	$retorno = array();

	$retorno['ok'] = 1;

	if($gerouErro){
		$retorno['gerouErro']   = $gerouErro;
		$retorno['arquivoErro'] = "custos-nao-importados.csv";
	}
	

	echo json_encode($retorno);


		

}

function gerarArquivoCSV(){

	$ok = 0;
	$msg = "";

	$dadosSaida  = array();
	$saidaTabela = array();
	$tabela = "";

	$anoIni         = $_POST['anoIni'];
	$anoFim         = $_POST['anoFim'];
	$periodoIni     = $_POST['periodoIni'];
	$periodoFim     = $_POST['periodoFim'];
	$arquivoEntrada = $_POST['arquivoEntrada'];
	$hospital       = $_POST['hospital'];	

	$path = "/var/www/html/octopus-temp/arquivos/php/files/custoPaciente-".$periodoIni."-".$anoIni." a ".$periodoFim."-".$anoFim."-".$hospital.".csv";
	//$path = "c:/xampp/htdocs/octopus-temp/arquivos/php/files/custoPaciente-".$periodoIni."-".$anoIni." a ".$periodoFim."-".$anoFim."-".$hospital.".csv";

	$arquivo = "custoPaciente-".$periodoIni."-".$anoIni." a ".$periodoFim."-".$anoFim."-".$hospital.".csv";

	$arquivoSaida = fopen($path,"w");

	$cabecalho  = "COD. REMESSA;SENHA;PRESTADOR DRG;USUARIO IAG;SENHA IAG;CARTEIRA;NOME;NR. ATENDIMENTO;ACAO;COD.ITEM CONSUMO;DESC.ITEM CONSUMO;COD.GRUPO CONSUMO;QTDE ITEM CONSUMO;";
	$cabecalho .= "DATA E HORA;VL.UNITARIO ITEM CONSUMO;VL.TOTAL ITEM CONSUMO;VL.CUSTO VARIAVEL DIRETO;VL.CUSTO FIXO DIRETO;";
	$cabecalho .= "VL.CUSTO VARIAVEL INDIRETO;VL.CUSTO FIXO INDIRETO;VL.DEDUCOES;QTDE RECEITA;VL.UNITARIO RECEITA;VL.TOTAL RECEITA;COD.PRESTADOR;DESC.PRESTADOR;";
	$cabecalho .= "UNIDADE;UNIDADE PRESTADORA;TRANSACAO;NR SERIE DOC ORIGINAL;NR DOC ORIGINAL;NR DOC SISTEMA;TIPO INSUMO;INSUMO;NR PROCESSO;NR SEQ DIGITACAO;NR DRG\n";

	$escrita = fwrite($arquivoSaida,$cabecalho);

	$senhas = null;

	if($arquivoEntrada != ""){

		$path = "/var/www/html/octopus-temp/arquivos/php/files/".$arquivoEntrada;
		//$path = "c:/xampp/htdocs/html/octopus-temp/arquivos/php/files/".$arquivoEntrada;

		$file = fopen($path,"r");

		$count = 0;

		while (!feof ($file)) {
			$linha = fgets($file,4096);

			if($count != 0){
				$vetor =  explode(";",$linha);

				$senhas[$vetor['21'].'-'.$vetor['22'].'-'.$vetor['23'].'-'.$vetor['24'].'-'.$vetor['25'].'-'.$vetor['26'].'-'.$vetor['27'].'-'.$vetor['28'].'-'.$vetor['29'].'-'.$vetor['30']] = $vetor['1'];

				$count++;
			}else{
				$count++;
			}
		}

	}

	$DRG = new DRG();
	
	$resultado = $DRG->solicitaDadosCustosPaciente($anoIni,$anoFim,$periodoIni,$periodoFim,"prod");

	foreach($resultado as $resultadoParcial){

		foreach($resultadoParcial as $registros){

			foreach($registros as $dados){

				if($dados->{'cd-prestador-drg'} == $hospital){

					if($senhas != null){

						$indice  = $dados->{'cd-unidade'}.'-';
						$indice .= $dados->{'cd-unidade-prestadora'}.'-';
						$indice .= $dados->{'cd-transacao'}.'-';
						$indice .= $dados->{'nr-serie-doc-original'}.'-';
						$indice .= $dados->{'nr-doc-original'}.'-';
						$indice .= $dados->{'nr-doc-sistema'}.'-';
						$indice .= $dados->{'cd-tipo-insumo'}.'-';
						$indice .= $dados->{'cd-insumo'}.'-';
						$indice .= $dados->{'nr-processo'}.'-';
						$indice .= $dados->{'nr-seq-digitacao'};

						$senhaEnvio = $senhas[$indice];

					}else{

						$senhaEnvio = $dados->{'ds-senha'};

					}				

					$conteudo  = $dados->{'cd-remessa'}.";";
					$conteudo .= $senhaEnvio.";";
					$conteudo .= $dados->{'cd-prestador-drg'}.";";
					$conteudo .= $dados->{'ds-usuario-iag'}.";";
					$conteudo .= $dados->{'ds-senha-iag'}.";";
					$conteudo .= $dados->{'cd-unidade-carteira'}."".str_pad($dados->{'cd-carteira'},13,"0",STR_PAD_LEFT).";";
					$conteudo .= $dados->{'nm-paciente'}.";";				
					$conteudo .= ";";
					$conteudo .= "INCLUIR;";
					$conteudo .= $dados->{'cd-item-consumo'}.";";
					$conteudo .= $dados->{'ds-item-consumo'}.";";
					$conteudo .= $dados->{'cd-grupo-consumo'}.";";
					$conteudo .= $dados->{'qt-item-consumo'}.";";
					$conteudo .= $dados->{'ds-data-hora'}.";";
					$conteudo .= $dados->{'vl-unitario-consumo'}.";";  
					$conteudo .= $dados->{'vl-total-consumo'}.";";
					$conteudo .= "0;";
					$conteudo .= "0;";
					$conteudo .= "0;";
									$conteudo .= "0;";
									$conteudo .= "0;";
									$conteudo .= "0;";
									$conteudo .= "0;";
									$conteudo .= "0;";
									$conteudo .= $dados->{'cd-prestador'}.";";
									$conteudo .= $dados->{'ds-prestador'}.";";
									$conteudo .= $dados->{'cd-unidade'}.";";           
									$conteudo .= $dados->{'cd-unidade-prestadora'}.";";
									$conteudo .= $dados->{'cd-transacao'}.";";
									$conteudo .= $dados->{'nr-serie-doc-original'}.";";
									$conteudo .= $dados->{'nr-doc-original'}.";";
									$conteudo .= $dados->{'nr-doc-sistema'}.";";
									$conteudo .= $dados->{'cd-tipo-insumo'}.";";
									$conteudo .= $dados->{'cd-insumo'}.";";
									$conteudo .= $dados->{'nr-processo'}.";";
									$conteudo .= $dados->{'nr-seq-digitacao'}.";";
									$conteudo .= ";\n";				 

									$escrita = fwrite($arquivoSaida,$conteudo);

									$ok = 1;

					}

			}

		}

	}

	fclose($arquivoSaida);

	$retorno['ok']      = $ok;
	$retorno['arquivo'] = $arquivo;

	echo json_encode($retorno);

}

?>