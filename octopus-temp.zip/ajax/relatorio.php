<?php
set_time_limit(240);
include("../inc/config.php");
include("../classes/Utils.class.php");
include("../classes/Departamentos.class.php");
include("../classes/Relatorios.class.php");
session_start();

//Math.round(number).toFixed(2);
//$_GET['acao'] = 'buscaIncidentes';

if($_GET['acao']  == 'montaDepartamentos'){
	montaDepartamentos();
}else if($_GET['acao']  == 'buscaIncidentes'){
	buscaIncidentes();
}else if($_GET['acao']  == 'buscaIncidentesPrazo'){
	buscaIncidentesPrazo();
}else if($_GET['acao']  == 'buscaIncidentesSeveridade'){
	buscaIncidentesSeveridade();
}else if($_GET['acao']  == 'buscaIncidentesOrigem'){
	buscaIncidentesOrigem();	
}else if($_GET['acao']  == 'quantidadeTotalIncidentesServico'){
	quantidadeTotalIncidentesServico();
}else if($_GET['acao']  == 'quantidadeTotalIncidentesColaborador'){
	quantidadeTotalIncidentesColaborador();
}else if($_GET['acao']  == 'incidentesAbertos'){
	incidentesAbertos();
}else if($_GET['acao']  == 'buscaRequisicoes'){
	buscaRequisicoes();
}else if($_GET['acao']  == 'buscaRequisicoesPrazo'){
	buscaRequisicoesPrazo();
}else if($_GET['acao']  == 'buscaRequisicoesSeveridade'){
	buscaRequisicoesSeveridade();
}else if($_GET['acao']  == 'buscaRequisicoesOrigem'){
	buscaRequisicoesOrigem();
}else if($_GET['acao']  == 'quantidadeTotalRequisicoesServico'){
	quantidadeTotalRequisicoesServico();
}else if($_GET['acao']  == 'quantidadeTotalRequisicoesColaborador'){
	quantidadeTotalRequisicoesColaborador();
}else if($_GET['acao']  == 'requisicoesAbertos'){
	requisicoesAbertos();
}else if($_GET['acao']  == 'buscaDesenvolvimentos'){
	buscaDesenvolvimentos();
}else if($_GET['acao']  == 'buscaDesenvolvimentosPrazo'){
	buscaDesenvolvimentosPrazo();
}else if($_GET['acao']  == 'quantidadeTotalDesenvolvimentosServico'){
	quantidadeTotalDesenvolvimentosServico();
}else if($_GET['acao']  == 'quantidadeTotalDesenvolvimentosColaborador'){
	quantidadeTotalDesenvolvimentosColaborador();
}else if($_GET['acao']  == 'desenvolvimentosAbertos'){
	desenvolvimentosAbertos();
}else if($_GET['acao']  == 'desenvolvimentosEncerrados'){
	desenvolvimentosEncerrados();
}else if($_GET['acao']  == 'buscaProjetos'){
	buscaProjetos();
}

function mesDescricao($mes){
	
	$mesDescricao = "";
	
	switch ($mes) {
		case 1:
			$mesDescricao = "Janeiro";
			break;
		case 2:
			$mesDescricao = "Fevereiro";
			break;
		case 3:
			$mesDescricao = "Março";
			break;
		case 4:
			$mesDescricao = "Abril";
			break;
		case 5:
			$mesDescricao = "Maio";
			break;
		case 6:
			$mesDescricao = "Junho";
			break;
		case 7:
			$mesDescricao = "Julho";
			break;
		case 8:
			$mesDescricao = "Agosto";
			break;
		case 9:
			$mesDescricao = "Setembro";
			break;
		case 10:
			$mesDescricao = "Outubro";
			break;
		case 11:
			$mesDescricao = "Novembro";
			break;
		case 12:
			$mesDescricao = "Dezembro";
			break;			
	}
	
	return $mesDescricao;
	
}

function mesAnoDescricao($mes,$ano){
	
	$mesDescricao = "";
	
	switch ($mes) {
		case 1:
			$mesDescricao = "Janeiro/".$ano;
			break;
		case 2:
			$mesDescricao = "Fevereiro/".$ano;
			break;
		case 3:
			$mesDescricao = "Março/".$ano;
			break;
		case 4:
			$mesDescricao = "Abril/".$ano;
			break;
		case 5:
			$mesDescricao = "Maio/".$ano;
			break;
		case 6:
			$mesDescricao = "Junho/".$ano;
			break;
		case 7:
			$mesDescricao = "Julho/".$ano;
			break;
		case 8:
			$mesDescricao = "Agosto/".$ano;
			break;
		case 9:
			$mesDescricao = "Setembro/".$ano;
			break;
		case 10:
			$mesDescricao = "Outubro/".$ano;
			break;
		case 11:
			$mesDescricao = "Novembro/".$ano;
			break;
		case 12:
			$mesDescricao = "Dezembro/".$ano;
			break;			
	}
	
	return $mesDescricao;
	
}

function mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal){
	
	$numeroMeses = 0;
	
	$ano = $anoInicial;
	while($ano <= $anoFinal){
		if($ano == $anoInicial){
			$mes = $mesInicial;
			while($mes <= 12){
				$mes++;
				$numeroMeses++;
			}
		}else{
			if($ano == $anoFinal){
				$mes = 1;
				while($mes <= $mesFinal){
					$mes++;
					$numeroMeses++;
				}
			}else{
				$mes = 1;
				while($mes <= 12){
					$mes++;
					$numeroMeses++;
				}
			}			
		}
		$ano++;
	}
	
	return $numeroMeses;
}

function buscaIncidentes(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$abertos = array();
	$encerrados = array();
	$meses = array();	
	$i = 1;
	$inicio = 1;
	
	$utils = new Utils();

	//print $utils->mesDiferencaData('2012-01-01','2016-04-28');
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];

	//$departamento = 5;
	//$periodo = '01/12/2012 - 30/04/2016';	
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
/*	print $dataInicial."<br>";
	print $dataFinal."<br>"; 
	
	print $anoInicial."<br>";
	print $anoFinal."<br>"; 	
	
	print $utils->mesDiferencaData($dataInicial,$dataFinal)."<br>";*/
	
	//$fim = $utils->mesDiferencaData($dataInicial,$dataFinal);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraTabelaIncidentes($departamento,$dataInicial,$dataFinal);

	//print "<pre>";
	//print_r($relatorios);
	//print "</pre>";

	$numeroMeses = 0;
	
	if($verificaAnos == 0){
		$numeroMeses = 12;
		$mesInicial = 1;
	}else{
		$numeroMeses = mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal);
	}
	
	if($numeroMeses > 0){	
	
		$anoAtual = $anoInicial;
	
		while($i <= $numeroMeses){

			if($mesInicial == 13){
				
				$mesInicial = 1;
				$anoAtual   = $anoAtual + 1;
			}
			
			$per = str_pad($mesInicial, 2, '0', STR_PAD_LEFT).$anoAtual;
			
			if(count($relatorios[$per]) > 0){
				
				if($relatorios[$per]['QtdeAbertos'] != ""){
					array_push($abertos, $relatorios[$per]['QtdeAbertos']);
				}else{
					array_push($abertos, 0);
				}
				if($relatorios[$per]['QtdeEncerrados'] != ""){
					array_push($encerrados, $relatorios[$per]['QtdeEncerrados']);
				}else{
					array_push($encerrados, 0);
				}
							
			}else{
				array_push($abertos, 0);
				array_push($encerrados, 0);			
			}
			$mesDescricao = mesAnoDescricao($mesInicial,$anoAtual);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
			$mesInicial++;
			
		}
	
		$retorno['abertos']    = $abertos;
		$retorno['encerrados'] = $encerrados;
		$retorno['meses']      = $meses;
	
	}else{
		$ok = 0;
	}
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function buscaIncidentesPrazo(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$prazo = array();
	$meses = array();
	$i = 1;
	$inicio = 1;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	//$departamento = 5;
	//$periodo = '01/01/2016 - 31/03/2016';	
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoTotalPrazoIncidentes($departamento,$dataInicial,$dataFinal);
	
	//print "<pre>";
	//print_r($relatorios);
	//print "</pre>";
	
	$numeroMeses = 0;
	
	if($verificaAnos == 0){
		$numeroMeses = 12;
		$mesInicial = 1;
	}else{
		$numeroMeses = mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal);
	}
	
	if($numeroMeses > 0){
	
		$anoAtual = $anoInicial;
		
		while($i <= $numeroMeses){
		
			if($mesInicial == 13){
				
				$mesInicial = 1;
				$anoAtual   = $anoAtual + 1;
			}
			
			$per = str_pad($mesInicial, 2, '0', STR_PAD_LEFT).$anoAtual;
			
			if(count($relatorios[$per]) > 0){
				
				if($relatorios[$per] != ""){
					array_push($prazo, $relatorios[$per]);
				}else{
					array_push($prazo, 0);
				}
							
			}else{
				array_push($prazo, 0);
			}
			$mesDescricao = mesAnoDescricao($mesInicial,$anoAtual);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
			$mesInicial++;
		}	
	
		$retorno['prazo'] = $prazo;
		$retorno['meses'] = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}


function buscaIncidentesSeveridade(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$retorno['critica'] = 0;
	$retorno['alta']    = 0;
	$retorno['media']   = 0;
	$retorno['baixa']   = 0;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoSeveridadeIncidentes($departamento,$dataInicial,$dataFinal,$acumulado);
	
	//print "<pre>";
	//print_r($relatorios);
	//print "</pre>";
	
	foreach($relatorios as $key => $dados){
		
		if(utf8_encode($key) == "Crítica"){
			$retorno['critica'] = $dados;
		}
		if($key == "Alta"){
			$retorno['alta'] = $dados;
		}
		if(utf8_encode($key) == "Média"){
			$retorno['media'] = $dados;
		}
		if($key == "Baixa"){
			$retorno['baixa'] = $dados;
		}
		$ok = 1;
	}
	
	$retorno['mes'] = mesDescricao($mesFinal);
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function buscaIncidentesOrigem(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$retorno['PortalWeb']  = 0;
	$retorno['Telefone']   = 0;
	$retorno['Presencial'] = 0;
	$retorno['Email']      = 0;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	//$departamento = 5;
	//$mes          = 3;
	//$ano          = 2016;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoOrigemIncidentes($departamento,$dataInicial,$dataFinal,$acumulado);
	
	foreach($relatorios as $key => $dados){
		
		if(utf8_encode($key) == "Portal Web"){
			$retorno['PortalWeb'] = $dados;
		}
		if($key == "Telefone"){
			$retorno['Telefone'] = $dados;
		}
		if(utf8_encode($key) == "Presencial"){
			$retorno['Presencial'] = $dados;
		}
		if($key == "E-mail"){
			$retorno['Email'] = $dados;
		}
		$ok = 1;
	}
	
	$retorno['mes'] = mesDescricao($mesFinal);
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function quantidadeTotalIncidentesServico(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$servicos = array();
	$resultados = array();	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	/*$departamento = 5;
	$mes = 8;
	$ano = 2015;*/
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->quantidadeTotalIncidentesServico($departamento,$dataInicial,$dataFinal,$acumulado);
	
	$tabela .= "<h3>Qtde. de Incidentes Abertos por Servi&ccedil;os - TOP 10</h3>
	            <table id='tabelaTotalIncidentesServico' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th  width='70%'>Servi&ccedil;o</th>
                        <th>Qtde</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $key => $dados){
		
		array_push($servicos, utf8_encode($key));
		array_push($resultados, $dados['Abertura']);
		
		$tabela .= "<tr>
                       <td>".$key."</td>
                       <td>".$dados['Abertura']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	

	$retorno['servicos']   = $servicos;
	$retorno['resultados'] = $resultados;
		
	$retorno['mes']    = mesDescricao($mesFinal);	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function quantidadeTotalIncidentesColaborador(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$colaborador = array();
	$resultados = array();
		
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->quantidadeTotalIncidentesColaborador($departamento,$dataInicial,$dataFinal,$acumulado);
	
	$tabela .= "<h3>Qtde. de Incidentes Abertos por Colaborador - TOP 10</h3>
	            <table id='tabelaTotalIncidentesColaborador' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th width='70%'>Colaborador</th>
                        <th>Qtde</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $key => $dados){
	
		array_push($colaborador, utf8_encode($key));
		array_push($resultados, $dados['Qtde']);
		
		$tabela .= "<tr>
                       <td>".$key."</td>
                       <td>".$dados['Qtde']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";

	$retorno['colaborador'] = $colaborador;
	$retorno['resultados'] = $resultados;	

	$retorno['mes']    = mesDescricao($mesFinal);
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function incidentesAbertos(){
	$ok = 0;
	$msg = "";
	$retorno = array();
		
	$departamento = $_POST['departamento'];	
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->incidentesAbertos($departamento);
	
	$tabela .= "<h3>Incidentes <b>ABERTOS</b> at&eacute; ".date("d/m/Y")."</h3>
	            <table id='tabelaIncidentesAbertos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>N&uacute;mero</th>
                        <th>Data</th>
                        <th>Previs&atilde;o</th>
                        <th>Descri&ccedil;&atilde;o</th>
                        <th>Contato</th>
                        <th>Situa&ccedil;&atilde;o</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $dados){
		
		$tabela .= "<tr>
                       <td>".$dados['Numero']."</td>
                       <td>".$dados['Data']."</td>
                       <td>".$dados['Previsao']."</td>
                       <td style='text-align:justify;'>".$dados['Descricao']."</td>
                       <td>".$dados['Contato']."</td>
                       <td>".$dados['Situacao']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	

	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function buscaRequisicoes(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$abertos = array();
	$encerrados = array();
	$meses = array();
	$i = 1;
	$inicio = 1;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];

	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraTabelaRequisicoes($departamento,$dataInicial,$dataFinal);
	
	$numeroMeses = 0;
	
	if($verificaAnos == 0){
		$numeroMeses = 12;
		$mesInicial = 1;
	}else{
		$numeroMeses = mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal);
	}
	
	if($numeroMeses > 0){	
	
		$anoAtual = $anoInicial;
	
		while($i <= $numeroMeses){
		
			if($mesInicial == 13){
				
				$mesInicial = 1;
				$anoAtual   = $anoAtual + 1;
			}
			
			$per = str_pad($mesInicial, 2, '0', STR_PAD_LEFT).$anoAtual;
			
			if(count($relatorios[$per]) > 0){
				
				if($relatorios[$per]['QtdeAbertos'] != ""){
					array_push($abertos, $relatorios[$per]['QtdeAbertos']);
				}else{
					array_push($abertos, 0);
				}
				if($relatorios[$per]['QtdeEncerrados'] != ""){
					array_push($encerrados, $relatorios[$per]['QtdeEncerrados']);
				}else{
					array_push($encerrados, 0);
				}
							
			}else{
				array_push($abertos, 0);
				array_push($encerrados, 0);			
			}
			$mesDescricao = mesAnoDescricao($mesInicial,$anoAtual);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
			$mesInicial++;
		}
	
		$retorno['abertos']    = $abertos;
		$retorno['encerrados'] = $encerrados;
		$retorno['meses']      = $meses;		
	
	}else{
		$ok = 0;
	}
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function buscaRequisicoesPrazo(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$prazo = array();
	$meses = array();
	$i = 1;
	$inicio = 1;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];

	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoTotalRequisicoesPrazo($departamento,$dataInicial,$dataFinal);
	
	$numeroMeses = 0;
	
	if($verificaAnos == 0){
		$numeroMeses = 12;
		$mesInicial = 1;
	}else{
		$numeroMeses = mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal);
	}
	
	if($numeroMeses > 0){
	
		$anoAtual = $anoInicial;
		
		while($i <= $numeroMeses){
		
			if($mesInicial == 13){
				
				$mesInicial = 1;
				$anoAtual   = $anoAtual + 1;
			}
			
			$per = str_pad($mesInicial, 2, '0', STR_PAD_LEFT).$anoAtual;
			
			if(count($relatorios[$per]) > 0){
				
				if($relatorios[$per] != ""){
					array_push($prazo, $relatorios[$per]);
				}else{
					array_push($prazo, 0);
				}
							
			}else{
				array_push($prazo, 0);
			}
			$mesDescricao = mesAnoDescricao($mesInicial,$anoAtual);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
			$mesInicial++;
		}	
	
		$retorno['prazo'] = $prazo;
		$retorno['meses'] = $meses;
	
	}else{
		$ok = 0;		
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function buscaRequisicoesSeveridade(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$retorno['critica'] = 0;
	$retorno['alta']    = 0;
	$retorno['media']   = 0;
	$retorno['baixa']   = 0;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoSeveridadeRequisicoes($departamento,$dataInicial,$dataFinal,$acumulado);
	
	foreach($relatorios as $key => $dados){
		
		if(utf8_encode($key) == "Crítica"){
			$retorno['critica'] = $dados;
		}
		if($key == "Alta"){
			$retorno['alta'] = $dados;
		}
		if(utf8_encode($key) == "Média"){
			$retorno['media'] = $dados;
		}
		if($key == "Baixa"){
			$retorno['baixa'] = $dados;
		}
		$ok = 1;
	}
	
	$retorno['mes'] = mesDescricao($mesFinal);
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function buscaRequisicoesOrigem(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$retorno['PortalWeb']  = 0;
	$retorno['Telefone']   = 0;
	$retorno['Presencial'] = 0;
	$retorno['Email']      = 0;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoOrigemRequisicoes($departamento,$dataInicial,$dataFinal,$acumulado);
	
	foreach($relatorios as $key => $dados){
		
		if(utf8_encode($key) == "Portal Web"){
			$retorno['PortalWeb'] = $dados;
		}
		if($key == "Telefone"){
			$retorno['Telefone'] = $dados;
		}
		if(utf8_encode($key) == "Presencial"){
			$retorno['Presencial'] = $dados;
		}
		if($key == "E-mail"){
			$retorno['Email'] = $dados;
		}
		$ok = 1;
	}
	
	$retorno['mes'] = mesDescricao($mesFinal);
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function quantidadeTotalRequisicoesServico(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$servicos = array();
	$resultados = array();
		
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->quantidadeTotalRequisicoesServico($departamento,$dataInicial,$dataFinal,$acumulado);
	
	$tabela .= "<h3>Qtde. de Requisi&ccedil;&otilde;es Abertos por Servi&ccedil;os - TOP 10</h3>
	            <table id='tabelaTotalRequisicoesServico' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th  width='70%'>Servi&ccedil;o</th>
                        <th>Qtde</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $key => $dados){
	
		array_push($servicos, utf8_encode($key));
		array_push($resultados, $dados['Abertura']);
		
		$tabela .= "<tr>
                       <td>".$key."</td>
                       <td>".$dados['Abertura']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";

	$retorno['servicos']   = $servicos;
	$retorno['resultados'] = $resultados;	

	$retorno['mes']    = mesDescricao($mesFinal);	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function quantidadeTotalRequisicoesColaborador(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$colaborador = array();
	$resultados = array();
		
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->quantidadeTotalRequisicoesColaborador($departamento,$dataInicial,$dataFinal,$acumulado);
	
	$tabela .= "<h3>Qtde. de Requisi&ccedil;&otilde;es Abertos por Colaborador - TOP 10</h3>
	            <table id='tabelaTotalRequisicoesColaborador' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th width='70%'>Colaborador</th>
                        <th>Qtde</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $key => $dados){
		
		array_push($colaborador, utf8_encode($key));
		array_push($resultados, $dados['Qtde']);
		
		$tabela .= "<tr>
                       <td>".$key."</td>
                       <td>".$dados['Qtde']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	
	
	$retorno['colaborador'] = $colaborador;
	$retorno['resultados'] = $resultados;

	$retorno['mes']    = mesDescricao($mesFinal);
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function requisicoesAbertos(){
	$ok = 0;
	$msg = "";
	$retorno = array();
		
	$departamento = $_POST['departamento'];	
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->requisicoesAbertos($departamento);
	
	$tabela .= "<h3>Requisi&ccedil&otilde;es <b>ABERTAS</b> at&eacute; ".date("d/m/Y")."</h3>
	            <table id='tabelaRequisicoesAbertos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>N&uacute;mero</th>
                        <th>Tipo</th>
                        <th>Data</th>
                        <th>Previs&atilde;o</th>
                        <th>Descri&ccedil;&atilde;o</th>
                        <th>Contato</th>
                        <th>Situa&ccedil;&atilde;o</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $dados){
		
		$tabela .= "<tr>
                       <td>".$dados['Numero']."</td>
                       <td>".$dados['Tipo']."</td>
                       <td>".$dados['Data']."</td>
                       <td>".$dados['Previsao']."</td>
                       <td style='text-align:justify;'>".$dados['Descricao']."</td>
                       <td>".$dados['Contato']."</td>
                       <td>".$dados['Situacao']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	

	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function buscaDesenvolvimentos(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$abertos = array();
	$encerrados = array();
	$meses = array();
	$i = 1;
	$inicio = 1;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraTabelaDesenvolvimentos($departamento,$dataInicial,$dataFinal);
	
	$numeroMeses = 0;
	
	if($verificaAnos == 0){
		$numeroMeses = 12;
		$mesInicial = 1;
	}else{
		$numeroMeses = mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal);
	}
	
	if($numeroMeses > 0){	
	
		$anoAtual = $anoInicial;
	
		while($i <= $numeroMeses){
		
			if($mesInicial == 13){
				
				$mesInicial = 1;
				$anoAtual   = $anoAtual + 1;
			}
			
			$per = str_pad($mesInicial, 2, '0', STR_PAD_LEFT).$anoAtual;
			
			if(count($relatorios[$per]) > 0){
				
				if($relatorios[$per]['QtdeAbertos'] != ""){
					array_push($abertos, $relatorios[$per]['QtdeAbertos']);
				}else{
					array_push($abertos, 0);
				}
				if($relatorios[$per]['QtdeEncerrados'] != ""){
					array_push($encerrados, $relatorios[$per]['QtdeEncerrados']);
				}else{
					array_push($encerrados, 0);
				}
							
			}else{
				array_push($abertos, 0);
				array_push($encerrados, 0);			
			}
			$mesDescricao = mesAnoDescricao($mesInicial,$anoAtual);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
			$mesInicial++;
		}
	
		$retorno['abertos']    = $abertos;
		$retorno['encerrados'] = $encerrados;
		$retorno['meses']      = $meses;		
	
	}else{
		$ok = 0;
	}
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	echo json_encode($retorno);
}

function buscaDesenvolvimentosPrazo(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$prazo = array();
	$meses = array();
	$i = 1;
	$inicio = 1;
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->geraGraficoTotalPrazo($departamento,$dataInicial,$dataFinal);
	
	$numeroMeses = 0;
	
	if($verificaAnos == 0){
		$numeroMeses = 12;
		$mesInicial = 1;
	}else{
		$numeroMeses = mesesIntervalo($anoInicial,$mesInicial,$anoFinal,$mesFinal);
	}
	
	if($numeroMeses > 0){

		$anoAtual = $anoInicial;
		
		while($i <= $numeroMeses){

			if($mesInicial == 13){
				
				$mesInicial = 1;
				$anoAtual   = $anoAtual + 1;
			}
			
			$per = str_pad($mesInicial, 2, '0', STR_PAD_LEFT).$anoAtual;
			
			if(count($relatorios[$per]) > 0){				
				if($relatorios[$per]['Prazo'] != ""){
					array_push($prazo, $relatorios[$per]['Prazo']);
				}else{
					array_push($prazo, 0);
				}										
			}else{
				array_push($prazo, 0);		
			}
			
			$mesDescricao = mesAnoDescricao($mesInicial,$anoAtual);
			array_push($meses,$mesDescricao);
			$i++;
			$ok = 1;
			$mesInicial++;
		}
		$retorno['prazo'] = $prazo;
		$retorno['meses'] = $meses;
	}else{
		$ok = 0;		
	}
	$retorno['ok']  = $ok;
	$retorno['msg'] = ($msg);
	echo json_encode($retorno);
}

function quantidadeTotalDesenvolvimentosServico(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	$servicos = array();
	$resultados = array();
		
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}

	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->quantidadeTotalDesenvolvimentosServico($departamento,$dataInicial,$dataFinal,$acumulado);
	
	if($acumulado){
		$tabela .= "<h3>Qtde. de Desenvolvimentos Abertos por Servi&ccedil;os - TOP 10 - Acumulado</h3>";
	}else{
		$tabela .= "<h3>Qtde. de Desenvolvimentos Abertos por Servi&ccedil;os - TOP 10 - ".utf8_decode(mesDescricao($mesFinal). " de ".$anoFinal)."</h3>";
	}
	
	$tabela .= "<table id='tabelaTotalDesenvolvimentosServico' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th  width='70%'>Servi&ccedil;o</th>
                        <th>Qtde</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $key => $dados){
	
		array_push($servicos, utf8_encode($key));
		array_push($resultados, $dados['Abertura']);
		
		$tabela .= "<tr>
                       <td>".$key."</td>
                       <td>".$dados['Abertura']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	
	
	$retorno['servicos']   = $servicos;
	$retorno['resultados'] = $resultados;
    $retorno['mes']        = mesDescricao($mesFinal);
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function quantidadeTotalDesenvolvimentosColaborador(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
	$periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}

	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$verificaAnos = $anoFinal - $anoInicial;
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->quantidadeTotalDesenvolvimentosColaborador($departamento,$dataInicial,$dataFinal,$acumulado);
	
	if($acumulado){
		$tabela .= "<h3>Qtde. de Desenvolvimentos Abertos por Colaborador - TOP 10 - Acumulado</h3>";
	}else{
		$tabela .= "<h3>Qtde. de Desenvolvimentos Abertos por Colaborador - TOP 10 - ".utf8_decode(mesDescricao($mesFinal). " de ".$anoFinal)."</h3>";
	}
	
	$tabela .= "<table id='tabelaTotalDesenvolvimentosColaborador' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th width='70%'>Colaborador</th>
                        <th>Qtde</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $key => $dados){
		
		$tabela .= "<tr>
                       <td>".$key."</td>
                       <td>".$dados['Qtde']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	

	$retorno['mes']    = mesDescricao($mesFinal);
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function desenvolvimentosAbertos(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$departamento = $_POST['departamento'];	
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->desenvolvimentosAbertos($departamento);
	
	$tabela .= "<h3>Desenvolvimentos <b>ABERTOS</b> at&eacute; ".date("d/m/Y")."</h3>
	            <table id='tabelaDesenvolvimentosAbertos' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>N&uacute;mero</th>
                        <th>Data</th>
                        <th>Previs&atilde;o</th>
                        <th>Descri&ccedil;&atilde;o</th>
                        <th>Etapa</th>
                        <th>Tempo</th>
                        <th>Resp</th>
                        <th>Contato</th>
                        <th>Situa&ccedil;&atilde;o</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($relatorios as $dados){
		
		$tabela .= "<tr>
                       <td>".$dados['Numero']."</td>
                       <td>".$dados['Data']."</td>
                       <td>".$dados['Previsao']."</td>
                       <td style='text-align:justify;'>".$dados['Descricao']."</td>
                       <td>".$dados['Etapa']."</td>
                       <td>".$dados['Tempo']."</td>
                       <td>".$dados['Resp']."</td>
                       <td>".$dados['Contato']."</td>
                       <td>".$dados['Situacao']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	

	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function desenvolvimentosEncerrados(){
	$ok = 0;
	$msg = "";
	$retorno = array();
	
	$utils = new Utils();
	
	$departamento = $_POST['departamento'];
    $periodo      = $_POST['periodo'];
	
	if($_POST['acumulado'] == 1){
		$acumulado = true;
	}else{
		$acumulado = false;
	}
	
	//$departamento = 5;
	//$periodo = '01/12/2015 - 31/03/2016';

	$dataInicial = substr($periodo,0,10);
	$dataFinal   = substr($periodo,13,10);
	
	$dataInicial = $utils->data_mysql($dataInicial);
	$dataFinal   = $utils->data_mysql($dataFinal);
	
	$anoInicial = substr($dataInicial,0,4);
	$anoFinal   = substr($dataFinal,0,4); 
	
	$mesInicial = substr($dataInicial,5,2);
	$mesFinal   = substr($dataFinal,5,2);
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->desenvolvimentosEncerrados($departamento,$dataInicial,$dataFinal,$acumulado);
	
	//print "<pre>";
	//print_r($relatorios);
	//print "<pre>";
	
	if($acumulado){
		$tabela .= "<h3>Desenvolvimentos <b>ENCERRADOS</b> durante o per&iacute;odo Acumulado</h3>";
	}else{
		$tabela .= "<h3>Desenvolvimentos <b>ENCERRADOS</b> durante o M&ecirc;s de ".utf8_decode(mesDescricao($mesFinal). " de ".$anoFinal)."</h3>";
	} 
	
	$tabela .= "<table id='tabelaDesenvolvimentosEncerrados' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>N&uacute;mero</th>
                        <th>Data</th>
                        <th>Previs&atilde;o</th>
                        <th>Descri&ccedil;&atilde;o</th>
                        <th>Etapa</th>
                        <th>Resp</th>
                        <th>Contato</th>
                        <th>Situa&ccedil;&atilde;o</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	
	foreach($relatorios as $dados){
		
		$tabela .= "<tr>
                       <td>".$dados['Numero']."</td>
                       <td>".$dados['Data']."</td>
                       <td>".$dados['Previsao']."</td>
                       <td style='text-align:justify;'>".$dados['Descricao']."</td>
                       <td>".$dados['Etapa']."</td>
                       <td>".$dados['Resp']."</td>
                       <td>".$dados['Contato']."</td>
                       <td>".$dados['Situacao']."</td>
                    </tr>";
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";	

	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function buscaProjetos(){
	
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
		
	$relatorio = new Relatorios();
	
	$departamento = $_POST['departamento'];
	
	$relatorios = $relatorio->buscaProjetos($departamento);
		
	$tabela = "";		
	
	foreach($relatorios as $dados){		
	//	var_dump(utf8_encode($dados['Nome do Projeto']));	
	
	/*	print "<pre>";
		print_r($dados);
		print "<pre>";	*/
		
	/*	$tabela .= "<tr>
                       <td>".utf8_encode($dados['Nome do Projeto'])."</td>
                       <td>".utf8_encode($dados['Departamento'])."</td>
                       <td>".utf8_encode($dados['Responsavel'])."</td>
                       <td>".utf8_encode($dados['Patrocinador'])."</td>
                       <td>".utf8_encode($dados['Proprietario'])."</td>
                       <td>".utf8_encode($dados['Status'])."</td>
                    </tr>";*/
		
		$ok = 1;
		
		$tabela .= "
		<table width=95% border=0 align='center'>	
			<tr>				
				<td style='font-size:20px;background-color:#2F75B5;' class='fonte'><font color=#ffffff><b>".$dados['Nome do Projeto']."</font></b></td>
			</tr>	
			<tr>
				<td>&nbsp;</td>
			</tr>			
		</table>
		
		<table width=95% border=0 align='center'>	
			<tr>
				<td style='font-size:15px;' class='fonte' width='15%'><font color=#000000><b>Status do Projeto:</b></font></td>
				<td style='font-size:15px;' class='fonte'><font color=#000000>".$dados['Status']."</font></td>
			</tr>
			<tr>
				<td style='font-size:15px;' class='fonte' width='15%'><font color=#000000><b>Departamento:</b></font></td>
				<td style='font-size:15px;' class='fonte'><font color=#000000>".$dados['Departamento']."</font></td>
			</tr>
			<tr>
				<td style='font-size:15px;' class='fonte' width='15%'><font color=#000000><b>Respons&aacute;vel:</b></font></td>
				<td style='font-size:15px;' class='fonte'><font color=#000000>".$dados['Responsavel']."</font></td>
			</tr>
			<tr>
				<td style='font-size:15px;' class='fonte' width='15%'><font color=#000000><b>Patrocinador:</b></font></td>
				<td style='font-size:15px;' class='fonte'><font color=#000000>".$dados['Patrocinador']."</font></td>
			</tr>
			<tr>
				<td style='font-size:15px;' class='fonte' width='15%'><font color=#000000><b>Propriet&aacute;rio:</b></font></td>
				<td style='font-size:15px;' class='fonte'><font color=#000000>".$dados['Proprietario']."</font></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>			
		</table>";		

	/*	$tabela .= "<table id='tabelaProjetos' class='table table-bordered table-striped'>
						<thead>
						  <tr>
							<th>Nome do Projeto</th>
							<th>Departamento</th>
							<th>Repons&aacute;vel</th>
							<th>Patrocinador</th>
							<th>Propriet&aacute;rio</th>
							<th>Status</th>
						  </tr>
						</thead>
						<tbody>";

		$tabela .= "<tr>
                       <td>".utf8_encode($dados['Nome do Projeto'])."</td>
                       <td>".utf8_encode($dados['Departamento'])."</td>
                       <td>".utf8_encode($dados['Responsavel'])."</td>
                       <td>".utf8_encode($dados['Patrocinador'])."</td>
                       <td>".utf8_encode($dados['Proprietario'])."</td>
                       <td>".utf8_encode($dados['Status'])."</td>
                    </tr>";
						
		$tabela .= "</tbody></table>";*/					
						
		if(utf8_encode($dados['Status']) != "Não Iniciado"){


			$sqlEPM = "SELECT puw.ProjectName AS [Nome do Projeto],

				   CONVERT(CHAR,puw.ProjectStartDate,103) + ' - ' + CONVERT(CHAR,puw.ProjectStartDate,108) AS [Inicio],
				   CONVERT(CHAR,puw.ProjectBaseline0StartDate,103) + ' - ' + CONVERT(CHAR,puw.ProjectBaseline0StartDate,108) AS [Inicio da Linha de Base],
				   CONVERT(CHAR,puw.ProjectActualStartDate,103) + ' - ' + CONVERT(CHAR,puw.ProjectActualStartDate,108) AS [Inicio Real],
				   round((puw.ProjectStartVariance / 8),2) AS [Variacao Inicial],
				   
				   CONVERT(CHAR,puw.ProjectFinishDate,103) + ' - ' + CONVERT(CHAR,puw.ProjectFinishDate,108) AS [Termino],
				   CONVERT(CHAR,puw.ProjectBaseline0FinishDate,103) + ' - ' + CONVERT(CHAR,puw.ProjectBaseline0FinishDate,108) AS [Termino da Linha de Base], 
				   CONVERT(CHAR,puw.ProjectActualFinishDate,103) + ' - ' + CONVERT(CHAR,puw.ProjectActualFinishDate,108) AS [Termino Real],
				   round((puw.ProjectFinishVariance / 8),2) AS [Variacao do Termino],

				   round((puw.ProjectDuration / 8),2) AS [Duracao Agendada],
				   round((puw.ProjectBaseline0Duration / 8),2) AS [Duracao Linha de Base],
				   round((puw.ProjectDurationVariance / 8),2) AS [Variacao da Duracao],
				   round((puw.ProjectRemainingDuration / 8),2) AS [Duracao Restante],
				   round((puw.ProjectActualDuration / 8),2) AS [Duracao Real],
				   round((((puw.ProjectActualDuration / 8) * 100) / (puw.ProjectDuration / 8)),2) AS [Porcentagem Duracao Concluida],
				   round(puw.ProjectPercentCompleted,2) AS [Porcentagem Concluida],
				   
				   round(puw.ProjectWork,2) AS [Trabalho Agendado],
				   round(puw.ProjectBaseline0Work,2) AS [Trabalho Linha de Base],
				   round(puw.ProjectWorkVariance,2) AS [Variacao do Trabalho],
				   round(puw.ProjectRemainingWork,2) AS [Trabalho Restante],
				   round(puw.ProjectActualWork,2) AS [Trabalho Atual],
				   round(((puw.ProjectActualWork * 100) / puw.ProjectWork),2) AS [Porcentagem Concluida Trabalho],
				   
				   round(puw.ProjectCost,2) AS [Custo Agendado],
				   round(puw.ProjectBaseline0Cost,2) AS [Custo Linha de Base],
				   round(puw.ProjectCostVariance,2) AS [Variacao do Custo],
				   puw.ProjectRemainingCost AS [Custo Restante],
				   puw.ProjectActualCost AS [Custo Real],

				   (SELECT count(t.TaskName)
					  FROM dbo.MSP_EpmProject_UserView u
				INNER JOIN dbo.MSP_EpmTask_UserView t 
						ON (u.ProjectUID = t.ProjectUID)
					 WHERE u.ProjectName LIKE '".substr($dados['Nome do Projeto'],0,6)."%'
					   AND t.TaskIsActive = 'True'
					   AND t.TaskIsSummary = 'False' 
					   AND t.TaskIsProjectSummary = 'False'						 
					   AND ((t.TaskPercentCompleted = 0) 
					   AND  (t.TaskPercentWorkCompleted = 0))) AS [Tarefas ainda nao iniciadas],

				   (SELECT count(t.TaskName)
					  FROM dbo.MSP_EpmProject_UserView u
				INNER JOIN dbo.MSP_EpmTask_UserView t 
						ON (u.ProjectUID = t.ProjectUID)
					 WHERE u.ProjectName LIKE '".substr($dados['Nome do Projeto'],0,6)."%'
					   AND t.TaskIsActive = 'True'
					   AND t.TaskIsSummary = 'False' 
					   AND t.TaskIsProjectSummary = 'False'						 
					   AND ((t.TaskPercentCompleted > 0 AND t.TaskPercentCompleted < 100) 
					   AND  (t.TaskPercentWorkCompleted > 0 AND t.TaskPercentWorkCompleted < 100))) AS [Tarefas em Atendimento],

				   (SELECT count(t.TaskName)
					  FROM dbo.MSP_EpmProject_UserView u
				INNER JOIN dbo.MSP_EpmTask_UserView t 
						ON (u.ProjectUID = t.ProjectUID)
					 WHERE u.ProjectName LIKE '".substr($dados['Nome do Projeto'],0,6)."%'
					   AND t.TaskIsActive = 'True'
					   AND t.TaskIsSummary = 'False' 
					   AND t.TaskIsProjectSummary = 'False'	
					   AND ((t.TaskPercentCompleted = 100) 
					    OR  (t.TaskPercentWorkCompleted = 100))) AS [Tarefas Concluidas],

				   (SELECT count(t.TaskName)
					  FROM dbo.MSP_EpmProject_UserView u
				INNER JOIN dbo.MSP_EpmTask_UserView t 
						ON (u.ProjectUID = t.ProjectUID)
					 WHERE u.ProjectName LIKE '".substr($dados['Nome do Projeto'],0,6)."%'
					   AND t.TaskIsActive = 'True'
					   AND t.TaskIsSummary = 'False' 
					   AND t.TaskIsProjectSummary = 'False'	
					   AND t.TaskOutlineLevel <> 0) AS [Total de Tarefas]
				   
			  FROM dbo.MSP_EpmProject_UserView puw
			 WHERE puw.ProjectName LIKE '".substr($dados['Nome do Projeto'],0,6)."%'";
			 
//print $sqlEPM."<br>";			 

			$resultEPM = mssql_query($sqlEPM);

			$rowEPM = mssql_fetch_array($resultEPM);			 
			
			$variacaoTermino = number_format(str_replace(",","",$rowEPM['Variacao do Termino']), 2, ',', '.');
			
			if($variacaoTermino > 0){
				$colorTermino = "red";
			}
			if($variacaoTermino < 0){
				$colorTermino = "green";
			}
			if($variacaoTermino == 0){
				$colorTermino = "black";
			}			

			$tabela .= "
			<table width='95%' border='0' align='center'>
				<tr>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>Datas</b></td>						
								</tr>

								<tr>
									<td width='50%' style='background-color:#EDEDED;'>In&iacute;cio</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Inicio']."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>In&iacute;cio da Linha de Base</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Inicio da Linha de Base']."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>In&iacute;cio Real</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Inicio Real']."</b></td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Varia&ccedil;&atilde;o Inicial</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Variacao Inicial']."</td>
								</tr>
						</table>
					</td>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff' class='fonte'><b>&nbsp;</b></td>						
								</tr>

								<tr>
									<td width='50%' style='background-color:#EDEDED;'>T&eacute;rmino</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Termino']."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>T&eacute;rmino da Linha de Base</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Termino da Linha de Base']."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>T&eacute;rmino Real</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Termino Real']."</b></td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Varia&ccedil;&atilde;o T&eacute;rmino</td>
									<td style='background-color:#EDEDED;'><font color='$colorTermino'>".$variacaoTermino." dias</font></td>
								</tr>
						</table>
					</td>			
				</tr>
			</table><br>";
			
			$variacaoDuracao = number_format(str_replace(",","",$rowEPM['Variacao da Duracao']), 2, ',', '.');
			
			if($variacaoDuracao > 0){
				$colorDuracao = "red";
			}
			if($variacaoDuracao < 0){
				$colorDuracao = "green";
			}
			if($variacaoDuracao == 0){
				$colorDuracao = "black";
			}			
			
			$tabela .= "
			<table width='95%' border='0' align='center'>
				<tr>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>Dura&ccedil;&atilde;o</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Agendado</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Duracao Agendada']), 2, ',', '.')." dias</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Linha de Base</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Duracao Linha de Base']), 2, ',', '.')." dias</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Varia&ccedil;&atilde;o</td>
									<td style='background-color:#EDEDED;'><font color='$colorDuracao'>".$variacaoDuracao." dias</font></td>
								</tr>
						</table>
					</td>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>&nbsp;</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Restante</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Duracao Restante']), 2, ',', '.')." dias</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Real</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Duracao Real']), 2, ',', '.')." dias</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Porcentagem Conclu&iacute;da</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Porcentagem Duracao Concluida']), 2, ',', '.')."%</td>
								</tr>
						</table>
					</td>			
				</tr>
			</table><br>";

			$variacaoTrabalho = number_format(str_replace(",","",$rowEPM['Variacao do Trabalho']), 2, ',', '.');
			
			if($variacaoTrabalho > 0){
				$colorTrabalho = "red";
			}
			if($variacaoTrabalho < 0){
				$colorTrabalho = "green";
			}
			if($variacaoTrabalho == 0){
				$colorTrabalho = "black";
			}
			
			$tabela .= "	
			<table width='95%' border='0' align='center'>
				<tr>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>Trabalho</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Agendado</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Trabalho Agendado']), 2, ',', '.')." hrs</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Linha de Base</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Trabalho Linha de Base']), 2, ',', '.')." hrs</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Varia&ccedil;&atilde;o</td>
									<td style='background-color:#EDEDED;'><font color='$colorTrabalho'>".number_format(str_replace(",","",$rowEPM['Variacao do Trabalho']), 2, ',', '.')." hrs</font></td>
								</tr>
						</table>
					</td>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>&nbsp;</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Restante</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Trabalho Restante']), 2, ',', '.')." hrs</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Real</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Trabalho Atual']), 2, ',', '.')." hrs</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Porcentagem Conclu&iacute;da</td>
									<td style='background-color:#EDEDED;'>".number_format(str_replace(",","",$rowEPM['Porcentagem Concluida Trabalho']), 2, ',', '.')."%</td>
								</tr>
						</table>
					</td>			
				</tr>
			</table><br>";
			
			$variacaoCusto = number_format(str_replace(",","",$rowEPM['Variacao do Custo']), 2, ',', '.');
			
			if($variacaoCusto > 0){
				$colorCusto = "red";
			}
			if($variacaoCusto < 0){
				$colorCusto = "green";
			}
			if($variacaoCusto == 0){
				$colorCusto = "black";
			}
			
			$tabela .= "
			<table width='95%' border='0' align='center'>
				<tr>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>Custo</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Agendado</td>
									<td style='background-color:#EDEDED;'>R$ ".number_format(str_replace(",","",$rowEPM['Custo Agendado']), 2, ',', '.')."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Linha de Base</td>
									<td style='background-color:#EDEDED;'>R$ ".number_format(str_replace(",","",$rowEPM['Custo Linha de Base']), 2, ',', '.')."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Varia&ccedil;&atilde;o</td>
									<td style='background-color:#EDEDED;'><font color='$colorCusto'>R$ ".$variacaoCusto."</font></td>
								</tr>
						</table>
					</td>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>&nbsp;</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Restante</td>
									<td style='background-color:#EDEDED;'>R$ ".number_format(str_replace(",","",$rowEPM['Custo Restante']), 2, ',', '.')."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Real</td>
									<td style='background-color:#EDEDED;'>R$ ".number_format(str_replace(",","",$rowEPM['Custo Real']), 2, ',', '.')."</td>
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
									<td style='background-color:#EDEDED;'>&nbsp;</td>
								</tr>								
						</table>
					</td>			
				</tr>
			</table><br>

			<table width='95%' border='0' align='center'>
				<tr>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=2 style='font-size:16px;background-color:#5B5C65;color:#ffffff;' class='fonte'><b>Status das Tarefas</b></td>						
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Tarefas ainda n&atilde;o iniciadas</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Tarefas ainda nao iniciadas']."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Tarefas em Andamento</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Tarefas em Atendimento']."</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Tarefas Conclu&iacute;das</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Tarefas Concluidas']."</td>
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>Total de Tarefas</td>
									<td style='background-color:#EDEDED;'>".$rowEPM['Total de Tarefas']."</td>
								</tr>						
						</table>
					</td>
					<td width='50%' valign='top'>
						<table width=100% border=0 align='left'>
								<tr>
									<td width='50%' style='font-size:16px;background-color:#5B5C65;color:#ffffff;'>&nbsp;</td>
									<td width='50%' style='font-size:16px;background-color:#5B5C65;color:#ffffff;'>&nbsp;</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
								</tr>					
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
								</tr>
								<tr>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
									<td width='50%' style='background-color:#EDEDED;'>&nbsp;</td>
								</tr>									
						</table>
					</td>			
				</tr>
			</table><br>	
			
			<table width='95%' border='0' align='center'>
				<tr>
					<td width='100%' valign='top'>
						<table width=100% border=0 align='left'>	
								<tr>
									<td colspan=11 style='font-size:12px;' class='fonte'>LB* = Linha de Base</td>						
								</tr>
								<tr>
									<td colspan=11>&nbsp;</td>						
								</tr>								
								<tr>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Tarefa</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>In&iacute;cio</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Fim</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>In&iacute;cio LB*</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Fim LB*</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Respons&aacute;vel</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Custo LB*</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Custo</td>									
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>% Trabalho Conclu&iacute;do</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>% Conclu&iacute;do</td>
									<td style='background-color:#5B5C65;color:#ffffff;' align='center'>Status</td>
								</tr>";
								
								//FFF0C7
						
						$sqlTarefa = "SELECT MSP_EpmProject_UserView.ProjectName AS [Nome do Projeto], 
											 MSP_EpmTask_UserView.TaskName AS [Tarefa], 
											 CONVERT(CHAR,MSP_EpmTask_UserView.TaskStartDate,103) AS [Inicio],
											 CONVERT(CHAR,MSP_EpmTask_UserView.TaskFinishDate,103) AS [Fim],
											 CONVERT(CHAR,MSP_EpmTask_UserView.TaskBaseline0StartDate,103) AS [Data Inicio_LB0],
											 CONVERT(CHAR,MSP_EpmTask_UserView.TaskBaseline0FinishDate,103) AS [Data Termino_LB0], 
											 MSP_EpmResource_UserView.ResourceName AS [Responsavel Tarefa], 
											 MSP_EpmTask_UserView.TaskPercentCompleted AS [Percentual da Tarefa], 
											 dbo.MSP_EpmAssignment_UserView.AssignmentActualCost AS [Custo], 
											 dbo.MSP_EpmAssignment_UserView.AssignmentBaseline0Cost AS [Custo_LBO],											 
											 MSP_EpmTask_UserView.TaskPercentWorkCompleted AS [Percentual do Projeto], 
										CASE
										WHEN MSP_EpmTask_UserView.TaskBaseline0FinishDate < GetDate()
										THEN 'Atrasada'
										ELSE 'No Prazo' END AS [Status]
					 
										FROM dbo.MSP_EpmProject_UserView
								  INNER JOIN dbo.MSP_EpmTask_UserView 
										  ON (MSP_EpmProject_UserView.ProjectUID = MSP_EpmTask_UserView.ProjectUID)
								  INNER JOIN dbo.MSP_EpmAssignment_UserView 
										  ON ((MSP_EpmAssignment_UserView.ProjectUID = MSP_EpmProject_UserView.ProjectUID) 
										 AND  (MSP_EpmAssignment_UserView.TaskUID = MSP_EpmTask_UserView.TaskUID))
								  INNER JOIN dbo.MSP_EpmResource_UserView 
										  ON (MSP_EpmAssignment_UserView.ResourceUID = MSP_EpmResource_UserView.ResourceUID)
									   WHERE (MSP_EpmResource_UserView.EDR LIKE 'Unimed VTRP.Tecnologia da Informa%'
										  OR MSP_EpmResource_UserView.EDR LIKE 'Unimed VTRP.".$dados['Departamento']."%')
										 AND MSP_EpmProject_UserView.ProjectName LIKE '".substr($dados['Nome do Projeto'],0,6)."%'
										 AND MSP_EpmTask_UserView.TaskIsActive = 'True'
										 AND ((MSP_EpmTask_UserView.TaskPercentCompleted < 100) 
										 AND  (MSP_EpmTask_UserView.TaskPercentWorkCompleted < 100))
									ORDER BY MSP_EpmProject_UserView.ProjectName, MSP_EpmTask_UserView.TaskIndex, MSP_EpmTask_UserView.TaskName";						
						
//print $sqlTarefa."<br>";
						
						$resultTarefa = mssql_query($sqlTarefa);
						
						

						$color = "aliceblue";
						
						while($rowTarefa = mssql_fetch_array($resultTarefa)){
						
							if($rowTarefa['Data Termino_LB0'] == ""){
								$data = "-";
								$status = "-";
							}else{
								$data = $rowTarefa['Data Termino_LB0'];
								$status = $rowTarefa['Status'];
							}	
								
							if($color == "aliceblue"){
								$color = "#ffffff";
							}else{
								$color = "aliceblue";
							}
								
								$tabela .= "
								<tr>
									<td width='35%' style='background-color:$color;'>".$rowTarefa['Tarefa']."</td>
									<td style='background-color:$color;'>".$rowTarefa['Inicio']."</td>
									<td style='background-color:$color;'>".$rowTarefa['Fim']."</td>
									<td style='background-color:$color;'>".$rowTarefa['Data Inicio_LB0']."</td>
									<td style='background-color:$color;'>".$data."</td>
									<td style='background-color:$color;'>".$rowTarefa['Responsavel Tarefa']."</td>
									<td style='background-color:$color;'>R$ ".number_format(str_replace(",","",$rowTarefa['Custo_LBO']), 2, ',', '.')."</td>
									<td style='background-color:$color;'>R$ ".number_format(str_replace(",","",$rowTarefa['Custo']), 2, ',', '.')."</td>									
									<td style='background-color:$color;' align='center'>".number_format(str_replace(",","",$rowTarefa['Percentual da Tarefa']), 2, ',', '.')."</td>
									<td style='background-color:$color;' align='center'>".number_format(str_replace(",","",$rowTarefa['Percentual do Projeto']), 2, ',', '.')."</td>
									<td style='background-color:$color;'>".$status."</td>							
								</tr>";
						}
								
						$tabela .= "		
						</table>
					</td>
				</tr>
				<tr><td>&nbsp;</td></tr>
				<tr><td>&nbsp;</td></tr>
				<tr><td>&nbsp;</td></tr>
			</table>";			
			
		}	/* --- FIM IF STATUS NAO INICIADO --- */
		
		
	}
	
		
	
	//print $tabela;
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = utf8_encode($tabela);
	echo json_encode($retorno);
}

function montaDepartamentos(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$select = "";
	
	$relatorio = new Relatorios();
	
	$relatorios = $relatorio->listaDepartamentosByDescricao();
	
	$select .= "<select class='form-control' id='departamentoConsulta'>
	            <option value=''>:: Selecione ::</option>";
	
	foreach($relatorios as $dados){
		
		$select .= "<option value=$dados[cddepartamento]>$dados[nmdepartamento]</option>";
		
		$ok = 1;
		
	}
	
	$select .= "</select>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['select'] = utf8_encode($select);
	echo json_encode($retorno);
}


?>