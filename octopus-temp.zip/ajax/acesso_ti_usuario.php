<?php
include("../inc/config.php");
include("../classes/Utils.class.php");
session_start();

//$_GET['acao'] = 'listaUsuarios';

if($_GET['acao']  == 'listaUsuarios'){
	listaUsuarios();
}

function listaUsuarios(){
	$ok = 0;
	$msg = "";
	$array = array();
	$retorno = array();
	$tabela = "";
	
	$usuarios = $_SESSION['lista_nome_usuarios'];
	$emails = $_SESSION['lista_email_usuarios'];
	
	foreach($usuarios as $key => $dados){
	
		$array[$key] = $dados;
	}
		
	$tabela .= "<table id='tabelaUsuarios' class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>Login</th>
                        <th>Nome</th>
						<th>E-mail</th>
                      </tr>
                    </thead>
                    <tbody>";
	
	foreach($usuarios as $key => $dados){
			
		$login = $key;
		$nome  = $dados;
		$email = $_SESSION['lista_email_usuarios'][$key];
		
		if(($login != '')&($email != '')){
			
			$tabela .= "<tr>
						   <td>$login</td>
						   <td>$nome</td>
						   <td>$email</td>
						</tr>";
		}
		
		$ok = 1;
	}
	
	$tabela .= "</tbody></table>";
	
	$retorno['ok']     = $ok;
	$retorno['msg']    = ($msg);
	$retorno['tabela'] = $tabela;
	echo json_encode($retorno);
}

?>