function exibeDemonstrativo(msg){
	$('#dialogDemonstrativoMsg').html(msg);
	$('#dialog-demonstrativo').modal();
}

function exibeErro(msg){
	$('#dialogErrorMsg').html(msg);
	$('#dialog-error').modal();
}

function formata_data(data){
	data = data.split('-');
	return data[2]+"/"+data[1]+"/"+data[0];
}

function formataCarteira(carteira){
	if(carteira > 0){
		while(carteira.length < 13){
			carteira = "0"+carteira;
		}
		carteira = "0029."+carteira.substr(0,12)+"-"+carteira[12];
	}
	return carteira;
}
function exibeExclusao(msg){
    $('#dialog-message-exclusao').html(msg);
    $('#dialog-exclusao').modal();
}
function findarPlano(msg){
    $('#dialog-message-findar').html(msg);
    $('#dialog-findar').modal();
}
function exibeConfirmaInclusao(msg){
    $('#dialog-message-confirma-inclusao-coop').html(msg);
    $('#dialog-confirma-inclusao-coop').modal();
}
function exibeConfirmaAlteracao(msg){
    $('#dialog-message-confirma-alteracao-coop').html(msg);
    $('#dialog-confirma-alteracao-coop').modal();
}
function moeda(valor, casas, separdor_decimal, separador_milhar){ 
 
 var valor_total = parseInt(valor * (Math.pow(10,casas)));
 var inteiros =  parseInt(parseInt(valor * (Math.pow(10,casas))) / parseFloat(Math.pow(10,casas)));
 var centavos = parseInt(parseInt(valor * (Math.pow(10,casas))) % parseFloat(Math.pow(10,casas)));
 
  
 if(centavos%10 == 0 && centavos+"".length<2 ){
  centavos = centavos+"0";
 }else if(centavos<10){
  centavos = "0"+centavos;
 }
  
 var milhares = parseInt(inteiros/1000);
 inteiros = inteiros % 1000; 
 
 var retorno = "";
 
 if(milhares>0){
  retorno = milhares+""+separador_milhar+""+retorno
  if(inteiros == 0){
   inteiros = "000";
  } else if(inteiros < 10){
   inteiros = "00"+inteiros; 
  } else if(inteiros < 100){
   inteiros = "0"+inteiros; 
  }
 }
  retorno += inteiros+""+separdor_decimal+""+centavos;
 
 
 return retorno;
 
}



function validaCPF(CPF) {
CPF = CPF.replace(".","");
CPF = CPF.replace(".","");
CPF = CPF.replace("-","");

// Verifica se o campo é nulo
if (CPF == '') {
  return true;
}else if(CPF == '00000000000'){
	return false;
}else if(CPF == '11111111111'){
	return false;
}else if(CPF == '22222222222'){
	return false;
}else if(CPF == '33333333333'){
	return false;
}else if(CPF == '44444444444'){
	return false;
}else if(CPF == '55555555555'){
	return false;
}else if(CPF == '66666666666'){
	return false;
}else if(CPF == '77777777777'){
	return false;
}else if(CPF == '88888888888'){
	return false;
}else if(CPF == '99999999999'){
	return false;
}
// Aqui começa a checagem do CPF
var POSICAO, I, SOMA, DV, DV_INFORMADO;
var DIGITO = new Array(10);
DV_INFORMADO = CPF.substr(9, 2); // Retira os dois últimos dígitos do número informado

// Desemembra o número do CPF na array DIGITO
for (I=0; I<=8; I++) {
  DIGITO[I] = CPF.substr( I, 1);
}

// Calcula o valor do 10º dígito da verificação
POSICAO = 10;
SOMA = 0;
   for (I=0; I<=8; I++) {
      SOMA = SOMA + DIGITO[I] * POSICAO;
      POSICAO = POSICAO - 1;
   }
DIGITO[9] = SOMA % 11;
   if (DIGITO[9] < 2) {
        DIGITO[9] = 0;
}
   else{
       DIGITO[9] = 11 - DIGITO[9];
}

// Calcula o valor do 11º dígito da verificação
POSICAO = 11;
SOMA = 0;
   for (I=0; I<=9; I++) {
      SOMA = SOMA + DIGITO[I] * POSICAO;
      POSICAO = POSICAO - 1;
   }
DIGITO[10] = SOMA % 11;
   if (DIGITO[10] < 2) {
        DIGITO[10] = 0;
   }
   else {
        DIGITO[10] = 11 - DIGITO[10];
   }

// Verifica se os valores dos dígitos verificadores conferem
DV = DIGITO[9] * 10 + DIGITO[10];
   if (DV != DV_INFORMADO) {
      
      
      return false;
   }else{
	return true;
   }
}

function isDataValida(date){
	var ExpReg=new RegExp("(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/[12][0-9]{3}");
	ardt=date.split("/");
	erro=false;
	if ( date.search(ExpReg)==-1){
		erro = true;
		}
	else if (((ardt[1]==4)||(ardt[1]==6)||(ardt[1]==9)||(ardt[1]==11))&&(ardt[0]>30))
		erro = true;
	else if ( ardt[1]==2) {
		if ((ardt[0]>28)&&((ardt[2]%4)!=0))
			erro = true;
		if ((ardt[0]>29)&&((ardt[2]%4)==0))
			erro = true;
	}
	return erro;
	
}


function calcular_idade(data){
    //calculo a data de hoje
    hoje=new Date();
    //calculo a data que recebo
    //descomponho a data em um array
    var array_data = data.split('/');
    //se o array nao tem tres partes, a data eh incorreta
    if (array_data.length!=3)
       return false
    //comprovo que o ano, mes, dia são corretos
    var ano;
    ano = parseInt(array_data[2]);
    if (isNaN(ano))
       return false;
    var mes;
    mes = parseInt(array_data[1]);
    if (isNaN(mes))
       return false;
    var dia;
    dia = parseInt(array_data[0]);
    if (isNaN(dia))
       return false;
    //se o ano da data que recebo so tem 2 cifras temos que muda-lo a 4
    if (ano<=99)
       ano +=1900;
    //subtraio os anos das duas datas
if (/MSIE (5\.5|6|7|8)/.test(navigator.userAgent)){
	var idade=parseInt(hoje.getYear()) -  ano - 1; 
}else{
    var idade=parseInt(hoje.getYear()) -  ano - 1 + 1900; //-1 porque ainda nao fez anos durante este ano
}
//se subtraio os meses e for menor que 0 entao nao cumpriu anos. Se for maior sim ja cumpriu
    if (hoje.getMonth() + 1 - mes < 0) //+ 1 porque os meses comecam em 0
       return idade;
    if (hoje.getMonth() + 1 - mes > 0)
       return idade+1;
    //entao eh porque sao iguais. Vejo os dias
    //se subtraio os dias e der menor que 0 entao nao cumpriu anos. Se der maior ou igual sim que já cumpriu
    if (hoje.getUTCDate() - dia >= 0)
       return idade + 1;
    return idade;
} 

function validaCPFAtualizacao(cpf){
	if(cpf != '' && cpf != '___.___.___-__'){
		if(!validaCPF(cpf)){
			$('#msg-erro-cpf-atualizacao-valido').hide();
			$('#msg-erro-cpf-atualizacao-invalido').show('pulsate',{},500);
			
		}else{
			$('#msg-erro-cpf-atualizacao-invalido').hide();
			$('#msg-erro-cpf-atualizacao-valido').show('pulsate',{},500);
			
		}
	}else{
		$('#msg-erro-cpf-atualizacao-invalido').hide();
		$('#msg-erro-cpf-atualizacao-valido').hide();
	}
}

function validaCNSAtualizacao(cns){
	if(cns != '' && cns != '_______________'){
		if(isDvCnsValido(cns)){
			$('#msg-erro-cns-atualizacao-invalido').hide();
			$('#msg-erro-cns-atualizacao-valido').show('pulsate',{},500);
		}else{
			$('#msg-erro-cns-atualizacao-valido').hide();
			$('#msg-erro-cns-atualizacao-invalido').show('pulsate',{},500);
		}
	}else{
		$('#msg-erro-cns-atualizacao-invalido').hide();
		$('#msg-erro-cns-atualizacao-valido').hide();
	}
}

function validaDNAtualizacao(dn){
	if(dn != '' && dn != '___________'){
		if(isDNValida(dn)){
			$('#msg-erro-dn-atualizacao-invalido').hide();
			$('#msg-erro-dn-atualizacao-valido').show('pulsate',{},500);
		}else{
			$('#msg-erro-dn-atualizacao-valido').hide();
			$('#msg-erro-dn-atualizacao-invalido').show('pulsate',{},500);
		}
	}else{
		$('#msg-erro-dn-atualizacao-invalido').hide();
		$('#msg-erro-dn-atualizacao-valido').hide();
	}
}

function isDNValida(dnParam){
	var dn = new String();
	dn = ""+dnParam;
	if(dn.trim().length != 11
	   || dn.trim() == "00000000000"
	   || dn.trim() == "11111111111"
	   || dn.trim() == "22222222222"
	   || dn.trim() == "33333333333"
	   || dn.trim() == "44444444444"
	   || dn.trim() == "55555555555"
	   || dn.trim() == "66666666666"
	   || dn.trim() == "77777777777"
	   || dn.trim() == "88888888888"
	   || dn.trim() == "99999999999"){
	   return false;
	}
	return true;
}

function isDvCnsValido(numCnsParam){
	var numCns = new String();
	numCns = ""+numCnsParam;
	var cns = numCns.replace(/[^0-9]/g, "");
	if (cns == "000000000000000") {
		return false;
	}
	return validaCns(cns) || validaCnsProv(cns);
}

function validaCnsProv(cnsParam){
	var cns = new String();
	cns = ""+cnsParam;
	if (cns.trim().length != 15) {
		return false;
	}
	var resto;
	var soma;
	soma = ((parseInt(cns.substring(0, 1))) * 15)
	+ ((parseInt(cns.substring(1, 2))) * 14)
	+ ((parseInt(cns.substring(2, 3))) * 13)
	+ ((parseInt(cns.substring(3, 4))) * 12)
	+ ((parseInt(cns.substring(4, 5))) * 11)
	+ ((parseInt(cns.substring(5, 6))) * 10)
	+ ((parseInt(cns.substring(6, 7))) * 9)
	+ ((parseInt(cns.substring(7, 8))) * 8)
	+ ((parseInt(cns.substring(8, 9))) * 7)
	+ ((parseInt(cns.substring(9, 10))) * 6)
	+ ((parseInt(cns.substring(10, 11))) * 5)
	+ ((parseInt(cns.substring(11, 12))) * 4)
	+ ((parseInt(cns.substring(12, 13))) * 3)
	+ ((parseInt(cns.substring(13, 14))) * 2)
	+ ((parseInt(cns.substring(14, 15))) * 1);
	resto = soma % 11;
	if (resto != 0) {
		return (false);
	} else {
		return (true);
	}
}
function validaCns(cnsParam){
	var cns = new String();
	cns = ""+cnsParam;
	if (cns.trim().length != 15) {
		return false;
	}
	var soma;
	var resto;
	var dv;
	var pis = new String("");
	var resultado = new String();
	pis = cns.substring(0, 11);
	soma = ((parseInt(pis.substring(0, 1))) * 15)
	+ ((parseInt(pis.substring(1, 2))) * 14)
	+ ((parseInt(pis.substring(2, 3))) * 13)
	+ ((parseInt(pis.substring(3, 4))) * 12)
	+ ((parseInt(pis.substring(4, 5))) * 11)
	+ ((parseInt(pis.substring(5, 6))) * 10)
	+ ((parseInt(pis.substring(6, 7))) * 9)
	+ ((parseInt(pis.substring(7, 8))) * 8)
	+ ((parseInt(pis.substring(8, 9))) * 7)
	+ ((parseInt(pis.substring(9, 10))) * 6)
	+ ((parseInt(pis.substring(10, 11))) * 5);
	
	resto = soma % 11;
	dv = 11 - resto;
	if (dv == 11) {
		dv = 0;
	}
	if (dv == 10) {
		soma = ((parseInt(pis.substring(0, 1))) * 15) + ((parseInt(pis.substring(1, 2))) * 14) + ((parseInt(pis.substring(2, 3))) * 13) + ((parseInt(pis.substring(3, 4))) * 12) + ((parseInt(pis.substring(4, 5))) * 11) + ((parseInt(pis.substring(5, 6))) * 10) + ((parseInt(pis.substring(6, 7))) * 9) + ((parseInt(pis.substring(7, 8))) * 8) + ((parseInt(pis.substring(8, 9))) * 7) + ((parseInt(pis.substring(9, 10))) * 6) + ((parseInt(pis.substring(10, 11))) * 5)
		+ 2;
		resto = soma % 11;
		dv = 11 - resto;
		resultado = pis + "001" + dv;
	} else {
		resultado = pis + "000" + dv;
	}
	if (cns != resultado) {
		return (false);
	} else {
		return (true);
	}
}
