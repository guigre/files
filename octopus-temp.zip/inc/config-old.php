<?php
//-- EXIBE ERROS?
error_reporting(E_ALL  ^ E_NOTICE);
ini_set('display_errors','Off');

//-- CAMINHOS NO SERVIDOR

/* --- LOCALHOST --- */
/*define("DIR_FS_SITE","C:/xampp/htdocs/octopus/");
define("DIR_WS_SITE","http://localhost/octopus/");*/

/* --- SERVER --- */
define("DIR_FS_SITE","/var/www/html/octopus-temp/");
define("DIR_WS_SITE","http://octopus-temp.unimedvtrp.com.br/");
define("DIR_FS_WSDL",DIR_WS_SITE."wsdl/");

define("DIR_FS_CLASSES",DIR_FS_SISTEMA."classes/");
define("DIR_WS_CLASSES",DIR_WS_SISTEMA."classes/");
define("DIR_FS_LIB",DIR_FS_SISTEMA."lib/");
define("DIR_WS_LIB",DIR_WS_SISTEMA."lib/");
define('DIR_FS_INC',DIR_FS_SISTEMA.'inc/');
define('DIR_WS_INC',DIR_WS_SISTEMA.'inc/');
define("DIR_FS_CONFIG",DIR_FS_SISTEMA);

//-- CONFIGS FUNCIONALIDADES
define("DEFAULT_ENCODING", "ISO-8859-1");
define("SOAP_ENCODE","UTF-8");
define("VERSAO_WSDL",0);
define("SESSION_TIMEOUT",30000);
define("EMAIL_NOME","Sistema Octopus - Unimed VTRP");
define("NOME_SITE","Sistema Octopus - Unimed VTRP");
define("TAMANHO_MIN_SENHA",6);
define("MENUS","Indicadores Gerais,Indicadores TI,Sistema Atendimento,Privil�gios,SMS,RAs Tecnologia,Simula Acesso Coop,Comercializa��o");

//-- BANCO DE DADOS
/*$bdHost = "localhost";
$bdUser = "root";
$bdPass = "";
$bancoDados = "octopus";
$tipoConexao = "mysql";
$debug = 0;*/

/* ------- LOCALHOST --------*/ 
//BANCO DE DADOS ORACLE - PROT
/*$hostOracle  = "octopus-prot";
$userOracle  = "octopus";
$senhaOracle = "0cT0pu5";*/

//BANCO DE DADOS ORACLE - PROD
/*$hostOracle  = "octopus";
$userOracle  = "octopus";
$senhaOracle = "0cT0pu5";*/
/* ---------------------------*/

/* ------- SERVER --------*/ 
//BANCO DE DADOS ORACLE - PROT
/*$hostOracle  = "//srv-orcl-prot01/PROT";
$userOracle  = "octopus";
$senhaOracle = "0cT0pu5";*/

//BANCO DE DADOS ORACLE - PROD
$hostOracle  = "//srv-orcl-prod01/orcl";
$userOracle  = "octopus";
$senhaOracle = "0cT0pu5";
/* ---------------------------*/

//-- BANCO DE DADOS ORQUESTRA PROT
$hostOrquestraProt = "//srv-orcl-prot01.unimedvtrp.com.br/PROT";
$userOrquestraProt = "ORQUESTRA_BPM";
$senhaOrquestraProt = "ORQUESTRA_BPM";

//BANCO DE DADOS ORACLE - SISTEMA DE ATENDIMENTO
$hostOracleSA  = "sccard.unimedvtrp.com.br";
$userOracleSA  = "datacenter";
$senhaOracleSA = "datacenterrac";

// BANCO DE DADOS SQL SERVER - QUALITOR
//$hostSqlServer = "srvdb9";
//$infoSqlServer = array( "Database"=>"Qualitor_PROD", "UID"=>"sa", "PWD"=>"unimed029");

$hostSqlServer = "srvdb9";
$infoSqlServer = array( "Database"=>"qualitorv8_prod", "UID"=>"qualitorv8", "PWD"=>"qualitorv8@29");

// BANCO DE DADOS SQL SERVER - EPM
$hostSqlServerEPM = "srvdb9";
$infoSqlServerEPM = array( "Database"=>"ProjectServer_Reporting", "UID"=>"indicador_epm", "PWD"=>"unimed029@");

// BANCO DE DADOS MSSQL - QUALITOR
$hostMssql = "srvdb9";
$userMssql = "qualitorv8";
$senhaMssql = "qualitorv8@29";

// BANCO DE DADOS MSSQL - EPM
$hostMssqlEPM = "srvdb9";
$userMssqlEPM = "indicador_epm";
$senhaMssqlEPM = "unimed029@";


?>
