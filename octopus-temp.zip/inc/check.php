<?php
if(!isset($_SESSION['usuario'])){
     session_destroy();
     print "<p>ACESSO NEGADO</p>
     <a href='index.php'>tente novamente</a>";
     exit();
}
?>