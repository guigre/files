<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sistema Octopus - Unimed VTRP</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/font-awesome-4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
    <!-- Morris chart -->
    <link rel="stylesheet" href="plugins/morris/morris.css">
	<!-- DataTables -->
    <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="plugins/iCheck/all.css">
    <!-- Bootstrap Color Picker -->
    <link rel="stylesheet" href="plugins/colorpicker/bootstrap-colorpicker.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">

    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

	<link rel="stylesheet" href="inc/estilo.css">

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="plugins/jQuery/jquery.maskMoney.min.js"></script>
	<!-- CSV -->
	<script src="plugins/jQuery/jquery.csv-0.71.js" type="text/javascript"></script>

	<!-- highlight-->
	<script src="plugins/jQuery/jquery.highlight.js" type="text/javascript"></script>

	<!-- Filtro input -->
	<script src="plugins/jQuery/jquery.filter_input.js" type="text/javascript"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>

    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>    <!-- page script -->

    <!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="plugins/input-mask/jquery.inputmask.js"></script>
    <script src="plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
    <script src="plugins/input-mask/jquery.inputmask.extensions.js"></script>
    <!-- date-range-picker -->
	<script src="inc/moment.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap color picker -->
    <script src="plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>

	<!-- Highcharts -->
	<script src="plugins/highcharts/js/highcharts.js"></script>
	<script src="plugins/highcharts/js/modules/exporting.js"></script>

  <!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
  <script src="js/vendor/jquery.ui.widget.js"></script>
  <!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
  <script src="js/jquery.iframe-transport.js"></script>
  <!-- The basic File Upload plugin -->
  <script src="js/jquery.fileupload.js"></script>


	<script src="inc/lwScripts.js"></script>
	<script src="inc/canvasloader.js"></script>

	<!-- MD5 criptografia -->
	<script src="plugins/jQuery/jquery.md5.js" type="text/javascript"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <!--
  BODY TAG OPTIONS:
  =================
  Apply one or more of the following classes to get the
  desired effect
  |---------------------------------------------------------|
  | SKINS         | skin-blue                               |
  |               | skin-black                              |
  |               | skin-purple                             |
  |               | skin-yellow                             |
  |               | skin-red                                |
  |               | skin-green                              |
  |---------------------------------------------------------|
  |LAYOUT OPTIONS | fixed                                   |
  |               | layout-boxed                            |
  |               | layout-top-nav                          |
  |               | sidebar-collapse                        |
  |               | sidebar-mini                            |
  |---------------------------------------------------------|
  -->
  <body class="hold-transition skin-green sidebar-mini sidebar-collapse" id="voltarTopo">

	<?php
	if(!isset($_SESSION['iniciou'])){

		print "<div align=center>
					<p>&nbsp;</p>
					<div class='alert alert-warning' style='width:750px;'>Acesso n&atilde;o autorizado ou se&ccedil;&atilde;o expirou. <a href=index.php>Clique aqui</a> para voltar a tela de login.</div>
			</div>";

		die();
	}
	?>

<script>

$(document).ready(function(){

	var data = new Date();

	/*$('#mesConsultaImportar').val((data.getMonth()));
	$('#anoConsultaImportar').val((data.getFullYear()));*/

	$('#mesConsulta').val((data.getMonth()));
	$('#anoConsulta').val((data.getFullYear()));

	$('#mesConsultaRequisicoes').val((data.getMonth()));
	$('#anoConsultaRequisicoes').val((data.getFullYear()));

	$('#mesConsultaDesenvolvimento').val((data.getMonth()));
	$('#anoConsultaDesenvolvimento').val((data.getFullYear()));

	$('#mesConsultaPPR').val((data.getMonth()));
	$('#anoConsultaPPR').val((data.getFullYear()));

	$("#dataInicialConsulta").inputmask("dd/mm/yyyy", {"placeholder": ""});
	$("#dataFinalConsulta").inputmask("dd/mm/yyyy", {"placeholder": ""});

    $('#periodoConsulta').daterangepicker();

	$(".voltarTopo").hide();
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 300) {
				$('.voltarTopo').fadeIn();
			} else {
				$('.voltarTopo').fadeOut();
			}
		});
		$('.voltarTopo').click(function() {
			$('body,html').animate({scrollTop:0},600);

		});

	});

	$('#mensagemEnvio').filter_input({regex:'[ a-zA-Z0-9@#<>,.!?$;:()/\\]\\[_]'});



	//Date range picker
	$('#periodo').daterangepicker({
	'format' : 'DD/MM/YYYY',
    'startDate': '01/01/2017',
    'endDate': data,
	});

});

function alterarSenha(){

	alert('RAAAA!! Em Breve!!!!');

}

</script>

    <div id="canvasloader-container" class="wrapper">

      <!-- Main Header -->
      <header class="main-header">

        <!-- Logo -->
		<a href="index2.php" class="logo" style="background-color:#0A5F55;">
		 <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>O</b>S</span>
          <!-- logo for regular state and mobile devices -->
         <span class="logo-lg"><b><img src="img/oct.jpg">&nbsp;Sistema Octopus</b></span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation" style="background-color:#00995D;">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- User Account Menu -->
              <li class="dropdown user user-menu">
                <!-- Menu Toggle Button -->
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <!-- The user image in the navbar-->
                  <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
                  <!-- hidden-xs hides the username on small devices so only the image appears. -->
                  <span class="hidden-xs"><?php print $_SESSION['nome']; ?></span>&nbsp;&nbsp;&nbsp;<i class="fa fa-sort-desc"></i>
                </a>
                <ul class="dropdown-menu">
                  <!-- The user image in the menu -->
                  <li class="user-header" style="background-color:#00995D;">
                    <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                    <p>
                      <?php print $_SESSION['nome']; ?>
                      <small><?php print $_SESSION['mail']; ?></small>
                    </p>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-right">
					  <!--<button type="button" class="btn btn-primary" onclick="javascript:void(alterarSenha())" id="btnConsultar">Altarar Senha</button>-->
                      <a href="destroy.php" class="btn btn-default btn-flat">Sair</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
              <!--<li>
                <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
              </li>-->
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php print $_SESSION['nome']; ?></p>
            </div>
          </div>
          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">MENU DE NAVEGAÇÃO</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="active"><a href="index2.php"><i class="fa fa-home"></i> <span>Página Inicial</span></a></li>

			<?php if(isset($_SESSION['menu_indic_gerais']) && $_SESSION['menu_indic_gerais']){

			print "<li class='treeview'>
					  <a href='#'><i class='fa fa-bar-chart'></i> <span>Indicadores Gerais</span> <i class='fa fa-angle-left pull-right'></i></a>
					  <ul class='treeview-menu'>
						<li><a href='indicadores.php'>Indicadores</a></li>
						<li><a href='resultados.php'>Resultados</a></li>
						<li><a href='departamentos.php'>Departamentos</a></li>
						<li><a href='relatorios.php'>Relatórios</a></li>
						<li><a href='importarQualitor.php'>Importar Dados Qualitor</a></li>
					  </ul>
					</li>";
			}?>
			<?php if(isset($_SESSION['menu_indic_ti']) && $_SESSION['menu_indic_ti']){
				print "<li class='treeview'>
					  <a href='#'><i class='fa fa-line-chart'></i> <span>Indicadores TI</span> <i class='fa fa-angle-left pull-right'></i></a>
					  <ul class='treeview-menu'>
						<li><a href='visualizar.php'>Visualizar Indicadores</a></li>
					  </ul>
					</li>";
			}?>
			<?php if(isset($_SESSION['menu_sis_aten']) && $_SESSION['menu_sis_aten']){
				print "<li class='treeview'>
					  <a href='#'><i class='fa fa-heartbeat'></i> <span>Sistema de Atendimento</span> <i class='fa fa-angle-left pull-right'></i></a>
					  <ul class='treeview-menu'>
						<li><a href='relatoriosSA.php'>Relatórios</a></li>
					  </ul>
					</li>";
			}?>
			<?php if(isset($_SESSION['menu_privilegios']) && $_SESSION['menu_privilegios']){
				print "<li class='treeview'>
						<a href='privilegios.php'><i class='fa fa-user'></i> <span>Privilégios</span></i></a>
					</li>";
			}?>

			<?php if(isset($_SESSION['menu_sms']) && $_SESSION['menu_sms']){

				print "<li class='treeview'>
					  <a href='sms.php'><i class='fa fa-mobile'></i> <span>SMS</span></i></a>
					  </li>";
			}?>

			<?php if(isset($_SESSION['menu_ras_ti']) && $_SESSION['menu_ras_ti']){

				print "<li class='treeview'>
					  <a href='ras-tecnologia.php'><i class='fa fa-inbox'></i> <span>RAs Tecnologia</span></i></a>
					  </li>";
			}?>

			<?php if(isset($_SESSION['menu_acesso_restrito']) && $_SESSION['menu_acesso_restrito']){

				print "<li class='treeview'>
					  <a href='simulaAcessoRestrito.php'><i class='fa fa-lock'></i> <span>Acesso Restrito Cooperado</span></i></a>
					  </li>";
			}?>

			<?php if(isset($_SESSION['menu_comercializacao']) && $_SESSION['menu_comercializacao']){

				print "<li class='treeview'>
						  <a href='#'><i class='fa fa-money'></i> <span>Comercialização</span> <i class='fa fa-angle-left pull-right'></i></a>
						  <ul class='treeview-menu'>
							<li><a href='planos.php'>Planos</a></li>
							<li><a href='planoFaixaEtaria.php'>Planos x Faixa Etária</a></li>
							<li><a href='tabelaPreco.php'>Tabela de Preço</a></li>
							<li><a href='tabelaPrecoModulo.php'>Tabela de Preço x Módulo</a></li>
							<li><a href='descontos.php'>Descontos</a></li>
              <li><a href='campanhas.php'>Campanhas</a></li>
						  </ul>
						</li>";
			}?>

			<?php if(isset($_SESSION['menu_drg']) && $_SESSION['menu_drg']){

				print "<li class='treeview'>
						  <a href='#'><i class='fa fa-exchange'></i> <span>DRG</span> <i class='fa fa-angle-left pull-right'></i></a>
						  <ul class='treeview-menu'>
							<li><a href='drg-novo.php'>Enviar Custos Paciente</a></li>
						  </ul>
						</li>";
			}
			?>
			<?php if(isset($_SESSION['menu_auditoria_processos']) && $_SESSION['menu_auditoria_processos']){

				print "<li class='treeview'>
						  <a href='#'><i class='fa fa-tasks'></i> <span>Auditoria de Processos</span> <i class='fa fa-angle-left pull-right'></i></a>
						  <ul class='treeview-menu'>
							<li><a href='processos.php'>Processos</a></li>
							<li><a href='perguntas.php'>Perguntas</a></li>
							<li><a href='perguntas_to_processos.php'>Perguntas x Processos</a></li>
						  </ul>
						</li>";
			}?>

			<?php if(isset($_SESSION['menu_controle_acesso_ti']) && $_SESSION['menu_controle_acesso_ti']){

				print "<li class='treeview'>
						  <a href='#'><i class='fa fa-key'></i> <span>Controle Acessos TI</span> <i class='fa fa-angle-left pull-right'></i></a>
						  <ul class='treeview-menu'>
							<li><a href='acesso_ti_usuario.php'>Usuários</a></li>
						  </ul>
						</li>";
			}?>



          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>
