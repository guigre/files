      <?php
				$ano = date("Y");
			?>
			
			<input type="button" class="voltarTopo" onclick="$('html,body').animate({scrollTop: $('#voltarTopo').offset().top}, 2000);">
	  <!-- Main Footer -->
	  <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Versão 1.1 Beta
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; <?php print $ano; ?> <a href="http://www.unimedvtrp.com.br" style="color:#00995D;">Unimed Vales do Taquari e Rio Pardo</a>.</strong> All rights reserved.
      </footer>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Create the tabs -->
        <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
          <li class="active"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
          <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
        </ul>
        <!-- Tab panes -->
        <div class="tab-content">
          <!-- Home tab content -->
          <div class="tab-pane active" id="control-sidebar-home-tab">
            <h3 class="control-sidebar-heading">Recent Activity</h3>
            <ul class="control-sidebar-menu">
              <li>
                <a href="javascript::;">
                  <i class="menu-icon fa fa-birthday-cake bg-red"></i>
                  <div class="menu-info">
                    <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>
                    <p>Will be 23 on April 24th</p>
                  </div>
                </a>
              </li>
            </ul><!-- /.control-sidebar-menu -->

            <h3 class="control-sidebar-heading">Tasks Progress</h3>
            <ul class="control-sidebar-menu">
              <li>
                <a href="javascript::;">
                  <h4 class="control-sidebar-subheading">
                    Custom Template Design
                    <span class="label label-danger pull-right">70%</span>
                  </h4>
                  <div class="progress progress-xxs">
                    <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                  </div>
                </a>
              </li>
            </ul><!-- /.control-sidebar-menu -->

          </div><!-- /.tab-pane -->
          <!-- Stats tab content -->
          <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div><!-- /.tab-pane -->
          <!-- Settings tab content -->
          <div class="tab-pane" id="control-sidebar-settings-tab">
            <form method="post">
              <h3 class="control-sidebar-heading">General Settings</h3>
              <div class="form-group">
                <label class="control-sidebar-subheading">
                  Report panel usage
                  <input type="checkbox" class="pull-right" checked>
                </label>
                <p>
                  Some information about this general settings option
                </p>
              </div><!-- /.form-group -->
            </form>
          </div><!-- /.tab-pane -->
        </div>
      </aside><!-- /.control-sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <!-- Optionally, you can add Slimscroll and FastClick plugins.
         Both of these plugins are recommended to enhance the
         user experience. Slimscroll is required when using the
         fixed layout. -->
		 
	<!-- ERROR MODAL BOX -->
	<div class="modal fade" id="dialog-error" style='display:none;'>
		<div class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"><i class='fa fa-warning'></i> Aviso</h4>
			</div>
			<div class="modal-body" id=dialogErrorMsg>
				
			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-default" data-dismiss="modal" >Fechar</button>
			</div>
		  </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	  </div><!-- /.modal -->
	<!-- ERROR MODAL BOX : FIM -->	

	<div class="modal fade" id="dialog-exclusao" style="display:none;">
	<div class="modal-dialog">
	  <div class="modal-content">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		  <h4 class="modal-title">Excluir?</h4>
		</div>
		<div class="modal-body" id="dialog-message-exclusao">

		</div>
		<div class="modal-footer">
		  <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		  <button type="button" class="btn btn-success" onclick="excluir()" data-dismiss="modal">Excluir</button>
		</div>
	  </div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->	
	
	<div class="modal fade" id="dialog-findar" style="display:none;">
	<div class="modal-dialog">
	  <div class="modal-content">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		  <h4 class="modal-title">Findar?</h4>
		</div>
		<div class="modal-body" id="dialog-message-findar">

		</div>
		<div class="modal-footer">
		  <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		  <button type="button" class="btn btn-success" onclick="findar()" data-dismiss="modal">Findar</button>
		</div>
	  </div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->	
	
	<div class="modal fade" id="dialog-confirma-inclusao-coop" style="display:none;">
	<div class="modal-dialog">
	  <div class="modal-content">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		  <h4 class="modal-title">Confirmar?</h4>
		</div>
		<div class="modal-body" id="dialog-message-confirma-inclusao-coop">

		</div>
		<div class="modal-footer">
		  <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		  <button type="button" class="btn btn-success" onclick="incluiSenhaBancoDados()" data-dismiss="modal">Confirmar</button>
		</div>
	  </div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->

	<div class="modal fade" id="dialog-confirma-alteracao-coop" style="display:none;">
	<div class="modal-dialog">
	  <div class="modal-content">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		  <h4 class="modal-title">Confirmar?</h4>
		</div>
		<div class="modal-body" id="dialog-message-confirma-alteracao-coop">

		</div>
		<div class="modal-footer">
		  <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		  <button type="button" class="btn btn-success" onclick="alteraSenhaBancoDados()" data-dismiss="modal">Confirmar</button>
		</div>
	  </div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
		
    <!-- INCIDENTES ABERTOS -->		
	<div class="modal fade" id="dialog-incidentes-abertos" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesAbertosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	<!-- INCIDENTES ENCERRADOS -->  
	<div class="modal fade" id="dialog-incidentes-encerrados" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesEncerradosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	

	<!-- INCIDENTES PRAZO -->  
	<div class="modal fade" id="dialog-incidentes-prazo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesPrazoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	

	<!-- INCIDENTES PRAZO RESPOSTA SOLUÇÃO -->  
	<div class="modal fade" id="dialog-incidentes-prazo-resposta-solucao" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesPrazoRepostaSolucaoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	

	<!-- INCIDENTES ABERTOS SERCIÇOS PRINCIPAIS -->  
	<div class="modal fade" id="dialog-incidentes-principal" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesPrincipalModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	<!-- INCIDENTES POR NIVEL -->  
	<div class="modal fade" id="dialog-incidentes-nivel" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesNivelModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	<!-- INCIDENTES REABERTOS -->  
	<div class="modal fade" id="dialog-incidentes-reabertos" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesReabertosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	

	<!-- INCIDENTES SEVERIDADE -->  
	<div class="modal fade" id="dialog-incidentes-severidade" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesSeveridadeModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	<!-- INCIDENTES MAIORES 90 -->  
	<div class="modal fade" id="dialog-incidentes-maiores90" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesMaiores90Modal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	

	<!-- INCIDENTES BACKLOG -->  
	<div class="modal fade" id="dialog-incidentes-backlog" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesBacklogModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	 

	  	<!-- INCIDENTES SERVIÇOS MENSAIS -->  
	<div class="modal fade" id="dialog-incidentes-servicos" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesServicoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  	<!-- INCIDENTES SERVIÇOS ANUAIS -->  
	<div class="modal fade" id="dialog-incidentes-servicos-anual" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesServicoAnualModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	  
	  
	  	<!-- PPR -->  
	<div class="modal fade" id="dialog-documentos-ppr" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoDocumentosPPRModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>	 

	  	<!-- SOLICITACAO DEMANDAS -->  
	<div class="modal fade" id="dialog-solicitacao-demandas" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoPrazoSolicitacaoDemandasModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- TOTAL REQUISICOES ABERTAS -->  
	<div class="modal fade" id="dialog-total-req-abertas" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalRequisicoesAbertasModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- TOTAL REQUISICOES ENCERRDAS -->  
	<div class="modal fade" id="dialog-total-req-encerradas" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalRequisicoesEncerradasModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	  <!-- TOTAL REQUISICOES ENCERRADAS NO PRAZO -->  
	<div class="modal fade" id="dialog-percentual-req-prazo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoPercentualRequisicoesPrazoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- TOTAL REQUISICOES ENCERRADAS NO PRAZO POR TIPO -->  
	<div class="modal fade" id="dialog-perc-req-prazo-tipo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoPercentualReqPrazoTipoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	   <!-- QUANTIDADE REQUISICOES ENCERRADAS POR TIPO E NIVEL-->  
	<div class="modal fade" id="dialog-qtde-req-encer-tipo-nivel" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoQtdeReqEncerTipoNivelModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	<!-- TOTAL REQUISICOES ABERTAS POR TIPO -->  
	<div class="modal fade" id="dialog-req-abertas-tipo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoRequisicoesAbertasTipoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
  <!-- TOTAL REQUISICOES ENCERRADAS POR TIPO -->  
	<div class="modal fade" id="dialog-req-encerradas-tipo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoRequisicoesEncerradasTipoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
    <!-- PERCENTUAL REQUISICOES ABERTAS POR TIPO -->  
	<div class="modal fade" id="dialog-perc-req-abertas-tipo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoPercRequisicoesAbertasTipoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	<!-- PERCENTUAL REQUISICOES ABERTAS POR TIPO -->  
	<div class="modal fade" id="dialog-perc-req-encerradas-tipo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoPercRequisicoesEncerradasTipoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	 <!-- PERCENTUAL REQUISICOES REABERTAS POR TIPO -->  
	<div class="modal fade" id="dialog-requisicoes-reabertas" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoRequisicoesReabertasModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	 <!-- PERCENTUAL REQUISICOES ABERTAS POR SERVICO -->  
	<div class="modal fade" id="dialog-requisicoes-abertas-servico" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoRequisicoesAbertasServicoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>  
	  
	<!-- REQUISICOES ENCERRADAS POR NIVEL -->  
	<div class="modal fade" id="dialog-requisicoes-encerradas-nivel" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoRequisicoesEncerradasNivelModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	<!-- PERCENTUAL REQUISICOES ENCERRADAS POR TIPO E NIVEL-->  
	<div class="modal fade" id="dialog-perc-req-encer-tipo-nivel" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoPercReqEncerTipoNivelModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	 <!-- REQUISICOES EM ABERTO POR MAIS DE 90 DIAS -->  
	<div class="modal fade" id="dialog-requisicoes-maiores90" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalRequisicoesMaiores90Modal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- REQUISICOES EM ABERTO POR MAIS DE 90 DIAS -->  
	<div class="modal fade" id="dialog-requisicoes-backlog" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalRequisicoesBacklogModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS ABERTOS -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-abertos" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosAbertosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div> 
	  
	  <!-- DESENVOLVIMENTOS ENCERRADOS -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-encerrados" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosEncerradosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

     <!-- DESENVOLVIMENTOS CANCELADOS -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-cancelados" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosCanceladosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	<!-- DESENVOLVIMENTOS PRAZO -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-prazo" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosPrazoModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS PRAZO E FORA PRAZO -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-prazo-e-fora" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosPrazoEForaModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS REAGENDADOS -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-reagendados" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvReagendadosModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- INCIDENTES DEVIDO DESENVOLVIMENTOS -->  
	 <div class="modal fade" id="dialog-incidentes-devido-desenv" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalIncidentesDevidoDesenvModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS BACKLOG -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-backlog" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosBacklogModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>

	 <!-- DESENVOLVIMENTOS ETAPA -->  
	 <div class="modal fade" id="dialog-desenvolvimentos-etapa" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvimentosEtapaModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS FORA PRAZO ETAPA -->  
	 <div class="modal fade" id="dialog-desenvolv-fora-prazo-etapa" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvForaPrazoEtapaModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS FORA PRAZO RESPONSAVEL -->  
	 <div class="modal fade" id="dialog-desenvolv-fora-prazo-resp" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvForaPrazoRespModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- DESENVOLVIMENTOS FORA PRAZO DIAS -->  
	 <div class="modal fade" id="dialog-desenvolv-fora-prazo-dias" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoTotalDesenvolvForaPrazoDiasModal" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <!-- Modal Generico -->
	  <div class="modal fade" id="dialog-generico" style='display:none;'>
		<div class="modal-dialog" style="width:1200px;">
		  <div class="modal-content" style="height:600px;">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title"></h4>
			</div>
			<div id="graficoModalGenerico" style="width:1200px;height:500px;"></div>
			<div class="modal-footer">
			  <button id="button-ok" type="button" class="btn btn-default" data-dismiss="modal" style="background-color:#00995D;color:#ffffff">Fechar</button>
			</div>
		  </div>
		</div>
	  </div>
	  
  </body>
</html>