<?php

$hostOrquestraProt = "//srv-orcl-prot01.unimedvtrp.com.br/PROT";
$userOrquestraProt = "ORQUESTRA_BPM";
$senhaOrquestraProt = "ORQUESTRA_BPM";

$conexaoOracleOrquestra = oci_connect($userOrquestraProt, $senhaOrquestraProt, $hostOrquestraProt, 'AL32UTF8');
if($conexaoOracleOrquestra){
	print "OKKKKK";
}else{
	print "NOKKK";
}
			
			
?>