<?php include("inc/topo.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i class="fa fa-file-text"></i> Relatório do Sistema de Atendimento
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Your Page Content Here -->
		  
              <!-- Horizontal Form -->
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Filtros do Relatório</h3>&nbsp;&nbsp;
				  <small><font color="red">(Campos com (*) são obrigatórios.)</font></small>				  
                </div><!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="relatorioConsulta" class="col-sm-2 control-label">Relatório</label>
					  <div class="col-xs-2">
                      <select class="form-control" id="relatorioConsulta">
						<option value=''>:: Selecione ::</option>
						<option value='1'>Consultas Padrão</option>
                      </select>
					  </div>
                    </div>
                    <div class="form-group">
                      <label for="prestadorConsulta" class="col-sm-2 control-label">Prestador</label>
                      <div class="col-xs-2">
                        <input type="text" class="form-control" id="prestadorConsulta" placeholder="" value="">
                      </div>
                    </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Período</label>
                    <div class="col-xs-3">
					<div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
					  <input type="text" class="form-control pull-right" id="periodoConsulta">
                    </div><!-- /.input group -->
					</div>
                  </div><!-- /.form group -->					
                    <div class="box-footer">
						<button type="button" class="btn btn-primary" onclick="javascript:void(consultar())" id="btnConsultar">Consultar</button>&nbsp;&nbsp;
                    </div><!-- /.box-footer -->
                </form>
              </div><!-- /.box -->
			  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Consulta</h3>
                </div><!-- /.box-header -->
                <div class="box-body" id="divRelatorioConsultaPadrao" style="display:none;">						
									
                </div><!-- /.box-body -->
			    <div class="loader" style="display:none;">
					<span><img src="img/ajax-loader.gif"></span>
				</div>

				
              </div><!-- /.box -->				  
			  
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
	  

<script>

	function limpaDivs(){
		
		$('#divRelatorioConsultaPadrao').html('');
		
	}

	function consultasPadrao(prestador,dataInicial,dataFinal){
		
		$.ajax({
			url: 'ajax/relatorioSA.php?acao=consultasPadrao',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			data: {
				'prestador'   : prestador,
				'dataInicial' : dataInicial,
				'dataFinal'   : dataFinal		
			},			
			beforeSend: function() {
				$('.loader').show();				
			},
			complete: function() {
				$('.loader').hide();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divRelatorioConsultaPadrao').html(result.tabela);
						
						        $('#tabelaConsultasPadrao').DataTable();
						
						
						$('#divRelatorioConsultaPadrao').show();
						
					}else{
										
						$('#divRelatorioConsultaPadrao').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});		
		
	}
	
	function consultar(){
		
		limpaDivs();
		
		var prestador   = $('#prestadorConsulta').val();
		var dataInicial = $('#dataInicialConsulta').val();
		var dataFinal   = $('#dataFinalConsulta').val();
		
		consultasPadrao(prestador,dataInicial,dataFinal);
		
	}
	
</script>	  

<?php include("inc/rodape.php"); ?>

