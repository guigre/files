	<?php

// 3281985429 8815154723 9527220530 6037919201

/*
$xml = "<loteCustoPaciente>
<CustoPaciente>
<codigo>4136</codigo>
<numeroAutorizacao>1800029321</numeroAutorizacao>
<numeroAtendimento></numeroAtendimento>
<acao>SUBSTITUIR</acao></CustoPaciente>
</loteCustoPaciente>";
*/

$xml = "<loteCustoPaciente>
<CustoPaciente>
									<codigo>13317</codigo>
									<numeroAutorizacao>1800069101</numeroAutorizacao>
									<numeroAtendimento></numeroAtendimento>
									<acao>INCLUIR</acao><ItemCustoPaciente>
									<codigoItemConsumo>40805018</codigoItemConsumo>
									<descricaoItemConsumo>RX DE TORAX - 1 INCIDENCIA</descricaoItemConsumo>
									<codigoGrupoConsumo>4</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:26:00</dataConsumo>
									<valorCustoUnitario>14.9</valorCustoUnitario>
									<valorCustoTotal>14.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40805018</codigoItemConsumo>
									<descricaoItemConsumo>RX DE TORAX - 1 INCIDENCIA</descricaoItemConsumo>
									<codigoGrupoConsumo>4</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>14.9</valorCustoUnitario>
									<valorCustoTotal>14.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40805018</codigoItemConsumo>
									<descricaoItemConsumo>RX DE TORAX - 1 INCIDENCIA</descricaoItemConsumo>
									<codigoGrupoConsumo>4</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:13:00</dataConsumo>
									<valorCustoUnitario>14.9</valorCustoUnitario>
									<valorCustoTotal>14.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40805018</codigoItemConsumo>
									<descricaoItemConsumo>RX DE TORAX - 1 INCIDENCIA</descricaoItemConsumo>
									<codigoGrupoConsumo>4</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T11:51:00</dataConsumo>
									<valorCustoUnitario>14.9</valorCustoUnitario>
									<valorCustoTotal>14.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T11:51:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T11:51:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T10:42:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T10:42:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:06:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:06:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:27:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:27:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:26:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:26:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T10:20:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T10:20:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:20:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:20:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T09:35:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T09:35:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:54:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:54:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20103093</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ATENDIMENTO FISIATRICO NO PRE E POS-OPERATORI</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T11:40:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>20203047</codigoItemConsumo>
									<descricaoItemConsumo>FISIOTERAPIA - ASSISTENCIA FISIATRICA RESPIRATORIA</descricaoItemConsumo>
									<codigoGrupoConsumo>18</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T11:40:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>19.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000177</codigoFornecedor>
									<descricaoFornecedor>PHYSICAL - FISIOTERAPIA LTDA ME</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301630</codigoItemConsumo>
									<descricaoItemConsumo>CREATININA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T03:24:00</dataConsumo>
									<valorCustoUnitario>4.32</valorCustoUnitario>
									<valorCustoTotal>4.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302016</codigoItemConsumo>
									<descricaoItemConsumo>GASOMETRIA (PH, PCO2, SA, O2, EXCESSO BASE)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T03:24:00</dataConsumo>
									<valorCustoUnitario>24.96</valorCustoUnitario>
									<valorCustoTotal>24.96</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302237</codigoItemConsumo>
									<descricaoItemConsumo>MAGNESIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T03:24:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T03:24:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302423</codigoItemConsumo>
									<descricaoItemConsumo>SODIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T03:24:00</dataConsumo>
									<valorCustoUnitario>5.28</valorCustoUnitario>
									<valorCustoTotal>5.28</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T03:24:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302237</codigoItemConsumo>
									<descricaoItemConsumo>MAGNESIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T03:18:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T03:18:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302407</codigoItemConsumo>
									<descricaoItemConsumo>RESERVA ALCALINA (BICARBONATO)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T03:18:00</dataConsumo>
									<valorCustoUnitario>9.36</valorCustoUnitario>
									<valorCustoTotal>9.36</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T03:18:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301419</codigoItemConsumo>
									<descricaoItemConsumo>CALCIO IONICO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301630</codigoItemConsumo>
									<descricaoItemConsumo>CREATININA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>4.32</valorCustoUnitario>
									<valorCustoTotal>4.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301931</codigoItemConsumo>
									<descricaoItemConsumo>FOSFORO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302237</codigoItemConsumo>
									<descricaoItemConsumo>MAGNESIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302407</codigoItemConsumo>
									<descricaoItemConsumo>RESERVA ALCALINA (BICARBONATO)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>9.36</valorCustoUnitario>
									<valorCustoTotal>9.36</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302423</codigoItemConsumo>
									<descricaoItemConsumo>SODIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T03:33:00</dataConsumo>
									<valorCustoUnitario>5.28</valorCustoUnitario>
									<valorCustoTotal>5.28</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301931</codigoItemConsumo>
									<descricaoItemConsumo>FOSFORO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T03:54:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302016</codigoItemConsumo>
									<descricaoItemConsumo>GASOMETRIA (PH, PCO2, SA, O2, EXCESSO BASE)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T03:54:00</dataConsumo>
									<valorCustoUnitario>24.96</valorCustoUnitario>
									<valorCustoTotal>24.96</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T03:54:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302237</codigoItemConsumo>
									<descricaoItemConsumo>MAGNESIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T03:54:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T03:54:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302423</codigoItemConsumo>
									<descricaoItemConsumo>SODIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T03:54:00</dataConsumo>
									<valorCustoUnitario>5.28</valorCustoUnitario>
									<valorCustoTotal>5.28</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301630</codigoItemConsumo>
									<descricaoItemConsumo>CREATININA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T03:58:00</dataConsumo>
									<valorCustoUnitario>4.32</valorCustoUnitario>
									<valorCustoTotal>4.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302016</codigoItemConsumo>
									<descricaoItemConsumo>GASOMETRIA (PH, PCO2, SA, O2, EXCESSO BASE)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T03:58:00</dataConsumo>
									<valorCustoUnitario>24.96</valorCustoUnitario>
									<valorCustoTotal>24.96</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T03:58:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302580</codigoItemConsumo>
									<descricaoItemConsumo>UREIA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T03:58:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T03:58:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T03:37:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302407</codigoItemConsumo>
									<descricaoItemConsumo>RESERVA ALCALINA (BICARBONATO)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T03:37:00</dataConsumo>
									<valorCustoUnitario>9.36</valorCustoUnitario>
									<valorCustoTotal>9.36</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T03:37:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304442</codigoItemConsumo>
									<descricaoItemConsumo>PLAQUETAS, CONTAGEM</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T03:37:00</dataConsumo>
									<valorCustoUnitario>2.4</valorCustoUnitario>
									<valorCustoTotal>2.4</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302016</codigoItemConsumo>
									<descricaoItemConsumo>GASOMETRIA (PH, PCO2, SA, O2, EXCESSO BASE)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T03:48:00</dataConsumo>
									<valorCustoUnitario>24.96</valorCustoUnitario>
									<valorCustoTotal>24.96</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T03:48:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302580</codigoItemConsumo>
									<descricaoItemConsumo>UREIA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T03:48:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T03:48:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301630</codigoItemConsumo>
									<descricaoItemConsumo>CREATININA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T03:27:00</dataConsumo>
									<valorCustoUnitario>4.32</valorCustoUnitario>
									<valorCustoTotal>4.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T03:27:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302423</codigoItemConsumo>
									<descricaoItemConsumo>SODIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T03:27:00</dataConsumo>
									<valorCustoUnitario>5.28</valorCustoUnitario>
									<valorCustoTotal>5.28</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T03:27:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301222</codigoItemConsumo>
									<descricaoItemConsumo>ALBUMINA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T02:31:00</dataConsumo>
									<valorCustoUnitario>3.6</valorCustoUnitario>
									<valorCustoTotal>3.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T02:31:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301109</codigoItemConsumo>
									<descricaoItemConsumo>ACIDO LACTICO (LACTATO)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>12.48</valorCustoUnitario>
									<valorCustoTotal>12.48</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301419</codigoItemConsumo>
									<descricaoItemConsumo>CALCIO IONICO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>9.6</valorCustoUnitario>
									<valorCustoTotal>9.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301630</codigoItemConsumo>
									<descricaoItemConsumo>CREATININA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>4.32</valorCustoUnitario>
									<valorCustoTotal>4.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40301931</codigoItemConsumo>
									<descricaoItemConsumo>FOSFORO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302016</codigoItemConsumo>
									<descricaoItemConsumo>GASOMETRIA (PH, PCO2, SA, O2, EXCESSO BASE)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>24.96</valorCustoUnitario>
									<valorCustoTotal>24.96</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302237</codigoItemConsumo>
									<descricaoItemConsumo>MAGNESIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302318</codigoItemConsumo>
									<descricaoItemConsumo>POTASSIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302423</codigoItemConsumo>
									<descricaoItemConsumo>SODIO</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>5.28</valorCustoUnitario>
									<valorCustoTotal>5.28</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40302580</codigoItemConsumo>
									<descricaoItemConsumo>UREIA</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>4.56</valorCustoUnitario>
									<valorCustoTotal>4.56</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304361</codigoItemConsumo>
									<descricaoItemConsumo>HEMOGRAMA COM CONTAGEM DE PLAQUETAS OU FRACOES (ERITROGRAMA,</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>6</valorCustoUnitario>
									<valorCustoTotal>6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304590</codigoItemConsumo>
									<descricaoItemConsumo>TEMPO DE PROTROMBINA (TP)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>5.04</valorCustoUnitario>
									<valorCustoTotal>5.04</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>40304639</codigoItemConsumo>
									<descricaoItemConsumo>TEMPO DE TROMBOPLASTINA PARCIAL ATIVADA (KTTP)</descricaoItemConsumo>
									<codigoGrupoConsumo>9</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T03:33:00</dataConsumo>
									<valorCustoUnitario>4.8</valorCustoUnitario>
									<valorCustoTotal>4.8</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000002</codigoFornecedor>
									<descricaoFornecedor>LABORATORIO HERMANN LTDA</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>30913012</codigoItemConsumo>
									<descricaoItemConsumo>IMPLANTE DE CATETER VENOSO CENTRAL POR PUNCAO, PARA NPP, QT,</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>233.03</valorCustoUnitario>
									<valorCustoTotal>233.03</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>31951</codigoFornecedor>
									<descricaoFornecedor>JULIANA LESSA MARIANTE PIMENTEL</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>10102019</codigoItemConsumo>
									<descricaoItemConsumo>VISITA HOSPITALAR (PACIENTE INTERNADO)</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>78</valorCustoUnitario>
									<valorCustoTotal>312</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>31951</codigoFornecedor>
									<descricaoFornecedor>JULIANA LESSA MARIANTE PIMENTEL</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>30909139</codigoItemConsumo>
									<descricaoItemConsumo>HEMODEPURACAO DE CASOS AGUDOS (SESSAO HEMODIALISE, HEMOFILTR</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>233.03</valorCustoUnitario>
									<valorCustoTotal>2097.27</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>31951</codigoFornecedor>
									<descricaoFornecedor>JULIANA LESSA MARIANTE PIMENTEL</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>10102019</codigoItemConsumo>
									<descricaoItemConsumo>VISITA HOSPITALAR (PACIENTE INTERNADO)</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>78</valorCustoUnitario>
									<valorCustoTotal>468</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>26097</codigoFornecedor>
									<descricaoFornecedor>ALINE COSTA MATHIAS</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>10102019</codigoItemConsumo>
									<descricaoItemConsumo>VISITA HOSPITALAR (PACIENTE INTERNADO)</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>78</valorCustoUnitario>
									<valorCustoTotal>312</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>32683</codigoFornecedor>
									<descricaoFornecedor>PATRICIA FORMIGHERI FELDENS</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>30913012</codigoItemConsumo>
									<descricaoItemConsumo>IMPLANTE DE CATETER VENOSO CENTRAL POR PUNCAO, PARA NPP, QT,</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>233.03</valorCustoUnitario>
									<valorCustoTotal>233.03</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>11704</codigoFornecedor>
									<descricaoFornecedor>HELIO MALLMANN</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>10102019</codigoItemConsumo>
									<descricaoItemConsumo>VISITA HOSPITALAR (PACIENTE INTERNADO)</descricaoItemConsumo>
									<codigoGrupoConsumo>998</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T12:35:00</dataConsumo>
									<valorCustoUnitario>78</valorCustoUnitario>
									<valorCustoTotal>78</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>11704</codigoFornecedor>
									<descricaoFornecedor>HELIO MALLMANN</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>117.61</valorCustoUnitario>
									<valorCustoTotal>117.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>117.61</valorCustoUnitario>
									<valorCustoTotal>117.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>117.61</valorCustoUnitario>
									<valorCustoTotal>117.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>117.605</valorCustoUnitario>
									<valorCustoTotal>235.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>117.605</valorCustoUnitario>
									<valorCustoTotal>235.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>117.6066666667</valorCustoUnitario>
									<valorCustoTotal>352.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>117.605</valorCustoUnitario>
									<valorCustoTotal>235.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>117.6066666667</valorCustoUnitario>
									<valorCustoTotal>352.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>96241950</codigoItemConsumo>
									<descricaoItemConsumo>NOVASOURCE HI PROTEIN BAUNILHA 1000ML SF C/ 6 FRASCOS 1000ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>117.61</valorCustoUnitario>
									<valorCustoTotal>117.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>5.11</valorCustoUnitario>
									<valorCustoTotal>5.11</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019687</codigoItemConsumo>
									<descricaoItemConsumo>BAXTER GLICOSE 50 MG/ML SOL INJ IV CX BOLS PLAS INC PVC SIST FECH X 500 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>5.115</valorCustoUnitario>
									<valorCustoTotal>10.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>3.41</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>3.41</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>3.41</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>3.41</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>6.82</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90019865</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE SODIO - BAXTER 9 MG/ML SOL INJ IV BOLS PVC INC SIST FECH X 250 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T08:30:00</dataConsumo>
									<valorCustoUnitario>3.41</valorCustoUnitario>
									<valorCustoTotal>3.41</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90044410</codigoItemConsumo>
									<descricaoItemConsumo>PROVIVE 10MG/ML EMU INJ CT 5 FA VD INC X 20 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>40.18</valorCustoUnitario>
									<valorCustoTotal>40.18</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90045629</codigoItemConsumo>
									<descricaoItemConsumo>COMPAZ 5 MG COM CX BL AL PLAS INC X 200 EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>.13</valorCustoUnitario>
									<valorCustoTotal>.13</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90045777</codigoItemConsumo>
									<descricaoItemConsumo>DIMORF 10 MG/ML SOL INJ CX 50 AMP VD AMB X 1ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>3.83</valorCustoUnitario>
									<valorCustoTotal>3.83</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046170</codigoItemConsumo>
									<descricaoItemConsumo>FENTANEST 0,05 MG/ML  SOL INJ CX 25 FA VD INC X 10 ML EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>20</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>1.496</valorCustoUnitario>
									<valorCustoTotal>29.92</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046170</codigoItemConsumo>
									<descricaoItemConsumo>FENTANEST 0,05 MG/ML  SOL INJ CX 25 FA VD INC X 10 ML EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>40</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T08:30:00</dataConsumo>
									<valorCustoUnitario>1.496</valorCustoUnitario>
									<valorCustoTotal>59.84</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046439</codigoItemConsumo>
									<descricaoItemConsumo>HALO 5 MG COM CT BL AL PLAS INC X 200 EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>.265</valorCustoUnitario>
									<valorCustoTotal>.53</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90046501</codigoItemConsumo>
									<descricaoItemConsumo>HEMOFOL 5000 UI/0,25 ML SOL INJ CX 25 AMP VD INC X 0,25 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>4.885</valorCustoUnitario>
									<valorCustoTotal>9.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90057651</codigoItemConsumo>
									<descricaoItemConsumo>MALEATO DE DEXCLORFENIRAMINA 2 MG COM CT BL AL PLAS OPC X 20</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>.4433333333</valorCustoUnitario>
									<valorCustoTotal>1.33</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>3.25</valorCustoUnitario>
									<valorCustoTotal>6.5</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>3.2466666667</valorCustoUnitario>
									<valorCustoTotal>9.74</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>3.25</valorCustoUnitario>
									<valorCustoTotal>3.25</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90065573</codigoItemConsumo>
									<descricaoItemConsumo>SOLUCAO FISIOLOGICA DE CLORETO DE SODIO EQUIPLEX 9 MG/ML SOL INJ IV CX 70 FR PLAS TRANS PE SIST FECH X 100 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T08:30:00</dataConsumo>
									<valorCustoUnitario>3.25</valorCustoUnitario>
									<valorCustoTotal>6.5</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90072278</codigoItemConsumo>
									<descricaoItemConsumo>CLORETO DE POTASSIO 1 G/10 ML SOL INJ CX 200 FR PLAS TRANS X 10 ML REST. HOSP.</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>.7675</valorCustoUnitario>
									<valorCustoTotal>3.07</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90087925</codigoItemConsumo>
									<descricaoItemConsumo>AEROLIN 100 MCG AER CT LATA AL 200 DOSES C/ APLICADOR</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>324</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>.1665740741</valorCustoUnitario>
									<valorCustoTotal>53.97</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>8</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>1.20375</valorCustoUnitario>
									<valorCustoTotal>9.63</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>1.2033333333</valorCustoUnitario>
									<valorCustoTotal>7.22</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>5</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>1.204</valorCustoUnitario>
									<valorCustoTotal>6.02</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>8</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>1.20375</valorCustoUnitario>
									<valorCustoTotal>9.63</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>1.2033333333</valorCustoUnitario>
									<valorCustoTotal>7.22</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>1.2033333333</valorCustoUnitario>
									<valorCustoTotal>3.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>1.2033333333</valorCustoUnitario>
									<valorCustoTotal>3.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>1.2033333333</valorCustoUnitario>
									<valorCustoTotal>3.61</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90104765</codigoItemConsumo>
									<descricaoItemConsumo>ISOFARMA - AGUA PARA INJECAO SOL INJ CX 200 AMP POLIET INC X 10 ML </descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T08:30:00</dataConsumo>
									<valorCustoUnitario>1.2</valorCustoUnitario>
									<valorCustoTotal>1.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90118154</codigoItemConsumo>
									<descricaoItemConsumo>MAGNOSTASE 2 MG COM CT BL AL PLAS INC X 200</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>.54</valorCustoUnitario>
									<valorCustoTotal>2.16</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90135377</codigoItemConsumo>
									<descricaoItemConsumo>ANDROCORTIL 500 MG PO LIOF CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>9.17</valorCustoUnitario>
									<valorCustoTotal>9.17</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90137060</codigoItemConsumo>
									<descricaoItemConsumo>CLORIDRATO DE VANCOMICINA 500 MG PO LIOF INJ CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>26.63</valorCustoUnitario>
									<valorCustoTotal>53.26</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90137485</codigoItemConsumo>
									<descricaoItemConsumo>DIPIRONA SODICA 500 MG/ML SOL INJ CT 120 AMP VD AMB  X 2 MLEMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>.79</valorCustoUnitario>
									<valorCustoTotal>.79</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90137485</codigoItemConsumo>
									<descricaoItemConsumo>DIPIRONA SODICA 500 MG/ML SOL INJ CT 120 AMP VD AMB  X 2 MLEMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T08:30:00</dataConsumo>
									<valorCustoUnitario>.79</valorCustoUnitario>
									<valorCustoTotal>.79</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90138910</codigoItemConsumo>
									<descricaoItemConsumo>NISTATINA 25.000 UI/G CREM VAG CX 50 BG AL X 60 G  50 APLIC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>.2011111111</valorCustoUnitario>
									<valorCustoTotal>1.81</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>41.315</valorCustoUnitario>
									<valorCustoTotal>165.26</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>41.315</valorCustoUnitario>
									<valorCustoTotal>165.26</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90167066</codigoItemConsumo>
									<descricaoItemConsumo>CEFTAFOR 1 G PO INJ  SOL DIL CX 50 FA VD INC EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>41.3166666667</valorCustoUnitario>
									<valorCustoTotal>247.9</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90180623</codigoItemConsumo>
									<descricaoItemConsumo>FOSFATO SODICO DE PREDNISOLONA 3 MG/ML SOL OR CT FR PLAS OPC X 120 ML  SER DOSAD</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>10</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>.186</valorCustoUnitario>
									<valorCustoTotal>1.86</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90180623</codigoItemConsumo>
									<descricaoItemConsumo>FOSFATO SODICO DE PREDNISOLONA 3 MG/ML SOL OR CT FR PLAS OPC X 120 ML  SER DOSAD</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>10</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>.186</valorCustoUnitario>
									<valorCustoTotal>1.86</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90180623</codigoItemConsumo>
									<descricaoItemConsumo>FOSFATO SODICO DE PREDNISOLONA 3 MG/ML SOL OR CT FR PLAS OPC X 120 ML  SER DOSAD</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>10</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>.186</valorCustoUnitario>
									<valorCustoTotal>1.86</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90180623</codigoItemConsumo>
									<descricaoItemConsumo>FOSFATO SODICO DE PREDNISOLONA 3 MG/ML SOL OR CT FR PLAS OPC X 120 ML  SER DOSAD</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>10</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>.186</valorCustoUnitario>
									<valorCustoTotal>1.86</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90180623</codigoItemConsumo>
									<descricaoItemConsumo>FOSFATO SODICO DE PREDNISOLONA 3 MG/ML SOL OR CT FR PLAS OPC X 120 ML  SER DOSAD</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>10</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>.186</valorCustoUnitario>
									<valorCustoTotal>1.86</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90180623</codigoItemConsumo>
									<descricaoItemConsumo>FOSFATO SODICO DE PREDNISOLONA 3 MG/ML SOL OR CT FR PLAS OPC X 120 ML  SER DOSAD</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>10</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>.186</valorCustoUnitario>
									<valorCustoTotal>1.86</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90198379</codigoItemConsumo>
									<descricaoItemConsumo>SANTIAZEPAM 5 MG COM CX ENV AL POLIET X 1.000 EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>.07</valorCustoUnitario>
									<valorCustoTotal>.14</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90209117</codigoItemConsumo>
									<descricaoItemConsumo>MIDAZOLAM 5 MG/ML SOL INJ CX 5 AMP VD INC X 3 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>10.52</valorCustoUnitario>
									<valorCustoTotal>10.52</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90210670</codigoItemConsumo>
									<descricaoItemConsumo>UNIFENTAL 50 MCG/ML SOL INJ CT 50 AMP VD INC X 2 ML - REST HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>1.3</valorCustoUnitario>
									<valorCustoTotal>1.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90210670</codigoItemConsumo>
									<descricaoItemConsumo>UNIFENTAL 50 MCG/ML SOL INJ CT 50 AMP VD INC X 2 ML - REST HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>1.3</valorCustoUnitario>
									<valorCustoTotal>1.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90210778</codigoItemConsumo>
									<descricaoItemConsumo>UNI HALOPER 5 MG/ML SOL INJ CX 50 AMP VD  AMB X 1 ML  EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>3.8</valorCustoUnitario>
									<valorCustoTotal>3.8</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90210786</codigoItemConsumo>
									<descricaoItemConsumo>UNI HALOPER 5 MG COM CT BL AL PLAS INC X 200  EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>.2166666667</valorCustoUnitario>
									<valorCustoTotal>.65</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90210786</codigoItemConsumo>
									<descricaoItemConsumo>UNI HALOPER 5 MG COM CT BL AL PLAS INC X 200  EMB HOSP</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>.22</valorCustoUnitario>
									<valorCustoTotal>.22</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90278437</codigoItemConsumo>
									<descricaoItemConsumo>PANTASUN 40 MG/ML PO LIOF INJ CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>98.05</valorCustoUnitario>
									<valorCustoTotal>98.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90282981</codigoItemConsumo>
									<descricaoItemConsumo>AGUA PARA INJETAVEIS SOL INJ CX 200 AMP PLAS TRANS X 10 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>.1925</valorCustoUnitario>
									<valorCustoTotal>.77</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90295293</codigoItemConsumo>
									<descricaoItemConsumo>TERBUTIL 0,5 MG/ML SOL INJ CT 50 AMP VD INC X 1 ML</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>5.33</valorCustoUnitario>
									<valorCustoTotal>10.66</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90302079</codigoItemConsumo>
									<descricaoItemConsumo>MUPIROCINA 20 MG/G POM DERM CT BG AL X 15 G</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>2.06</valorCustoUnitario>
									<valorCustoTotal>4.12</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90302079</codigoItemConsumo>
									<descricaoItemConsumo>MUPIROCINA 20 MG/G POM DERM CT BG AL X 15 G</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>2.06</valorCustoUnitario>
									<valorCustoTotal>4.12</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>202.15</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>101.08</valorCustoUnitario>
									<valorCustoTotal>101.08</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>101.0766666667</valorCustoUnitario>
									<valorCustoTotal>303.23</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90324811</codigoItemConsumo>
									<descricaoItemConsumo>BEDFORDPOLY B 500.000 UI PO LIOF CT FA VD INC</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>101.075</valorCustoUnitario>
									<valorCustoTotal>404.3</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T11:18:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T09:25:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T12:37:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:31:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T09:51:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T11:23:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T10:19:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T12:55:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:46:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90342259</codigoItemConsumo>
									<descricaoItemConsumo>SINVASTATINA 20MG COMP REV CT AL PLAST INC X 30</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T11:54:00</dataConsumo>
									<valorCustoUnitario>.6</valorCustoUnitario>
									<valorCustoTotal>.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>90364317</codigoItemConsumo>
									<descricaoItemConsumo>HEMITARTARATO DE ZOLPIDEM 10 MG COM REV CT BL AL PLAS OPC X 20</descricaoItemConsumo>
									<codigoGrupoConsumo>30</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T14:45:00</dataConsumo>
									<valorCustoUnitario>2.03</valorCustoUnitario>
									<valorCustoTotal>2.03</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T07:00:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60000260</codigoItemConsumo>
									<descricaoItemConsumo>DIARIA COMPACTA DE UTI ADULTO GERAL</descricaoItemConsumo>
									<codigoGrupoConsumo>311</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-15T12:01:00</dataConsumo>
									<valorCustoUnitario>1916.21</valorCustoUnitario>
									<valorCustoTotal>1916.21</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>98500415</codigoItemConsumo>
									<descricaoItemConsumo>HEMODIALISE AGUDA</descricaoItemConsumo>
									<codigoGrupoConsumo>997</codigoGrupoConsumo>
									<quantidadeItemConsumo>9</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T09:00:00</dataConsumo>
									<valorCustoUnitario>518.45</valorCustoUnitario>
									<valorCustoTotal>4666.05</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>40000100</codigoFornecedor>
									<descricaoFornecedor>CLINEFRON CL NEFROL ALTO TAQUARI LTDA EPP</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>98500578</codigoItemConsumo>
									<descricaoItemConsumo>UNIDADE DE CONCETRADO DE HEMACEAS</descricaoItemConsumo>
									<codigoGrupoConsumo>11</codigoGrupoConsumo>
									<quantidadeItemConsumo>2</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T08:00:00</dataConsumo>
									<valorCustoUnitario>280.245</valorCustoUnitario>
									<valorCustoTotal>560.49</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>30000008</codigoFornecedor>
									<descricaoFornecedor>HEMOTERAPIA DO VALE DO TAQUARI LTDA - EPP</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>18800010</codigoItemConsumo>
									<descricaoItemConsumo>O2 LIQUIDO/MINUTO - UTI</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>50</quantidadeItemConsumo>
									<dataConsumo>2018-02-15T07:30:00</dataConsumo>
									<valorCustoUnitario>.11</valorCustoUnitario>
									<valorCustoTotal>5.5</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60006021</codigoItemConsumo>
									<descricaoItemConsumo>INALACAO COM OXIGENIO, VAZAO DE 3 LITROS/MIN, POR HORA CORRIDA OU SUBSEQUENTE, NA UTI / SEMI-UTI</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>18</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T10:20:00</dataConsumo>
									<valorCustoUnitario>6.65</valorCustoUnitario>
									<valorCustoTotal>119.7</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60006021</codigoItemConsumo>
									<descricaoItemConsumo>INALACAO COM OXIGENIO, VAZAO DE 3 LITROS/MIN, POR HORA CORRIDA OU SUBSEQUENTE, NA UTI / SEMI-UTI</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-05T07:00:00</dataConsumo>
									<valorCustoUnitario>6.65</valorCustoUnitario>
									<valorCustoTotal>159.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60006021</codigoItemConsumo>
									<descricaoItemConsumo>INALACAO COM OXIGENIO, VAZAO DE 3 LITROS/MIN, POR HORA CORRIDA OU SUBSEQUENTE, NA UTI / SEMI-UTI</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>4</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T07:00:00</dataConsumo>
									<valorCustoUnitario>6.65</valorCustoUnitario>
									<valorCustoTotal>26.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60006021</codigoItemConsumo>
									<descricaoItemConsumo>INALACAO COM OXIGENIO, VAZAO DE 3 LITROS/MIN, POR HORA CORRIDA OU SUBSEQUENTE, NA UTI / SEMI-UTI</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T12:10:00</dataConsumo>
									<valorCustoUnitario>6.65</valorCustoUnitario>
									<valorCustoTotal>6.65</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60006021</codigoItemConsumo>
									<descricaoItemConsumo>INALACAO COM OXIGENIO, VAZAO DE 3 LITROS/MIN, POR HORA CORRIDA OU SUBSEQUENTE, NA UTI / SEMI-UTI</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>3</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T10:35:00</dataConsumo>
									<valorCustoUnitario>6.65</valorCustoUnitario>
									<valorCustoTotal>19.95</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T15:42:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T10:20:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>53.58</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>20</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T07:00:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>178.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T10:35:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>23</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T10:35:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>205.39</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T18:09:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T12:19:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T14:59:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>21</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T07:00:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>187.53</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T15:42:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T10:35:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>214.32</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60028599</codigoItemConsumo>
									<descricaoItemConsumo>OXIGENIO NO RESPIRADOR/VENTILADOR, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-15T07:00:00</dataConsumo>
									<valorCustoUnitario>8.93</valorCustoUnitario>
									<valorCustoTotal>8.93</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-03T10:35:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>6</quantidadeItemConsumo>
									<dataConsumo>2018-02-04T10:19:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>32.4</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>20</quantidadeItemConsumo>
									<dataConsumo>2018-02-06T07:00:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>108</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-07T07:00:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>23</quantidadeItemConsumo>
									<dataConsumo>2018-02-08T12:10:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>124.2</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-09T18:08:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-10T12:10:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-11T14:59:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>21</quantidadeItemConsumo>
									<dataConsumo>2018-02-12T07:00:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>113.4</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-13T15:42:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>24</quantidadeItemConsumo>
									<dataConsumo>2018-02-14T18:30:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>129.6</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034122</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR HORA</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>1</quantidadeItemConsumo>
									<dataConsumo>2018-02-15T07:00:00</dataConsumo>
									<valorCustoUnitario>5.4</valorCustoUnitario>
									<valorCustoTotal>5.4</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente><ItemCustoPaciente>
									<codigoItemConsumo>60034130</codigoItemConsumo>
									<descricaoItemConsumo>AR COMPRIMIDO, POR MINUTO</descricaoItemConsumo>
									<codigoGrupoConsumo>313</codigoGrupoConsumo>
									<quantidadeItemConsumo>50</quantidadeItemConsumo>
									<dataConsumo>2018-02-15T07:00:00</dataConsumo>
									<valorCustoUnitario>.1</valorCustoUnitario>
									<valorCustoTotal>5</valorCustoTotal>
									<valorCustoVariavelDireto></valorCustoVariavelDireto>
									<valorCustoFixoDireto></valorCustoFixoDireto>
									<valorCustoVariavelIndireto></valorCustoVariavelIndireto>
									<valorCustoFixoIndireto></valorCustoFixoIndireto>
									<valorDeducoes></valorDeducoes>
									<quantidadeReceitaItemConsumo></quantidadeReceitaItemConsumo>
									<valorReceitaUnitario></valorReceitaUnitario>
									<valorReceitaTotal></valorReceitaTotal>
									<codigoFornecedor>20000023</codigoFornecedor>
									<descricaoFornecedor>SOCIEDADE BENEFICENCIA E CARIDADE DE LAJEADO</descricaoFornecedor>
									</ItemCustoPaciente></CustoPaciente></loteCustoPaciente>";
						
$user = "BrUN0B0rn-264";
$pass = "hhtY3"; 
$pass .= "$";
$pass .= "G91";									
$options = array('trace' => 1, 'exceptions' => 1, 'cache_wsdl' => WSDL_CACHE_NONE, 'connection_timeout' => 3000);
$wsdl = "https://iagwebservice.sigquali.com.br/iagwebservice/enviaDadosCustoPaciente?wsdl";
		$envio = new SoapClient($wsdl,$options);		
		try{
			$params = array('xml'        => $xml,
						    'usuarioIAG' => $user,
						    'senhaIAG'   => $pass);
			$resultado = $envio->enviaDadosCustoPaciente($params);
			print "<pre>";
			print_r($resultado);
			print "</pre>";
		}catch(SoapFault $exception){
			print "<pre>";
			print_r($exception);
			print "</pre>";			
		}
