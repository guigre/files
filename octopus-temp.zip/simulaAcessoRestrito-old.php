<?php include("inc/topo.php"); ?>
	<form method="post" action="http://www.unimedvtrp.com.br/cgi-bin/webssl/dep/spweb003a" name="acessar" target="_blank" id="myForm">
	<!--<form method="post" action="http://srv-prgs-prod02/cgi-bin/web/WService=wgpldts11prot/dep/spweb003a" name="acessar" target="_blank" id="myForm">-->
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					<i class="fa fa-lock"></i> Acesso Restrito Cooperado
				</h1>
			</section>

			<!-- Main content -->
			<section class="content">

				<!-- Your Page Content Here -->
			  
				<!-- Horizontal Form -->
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Simulação de acesso restrito do cooperado</h3>&nbsp;&nbsp;
					</div><!-- /.box-header -->
					<div>
						<input type="hidden" name="codigoPrestador">
						<input type="hidden" name="senhaPrestador">
						<input type="hidden" name="usuarioAtendente">
						<input type="hidden" name="senhaAtendente">
					</div>
					<div class="box-body" id="divTabela">
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</section><!-- /.content -->
		</div><!-- /.content-wrapper -->
	</form>
<script>

	function iniciaTela(){
		document.acessar.codigoPrestador.value = "";
		document.acessar.senhaPrestador.value = "";
		document.acessar.usuarioAtendente.value = "";
		document.acessar.senhaAtendente.value = "";
	}
	
	function validaForm(theForm,crm){
	
		var enviar = "yes";
		
		theForm.codigoPrestador.value = crm;
		theForm.usuarioAtendente.value = '<?php print $_SESSION['usuario']; ?>';
		theForm.senhaAtendente.value = '<?php print md5($_SESSION['usuario'].md5($_SESSION['senha']).date("d/m/Y")); ?>';
		
		/*var senhaantes = '<?php print md5($_SESSION['senha']); ?>';*/
		
		if (theForm.codigoPrestador.value == ""){
			alert("Campo Código obrigatório.");
			enviar = "no";
		}

		if ((theForm.senhaPrestador.value == "") && (enviar == "yes")){
			
			if ((theForm.usuarioAtendente.value == "") || (theForm.senhaAtendente.value == "")){
				alert("Campo Senha obrigatório.");
				enviar = "no";
			}
		}

		if (enviar == "yes"){
		
			/*alert(theForm.codigoPrestador.value + "\n" +
			      theForm.senhaPrestador.value    + "\n" +
				  senhaantes                      + "\n" +
			      theForm.usuarioAtendente.value  + "\n" +
			      theForm.senhaAtendente.value);*/
		
			theForm.submit();
		}
	}
	
	function atualizaTabela(){		

		$.ajax({
			url: 'ajax/cooperado.php?acao=listaCooperados',
			type: 'POST',
			timeout: 150000,
			dataType: 'json',
			beforeSend: function() {
				
			},
			complete: function() {
				
			},
			error: function(xhr, ajaxOptions, thrownError) {
				console.log(thrownError);
			},
			success: function(result) {
				//console.log(result);
				if(result != null){
					if(result.ok == 1){
						
						$('#divTabela').html(result.tabela);
						
						$("#tabelaCooperados").DataTable({
							"language": {
								"paginate": {
									"previous": "Anterior",
									"next": "Próximo"
								},
								"lengthMenu": "Mostre _MENU_ registros por página",
								"loadingRecords": "Carregando...",
								"processing": "Processando...",
								"search": "Procurar:",
								"zeroRecords": "Nada encontrado - desculpe",
								"info": "Mostrando página _PAGE_ de _PAGES_",
								"infoEmpty": "Sem registros"
							},
							"pagingType": "simple_numbers",
							"order": [ 1, "asc" ]
						});
						
					}else{
										
						$('#divTabela').html('<p>Sem resultados...');
						
					}
				}else{
					exibeErro('<p>Erro ao enviar dados. Por favor tente novamente em instantes.</p>');
				}
				
			}
		});			
	}
	
	iniciaTela();
	atualizaTabela();
	
</script>	  

<?php include("inc/rodape.php"); ?>