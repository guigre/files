<?php
include("class.phpmailer.php");

class myEmail extends PHPMailer {
  	
    var $Host     = "localhost";
    var $Mailer   = "smtp";   								// Alternative to IsSMTP()
    var $WordWrap = 50;	
    var $From 	  = "";
    var $SMTPAuth = false;    							 	// turn on SMTP authentication
    var $Username = "daner.bencke@unimedvtrp.com.br";  						// will be changed to my SMTP username
    var $Password = ""; 							// will be chaged to my SMTP password
    
    function myEmail($lang,$langDir){
    	$this->SetLanguage($lang,$langDir);
    }
    
    // Replace the default error_handler
    function error_handler($msg) {
        print("Erro ao enviar email!<br>");
        print("Descri��o do problema: ");
        printf("%s", $msg);
        exit;
    }
}

?>
