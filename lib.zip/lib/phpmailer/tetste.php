<?php
	include("class.myemail.php");
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: Comercial <comercial@liquidworks.com.br>\r\n";
	$mail = new myEmail();
	$mail->FromName = "Comercial";
	$mail->From = "comercial@liquidworks.com.br";
	$mail->Subject = "Teste phpMailer";
	$mail->Body = "<p><b>Teste<b></p><p>123456789</p>";
	$mail->AddCustomHeader($headers);
	$mail->AddBCC("rafa.wmonteiro@gmail.com");
	$mail->ContentType="text/html";
	$mail->IsHTML(true);
	if($mail->send()){
		print "Enviado com sucesso!";		
	}else{
		print "N�O foi enviado!!";
		
	}
	
?>