<?php
        

	// Grava erros no arquivo de log
	function Handler($eNum, $eMsg, $file, $line, $eVars)
	{
		
		$e = "";
		$Data = date("Y-m-d H:i:s (T)");
		
		$errortype = array(
				E_ERROR 			=> 'ERROR',
				E_WARNING			=> 'WARNING',
				E_PARSE				=> 'PARSING ERROR',
				/*E_NOTICE			=> 'RUNTIME NOTICE',
				E_CORE_ERROR		=> 'CORE ERROR',
				E_CORE_WARNING      => 'CORE WARNING',
                E_COMPILE_ERROR     => 'COMPILE ERROR',
                E_COMPILE_WARNING   => 'COMPILE WARNING',
                E_USER_ERROR        => 'ERRO NA TRANSACAO',
                E_USER_WARNING      => 'USER WARNING',
                E_USER_NOTICE       => 'USER NOTICE',
                E_STRICT            => 'RUNTIME NOTICE',*/
                E_RECOVERABLE_ERROR	=> 'CATCHABLE FATAL ERROR'
				);
        if(strlen($errortype[$eNum])>2){
    		$e .= "**********************************************************\n";
    		$e .= $eNum . " " . $errortype[$eNum] . " - ";
    		$e .= $Data . "\n";
    		$e .= "     ARQUIVO: " . $file . "(Linha " . $line .")\n";
    		$e .= "     MENSAGEM: " . "\n" . $eMsg . "\n\n";

    		error_log($e, 3, LOG_FILE);
		}
		//exit();
	}
	
	$olderror = set_error_handler("Handler");
	ini_set('error_log', LOG_FILE);
	ini_set('log_errors', 'On');
	ini_set('display_errors', 'On');
	ini_set("date.timezone", "America/Sao_Paulo");

?>
