<?php

include("../../config.php");
if(!isset($_GET['w'])) $_GET['w'] = 400;
if(!isset($_GET['h'])) $_GET['h'] = 400;

$badges = "";

require_once 'ThumbLib.inc.php';
$fileName = (isset($_GET['file'])) ? urldecode($_GET['file']) : null;
if($fileName == null || strlen($fileName) <= 0){

	try{
         $thumb = PhpThumbFactory::create("no-img.jpg");
         $thumb->adaptiveResize($_GET['w'], $_GET['h']);
         $thumb->show();
    }
    catch (Exception $e){
        var_dump($e);
    }
}else{

	if(strpos($fileName,"/") !== FALSE){
		$path = explode("/",$fileName);
		$fileName = $path[count($path)-1];
	}
	
	$fileName = DIR_FS_PROD.$fileName;
//var_dump($fileName);
if ( !file_exists($fileName)){
     // handle missing images however you want... perhaps show a default image??  Up to you...
   
    try{
         $thumb = PhpThumbFactory::create("no-img.jpg");
         $thumb->adaptiveResize($_GET['w'], $_GET['h']);
         $thumb->show();
    }
    catch (Exception $e){
         // handle error here however you'd like
        var_dump($e);
    }
}else{


	//$cacheDIR = '/home/mariai/public_html/lib/thumb/cache/';
	$cacheDIR = DIR_FS_CACHE;
	//$nome = $cacheDIR.basename($fileName)."-".$_GET['w']."-".$_GET['h'].".jpg";
	$nome = $cacheDIR.basename($fileName)."-".$_GET['w']."-".$_GET['h']."-".$badges.".jpg";
	//-- já tem cache?
	if(file_exists($nome)){
		
		header("Content-length: ".filesize($nome));
		//header("Content-type: ".mime_content_type($nome));
		header("Content-type: image/jpeg");
		
		readfile($nome);
		
	}else{

		try{
			 $thumb = PhpThumbFactory::create($fileName);
			 $thumb->adaptiveResize($_GET['w'], $_GET['h']);
			 $thumb->save($nome,'jpg');
			 $thumb->show();
		}
		catch (Exception $e){
			 // handle error here however you'd like
			var_dump($e);
		}
	
	}
}

}
?>
