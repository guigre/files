<?php
if(!isset($_GET['w'])) $_GET['w'] = 400;
if(!isset($_GET['h'])) $_GET['h'] = 400;

require_once 'ThumbLib.inc.php';
$fileName = (isset($_GET['file'])) ? urldecode($_GET['file']) : null;

if ($fileName === null || !file_exists($fileName)){
     // handle missing images however you want... perhaps show a default image??  Up to you...
    try{
         $thumb = PhpThumbFactory::create("no-img.png");
         $thumb->adaptiveResize($_GET['w'], $_GET['h']);
         //$thumb-> createReflection(40, 40, 80, false, '#a4a4a4');
         $thumb->show();
    }
    catch (Exception $e){
         // handle error here however you'd like
        var_dump($e);
    }
}else{
    try{
         $thumb = PhpThumbFactory::create($fileName);
         $thumb->adaptiveResize($_GET['w'], $_GET['h']);
         //$thumb-> createReflection(40, 40, 80, false, '#a4a4a4');
         $thumb->show();
    }
    catch (Exception $e){
         // handle error here however you'd like
        var_dump($e);
    }
}
?>
